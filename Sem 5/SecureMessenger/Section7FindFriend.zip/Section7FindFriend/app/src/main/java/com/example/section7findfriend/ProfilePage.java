package com.example.section7findfriend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.section7findfriend.userAuthentication.LoginPage;
import com.google.firebase.auth.FirebaseAuth;

public class ProfilePage extends AppCompatActivity {

    Button btnLogOff;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        btnLogOff=findViewById(R.id.btnLogoff);

        btnLogOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LogOff();
            }
        });
    }

   private void LogOff()
   {

         FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(ProfilePage.this, LoginPage.class);

        //To make sure user cant go  back

       intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

       startActivity(intent);

   }

}