import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV || "development",
  tracesSampleRate: process.env.NODE_ENV === "production" ? 0.1 : 1.0,
  // Don't send errors in development
  enabled: process.env.NODE_ENV === "production",
  ignoreErrors: [
    // Expected auth errors — don't pollute Sentry
    "Invalid token",
    "Not authenticated",
    "Too many login attempts",
  ],
});
