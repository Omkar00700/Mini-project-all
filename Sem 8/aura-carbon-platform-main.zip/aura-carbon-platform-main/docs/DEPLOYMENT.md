# Deployment Guide

## Overview

This guide covers deployment strategies and configurations for the Aura Platform across different environments.

## Environments

### Development

- **URL**: http://localhost:3000
- **Purpose**: Local development and testing
- **Database**: Local PostgreSQL instance
- **Features**: Hot reloading, debug mode, development tools

### Staging

- **URL**: https://staging.auraplatform.com
- **Purpose**: Pre-production testing and QA
- **Database**: Staging PostgreSQL instance
- **Features**: Production-like environment, testing data

### Production

- **URL**: https://auraplatform.com
- **Purpose**: Live application for end users
- **Database**: Production PostgreSQL cluster
- **Features**: High availability, monitoring, backups

## Deployment Platforms

### Vercel (Recommended for Frontend)

#### Setup

1. **Connect Repository**

   ```bash
   # Install Vercel CLI
   npm i -g vercel

   # Login and setup
   vercel login
   vercel --prod
   ```

2. **Environment Variables**
   Configure in Vercel dashboard or via CLI:

   ```bash
   vercel env add NEXT_PUBLIC_SUPABASE_URL
   vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
   vercel env add DATABASE_URL
   ```

3. **Build Configuration**
   ```json
   {
     "buildCommand": "npm run build",
     "outputDirectory": ".next",
     "installCommand": "npm install",
     "framework": "nextjs"
   }
   ```

#### Automatic Deployments

- **Production**: Deploys from `main` branch
- **Preview**: Deploys from feature branches
- **Environment**: Automatic environment detection

### AWS (Enterprise Deployment)

#### Infrastructure as Code

```yaml
# docker-compose.yml
version: "3.8"
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=${DATABASE_URL}
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=aura_platform
      - POSTGRES_USER=${DB_USER}
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

#### Kubernetes Deployment

```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aura-platform
spec:
  replicas: 3
  selector:
    matchLabels:
      app: aura-platform
  template:
    metadata:
      labels:
        app: aura-platform
    spec:
      containers:
        - name: app
          image: aura-platform:latest
          ports:
            - containerPort: 3000
          env:
            - name: NODE_ENV
              value: "production"
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: app-secrets
                  key: database-url
```

## CI/CD Pipeline

### GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: "18"
          cache: "npm"

      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npm run test
      - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3
      - uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
          vercel-args: "--prod"
```

## Environment Configuration

### Environment Variables

#### Required for All Environments

```env
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://auraplatform.com
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=https://auraplatform.com
```

#### Database Configuration

```env
DATABASE_URL=postgresql://user:password@host:5432/database
DIRECT_URL=postgresql://user:password@host:5432/database
```

#### External Services

```env
# Authentication
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-supabase-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Payment Processing
STRIPE_SECRET_KEY=your-stripe-secret
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your-stripe-public

# Email Services
SENDGRID_API_KEY=your-sendgrid-key
SENDGRID_FROM_EMAIL=noreply@auraplatform.com

# Monitoring
DATADOG_API_KEY=your-datadog-key
SENTRY_DSN=your-sentry-dsn
```

### Security Configuration

#### Headers

```javascript
// next.config.mjs
const securityHeaders = [
  {
    key: "X-DNS-Prefetch-Control",
    value: "on",
  },
  {
    key: "Strict-Transport-Security",
    value: "max-age=63072000; includeSubDomains; preload",
  },
  {
    key: "X-XSS-Protection",
    value: "1; mode=block",
  },
  {
    key: "X-Frame-Options",
    value: "SAMEORIGIN",
  },
  {
    key: "X-Content-Type-Options",
    value: "nosniff",
  },
  {
    key: "Referrer-Policy",
    value: "origin-when-cross-origin",
  },
];
```

## Database Deployment

### Migrations

```bash
# Run database migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate

# Seed database (if needed)
npx prisma db seed
```

### Backup Strategy

```bash
# Automated daily backups
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql

# Restore from backup
psql $DATABASE_URL < backup_20240101.sql
```

## Monitoring and Logging

### Health Checks

```javascript
// pages/api/health.js
export default function handler(req, res) {
  res.status(200).json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version,
  });
}
```

### Performance Monitoring

- **Core Web Vitals**: Automated monitoring
- **Error Tracking**: Sentry integration
- **Analytics**: Custom analytics dashboard
- **Uptime Monitoring**: External service monitoring

### Logging Configuration

```javascript
// lib/logger.js
import winston from "winston";

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: "error.log", level: "error" }),
    new winston.transports.File({ filename: "combined.log" }),
  ],
});
```

## Rollback Strategy

### Automated Rollback

```bash
# Vercel rollback to previous deployment
vercel rollback

# Kubernetes rollback
kubectl rollout undo deployment/aura-platform
```

### Manual Rollback

1. Identify stable version
2. Deploy previous version
3. Verify functionality
4. Update DNS if needed
5. Monitor for issues

## Performance Optimization

### Build Optimization

```javascript
// next.config.mjs
const nextConfig = {
  experimental: {
    optimizePackageImports: ["lucide-react"],
  },
  compiler: {
    removeConsole: process.env.NODE_ENV === "production",
  },
  images: {
    formats: ["image/webp", "image/avif"],
  },
};
```

### CDN Configuration

- **Static Assets**: Serve via CDN
- **Image Optimization**: Next.js Image component
- **Caching Strategy**: Aggressive caching for static content

## Troubleshooting

### Common Deployment Issues

1. **Build Failures**
   - Check environment variables
   - Verify dependencies
   - Review build logs

2. **Runtime Errors**
   - Check application logs
   - Verify database connectivity
   - Validate external service connections

3. **Performance Issues**
   - Monitor resource usage
   - Check database queries
   - Review caching strategy

### Emergency Procedures

1. **Service Outage**
   - Enable maintenance mode
   - Investigate root cause
   - Implement hotfix or rollback
   - Communicate with users

2. **Data Issues**
   - Stop write operations
   - Assess data integrity
   - Restore from backup if needed
   - Validate data consistency

## Security Checklist

- [ ] Environment variables secured
- [ ] HTTPS enforced
- [ ] Security headers configured
- [ ] Database access restricted
- [ ] API rate limiting enabled
- [ ] Error messages sanitized
- [ ] Dependencies updated
- [ ] Security scanning enabled

## Post-Deployment

### Verification Steps

1. Health check endpoints
2. Critical user journeys
3. Performance metrics
4. Error rates
5. Database connectivity
6. External service integrations

### Monitoring Setup

1. Configure alerts
2. Set up dashboards
3. Enable error tracking
4. Monitor performance metrics
5. Set up log aggregation
