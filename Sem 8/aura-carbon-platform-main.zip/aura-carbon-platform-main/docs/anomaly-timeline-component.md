# Anomaly Timeline UI Component

## Overview

A React component that displays detected anomalies in a visual timeline format with severity indicators, category icons, and acknowledgment functionality.

## Component Location

- **Main Component**: [`src/components/analytics/AnomalyTimeline.tsx`](file:///d:/Aura_Carbon_MP/aura-platform/src/components/analytics/AnomalyTimeline.tsx)
- **Demo Page**: [`src/app/analytics/anomalies/page.tsx`](file:///d:/Aura_Carbon_MP/aura-platform/src/app/analytics/anomalies/page.tsx)
- **Export Index**: [`src/components/analytics/index.ts`](file:///d:/Aura_Carbon_MP/aura-platform/src/components/analytics/index.ts)

## Features

### 1. Timeline View

- Anomalies grouped by date
- Chronological ordering (newest first)
- Visual timeline with connecting lines
- Timeline dot indicators

### 2. Severity Indicators

- **Color-Coded Cards**:
  - **High Severity**: Red background (`bg-red-100 text-red-800 border-red-300`)
  - **Medium Severity**: Amber background (`bg-amber-100 text-amber-800 border-amber-300`)
  - **Low Severity**: Blue background (`bg-blue-100 text-blue-800 border-blue-300`)
- **Severity Badges**: Colored badges using UI component variants
  - High → `destructive` variant
  - Medium → `default` variant
  - Low → `secondary` variant

### 3. Category Icons

- **Energy/Electricity**: ⚡ Zap icon
- **Transportation/Vehicle**: 🚗 Car icon
- **Food**: 🍽️ Utensils icon
- **Waste**: 🗑️ Trash icon
- **Water**: 💧 Droplet icon

### 4. Data Display

Each anomaly card shows:

- **Date**: When the anomaly occurred
- **Category**: Type of emission (with icon)
- **Expected Value**: Baseline CO₂ emissions
- **Actual Value**: Measured CO₂ emissions
- **Percent Change**: `+/- X%` from expected
- **Deviation**: Statistical deviation (σ)
- **Trend Arrow**: ↗️ (increase) or ↘️ (decrease)

### 5. Acknowledgment System

- **Acknowledge Button**: Allows users to mark anomalies as reviewed
- **Visual Feedback**: Acknowledged anomalies show:
  - Green checkmark badge
  - Reduced opacity (60%)
- **API Integration**: PATCH request to `/api/analytics/anomalies`
- **State Management**: Updates local state immediately for responsive UX

### 6. Filtering

- **Unacknowledged Filter**: Toggle button to show only unreviewed anomalies
- **Extensible**: Structure supports additional filters (category, severity, date range)

### 7. Empty States

- **No Anomalies**: Shows encouraging message with green checkmark
- **Loading State**: Displays loading indicator
- **Error State**: Shows error alert with details

## Usage

### Basic Usage

```tsx
import { AnomalyTimeline } from "@/components/analytics";

export default function AnomaliesPage() {
  const userId = "user-id-here";

  return <AnomalyTimeline userId={userId} />;
}
```

### With Custom Styling

```tsx
<AnomalyTimeline userId={userId} className="max-w-4xl mx-auto" />
```

## API Integration

The component fetches data from:

- **GET** `/api/analytics/anomalies?userId={id}` - Retrieve anomalies
- **PATCH** `/api/analytics/anomalies?anomalyId={id}` - Acknowledge anomaly

### Query Parameters (GET)

- `userId` (required): User ID to fetch anomalies for
- `severity` (optional): Filter by severity (low, medium, high)
- `category` (optional): Filter by category
- `acknowledged` (optional): Filter by acknowledgment status

## Component Architecture

```
AnomalyTimeline (Parent Component)
├── State Management
│   ├── anomalies: Anomaly[]
│   ├── loading: boolean
│   ├── error: string | null
│   └── filter: FilterOptions
├── API Integration
│   ├── fetchAnomalies() - useEffect
│   └── handleAcknowledge() - Event handler
└── Rendering
    ├── Card Header (title, description, filters)
    ├── Empty/Loading/Error States
    └── Timeline (grouped by date)
        └── AnomalyCard[] (individual anomalies)

AnomalyCard (Child Component)
├── Visual Elements
│   ├── Timeline dot indicator
│   ├── Category icon
│   ├── Severity badge
│   └── Acknowledged badge (if applicable)
├── Data Display
│   ├── Expected vs Actual values
│   ├── Percentage change
│   ├── Deviation (σ)
│   └── Trend arrow
└── Actions
    └── Acknowledge button
```

## Styling

### Tailwind Classes Used

- **Card Backgrounds**: Severity-based color coding
- **Typography**: Font weights, sizes, colors
- **Spacing**: Consistent padding and margins
- **Borders**: Rounded corners, border colors
- **Hover Effects**: `hover:shadow-md`, `hover:bg-*-50`
- **Transitions**: Smooth animations on state changes
- **Responsive**: Grid layouts adapt to screen size

### Design Tokens

- Uses shadcn/ui components: Card, Badge, Button, Alert
- Consistent with existing dashboard components
- Follows project's design system

## Demo Page

Access the component at: **`http://localhost:3000/analytics/anomalies`**

The demo page includes:

- Page title and description
- Full-width AnomalyTimeline component
- Demo user ID pre-configured
- Responsive container with max-width

## Testing

### Manual Testing Steps

1. **Start dev server**: `npm run dev`
2. **Navigate to**: `http://localhost:3000/analytics/anomalies`
3. **Verify display**: Check anomalies are shown in timeline
4. **Test acknowledgment**: Click "Acknowledge" button
5. **Test filtering**: Click "Unacknowledged" filter button
6. **Check responsiveness**: Resize browser window

### Expected Results

- 9 anomalies displayed (from seed data)
- Grouped by date
- Color-coded by severity (5 high, 1 medium, 3 low)
- Acknowledge buttons functional
- Filter toggles correctly
- Responsive layout

## TypeScript Interface

```typescript
export interface Anomaly {
  id: string;
  date: Date | string;
  category: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: "low" | "medium" | "high";
  acknowledged: boolean;
}
```

## Performance Considerations

- **API Calls**: Uses useEffect with dependency array to prevent unnecessary re-fetches
- **State Updates**: Optimistic UI updates for acknowledgments
- **Rendering**: Anomalies grouped by date to reduce re-renders
- **Memoization**: Could add useMemo for grouped anomalies if performance issues arise

## Accessibility

- **Semantic HTML**: Uses proper heading hierarchy
- **ARIA Attributes**: Buttons have descriptive labels
- **Keyboard Navigation**: All interactive elements focusable
- **Color Contrast**: Severity colors meet WCAG standards
- **Screen Reader**: Icon labels and descriptive text

## Future Enhancements

1. **Advanced Filtering**:
   - Date range picker
   - Multi-select category filter
   - Severity threshold slider

2. **Sorting Options**:
   - Sort by deviation (highest first)
   - Sort by date (oldest/newest)
   - Sort by category

3. **Bulk Actions**:
   - "Acknowledge All" button
   - Multi-select checkboxes

4. **Data Visualization**:
   - Mini charts showing emission trends
   - Sparklines for each category
   - Visual deviation indicators

5. **Export Functionality**:
   - Download anomalies as CSV
   - Print view
   - Share anomaly report

6. **Notifications**:
   - Real-time updates via WebSocket
   - Toast notifications for new anomalies
   - Email digest of high-severity anomalies

---

**Created**: January 29, 2026  
**Status**: ✅ Complete  
**Lines of Code**: 333  
**Dependencies**: shadcn/ui, lucide-react, Tailwind CSS
