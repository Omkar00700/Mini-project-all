# Daily Anomaly Detection Cron Job

## Overview

This background job runs daily to automatically detect anomalies in user activity data.

## Files

- **Job Logic**: `src/jobs/daily-anomaly-detection.ts`
- **API Trigger**: `src/app/api/cron/daily-anomaly-detection/route.ts`

## Usage

### Manual Execution (CLI)

```bash
npx tsx src/jobs/daily-anomaly-detection.ts
```

### API Trigger (POST)

```bash
# Using curl
curl -X POST http://localhost:3000/api/cron/daily-anomaly-detection \
  -H "Authorization: Bearer dev-secret-change-in-production"

# Using PowerShell
Invoke-WebRequest -Uri "http://localhost:3000/api/cron/daily-anomaly-detection" `
  -Method POST `
  -Headers @{"Authorization"="Bearer dev-secret-change-in-production"}
```

### Scheduling Options

#### Option 1: External Cron Service (Recommended for Production)

Use services like:

- **Vercel Cron** (if deploying to Vercel)
- **GitHub Actions** with scheduled workflows
- **cron-job.org** or similar external services

Configure to POST to `/api/cron/daily-anomaly-detection` daily.

#### Option 2: Node-cron (For Self-hosted)

Install `node-cron`:

```bash
npm install node-cron @types/node-cron
```

Create `src/jobs/scheduler.ts`:

```typescript
import cron from "node-cron";
import { runDailyAnomalyDetection } from "./daily-anomaly-detection";

// Run daily at 2 AM
cron.schedule("0 2 * * *", async () => {
  console.log("Running scheduled anomaly detection...");
  await runDailyAnomalyDetection();
});

console.log("Cron scheduler started");
```

## Environment Variables

- `CRON_SECRET`: Secret token for API authentication (default: `dev-secret-change-in-production`)

## Output

The job logs:

- Number of users processed
- Total anomalies detected
- Total anomalies saved (new ones only)
- Execution duration
- Any errors encountered

Example output:

```
[Cron] Starting daily anomaly detection...
[Cron] Processing 3 users
[Cron] ✅ demo@aura.com: 12 detected, 0 saved
[Cron] Daily anomaly detection completed
[Cron] Stats: 12 detected, 0 saved
[Cron] Users: 3 success, 0 errors
[Cron] Duration: 0.24s
```

## Testing

Tested manually on 2026-01-27:

- ✅ Processed 3 users successfully
- ✅ Detected 12 anomalies (no new saves due to duplicates)
- ✅ Completed in 0.24s
- ✅ Error handling working correctly
