# Development Guide

## Getting Started

This guide covers the development setup and workflow for the Aura Platform.

### Prerequisites

- Node.js 18+ (LTS recommended)
- npm or yarn package manager
- Git
- VS Code (recommended) with extensions:
  - ESLint
  - Prettier
  - Tailwind CSS IntelliSense
  - TypeScript Importer

### Development Workflow

1. **Start Development Server**

   ```bash
   npm run dev
   ```

2. **Code Quality Checks**

   ```bash
   npm run lint          # Check for linting issues
   npm run type-check    # TypeScript type checking
   npm run format:check  # Check code formatting
   ```

3. **Fix Issues**
   ```bash
   npm run lint:fix      # Auto-fix linting issues
   npm run format        # Auto-format code
   ```

### Project Structure

```
src/
├── app/                    # Next.js App Router
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Home page
├── components/            # React components
│   ├── ui/               # shadcn/ui components
│   └── theme-provider.tsx # Theme provider
├── lib/                  # Utility libraries
│   └── utils.ts          # Common utilities
├── hooks/                # Custom React hooks
├── services/             # API services
├── store/                # State management
├── types/                # TypeScript types
└── utils/                # Helper functions
```

### Coding Standards

#### TypeScript

- Use strict TypeScript configuration
- Define interfaces for all data structures
- Use proper type annotations
- Avoid `any` type when possible

#### React

- Use functional components with hooks
- Follow React best practices
- Use proper component composition
- Implement proper error boundaries

#### Styling

- Use Tailwind CSS utility classes
- Follow the design system color palette
- Use CSS custom properties for theming
- Implement responsive design patterns

#### Git Workflow

- Use conventional commit messages
- Create feature branches for new work
- Run pre-commit hooks (automatic)
- Keep commits focused and atomic

### Environment Configuration

#### Development Environment

```env
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

#### Required Environment Variables

See `.env.example` for the complete list of required environment variables.

### Testing (Planned)

#### Unit Tests

```bash
npm run test              # Run unit tests
npm run test:watch        # Run tests in watch mode
npm run test:coverage     # Generate coverage report
```

#### E2E Tests

```bash
npm run test:e2e          # Run end-to-end tests
npm run test:e2e:ui       # Run E2E tests with UI
```

### Performance

#### Bundle Analysis

```bash
npm run analyze           # Analyze bundle size
```

#### Performance Monitoring

- Use Next.js built-in performance metrics
- Monitor Core Web Vitals
- Implement performance budgets

### Deployment

#### Build for Production

```bash
npm run build             # Create production build
npm run start             # Start production server
```

#### Environment-Specific Builds

```bash
npm run build:staging     # Build for staging
npm run build:production  # Build for production
```

### Troubleshooting

#### Common Issues

1. **TypeScript Errors**
   - Run `npm run type-check` to identify issues
   - Check import paths and type definitions

2. **Linting Errors**
   - Run `npm run lint:fix` to auto-fix issues
   - Check ESLint configuration

3. **Build Failures**
   - Clear `.next` directory
   - Delete `node_modules` and reinstall
   - Check environment variables

4. **Styling Issues**
   - Verify Tailwind CSS configuration
   - Check CSS custom properties
   - Validate component class names

### VS Code Configuration

Recommended `.vscode/settings.json`:

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "typescript.preferences.importModuleSpecifier": "relative",
  "tailwindCSS.experimental.classRegex": [["cn\\(([^)]*)\\)", "'([^']*)'"]]
}
```

### Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [shadcn/ui Documentation](https://ui.shadcn.com)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)
