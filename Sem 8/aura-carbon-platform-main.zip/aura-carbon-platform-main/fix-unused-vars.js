const fs = require("fs");
const path = require("path");

// Files and their unused variables to prefix with underscore
const fixes = [
  // API routes
  {
    file: "src/app/api/carbon/emission-factors/route.ts",
    vars: ["user", "request"],
  },
  {
    file: "src/app/api/carbon/transportation/distance/route.ts",
    vars: ["user"],
  },
  { file: "src/app/api/carbon/transportation/route.ts", vars: ["user"] },
  {
    file: "src/app/api/analytics/forecasts/route.ts",
    vars: ["months", "model"],
  },

  // Components
  { file: "src/components/3d/particles.tsx", vars: ["i"] },
  { file: "src/components/dashboard/dashboard-widget.tsx", vars: ["id"] },
  { file: "src/components/dashboard/QuickAddActivity.tsx", vars: ["userId"] },
  {
    file: "src/components/dashboard/streak-card.tsx",
    vars: ["lastMaintained"],
  },
  {
    file: "src/components/dashboard/OnboardingChecklist.tsx",
    vars: ["userId"],
  },
  { file: "src/components/dashboard/activity-log-tab.tsx", vars: ["index"] },
  {
    file: "src/components/forms/form-fields.tsx",
    vars: ["name", "addButtonText"],
  },
  {
    file: "src/components/forms/carbon-wizard/carbon-footprint-wizard.tsx",
    vars: ["data", "updateData"],
  },
  {
    file: "src/components/forms/carbon-wizard/energy-step.tsx",
    vars: ["errors"],
  },
  {
    file: "src/components/forms/carbon-wizard/transportation-step.tsx",
    vars: ["errors"],
  },

  // Services
  {
    file: "src/services/carbon-orchestrator.ts",
    vars: ["context", "categoryResults", "result"],
  },
  { file: "src/services/emission-factors.ts", vars: ["fuelType"] },
  {
    file: "src/services/gamification/achievement.service.ts",
    vars: ["metadata"],
  },
  {
    file: "src/services/notifications/notification.service.ts",
    vars: ["userId", "limit", "notificationId"],
  },
  { file: "src/services/user.ts", vars: ["userId", "action", "data"] },

  // Contexts
  { file: "src/contexts/auth-context-simple.tsx", vars: ["provider"] },

  // Hooks
  { file: "src/hooks/use-optimistic-updates.ts", vars: ["variables"] },

  // Store
  { file: "src/store/ui-store.ts", vars: ["get"] },
];

console.log("Fixing unused variables by prefixing with underscore...\n");

fixes.forEach(({ file, vars }) => {
  try {
    const filePath = path.join(process.cwd(), file);
    if (!fs.existsSync(filePath)) {
      console.log(`⚠ Skipping ${file} - file not found`);
      return;
    }

    let content = fs.readFileSync(filePath, "utf8");
    let modified = false;

    vars.forEach((varName) => {
      // Pattern to match parameter declarations
      const patterns = [
        // Function parameters: (varName: type)
        new RegExp(`\\(([^)]*\\b)${varName}(\\s*:\\s*[^,)]+)`, "g"),
        // Arrow function parameters: varName =>
        new RegExp(`\\b${varName}\\s*=>`, "g"),
        // Destructured parameters: { varName }
        new RegExp(`\\{([^}]*\\b)${varName}(\\s*[,}])`, "g"),
        // Variable declarations: const varName =
        new RegExp(`\\b(const|let|var)\\s+${varName}\\s*=`, "g"),
      ];

      patterns.forEach((pattern) => {
        if (pattern.test(content)) {
          content = content.replace(pattern, (match) => {
            return match.replace(new RegExp(`\\b${varName}\\b`), `_${varName}`);
          });
          modified = true;
        }
      });
    });

    if (modified) {
      fs.writeFileSync(filePath, content, "utf8");
      console.log(`✓ Fixed ${file}`);
    } else {
      console.log(`- No changes needed for ${file}`);
    }
  } catch (error) {
    console.error(`✗ Error fixing ${file}:`, error.message);
  }
});

console.log("\nDone!");
