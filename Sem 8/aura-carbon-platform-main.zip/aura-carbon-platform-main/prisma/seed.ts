import { PrismaClient } from "../generated/prisma";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const salt = await bcrypt.genSalt(10);
  const demoPassword = await bcrypt.hash("demo123", salt);
  // Demo User removed - only real users from database should appear in leaderboard
  // Create a regular user for seeding instead
  const demoUser = await prisma.user.upsert({
    where: { email: "seeded@aura.com" },
    update: {},
    create: {
      email: "seeded@aura.com",
      name: "Seeded User",
      passwordHash: demoPassword,
      location: {
        country: "India",
        region: "Maharashtra",
        city: "Mumbai",
      },
      household: {
        size: 3,
        type: "family",
      },
      preferences: {
        units: "metric",
        privacy_level: "private",
        notifications: {
          email: true,
          push: true,
          weekly_reports: true,
        },
      },
      subscription: {
        tier: "premium",
        features: ["advanced_analytics", "ai_predictions"],
      },
    },
  });

  // Removed hardcoded John Doe and Jane Smith users

  const emissionFactorsPath = path.join(
    process.cwd(),
    "data",
    "emission_factors_india.json"
  );
  const emissionFactorsData = JSON.parse(
    fs.readFileSync(emissionFactorsPath, "utf8")
  );

  for (const factor of emissionFactorsData) {
    const existing = await prisma.emissionFactor.findUnique({
      where: {
        category_subcategory_region: {
          category: factor.category,
          subcategory: factor.subcategory,
          region: factor.region,
        },
      },
    });

    const validFrom = new Date("2024-01-01");
    const validTo = new Date("2030-12-31");

    const factorData = {
      category: factor.category,
      subcategory: factor.subcategory,
      region: factor.region,
      value: factor.co2_per_unit,
      unit: factor.unit,
      source: factor.source,
      confidenceLevel: 0.9,
      validFrom,
      validTo,
    };

    if (existing) {
      await prisma.emissionFactor.update({
        where: {
          id: existing.id,
        },
        data: factorData,
      });
    } else {
      await prisma.emissionFactor.create({
        data: factorData,
      });
    }
  }

  const now = new Date();
  const activityDataList = [];

  for (let daysAgo = 89; daysAgo >= 0; daysAgo--) {
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);
    date.setHours(12, 0, 0, 0);

    const dayOfWeek = date.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    let electricityBase = isWeekend ? 11 : 9;
    let electricity = electricityBase + (Math.random() - 0.5) * 3;

    if (daysAgo === 45 || daysAgo === 67) {
      electricity = 25 + Math.random() * 3;
    }

    if (daysAgo === 30) {
      electricity = 2 + Math.random();
    }

    activityDataList.push({
      userId: demoUser.id,
      category: "energy",
      subcategory: "electricity",
      value: Math.round(electricity * 100) / 100,
      unit: "kWh",
      date: new Date(date),
      source: "api",
      metadata: {
        billing_period: "daily",
        meter_reading: true,
      },
    });

    let petrol = 0;

    if (!isWeekend) {
      petrol = 3 + (Math.random() - 0.5) * 1.5;
    } else {
      petrol = 0.5 + Math.random() * 1.5;
    }

    if (daysAgo >= 20 && daysAgo <= 22) {
      petrol = 15 + Math.random() * 5;
    }

    if (daysAgo >= 50 && daysAgo <= 54) {
      petrol = 0.3 + Math.random() * 0.3;
    }

    activityDataList.push({
      userId: demoUser.id,
      category: "transportation",
      subcategory: "personal_vehicle_gasoline",
      value: Math.round(petrol * 100) / 100,
      unit: "liter",
      date: new Date(date),
      source: "manual",
      metadata: {
        vehicle_type: "sedan",
        distance_km: Math.round(petrol * 12),
      },
    });

    let food = isWeekend
      ? 5 + Math.random() * 2
      : 3.5 + (Math.random() - 0.5) * 2;

    if (daysAgo === 15 || daysAgo === 60) {
      food = 12 + Math.random() * 3;
    }

    if (daysAgo >= 35 && daysAgo <= 38) {
      food = 2 + Math.random();
    }

    activityDataList.push({
      userId: demoUser.id,
      category: "food",
      subcategory: "groceries",
      value: Math.round(food * 100) / 100,
      unit: "kg",
      date: new Date(date),
      source: "manual",
      metadata: {
        food_type: "mixed",
        organic_percentage: 0.2 + Math.random() * 0.3,
      },
    });

    let waste = isWeekend
      ? 1.8 + Math.random() * 0.5
      : 1.2 + Math.random() * 0.6;

    if (daysAgo >= 70 && daysAgo <= 72) {
      waste = 8 + Math.random() * 3;
    }

    activityDataList.push({
      userId: demoUser.id,
      category: "waste",
      subcategory: "municipal_solid_waste",
      value: Math.round(waste * 100) / 100,
      unit: "kg",
      date: new Date(date),
      source: "estimated",
      metadata: {
        recycling_percentage: 0.3 + Math.random() * 0.2,
      },
    });
  }

  for (const activity of activityDataList) {
    await prisma.activityData.create({
      data: activity,
    });
  }

  // Removed other user activities for hardcoded users

  const currentTime = new Date();
  const currentYear = currentTime.getFullYear();
  const currentMonth = currentTime.getMonth();
  const historicalCalculations = [];

  for (let i = 5; i >= 0; i--) {
    let targetYear = currentYear;
    let targetMonth = currentMonth - i;

    while (targetMonth < 0) {
      targetMonth += 12;
      targetYear -= 1;
    }

    const monthStart = new Date(Date.UTC(targetYear, targetMonth, 1, 12, 0, 0));
    const monthEnd = new Date(
      Date.UTC(targetYear, targetMonth + 1, 0, 12, 0, 0)
    );

    const baseEmissions = 350;
    const trendReduction = i * 5;
    const randomVariation = (Math.random() - 0.5) * 40;
    const totalEmissions = baseEmissions - trendReduction + randomVariation;

    historicalCalculations.push({
      id: `calc_demo_${i}`,
      userId: demoUser.id,
      periodStart: monthStart,
      periodEnd: monthEnd,
      totalEmissions: Math.round(totalEmissions * 100) / 100,
      breakdown: {
        transportation: Math.round(totalEmissions * 0.35 * 100) / 100,
        energy: Math.round(totalEmissions * 0.3 * 100) / 100,
        food: Math.round(totalEmissions * 0.25 * 100) / 100,
        consumption: Math.round(totalEmissions * 0.1 * 100) / 100,
      },
      confidenceScore: 0.85 + Math.random() * 0.1,
      metadata: {
        calculation_method: "ghg_protocol",
        emission_factors_version: "2024.1",
        data_completeness: 0.9,
      },
    });
  }

  for (const calc of historicalCalculations) {
    await prisma.carbonCalculation.upsert({
      where: { id: calc.id },
      update: {},
      create: calc,
    });
  }

  // Removed hardcoded carbon calculation for user1
}

main()
  .catch((e) => {
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
