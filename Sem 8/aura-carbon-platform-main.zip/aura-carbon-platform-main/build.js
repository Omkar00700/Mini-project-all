#!/usr/bin/env node
const { execSync } = require("child_process");
const path = require("path");

// Set working directory to project root
process.chdir(__dirname);

// Set environment to restrict file system access
process.env.INIT_CWD = __dirname;
process.env.PWD = __dirname;

try {
  console.log("Generating Prisma Client...");
  execSync("npx prisma generate", {
    stdio: "inherit",
    cwd: __dirname,
    env: {
      ...process.env,
      INIT_CWD: __dirname,
      PWD: __dirname,
    },
  });

  console.log("Running Next.js Build...");
  execSync("next build", {
    stdio: "inherit",
    cwd: __dirname,
    env: {
      ...process.env,
      INIT_CWD: __dirname,
      PWD: __dirname,
    },
  });
} catch (error) {
  process.exit(error.status || 1);
}
