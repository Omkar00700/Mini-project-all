const apiKey = "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";

async function run() {
  const badMessages = [
    { role: "system", content: "You are helpful." },
    { role: "assistant", content: "Hi!" },
    { role: "user", content: "Hello" }
  ];

  const goodMessages = [
    { role: "system", content: "You are helpful." },
    { role: "user", content: "Hello" }
  ];

  console.log("Testing bad sequence (starts with assistant)...");
  let res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST", headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openrouter/free", messages: badMessages })
  });
  console.log("Bad Status:", res.status);
  console.log("Bad Response:", await res.text());

  console.log("\nTesting good sequence (starts with user)...");
  res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST", headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openrouter/free", messages: goodMessages })
  });
  console.log("Good Status:", res.status);
  console.log("Good Response:", (await res.text()).substring(0, 100));
}
run();
