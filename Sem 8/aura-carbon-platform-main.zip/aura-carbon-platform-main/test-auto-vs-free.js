const apiKey = "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";

async function run() {
  console.log("Testing openrouter/free ...");
  let res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST", headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openrouter/free", messages: [{role: "user", content: "Hi"}] })
  });
  console.log("Free Status:", res.status);
  console.log("Free Response:", (await res.text()).substring(0, 150));

  console.log("\nTesting openrouter/auto ...");
  res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST", headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: "openrouter/auto", messages: [{role: "user", content: "Hi"}] })
  });
  console.log("Auto Status:", res.status);
  console.log("Auto Response:", (await res.text()).substring(0, 300));
}
run();
