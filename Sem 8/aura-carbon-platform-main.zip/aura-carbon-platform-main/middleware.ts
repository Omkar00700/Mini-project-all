import { type NextRequest, NextResponse } from "next/server";
import * as jose from "jose";

// Basic Memory Rate Limiter for DDoS & Bot Protection
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const rateLimitStore = new Map<string, { count: number; timestamp: number }>();

function checkRateLimit(key: string, limit: number): boolean {
  const now = Date.now();
  const record = rateLimitStore.get(key);
  if (!record || now - record.timestamp > RATE_LIMIT_WINDOW) {
    rateLimitStore.set(key, { count: 1, timestamp: now });
    return true;
  }
  if (record.count >= limit) return false;
  record.count++;
  return true;
}

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET environment variable is not set.");
}
const secret = new TextEncoder().encode(JWT_SECRET);

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // All routes that require authentication
  const protectedRoutes = [
    "/dashboard",
    "/goals",
    "/profile",
    "/settings",
    "/calculator",
    "/achievements",
    "/leaderboard",
    "/recommendations",
    "/ai-chat",
    "/what-if",
    "/activities",
    "/impact",
    "/admin",
  ];

  // Auth routes — redirect to dashboard if already authenticated
  const authRoutes = ["/login", "/register"];

  const isProtectedRoute = protectedRoutes.some((route) =>
    pathname.startsWith(route)
  );
  const isAuthRoute = authRoutes.some((route) => pathname.startsWith(route));
  const ip =
    request.ip || request.headers.get("x-forwarded-for") || "127.0.0.1";

  // 1. API Rate Limiting
  if (pathname.startsWith("/api/auth/register")) {
    if (!checkRateLimit(`auth_${ip}`, 5)) {
      return NextResponse.json(
        { error: "Too many authentication attempts. Please try again later." },
        { status: 429 }
      );
    }
  }

  if (
    pathname.startsWith("/api/analytics/forecasts") ||
    pathname.startsWith("/api/calculate")
  ) {
    if (!checkRateLimit(`calc_${ip}`, 20)) {
      return NextResponse.json(
        { error: "Rate limit exceeded. Please wait." },
        { status: 429 }
      );
    }
  }

  // 2. JWT Authentication Verification using jose (Edge Compatible)
  const tokenValue = request.cookies.get("auth-token")?.value;
  let decodedToken: any = null;

  if (tokenValue) {
    try {
      const { payload } = await jose.jwtVerify(tokenValue, secret);
      decodedToken = payload;
    } catch (err) {
      // Token invalid or expired
    }
  }

  const isAuthenticated = !!decodedToken;

  // 3. Admin Route Protection
  if (pathname.startsWith("/admin")) {
    if (!isAuthenticated || decodedToken?.role !== "admin") {
      // Obfuscate via rewrite so attackers don't know the route exists
      return NextResponse.rewrite(new URL("/404", request.url));
    }
  }

  // 4. Auth Route Redirects
  if (isAuthRoute && isAuthenticated) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // 5. Protected Route Access Control
  if (isProtectedRoute && !isAuthenticated) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("from", pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
