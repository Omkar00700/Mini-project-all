import { db } from "@/lib/db";
import type {
  UserProfile,
  UpdateUserProfileData,
  UserProfileFormData,
  UserLocation,
  UserHousehold,
  UserPreferences,
  UserSubscription,
} from "@/types/user";

const prisma = db;

class UserService {
  async getUserProfile(userId: string): Promise<UserProfile | null> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
      });

      if (!user) {
        return null;
      }

      return {
        id: user.id,
        email: user.email,
        name: user.name,
        location: user.location as unknown as UserLocation,
        household: user.household as unknown as UserHousehold,
        preferences: user.preferences as unknown as UserPreferences,
        subscription: user.subscription as unknown as UserSubscription,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      };
    } catch (error) {
      throw new Error("Failed to fetch user profile");
    }
  }

  async updateUserProfile(
    userId: string,
    data: UpdateUserProfileData
  ): Promise<UserProfile> {
    try {
      const user = await prisma.user.update({
        where: { id: userId },
        data: {
          name: data.name,
          location: data.location,
          household: data.household,
          preferences: data.preferences
            ? JSON.parse(JSON.stringify(data.preferences))
            : undefined,
          updatedAt: new Date(),
        },
      });

      await this.createAuditLog(userId, "profile_update", {
        updatedFields: Object.keys(data),
        timestamp: new Date(),
      });

      return {
        id: user.id,
        email: user.email,
        name: user.name,
        location: user.location as unknown as UserLocation,
        household: user.household as unknown as UserHousehold,
        preferences: user.preferences as unknown as UserPreferences,
        subscription: user.subscription as unknown as UserSubscription,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      };
    } catch (error) {
      throw new Error("Failed to update user profile");
    }
  }

  async createUserProfile(
    formData: UserProfileFormData & { id: string; email: string }
  ): Promise<UserProfile> {
    try {
      const userData = {
        id: formData.id,
        email: formData.email,
        name: formData.name,
        location: {
          country: formData.country,
          region: formData.region,
          city: formData.city,
        },
        household: {
          size: formData.householdSize,
          type: formData.householdType,
          income_bracket: formData.incomeBracket,
        },
        preferences: {
          units: formData.units,
          privacy_level: formData.privacyLevel,
          notifications: formData.notifications,
          language: formData.language,
          timezone: formData.timezone,
          currency: formData.currency,
        },
        subscription: {
          tier: "free" as const,
          features: ["basic_tracking", "monthly_reports"],
        },
      };

      const user = await prisma.user.create({
        data: userData,
      });

      await this.createAuditLog(formData.id, "profile_creation", {
        timestamp: new Date(),
      });

      return {
        id: user.id,
        email: user.email,
        name: user.name,
        location: user.location as unknown as UserLocation,
        household: user.household as unknown as UserHousehold,
        preferences: user.preferences as unknown as UserPreferences,
        subscription: user.subscription as unknown as UserSubscription,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      };
    } catch (error) {
      throw new Error("Failed to create user profile");
    }
  }

  async deleteUserProfile(userId: string): Promise<void> {
    try {
      await this.createAuditLog(userId, "profile_deletion", { userId });

      await prisma.user.delete({
        where: { id: userId },
      });
    } catch (error) {
      throw new Error("Failed to delete user profile");
    }
  }

  private async createAuditLog(
    userId: string,
    action: string,
    data: Record<string, unknown>
  ): Promise<void> {
    try {
    } catch (error) {}
  }

  async getUsersByIds(userIds: string[]): Promise<UserProfile[]> {
    try {
      const users = await prisma.user.findMany({
        where: {
          id: {
            in: userIds,
          },
        },
      });

      return users.map((user) => ({
        id: user.id,
        email: user.email,
        name: user.name,
        location: user.location as unknown as UserLocation,
        household: user.household as unknown as UserHousehold,
        preferences: user.preferences as unknown as UserPreferences,
        subscription: user.subscription as unknown as UserSubscription,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      }));
    } catch (error) {
      throw new Error("Failed to fetch users");
    }
  }

  async searchUsers(query: string, limit: number = 10): Promise<UserProfile[]> {
    try {
      const users = await prisma.user.findMany({
        where: {
          OR: [{ name: { contains: query } }, { email: { contains: query } }],
        },
        take: limit,
      });

      return users.map((user) => ({
        id: user.id,
        email: user.email,
        name: user.name,
        location: user.location as unknown as UserLocation,
        household: user.household as unknown as UserHousehold,
        preferences: user.preferences as unknown as UserPreferences,
        subscription: user.subscription as unknown as UserSubscription,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      }));
    } catch (error) {
      throw new Error("Failed to search users");
    }
  }
}

export const userService = new UserService();
