import { db } from "@/lib/db";

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  read: boolean;
  createdAt: Date;
}

export type NotificationType =
  | "achievement_unlocked"
  | "goal_progress"
  | "goal_completed"
  | "goal_at_risk"
  | "anomaly_detected"
  | "weekly_report"
  | "monthly_report"
  | "recommendation"
  | "milestone"
  | "reminder"
  | "system";

export interface NotificationPreferences {
  achievements: boolean;
  goals: boolean;
  anomalies: boolean;
  reports: boolean;
  recommendations: boolean;
  reminders: boolean;
}

class NotificationService {
  async create(
    userId: string,
    type: NotificationType,
    title: string,
    message: string,
    data?: Record<string, unknown>
  ): Promise<Notification> {
    const notification: Notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId,
      type,
      title,
      message,
      data,
      read: false,
      createdAt: new Date(),
    };

    return notification;
  }

  async getUnread(userId: string): Promise<Notification[]> {
    return [];
  }

  async getAll(userId: string, limit: number = 50): Promise<Notification[]> {
    return [];
  }

  async markAsRead(notificationId: string): Promise<void> {}

  async markAllAsRead(userId: string): Promise<void> {}

  async notifyAchievement(
    userId: string,
    achievementName: string,
    achievementDescription: string
  ): Promise<void> {
    await this.create(
      userId,
      "achievement_unlocked",
      `🏆 Achievement Unlocked!`,
      `You've earned the "${achievementName}" badge! ${achievementDescription}`,
      { achievement: achievementName }
    );
  }

  async notifyGoalProgress(
    userId: string,
    goalName: string,
    progress: number
  ): Promise<void> {
    let message: string;

    if (progress >= 100) {
      message = `Congratulations! You've completed your goal: "${goalName}"`;
      await this.create(
        userId,
        "goal_completed",
        "🎉 Goal Completed!",
        message,
        {
          goal: goalName,
          progress,
        }
      );
    } else if (progress >= 75) {
      message = `You're ${progress}% towards your goal: "${goalName}". Almost there!`;
      await this.create(userId, "goal_progress", "🎯 Goal Update", message, {
        goal: goalName,
        progress,
      });
    } else if (progress >= 50) {
      message = `Halfway there! You're ${progress}% towards: "${goalName}"`;
      await this.create(userId, "goal_progress", "🎯 Goal Update", message, {
        goal: goalName,
        progress,
      });
    }
  }

  async notifyAnomaly(
    userId: string,
    category: string,
    severity: "low" | "medium" | "high",
    description: string
  ): Promise<void> {
    const emoji =
      severity === "high" ? "🚨" : severity === "medium" ? "⚠️" : "ℹ️";
    const title =
      severity === "high" ? "Unusual Activity Detected" : "Activity Insight";

    await this.create(
      userId,
      "anomaly_detected",
      `${emoji} ${title}`,
      description,
      { category, severity }
    );
  }

  async notifyWeeklyReport(
    userId: string,
    totalEmissions: number,
    changeFromLastWeek: number
  ): Promise<void> {
    const trend = changeFromLastWeek < 0 ? "decreased" : "increased";
    const emoji = changeFromLastWeek < 0 ? "📉" : "📈";

    await this.create(
      userId,
      "weekly_report",
      "📊 Weekly Carbon Report",
      `This week: ${totalEmissions.toFixed(1)} kg CO2. ${emoji} ${Math.abs(changeFromLastWeek).toFixed(1)}% ${trend} from last week.`,
      { totalEmissions, changeFromLastWeek }
    );
  }

  async notifyRecommendation(
    userId: string,
    category: string,
    tip: string,
    potentialSavings: number
  ): Promise<void> {
    await this.create(
      userId,
      "recommendation",
      "💡 Quick Tip",
      `${tip} Could save ${potentialSavings.toFixed(1)} kg CO2/year!`,
      { category, potentialSavings }
    );
  }

  async notifyMilestone(
    userId: string,
    milestone: string,
    description: string
  ): Promise<void> {
    await this.create(userId, "milestone", `🎉 ${milestone}`, description, {
      milestone,
    });
  }

  async sendReminder(
    userId: string,
    type: "log_activity" | "update_goal" | "check_progress"
  ): Promise<void> {
    const messages: Record<string, { title: string; message: string }> = {
      log_activity: {
        title: "📝 Activity Reminder",
        message:
          "Don't forget to log your activities! Keeping track helps improve your predictions.",
      },
      update_goal: {
        title: "🎯 Goal Check-in",
        message:
          "How's your carbon reduction goal going? Update your progress today.",
      },
      check_progress: {
        title: "📊 Weekly Check-in",
        message:
          "Your weekly carbon report is ready. See how you're doing this week!",
      },
    };

    const { title, message } = messages[type];
    await this.create(userId, "reminder", title, message, {
      reminderType: type,
    });
  }
}

export const notificationService = new NotificationService();
