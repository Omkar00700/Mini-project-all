import { z } from "zod";

export interface Location {
  latitude: number;
  longitude: number;
  address?: string;
  city?: string;
  country?: string;
}

export interface RouteOptions {
  mode: "driving" | "walking" | "bicycling" | "transit";
  avoidTolls?: boolean;
  avoidHighways?: boolean;
  avoidFerries?: boolean;
  optimize?: boolean;
}

export interface RouteResult {
  distance: number;
  duration: number;
  optimizedOrder?: number[];
  route: {
    legs: Array<{
      distance: number;
      duration: number;
      startLocation: Location;
      endLocation: Location;
    }>;
  };
  fuelEfficiencyFactor?: number;
}

export interface DistanceMatrix {
  origins: Location[];
  destinations: Location[];
  distances: number[][];
  durations: number[][];
}

class DistanceCalculator {
  private readonly EARTH_RADIUS_KM = 6371;
  private readonly GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

  calculateHaversineDistance(point1: Location, point2: Location): number {
    const lat1Rad = this.toRadians(point1.latitude);
    const lat2Rad = this.toRadians(point2.latitude);
    const deltaLatRad = this.toRadians(point2.latitude - point1.latitude);
    const deltaLonRad = this.toRadians(point2.longitude - point1.longitude);

    const a =
      Math.sin(deltaLatRad / 2) * Math.sin(deltaLatRad / 2) +
      Math.cos(lat1Rad) *
        Math.cos(lat2Rad) *
        Math.sin(deltaLonRad / 2) *
        Math.sin(deltaLonRad / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return this.EARTH_RADIUS_KM * c;
  }

  async calculateRouteDistance(
    origin: Location,
    destination: Location,
    options: RouteOptions = { mode: "driving" }
  ): Promise<RouteResult> {
    try {
      if (!this.GOOGLE_MAPS_API_KEY) {
        const distance = this.calculateHaversineDistance(origin, destination);
        const duration = this.estimateDuration(distance, options.mode);

        return {
          distance,
          duration,
          route: {
            legs: [
              {
                distance,
                duration,
                startLocation: origin,
                endLocation: destination,
              },
            ],
          },
          fuelEfficiencyFactor: this.estimateFuelEfficiencyFactor(options.mode),
        };
      }

      const url = this.buildDirectionsUrl(origin, destination, options);
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== "OK") {
        throw new Error(`Google Maps API error: ${data.status}`);
      }

      const route = data.routes[0];
      const leg = route.legs[0];

      return {
        distance: leg.distance.value / 1000,
        duration: leg.duration.value / 60,
        route: {
          legs: [
            {
              distance: leg.distance.value / 1000,
              duration: leg.duration.value / 60,
              startLocation: origin,
              endLocation: destination,
            },
          ],
        },
        fuelEfficiencyFactor: this.calculateFuelEfficiencyFromRoute(route),
      };
    } catch (error) {
      const distance = this.calculateHaversineDistance(origin, destination);
      const duration = this.estimateDuration(distance, options.mode);

      return {
        distance,
        duration,
        route: {
          legs: [
            {
              distance,
              duration,
              startLocation: origin,
              endLocation: destination,
            },
          ],
        },
        fuelEfficiencyFactor: 1.0,
      };
    }
  }

  async optimizeMultipleWaypoints(
    origin: Location,
    destination: Location,
    waypoints: Location[],
    options: RouteOptions = { mode: "driving", optimize: true }
  ): Promise<RouteResult> {
    try {
      if (!this.GOOGLE_MAPS_API_KEY || waypoints.length === 0) {
        return this.calculateRouteDistance(origin, destination, options);
      }

      const url = this.buildDirectionsUrlWithWaypoints(
        origin,
        destination,
        waypoints,
        options
      );
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== "OK") {
        throw new Error(`Google Maps API error: ${data.status}`);
      }

      const route = data.routes[0];
      const totalDistance =
        route.legs.reduce(
          (sum: number, leg: any) => sum + leg.distance.value,
          0
        ) / 1000;
      const totalDuration =
        route.legs.reduce(
          (sum: number, leg: any) => sum + leg.duration.value,
          0
        ) / 60;

      return {
        distance: totalDistance,
        duration: totalDuration,
        optimizedOrder: route.waypoint_order || [],
        route: {
          legs: route.legs.map((leg: any) => ({
            distance: leg.distance.value / 1000,
            duration: leg.duration.value / 60,
            startLocation: {
              latitude: leg.start_location.lat,
              longitude: leg.start_location.lng,
            },
            endLocation: {
              latitude: leg.end_location.lat,
              longitude: leg.end_location.lng,
            },
          })),
        },
        fuelEfficiencyFactor: this.calculateFuelEfficiencyFromRoute(route),
      };
    } catch (error) {
      return this.calculateRouteDistance(origin, destination, options);
    }
  }

  async calculateDistanceMatrix(
    origins: Location[],
    destinations: Location[],
    mode: "driving" | "walking" | "bicycling" | "transit" = "driving"
  ): Promise<DistanceMatrix> {
    try {
      if (!this.GOOGLE_MAPS_API_KEY) {
        const distances = origins.map((origin) =>
          destinations.map((dest) =>
            this.calculateHaversineDistance(origin, dest)
          )
        );
        const durations = distances.map((row) =>
          row.map((distance) => this.estimateDuration(distance, mode))
        );

        return { origins, destinations, distances, durations };
      }

      const url = this.buildDistanceMatrixUrl(origins, destinations, mode);
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== "OK") {
        throw new Error(`Google Maps API error: ${data.status}`);
      }

      const distances = data.rows.map((row: any) =>
        row.elements.map((element: any) =>
          element.status === "OK" ? element.distance.value / 1000 : 0
        )
      );

      const durations = data.rows.map((row: any) =>
        row.elements.map((element: any) =>
          element.status === "OK" ? element.duration.value / 60 : 0
        )
      );

      return { origins, destinations, distances, durations };
    } catch (error) {
      const distances = origins.map((origin) =>
        destinations.map((dest) =>
          this.calculateHaversineDistance(origin, dest)
        )
      );
      const durations = distances.map((row) =>
        row.map((distance) => this.estimateDuration(distance, mode))
      );

      return { origins, destinations, distances, durations };
    }
  }

  async geocodeAddress(address: string): Promise<Location | null> {
    try {
      if (!this.GOOGLE_MAPS_API_KEY) {
        throw new Error("Google Maps API key not configured");
      }

      const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${this.GOOGLE_MAPS_API_KEY}`;
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== "OK" || data.results.length === 0) {
        return null;
      }

      const result = data.results[0];
      return {
        latitude: result.geometry.location.lat,
        longitude: result.geometry.location.lng,
        address: result.formatted_address,
        city: this.extractAddressComponent(result, "locality"),
        country: this.extractAddressComponent(result, "country"),
      };
    } catch (error) {
      return null;
    }
  }

  async reverseGeocode(location: Location): Promise<string | null> {
    try {
      if (!this.GOOGLE_MAPS_API_KEY) {
        return `${location.latitude}, ${location.longitude}`;
      }

      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${location.latitude},${location.longitude}&key=${this.GOOGLE_MAPS_API_KEY}`;
      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== "OK" || data.results.length === 0) {
        return `${location.latitude}, ${location.longitude}`;
      }

      return data.results[0].formatted_address;
    } catch (error) {
      return `${location.latitude}, ${location.longitude}`;
    }
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  private estimateDuration(distanceKm: number, mode: string): number {
    const speedKmh = {
      driving: 50,
      walking: 5,
      bicycling: 15,
      transit: 30,
    };

    return (distanceKm / speedKmh[mode as keyof typeof speedKmh]) * 60;
  }

  private estimateFuelEfficiencyFactor(mode: string): number {
    const factors = {
      driving: 1.0,
      walking: 0,
      bicycling: 0,
      transit: 0.3,
    };

    return factors[mode as keyof typeof factors] || 1.0;
  }

  private calculateFuelEfficiencyFromRoute(route: any): number {
    let factor = 1.0;

    const legs = route.legs || [];
    for (const leg of legs) {
      const steps = leg.steps || [];
      let highwayDistance = 0;
      let cityDistance = 0;

      for (const step of steps) {
        if (
          step.html_instructions?.includes("highway") ||
          step.html_instructions?.includes("freeway")
        ) {
          highwayDistance += step.distance?.value || 0;
        } else {
          cityDistance += step.distance?.value || 0;
        }
      }

      const totalDistance = highwayDistance + cityDistance;
      if (totalDistance > 0) {
        const highwayRatio = highwayDistance / totalDistance;

        factor *= 1 - highwayRatio * 0.15;
      }
    }

    return Math.max(0.7, Math.min(1.3, factor));
  }

  private buildDirectionsUrl(
    origin: Location,
    destination: Location,
    options: RouteOptions
  ): string {
    const baseUrl = "https://maps.googleapis.com/maps/api/directions/json";
    const params = new URLSearchParams({
      origin: `${origin.latitude},${origin.longitude}`,
      destination: `${destination.latitude},${destination.longitude}`,
      mode: options.mode,
      key: this.GOOGLE_MAPS_API_KEY!,
    });

    if (options.avoidTolls) params.append("avoid", "tolls");
    if (options.avoidHighways) params.append("avoid", "highways");
    if (options.avoidFerries) params.append("avoid", "ferries");

    return `${baseUrl}?${params.toString()}`;
  }

  private buildDirectionsUrlWithWaypoints(
    origin: Location,
    destination: Location,
    waypoints: Location[],
    options: RouteOptions
  ): string {
    const baseUrl = "https://maps.googleapis.com/maps/api/directions/json";
    const waypointStr = waypoints
      .map((wp) => `${wp.latitude},${wp.longitude}`)
      .join("|");

    const params = new URLSearchParams({
      origin: `${origin.latitude},${origin.longitude}`,
      destination: `${destination.latitude},${destination.longitude}`,
      waypoints: options.optimize
        ? `optimize:true|${waypointStr}`
        : waypointStr,
      mode: options.mode,
      key: this.GOOGLE_MAPS_API_KEY!,
    });

    if (options.avoidTolls) params.append("avoid", "tolls");
    if (options.avoidHighways) params.append("avoid", "highways");
    if (options.avoidFerries) params.append("avoid", "ferries");

    return `${baseUrl}?${params.toString()}`;
  }

  private buildDistanceMatrixUrl(
    origins: Location[],
    destinations: Location[],
    mode: string
  ): string {
    const baseUrl = "https://maps.googleapis.com/maps/api/distancematrix/json";
    const originsStr = origins
      .map((loc) => `${loc.latitude},${loc.longitude}`)
      .join("|");
    const destinationsStr = destinations
      .map((loc) => `${loc.latitude},${loc.longitude}`)
      .join("|");

    const params = new URLSearchParams({
      origins: originsStr,
      destinations: destinationsStr,
      mode,
      key: this.GOOGLE_MAPS_API_KEY!,
    });

    return `${baseUrl}?${params.toString()}`;
  }

  private extractAddressComponent(
    result: any,
    type: string
  ): string | undefined {
    const component = result.address_components?.find((comp: any) =>
      comp.types.includes(type)
    );
    return component?.long_name;
  }
}

export const locationSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().optional(),
});

export const routeOptionsSchema = z.object({
  mode: z.enum(["driving", "walking", "bicycling", "transit"]),
  avoidTolls: z.boolean().optional(),
  avoidHighways: z.boolean().optional(),
  avoidFerries: z.boolean().optional(),
  optimize: z.boolean().optional(),
});

export const distanceCalculationSchema = z.object({
  origin: locationSchema,
  destination: locationSchema,
  options: routeOptionsSchema.optional(),
});

export const multipleWaypointsSchema = z.object({
  origin: locationSchema,
  destination: locationSchema,
  waypoints: z.array(locationSchema),
  options: routeOptionsSchema.optional(),
});

export const distanceMatrixSchema = z.object({
  origins: z.array(locationSchema),
  destinations: z.array(locationSchema),
  mode: z.enum(["driving", "walking", "bicycling", "transit"]).optional(),
});

export const geocodeSchema = z.object({
  address: z.string().min(1),
});

export const reverseGeocodeSchema = z.object({
  location: locationSchema,
});

export const distanceCalculator = new DistanceCalculator();
