import type { FoodData } from "@/types/carbon";

interface FoodEmissionFactor {
  category: string;
  subcategory: string;
  emissionFactor: number;
  unit: string;
  source: string;
  region: string;
  confidence: number;
}

interface FoodCalculationResult {
  totalEmissions: number;
  breakdown: {
    meat: number;
    dairy: number;
    plant_based: number;
    beverages: number;
    dining_out: number;
  };
  details: Array<{
    category: string;
    subcategory: string;
    consumption: number;
    unit: string;
    emissionFactor: number;
    emissions: number;
    confidence: number;
  }>;
  methodology: string;
  recommendations: string[];
}

class FoodCalculatorService {
  private foodDatabase: Map<string, FoodEmissionFactor> = new Map();

  constructor() {
    this.initializeFoodDatabase();
  }

  private initializeFoodDatabase(): void {
    const meatFactors: FoodEmissionFactor[] = [
      {
        category: "food",
        subcategory: "lamb",
        emissionFactor: 24.0,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.85,
      },
      {
        category: "food",
        subcategory: "pork",
        emissionFactor: 7.2,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.9,
      },
      {
        category: "food",
        subcategory: "chicken",
        emissionFactor: 6.9,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.9,
      },
      {
        category: "food",
        subcategory: "fish",
        emissionFactor: 5.4,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.8,
      },
    ];

    const dairyFactors: FoodEmissionFactor[] = [
      {
        category: "food",
        subcategory: "milk",
        emissionFactor: 3.2,
        unit: "kg CO2e/liter",
        source: "FAO 2019",
        region: "global",
        confidence: 0.9,
      },
      {
        category: "food",
        subcategory: "cheese",
        emissionFactor: 13.5,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.85,
      },
      {
        category: "food",
        subcategory: "yogurt",
        emissionFactor: 2.2,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.8,
      },
      {
        category: "food",
        subcategory: "butter",
        emissionFactor: 23.8,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.85,
      },
    ];

    const plantFactors: FoodEmissionFactor[] = [
      {
        category: "food",
        subcategory: "vegetables",
        emissionFactor: 2.0,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.8,
      },
      {
        category: "food",
        subcategory: "fruits",
        emissionFactor: 1.1,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.8,
      },
      {
        category: "food",
        subcategory: "grains",
        emissionFactor: 1.4,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.85,
      },
      {
        category: "food",
        subcategory: "legumes",
        emissionFactor: 0.9,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.8,
      },
      {
        category: "food",
        subcategory: "nuts",
        emissionFactor: 2.3,
        unit: "kg CO2e/kg",
        source: "FAO 2019",
        region: "global",
        confidence: 0.75,
      },
    ];

    const beverageFactors: FoodEmissionFactor[] = [
      {
        category: "food",
        subcategory: "coffee",
        emissionFactor: 16.9,
        unit: "kg CO2e/kg",
        source: "Carbon Trust 2020",
        region: "global",
        confidence: 0.8,
      },
      {
        category: "food",
        subcategory: "tea",
        emissionFactor: 5.8,
        unit: "kg CO2e/kg",
        source: "Carbon Trust 2020",
        region: "global",
        confidence: 0.75,
      },
      {
        category: "food",
        subcategory: "alcohol",
        emissionFactor: 1.9,
        unit: "kg CO2e/liter",
        source: "Carbon Trust 2020",
        region: "global",
        confidence: 0.7,
      },
      {
        category: "food",
        subcategory: "soft_drinks",
        emissionFactor: 0.7,
        unit: "kg CO2e/liter",
        source: "Carbon Trust 2020",
        region: "global",
        confidence: 0.75,
      },
    ];

    const diningFactors: FoodEmissionFactor[] = [
      {
        category: "food",
        subcategory: "restaurant_meals",
        emissionFactor: 5.2,
        unit: "kg CO2e/meal",
        source: "EPA 2021",
        region: "US",
        confidence: 0.7,
      },
      {
        category: "food",
        subcategory: "fast_food_meals",
        emissionFactor: 3.8,
        unit: "kg CO2e/meal",
        source: "EPA 2021",
        region: "US",
        confidence: 0.75,
      },
      {
        category: "food",
        subcategory: "delivery_meals",
        emissionFactor: 4.5,
        unit: "kg CO2e/meal",
        source: "EPA 2021",
        region: "US",
        confidence: 0.65,
      },
    ];

    [
      ...meatFactors,
      ...dairyFactors,
      ...plantFactors,
      ...beverageFactors,
      ...diningFactors,
    ].forEach((factor) => {
      this.foodDatabase.set(factor.subcategory, factor);
    });
  }

  async calculateFoodEmissions(data: FoodData): Promise<FoodCalculationResult> {
    try {
      let totalEmissions = 0;
      const breakdown = {
        meat: 0,
        dairy: 0,
        plant_based: 0,
        beverages: 0,
        dining_out: 0,
      };
      const details: any[] = [];
      const recommendations: string[] = [];

      if (data.meat) {
        const meatEmissions = await this.calculateMeatEmissions(data.meat);
        breakdown.meat = meatEmissions.total;
        totalEmissions += meatEmissions.total;
        details.push(...meatEmissions.details);
        recommendations.push(...meatEmissions.recommendations);
      }

      if (data.dairy) {
        const dairyEmissions = await this.calculateDairyEmissions(data.dairy);
        breakdown.dairy = dairyEmissions.total;
        totalEmissions += dairyEmissions.total;
        details.push(...dairyEmissions.details);
        recommendations.push(...dairyEmissions.recommendations);
      }

      if (data.plant_based) {
        const plantEmissions = await this.calculatePlantEmissions(
          data.plant_based
        );
        breakdown.plant_based = plantEmissions.total;
        totalEmissions += plantEmissions.total;
        details.push(...plantEmissions.details);
        recommendations.push(...plantEmissions.recommendations);
      }

      if (data.beverages) {
        const beverageEmissions = await this.calculateBeverageEmissions(
          data.beverages
        );
        breakdown.beverages = beverageEmissions.total;
        totalEmissions += beverageEmissions.total;
        details.push(...beverageEmissions.details);
        recommendations.push(...beverageEmissions.recommendations);
      }

      if (data.dining_out) {
        const diningEmissions = await this.calculateDiningEmissions(
          data.dining_out
        );
        breakdown.dining_out = diningEmissions.total;
        totalEmissions += diningEmissions.total;
        details.push(...diningEmissions.details);
        recommendations.push(...diningEmissions.recommendations);
      }

      const overallRecommendations = this.generateDietaryRecommendations(
        breakdown,
        totalEmissions
      );
      recommendations.push(...overallRecommendations);

      return {
        totalEmissions,
        breakdown,
        details,
        methodology: "FAO 2019 emission factors with regional adjustments",
        recommendations: Array.from(new Set(recommendations)),
      };
    } catch (error) {
      throw new Error("Failed to calculate food emissions");
    }
  }

  private async calculateMeatEmissions(meat: NonNullable<FoodData["meat"]>) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, consumption] of Object.entries(meat)) {
      if (consumption && consumption > 0) {
        const factor = this.foodDatabase.get(type);
        if (factor) {
          const emissions = consumption * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "food",
            subcategory: type,
            consumption,
            unit: "kg",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
          });

          if (type === "lamb" && consumption > 1) {
            recommendations.push(
              "Lamb has a high carbon footprint - try substituting with chicken or plant proteins"
            );
          }
        }
      }
    }

    return { total, details, recommendations };
  }

  private async calculateDairyEmissions(dairy: NonNullable<FoodData["dairy"]>) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, consumption] of Object.entries(dairy)) {
      if (consumption && consumption > 0) {
        const factor = this.foodDatabase.get(type);
        if (factor) {
          const emissions = consumption * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "food",
            subcategory: type,
            consumption,
            unit: type === "milk" ? "liters" : "kg",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
          });

          if (type === "cheese" && consumption > 1) {
            recommendations.push(
              "Cheese has a high carbon footprint - consider plant-based alternatives"
            );
          }
          if (type === "butter" && consumption > 0.5) {
            recommendations.push(
              "Try plant-based butter alternatives to reduce dairy emissions"
            );
          }
        }
      }
    }

    return { total, details, recommendations };
  }

  private async calculatePlantEmissions(
    plantBased: NonNullable<FoodData["plant_based"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, consumption] of Object.entries(plantBased)) {
      if (consumption && consumption > 0) {
        const factor = this.foodDatabase.get(type);
        if (factor) {
          const emissions = consumption * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "food",
            subcategory: type,
            consumption,
            unit: "kg",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
          });
        }
      }
    }

    if (total < 50) {
      recommendations.push(
        "Increase plant-based foods in your diet - they have much lower carbon footprints"
      );
    }

    return { total, details, recommendations };
  }

  private async calculateBeverageEmissions(
    beverages: NonNullable<FoodData["beverages"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, consumption] of Object.entries(beverages)) {
      if (consumption && consumption > 0) {
        const factor = this.foodDatabase.get(type);
        if (factor) {
          const emissions = consumption * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "food",
            subcategory: type,
            consumption,
            unit: type === "coffee" || type === "tea" ? "kg" : "liters",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
          });

          if (type === "coffee" && consumption > 1) {
            recommendations.push(
              "Coffee has a high carbon footprint - consider reducing consumption or choosing sustainable brands"
            );
          }
        }
      }
    }

    return { total, details, recommendations };
  }

  private async calculateDiningEmissions(
    diningOut: NonNullable<FoodData["dining_out"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, meals] of Object.entries(diningOut)) {
      if (meals && meals > 0) {
        const factor = this.foodDatabase.get(type);
        if (factor) {
          const emissions = meals * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "food",
            subcategory: type,
            consumption: meals,
            unit: "meals",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
          });
        }
      }
    }

    if (total > 100) {
      recommendations.push(
        "Frequent dining out increases your carbon footprint - try cooking more meals at home"
      );
    }

    return { total, details, recommendations };
  }

  private generateDietaryRecommendations(
    breakdown: any,
    totalEmissions: number
  ): string[] {
    const recommendations: string[] = [];

    const meatPercentage = (breakdown.meat / totalEmissions) * 100;
    const dairyPercentage = (breakdown.dairy / totalEmissions) * 100;
    const plantPercentage = (breakdown.plant_based / totalEmissions) * 100;

    if (meatPercentage > 60) {
      recommendations.push(
        "Your diet is meat-heavy. Consider adopting 'Meatless Monday' or reducing portion sizes"
      );
    }

    if (dairyPercentage > 30) {
      recommendations.push(
        "Try plant-based milk alternatives like oat, almond, or soy milk"
      );
    }

    if (plantPercentage < 20) {
      recommendations.push(
        "Increase your intake of vegetables, fruits, and legumes for a lower carbon footprint"
      );
    }

    if (totalEmissions > 200) {
      recommendations.push(
        "Consider following a more plant-forward diet to significantly reduce your food carbon footprint"
      );
    }

    return recommendations;
  }

  getEmissionFactor(subcategory: string): FoodEmissionFactor | undefined {
    return this.foodDatabase.get(subcategory);
  }

  getFoodDatabase(): Map<string, FoodEmissionFactor> {
    return new Map(this.foodDatabase);
  }
}

export const foodCalculator = new FoodCalculatorService();
