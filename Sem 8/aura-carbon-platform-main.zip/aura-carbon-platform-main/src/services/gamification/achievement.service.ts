import { db } from "@/lib/db";
import { notificationService } from "@/services/notifications/notification.service";
import {
  XP_REWARDS,
  LEVEL_CONFIG,
  calculateLevel,
} from "@/config/gamification";

export interface Achievement {
  id: string;
  name: string;
  description: string;
  category: AchievementCategory;
  tier: "bronze" | "silver" | "gold" | "platinum";
  icon: string;
  points: number;
  requirement: AchievementRequirement;
  unlockedAt?: Date;
  progress?: number;
}

export type AchievementCategory =
  | "tracking"
  | "reduction"
  | "streaks"
  | "milestones"
  | "goals"
  | "special";

export interface AchievementRequirement {
  type:
    | "activities_logged"
    | "co2_saved"
    | "days_streak"
    | "goals_completed"
    | "badges_earned"
    | "referrals"
    | "reports_exported"
    | "predictions_viewed";
  target: number;
}

export const ACHIEVEMENTS: Omit<Achievement, "unlockedAt" | "progress">[] = [
  {
    id: "first_step",
    name: "First Step",
    description: "Log your first activity",
    category: "tracking",
    tier: "bronze",
    icon: "👣",
    points: 10,
    requirement: { type: "activities_logged", target: 1 },
  },
  {
    id: "active_tracker",
    name: "Active Tracker",
    description: "Log 25 activities",
    category: "tracking",
    tier: "silver",
    icon: "📊",
    points: 50,
    requirement: { type: "activities_logged", target: 25 },
  },
  {
    id: "data_master",
    name: "Data Master",
    description: "Log 100 activities",
    category: "tracking",
    tier: "gold",
    icon: "🎯",
    points: 150,
    requirement: { type: "activities_logged", target: 100 },
  },
  {
    id: "carbon_pioneer",
    name: "Carbon Pioneer",
    description: "Log 500 activities",
    category: "tracking",
    tier: "platinum",
    icon: "🌟",
    points: 500,
    requirement: { type: "activities_logged", target: 500 },
  },

  {
    id: "small_saver",
    name: "Small Saver",
    description: "Save 10 kg of CO2",
    category: "reduction",
    tier: "bronze",
    icon: "🌱",
    points: 20,
    requirement: { type: "co2_saved", target: 10 },
  },
  {
    id: "eco_warrior",
    name: "Eco Warrior",
    description: "Save 100 kg of CO2",
    category: "reduction",
    tier: "silver",
    icon: "🦸",
    points: 100,
    requirement: { type: "co2_saved", target: 100 },
  },
  {
    id: "planet_guardian",
    name: "Planet Guardian",
    description: "Save 500 kg of CO2",
    category: "reduction",
    tier: "gold",
    icon: "🌍",
    points: 250,
    requirement: { type: "co2_saved", target: 500 },
  },
  {
    id: "climate_hero",
    name: "Climate Hero",
    description: "Save 2 tons of CO2",
    category: "reduction",
    tier: "platinum",
    icon: "🏆",
    points: 1000,
    requirement: { type: "co2_saved", target: 2000 },
  },

  {
    id: "week_warrior",
    name: "Week Warrior",
    description: "Maintain a 7-day logging streak",
    category: "streaks",
    tier: "bronze",
    icon: "🔥",
    points: 50,
    requirement: { type: "days_streak", target: 7 },
  },
  {
    id: "monthly_master",
    name: "Monthly Master",
    description: "Maintain a 30-day logging streak",
    category: "streaks",
    tier: "silver",
    icon: "📅",
    points: 200,
    requirement: { type: "days_streak", target: 30 },
  },
  {
    id: "consistency_king",
    name: "Consistency King",
    description: "Maintain a 100-day logging streak",
    category: "streaks",
    tier: "gold",
    icon: "👑",
    points: 500,
    requirement: { type: "days_streak", target: 100 },
  },
  {
    id: "eternal_flame",
    name: "Eternal Flame",
    description: "Maintain a 365-day logging streak",
    category: "streaks",
    tier: "platinum",
    icon: "💎",
    points: 2000,
    requirement: { type: "days_streak", target: 365 },
  },

  {
    id: "goal_starter",
    name: "Goal Starter",
    description: "Create your first goal",
    category: "goals",
    tier: "bronze",
    icon: "🎯",
    points: 25,
    requirement: { type: "goals_completed", target: 1 },
  },
  {
    id: "achiever",
    name: "Achiever",
    description: "Complete 10 goals",
    category: "goals",
    tier: "silver",
    icon: "🏅",
    points: 150,
    requirement: { type: "goals_completed", target: 10 },
  },
  {
    id: "champion",
    name: "Champion",
    description: "Complete 50 goals",
    category: "goals",
    tier: "gold",
    icon: "🎖️",
    points: 500,
    requirement: { type: "goals_completed", target: 50 },
  },
  {
    id: "visionary",
    name: "Visionary",
    description: "Complete 100 goals",
    category: "goals",
    tier: "platinum",
    icon: "✨",
    points: 1200,
    requirement: { type: "goals_completed", target: 100 },
  },

  {
    id: "early_adopter",
    name: "Early Adopter",
    description: "Join Aura in its first year",
    category: "special",
    tier: "gold",
    icon: "🚀",
    points: 100,
    requirement: { type: "activities_logged", target: 1 },
  },
  {
    id: "collection_specialist",
    name: "Collection Specialist",
    description: "Earn 15 badges",
    category: "special",
    tier: "silver",
    icon: "🎖️",
    points: 100,
    requirement: { type: "badges_earned", target: 15 },
  },
  {
    id: "aura_god",
    name: "Aura Deity",
    description: "Earn all platinum badges",
    category: "special",
    tier: "platinum",
    icon: "🌌",
    points: 5000,
    requirement: { type: "badges_earned", target: 30 },
  },
];

interface UserStats {
  activitiesLogged: number;
  co2Saved: number;
  daysStreak: number;
  goalsCompleted: number;
  badgesEarned: number;
  referrals: number;
  reportsExported: number;
  predictionsViewed: number;
}

export interface RewardResult {
  xpEarned: number;
  totalXp: number;
  newLevel: number;
  leveledUp: boolean;
  levelTitle: string;
  newAchievements: Achievement[];
}

class AchievementService {
  async processAction(
    userId: string,
    actionType: keyof typeof XP_REWARDS,
    metadata?: any
  ): Promise<RewardResult> {
    const baseReward = XP_REWARDS[actionType] || 0;

    const initialIdentity = await db.user.findUnique({
      where: { id: userId },
      select: { totalXp: true, currentLevel: true },
    });

    if (!initialIdentity)
      throw new Error("Identity resolution failed during reward processing.");

    const atomicIdentity = await db.user.update({
      where: { id: userId },
      data: { totalXp: { increment: baseReward } },
      select: { totalXp: true, currentLevel: true },
    });

    const activeExperience = atomicIdentity.totalXp;
    const computedLevelData = calculateLevel(activeExperience);
    let levelIterated = false;

    if (computedLevelData.level > initialIdentity.currentLevel) {
      levelIterated = true;
      await db.user.update({
        where: { id: userId },
        data: { currentLevel: computedLevelData.level },
      });
    }

    const resolvedUnlocks = await this.evaluateMilestoneEligibility(userId);
    let aggregatedReward = baseReward;

    if (resolvedUnlocks.length > 0) {
      const milestoneBonus = resolvedUnlocks.reduce(
        (acc, milestone) => acc + milestone.points,
        0
      );
      aggregatedReward += milestoneBonus;

      const identityPostMilestone = await db.user.update({
        where: { id: userId },
        data: { totalXp: { increment: milestoneBonus } },
        select: { totalXp: true, currentLevel: true },
      });

      const definitiveLevelData = calculateLevel(identityPostMilestone.totalXp);
      if (definitiveLevelData.level > computedLevelData.level) {
        levelIterated = true;
        await db.user.update({
          where: { id: userId },
          data: { currentLevel: definitiveLevelData.level },
        });
      }
    }

    const finalIdentityCapture = await db.user.findUnique({
      where: { id: userId },
      select: { totalXp: true, currentLevel: true },
    });

    const finalExperienceTarget =
      finalIdentityCapture?.totalXp ?? activeExperience;
    const finalProgressionState = calculateLevel(finalExperienceTarget);

    return {
      xpEarned: aggregatedReward,
      totalXp: finalExperienceTarget,
      newLevel: finalProgressionState.level,
      leveledUp: levelIterated,
      levelTitle: finalProgressionState.title,
      newAchievements: resolvedUnlocks,
    };
  }

  async getAchievements(userId: string): Promise<Achievement[]> {
    const aggregateMetrics = await this.compileIdentityMetrics(userId);
    const resolvedMilestones = await db.achievement.findMany({
      where: { userId },
    });

    const milestoneDictionary = new Map(
      resolvedMilestones.map((m) => [m.key, m])
    );

    return ACHIEVEMENTS.map((milestone) => {
      const completionRatio = this.calculateThresholdVelocity(
        milestone.requirement,
        aggregateMetrics
      );
      const activeMilestone = milestoneDictionary.get(milestone.id);

      return {
        ...milestone,
        progress: completionRatio,
        unlockedAt: activeMilestone?.unlockedAt,
        isUnlocked: !!activeMilestone,
      } as Achievement;
    });
  }

  async evaluateMilestoneEligibility(userId: string): Promise<Achievement[]> {
    const activeMetrics = await this.compileIdentityMetrics(userId);
    const existingMilestoneIds = await this.resolveMilestoneIdentifiers(userId);
    const newlyResolved: Achievement[] = [];

    for (const milestone of ACHIEVEMENTS) {
      if (existingMilestoneIds.includes(milestone.id)) continue;

      const completionRatio = this.calculateThresholdVelocity(
        milestone.requirement,
        activeMetrics
      );

      if (completionRatio >= 100) {
        const persistedMilestone = await this.persistMilestoneEvent(
          userId,
          milestone
        );
        newlyResolved.push({
          ...milestone,
          unlockedAt: persistedMilestone.unlockedAt,
          isUnlocked: true,
          progress: 100,
        } as Achievement);

        await notificationService.notifyAchievement(
          userId,
          milestone.name,
          milestone.description
        );
      }
    }

    return newlyResolved;
  }

  async getTotalPoints(userId: string): Promise<number> {
    const identity = await db.user.findUnique({
      where: { id: userId },
      select: { totalXp: true },
    });
    return identity?.totalXp || 0;
  }

  async getUserLevel(
    userId: string
  ): Promise<{ level: number; title: string; nextLevelPoints: number }> {
    const activeExperience = await this.getTotalPoints(userId);
    const computedLevel = calculateLevel(activeExperience);
    const nextTierConfiguration = LEVEL_CONFIG[computedLevel.level] || null;

    return {
      level: computedLevel.level,
      title: computedLevel.title,
      nextLevelPoints: nextTierConfiguration?.minXp || activeExperience + 1000,
    };
  }

  private async compileIdentityMetrics(userId: string): Promise<UserStats> {
    const activityVolume = await db.activityData.count({
      where: { userId },
    });

    const historicalGoalCompletions = await db.goal.count({
      where: {
        userId,
        endDate: { lt: new Date() },
      },
    });

    const identityTemporalState = await db.user.findUnique({
      where: { id: userId },
      select: { currentStreak: true },
    });

    const predictionsCount = await db.prediction.count({
      where: { userId },
    });

    const lifecycleEmissions = await db.carbonCalculation.findMany({
      where: { userId },
      select: { totalEmissions: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    });

    let cumulativeReduction = 0;
    if (lifecycleEmissions.length > 1) {
      const historicalBaseline = lifecycleEmissions[0].totalEmissions;
      for (const emissionSnapshot of lifecycleEmissions.slice(1)) {
        if (emissionSnapshot.totalEmissions < historicalBaseline) {
          cumulativeReduction +=
            historicalBaseline - emissionSnapshot.totalEmissions;
        }
      }
    }

    const resolvedMilestones = await this.resolveMilestoneIdentifiers(userId);

    return {
      activitiesLogged: activityVolume,
      co2Saved: Math.round(cumulativeReduction),
      daysStreak: identityTemporalState?.currentStreak || 0,
      goalsCompleted: historicalGoalCompletions,
      badgesEarned: resolvedMilestones.length,
      referrals: 0,
      reportsExported: 0,
      predictionsViewed: predictionsCount,
    };
  }

  private calculateThresholdVelocity(
    requirement: AchievementRequirement,
    metrics: UserStats
  ): number {
    const metricPointerMap: Record<string, keyof UserStats> = {
      activities_logged: "activitiesLogged",
      co2_saved: "co2Saved",
      days_streak: "daysStreak",
      goals_completed: "goalsCompleted",
      badges_earned: "badgesEarned",
      referrals: "referrals",
      reports_exported: "reportsExported",
      predictions_viewed: "predictionsViewed",
    };
    const lookupKey = metricPointerMap[requirement.type];
    const currentVelocity = metrics[lookupKey] || 0;
    return Math.min(100, (currentVelocity / requirement.target) * 100);
  }

  async calculateStreak(userId: string): Promise<number> {
    const identityState = await db.user.findUnique({
      where: { id: userId },
      select: {
        streakLastMaintained: true,
        currentStreak: true,
        streakFreezes: true,
        longestStreak: true,
        createdAt: true,
      },
    });

    if (!identityState) return 0;

    const normalizedToday = new Date();
    normalizedToday.setHours(0, 0, 0, 0);

    const temporalAnchor = identityState.streakLastMaintained
      ? new Date(identityState.streakLastMaintained)
      : null;
    if (temporalAnchor) temporalAnchor.setHours(0, 0, 0, 0);

    const lastFreezeGrant = (identityState as any).lastFreezeGrant
      ? new Date((identityState as any).lastFreezeGrant)
      : new Date(identityState.createdAt);
    const weeksSinceLastGrant = Math.floor(
      (normalizedToday.getTime() - lastFreezeGrant.getTime()) /
        (1000 * 3600 * 24 * 7)
    );

    if (weeksSinceLastGrant >= 1) {
      await db.user.update({
        where: { id: userId },
        data: {
          streakFreezes: { increment: 1 },
          lastFreezeGrant: normalizedToday,
        } as any,
      });
    }

    if (!temporalAnchor) {
      await db.user.update({
        where: { id: userId },
        data: { currentStreak: 1, streakLastMaintained: new Date() },
      });
      return 1;
    }

    const temporalDelta = Math.floor(
      (normalizedToday.getTime() - temporalAnchor.getTime()) /
        (1000 * 3600 * 24)
    );

    if (temporalDelta === 0) {
      return identityState.currentStreak;
    } else if (temporalDelta === 1) {
      const iteratedSequence = identityState.currentStreak + 1;
      await db.user.update({
        where: { id: userId },
        data: {
          currentStreak: iteratedSequence,
          streakLastMaintained: new Date(),
          longestStreak: {
            set: Math.max(iteratedSequence, identityState.longestStreak ?? 0),
          },
        },
      });
      return iteratedSequence;
    } else {
      const activeFreezes = identityState.streakFreezes;
      if (activeFreezes > 0 && activeFreezes >= temporalDelta - 1) {
        await db.user.update({
          where: { id: userId },
          data: {
            streakFreezes: { decrement: temporalDelta - 1 },
            streakLastMaintained: new Date(),
          },
        });
        return identityState.currentStreak;
      } else {
        await db.user.update({
          where: { id: userId },
          data: {
            currentStreak: 1,
            streakLastMaintained: new Date(),
            longestStreak: {
              set: Math.max(
                identityState.currentStreak,
                identityState.longestStreak ?? 0
              ),
            },
          },
        });
        return 1;
      }
    }
  }

  private async resolveMilestoneIdentifiers(userId: string): Promise<string[]> {
    const historicalMilestones = await db.achievement.findMany({
      where: { userId },
      select: { key: true },
    });
    return historicalMilestones.map((m) => m.key);
  }

  private async persistMilestoneEvent(
    userId: string,
    milestoneMap: Omit<Achievement, "unlockedAt" | "progress">
  ): Promise<any> {
    return await db.achievement.create({
      data: {
        userId,
        key: milestoneMap.id,
        title: milestoneMap.name,
        description: milestoneMap.description,
        icon: milestoneMap.icon,
      },
    });
  }
}

export const achievementService = new AchievementService();
