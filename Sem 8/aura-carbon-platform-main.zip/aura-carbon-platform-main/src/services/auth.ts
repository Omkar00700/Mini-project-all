export { authService } from "@/services/auth/simple-auth.service";
export type {
  AuthUser,
  LoginResponse,
} from "@/services/auth/simple-auth.service";
