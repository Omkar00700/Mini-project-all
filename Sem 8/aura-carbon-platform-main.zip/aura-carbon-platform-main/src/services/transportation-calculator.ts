import { emissionFactorsService } from "./emission-factors";
import {
  distanceCalculator,
  type Location,
  type RouteOptions,
} from "./distance-calculator";

interface VehicleSpecs {
  make: string;
  model: string;
  year: number;
  fuelType: "gasoline" | "diesel" | "electric" | "hybrid";
  engineSize?: number;
  fuelEfficiency: number;
  vehicleType: "compact" | "midsize" | "large" | "suv" | "truck" | "motorcycle";
}

interface TripData {
  distance?: number;
  origin?: Location;
  destination?: Location;
  waypoints?: Location[];
  routeOptions?: RouteOptions;
  passengers?: number;
  cargoWeight?: number;
  trafficCondition?: "light" | "moderate" | "heavy";
  drivingStyle?: "eco" | "normal" | "aggressive";
}

interface FlightData {
  origin: string | Location;
  destination: string | Location;
  distance?: number;
  class: "economy" | "premium_economy" | "business" | "first";
  aircraftType?: string;
  loadFactor?: number;
  roundTrip: boolean;
}

interface PublicTransportData {
  mode: "bus" | "train" | "metro" | "tram" | "ferry";
  distance: number;
  fuelType?: "diesel" | "electric" | "cng" | "biodiesel";
  occupancyRate?: number;
  region: string;
}

interface RidesharingData {
  service: "uber" | "lyft" | "taxi" | "other";
  vehicleType: "standard" | "premium" | "electric" | "pool";
  distance: number;
  waitTime?: number;
  detourFactor?: number;
}

class TransportationCalculator {
  async calculateTripDistance(trip: TripData): Promise<{
    distance: number;
    duration: number;
    routeEfficiencyFactor: number;
    optimizedRoute?: any;
  }> {
    if (trip.distance && trip.distance > 0) {
      return {
        distance: trip.distance,
        duration: this.estimateDuration(trip.distance, "driving"),
        routeEfficiencyFactor: 1.0,
      };
    }

    if (trip.origin && trip.destination) {
      const routeOptions: RouteOptions = {
        mode: "driving",
        optimize: trip.waypoints && trip.waypoints.length > 0,
        ...trip.routeOptions,
      };

      let routeResult;
      if (trip.waypoints && trip.waypoints.length > 0) {
        routeResult = await distanceCalculator.optimizeMultipleWaypoints(
          trip.origin,
          trip.destination,
          trip.waypoints,
          routeOptions
        );
      } else {
        routeResult = await distanceCalculator.calculateRouteDistance(
          trip.origin,
          trip.destination,
          routeOptions
        );
      }

      return {
        distance: routeResult.distance,
        duration: routeResult.duration,
        routeEfficiencyFactor: routeResult.fuelEfficiencyFactor || 1.0,
        optimizedRoute: routeResult,
      };
    }

    throw new Error(
      "Either distance or origin/destination must be provided for trip calculation"
    );
  }

  async calculateFlightDistance(flight: FlightData): Promise<number> {
    if (flight.distance && flight.distance > 0) {
      return flight.distance;
    }

    if (
      typeof flight.origin === "object" &&
      typeof flight.destination === "object"
    ) {
      return distanceCalculator.calculateHaversineDistance(
        flight.origin,
        flight.destination
      );
    }

    if (
      typeof flight.origin === "string" &&
      typeof flight.destination === "string"
    ) {
      const originLocation = await this.getAirportLocation(flight.origin);
      const destinationLocation = await this.getAirportLocation(
        flight.destination
      );

      if (originLocation && destinationLocation) {
        return distanceCalculator.calculateHaversineDistance(
          originLocation,
          destinationLocation
        );
      }
    }

    throw new Error(
      "Unable to calculate flight distance - invalid origin or destination"
    );
  }

  private async getAirportLocation(
    airportCode: string
  ): Promise<Location | null> {
    const airportDatabase: Record<string, Location> = {
      JFK: { latitude: 40.6413, longitude: -73.7781 },
      LAX: { latitude: 33.9425, longitude: -118.4081 },
      LHR: { latitude: 51.47, longitude: -0.4543 },
      CDG: { latitude: 49.0097, longitude: 2.5479 },
      NRT: { latitude: 35.772, longitude: 140.3929 },
      DXB: { latitude: 25.2532, longitude: 55.3657 },
      SIN: { latitude: 1.3644, longitude: 103.9915 },
      HKG: { latitude: 22.308, longitude: 113.9185 },
    };

    const upperCode = airportCode.toUpperCase();
    if (airportDatabase[upperCode]) {
      return airportDatabase[upperCode];
    }

    return await distanceCalculator.geocodeAddress(airportCode);
  }

  async calculatePersonalVehicleEmissions(
    vehicle: VehicleSpecs,
    trip: TripData
  ): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      trafficAdjustment: number;
      drivingStyleAdjustment: number;
      cargoAdjustment: number;
      passengerAdjustment: number;
      routeOptimizationSavings: number;
    };
    methodology: string;
    routeInfo?: any;
  }> {
    try {
      const tripInfo = await this.calculateTripDistance(trip);
      const distance = tripInfo.distance;
      const routeEfficiencyFactor = tripInfo.routeEfficiencyFactor;

      const emissionFactor = await emissionFactorsService.getEmissionFactor(
        "transportation",
        "personal_vehicle",
        "global",
        vehicle.fuelType
      );

      if (!emissionFactor) {
        throw new Error(`No emission factor found for ${vehicle.fuelType}`);
      }

      let fuelConsumption = distance / vehicle.fuelEfficiency;

      const trafficMultipliers = {
        light: 0.9,
        moderate: 1.0,
        heavy: 1.3,
      };
      const trafficMultiplier =
        trafficMultipliers[trip.trafficCondition || "moderate"];
      fuelConsumption *= trafficMultiplier;

      const drivingStyleMultipliers = {
        eco: 0.85,
        normal: 1.0,
        aggressive: 1.2,
      };
      const drivingStyleMultiplier =
        drivingStyleMultipliers[trip.drivingStyle || "normal"];
      fuelConsumption *= drivingStyleMultiplier;

      const cargoMultiplier = 1 + ((trip.cargoWeight || 0) / 50) * 0.01;
      fuelConsumption *= cargoMultiplier;

      const baseEmissions = fuelConsumption * emissionFactor.value;

      fuelConsumption *= routeEfficiencyFactor;

      const passengerCount = Math.max(1, trip.passengers || 1);
      const emissionsPerPerson = baseEmissions / passengerCount;

      const routeOptimizationSavings =
        (1 - routeEfficiencyFactor) * baseEmissions;

      return {
        totalEmissions: emissionsPerPerson,
        breakdown: {
          baseEmissions:
            (distance / vehicle.fuelEfficiency) * emissionFactor.value,
          trafficAdjustment: (trafficMultiplier - 1) * baseEmissions,
          drivingStyleAdjustment: (drivingStyleMultiplier - 1) * baseEmissions,
          cargoAdjustment: (cargoMultiplier - 1) * baseEmissions,
          passengerAdjustment: baseEmissions - emissionsPerPerson,
          routeOptimizationSavings,
        },
        methodology:
          "IPCC Guidelines with real-world adjustments and route optimization",
        routeInfo: tripInfo.optimizedRoute,
      };
    } catch (error) {
      throw new Error("Failed to calculate personal vehicle emissions");
    }
  }

  async calculateFlightEmissions(flight: FlightData): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      radiativeForcing: number;
      classMultiplier: number;
      loadFactorAdjustment: number;
    };
    methodology: string;
    flightDistance?: number;
  }> {
    try {
      const distance = await this.calculateFlightDistance(flight);

      const emissionFactor = await emissionFactorsService.getEmissionFactor(
        "transportation",
        "aviation",
        "global",
        flight.class
      );

      if (!emissionFactor) {
        throw new Error(`No emission factor found for ${flight.class} class`);
      }

      let baseEmissions = distance * emissionFactor.value;

      const loadFactor = flight.loadFactor || 0.8;
      const loadFactorAdjustment = 0.8 / loadFactor;
      baseEmissions *= loadFactorAdjustment;

      const radiativeForcingFactor =
        this.calculateRadiativeForcingFactor(distance);
      const radiativeForcing = baseEmissions * (radiativeForcingFactor - 1);
      const totalWithRF = baseEmissions * radiativeForcingFactor;

      const finalEmissions = flight.roundTrip ? totalWithRF * 2 : totalWithRF;

      return {
        totalEmissions: finalEmissions,
        breakdown: {
          baseEmissions: distance * emissionFactor.value,
          radiativeForcing,
          classMultiplier: 0,
          loadFactorAdjustment: baseEmissions - distance * emissionFactor.value,
        },
        methodology: "DEFRA with radiative forcing (RFI factor)",
        flightDistance: distance,
      };
    } catch (error) {
      throw new Error("Failed to calculate flight emissions");
    }
  }

  async calculatePublicTransportEmissions(
    transport: PublicTransportData
  ): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      occupancyAdjustment: number;
      regionalAdjustment: number;
    };
    methodology: string;
  }> {
    try {
      const emissionFactor = await emissionFactorsService.getEmissionFactor(
        "transportation",
        "public_transport",
        transport.region,
        transport.mode
      );

      if (!emissionFactor) {
        throw new Error(
          `No emission factor found for ${transport.mode} in ${transport.region}`
        );
      }

      let baseEmissions = transport.distance * emissionFactor.value;

      const standardOccupancy = this.getStandardOccupancy(transport.mode);
      const actualOccupancy = transport.occupancyRate || standardOccupancy;
      const occupancyAdjustment = standardOccupancy / actualOccupancy - 1;
      baseEmissions *= standardOccupancy / actualOccupancy;

      return {
        totalEmissions: baseEmissions,
        breakdown: {
          baseEmissions: transport.distance * emissionFactor.value,
          occupancyAdjustment: baseEmissions * occupancyAdjustment,
          regionalAdjustment: 0,
        },
        methodology: "Regional emission factors with occupancy adjustments",
      };
    } catch (error) {
      throw new Error("Failed to calculate public transport emissions");
    }
  }

  async calculateRidesharingEmissions(rideshare: RidesharingData): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      detourAdjustment: number;
      waitTimeEmissions: number;
      poolingAdjustment: number;
    };
    methodology: string;
  }> {
    try {
      const vehicleTypeMap = {
        standard: { fuelType: "gasoline" as const, efficiency: 12 },
        premium: { fuelType: "gasoline" as const, efficiency: 10 },
        electric: { fuelType: "electric" as const, efficiency: 5 },
        pool: { fuelType: "gasoline" as const, efficiency: 12 },
      };

      const vehicleSpec = vehicleTypeMap[rideshare.vehicleType];

      const emissionFactor = await emissionFactorsService.getEmissionFactor(
        "transportation",
        "personal_vehicle",
        "global",
        vehicleSpec.fuelType
      );

      if (!emissionFactor) {
        throw new Error(`No emission factor found for ${vehicleSpec.fuelType}`);
      }

      const detourFactor = rideshare.detourFactor || 1.2;
      const actualDistance = rideshare.distance * detourFactor;
      const fuelConsumption = actualDistance / vehicleSpec.efficiency;
      const baseEmissions = fuelConsumption * emissionFactor.value;

      const waitTime = rideshare.waitTime || 3;
      const idlingEmissions = this.calculateIdlingEmissions(
        waitTime,
        vehicleSpec.fuelType
      );

      let poolingAdjustment = 0;
      let finalEmissions = baseEmissions + idlingEmissions;

      if (rideshare.vehicleType === "pool") {
        poolingAdjustment = finalEmissions * 0.5;
        finalEmissions *= 0.5;
      }

      return {
        totalEmissions: finalEmissions,
        breakdown: {
          baseEmissions:
            (rideshare.distance / vehicleSpec.efficiency) *
            emissionFactor.value,
          detourAdjustment: (detourFactor - 1) * baseEmissions,
          waitTimeEmissions: idlingEmissions,
          poolingAdjustment: -poolingAdjustment,
        },
        methodology: "Vehicle-specific factors with rideshare adjustments",
      };
    } catch (error) {
      throw new Error("Failed to calculate ridesharing emissions");
    }
  }

  async calculateTransportationFootprint(data: {
    personalVehicle?: { vehicle: VehicleSpecs; trips: TripData[] };
    flights?: FlightData[];
    publicTransport?: PublicTransportData[];
    ridesharing?: RidesharingData[];
  }): Promise<{
    totalEmissions: number;
    breakdown: {
      personalVehicle: number;
      flights: number;
      publicTransport: number;
      ridesharing: number;
    };
    details: any[];
    methodology: string;
  }> {
    try {
      const details = [];
      let personalVehicleEmissions = 0;
      let flightEmissions = 0;
      let publicTransportEmissions = 0;
      let ridesharingEmissions = 0;

      if (data.personalVehicle) {
        for (const trip of data.personalVehicle.trips) {
          const result = await this.calculatePersonalVehicleEmissions(
            data.personalVehicle.vehicle,
            trip
          );
          personalVehicleEmissions += result.totalEmissions;
          details.push({ type: "personal_vehicle", ...result });
        }
      }

      if (data.flights) {
        for (const flight of data.flights) {
          const result = await this.calculateFlightEmissions(flight);
          flightEmissions += result.totalEmissions;
          details.push({ type: "flight", ...result });
        }
      }

      if (data.publicTransport) {
        for (const transport of data.publicTransport) {
          const result =
            await this.calculatePublicTransportEmissions(transport);
          publicTransportEmissions += result.totalEmissions;
          details.push({ type: "public_transport", ...result });
        }
      }

      if (data.ridesharing) {
        for (const rideshare of data.ridesharing) {
          const result = await this.calculateRidesharingEmissions(rideshare);
          ridesharingEmissions += result.totalEmissions;
          details.push({ type: "ridesharing", ...result });
        }
      }

      const totalEmissions =
        personalVehicleEmissions +
        flightEmissions +
        publicTransportEmissions +
        ridesharingEmissions;

      return {
        totalEmissions,
        breakdown: {
          personalVehicle: personalVehicleEmissions,
          flights: flightEmissions,
          publicTransport: publicTransportEmissions,
          ridesharing: ridesharingEmissions,
        },
        details,
        methodology:
          "Comprehensive transportation calculator with mode-specific factors",
      };
    } catch (error) {
      throw new Error("Failed to calculate transportation footprint");
    }
  }

  async getVehicleRecommendations(
    currentVehicle: VehicleSpecs,
    annualDistance: number
  ): Promise<{
    recommendations: Array<{
      vehicle: Partial<VehicleSpecs>;
      potentialSavings: number;
      paybackPeriod?: number;
      description: string;
    }>;
  }> {
    const recommendations = [];

    if (currentVehicle.fuelType !== "electric") {
      const electricSavings = await this.calculateElectricSavings(
        currentVehicle,
        annualDistance
      );
      recommendations.push({
        vehicle: {
          fuelType: "electric" as const,
          fuelEfficiency: 5,
        },
        potentialSavings: electricSavings.annualSavings,
        paybackPeriod: electricSavings.paybackYears,
        description: "Switch to electric vehicle for zero direct emissions",
      });
    }

    if (
      currentVehicle.fuelType === "gasoline" ||
      currentVehicle.fuelType === "diesel"
    ) {
      const hybridSavings = await this.calculateHybridSavings(
        currentVehicle,
        annualDistance
      );
      recommendations.push({
        vehicle: {
          fuelType: "hybrid" as const,
          fuelEfficiency: currentVehicle.fuelEfficiency * 1.4,
        },
        potentialSavings: hybridSavings.annualSavings,
        description: "Upgrade to hybrid for 30-40% emission reduction",
      });
    }

    return { recommendations };
  }

  private calculateRadiativeForcingFactor(distance: number): number {
    if (distance < 1000) return 2.0;
    if (distance < 3000) return 1.9;
    return 1.8;
  }

  private getStandardOccupancy(mode: string): number {
    const occupancyRates = {
      bus: 0.3,
      train: 0.4,
      metro: 0.35,
      tram: 0.25,
      ferry: 0.6,
    };
    return occupancyRates[mode as keyof typeof occupancyRates] || 0.3;
  }

  private calculateIdlingEmissions(
    waitTimeMinutes: number,
    fuelType: string
  ): number {
    const idlingRates = {
      gasoline: 0.004,
      diesel: 0.005,
      electric: 0.001,
      hybrid: 0.002,
    };

    const rate = idlingRates[fuelType as keyof typeof idlingRates] || 0.004;
    return waitTimeMinutes * rate;
  }

  private async calculateElectricSavings(
    currentVehicle: VehicleSpecs,
    annualDistance: number
  ) {
    const currentEmissions =
      (annualDistance / currentVehicle.fuelEfficiency) * 2.31;
    const electricEmissions = (annualDistance / 5) * 0.05;

    return {
      annualSavings: currentEmissions - electricEmissions,
      paybackYears: 8,
    };
  }

  private async calculateHybridSavings(
    currentVehicle: VehicleSpecs,
    annualDistance: number
  ) {
    const currentEmissions =
      (annualDistance / currentVehicle.fuelEfficiency) * 2.31;
    const hybridEmissions =
      (annualDistance / (currentVehicle.fuelEfficiency * 1.4)) * 2.31;

    return {
      annualSavings: currentEmissions - hybridEmissions,
    };
  }

  private estimateDuration(distanceKm: number, mode: string): number {
    const speedKmh = {
      driving: 50,
      walking: 5,
      bicycling: 15,
      transit: 30,
    };

    return (distanceKm / speedKmh[mode as keyof typeof speedKmh]) * 60;
  }
}

export const transportationCalculator = new TransportationCalculator();
