import { db } from "@/lib/db";

export const NATIONAL_AVERAGES = {
  india: {
    overall: {
      urban: 185,
      rural: 95,
      national: 140,
    },
    byCategory: {
      transportation: {
        urban: 55,
        rural: 15,
        national: 35,
        breakdown: {
          personal_vehicle: 30,
          public_transport: 8,
          flights: 12,
          two_wheeler: 5,
        },
      },
      energy: {
        urban: 75,
        rural: 45,
        national: 60,
        breakdown: {
          electricity: 50,
          cooking_lpg: 15,
          heating_cooling: 10,
        },
      },
      food: {
        urban: 40,
        rural: 30,
        national: 35,
        breakdown: {
          vegetarian: 25,
          non_vegetarian: 45,
          mixed_diet: 35,
        },
      },
      waste: {
        urban: 15,
        rural: 5,
        national: 10,
        breakdown: {
          landfill: 8,
          recycling: -1,
          composting: -0.5,
        },
      },
    },
    byHouseholdSize: {
      1: 120,
      2: 180,
      3: 240,
      4: 300,
      5: 360,
      "6+": 420,
    },
    byIncome: {
      low: 80,
      middle: 150,
      upper_middle: 250,
      high: 400,
    },
    byCity: {
      mumbai: { multiplier: 1.3, avg: 240 },
      delhi: { multiplier: 1.35, avg: 250 },
      bangalore: { multiplier: 1.2, avg: 220 },
      chennai: { multiplier: 1.15, avg: 210 },
      kolkata: { multiplier: 1.1, avg: 200 },
      hyderabad: { multiplier: 1.15, avg: 210 },
      pune: { multiplier: 1.1, avg: 200 },
      ahmedabad: { multiplier: 1.05, avg: 190 },
      jaipur: { multiplier: 1.0, avg: 180 },
      lucknow: { multiplier: 0.95, avg: 170 },
    } as Record<string, { multiplier: number; avg: number }>,
  },

  global: {
    overall: {
      usa: 450,
      eu: 280,
      china: 250,
      world: 150,
      sustainable: 83,
    },
  },
};

export interface CohortConfig {
  country: string;
  city?: string;
  region?: string;
  householdSize: number;
  incomeBracket?: string;
  lifestyle?: "urban" | "suburban" | "rural";
}

export interface BenchmarkResult {
  userId: string;
  period: Date;
  cohortKey: string;
  userValue: number;
  cohortAverage: number;
  percentile: number;
  rank: number | null;
  totalInCohort: number;
  nationalAverage: number;
  globalComparison: {
    vsNational: number;
    vsWorld: number;
    vsSustainable: number;
  };
  improvementPotential: number;
  categoryBreakdown: CategoryBenchmark[];
}

export interface CategoryBenchmark {
  category: string;
  userValue: number;
  cohortAverage: number;
  nationalAverage: number;
  percentile: number;
  improvementPotential: number;
  topPerformers: number;
}

export interface CohortMember {
  userId: string;
  totalEmissions: number;
  categoryEmissions: Record<string, number>;
  joinedAt: Date;
}

export interface SyntheticUser {
  id: string;
  emissions: number;
  categoryEmissions: Record<string, number>;
  cohortKey: string;
}

function generateSyntheticCohort(
  cohortKey: string,
  config: CohortConfig,
  count: number = 100
): SyntheticUser[] {
  const users: SyntheticUser[] = [];

  const cityData =
    NATIONAL_AVERAGES.india.byCity[config.city?.toLowerCase() || ""];
  const multiplier = cityData?.multiplier || 1;
  const baseEmissions = NATIONAL_AVERAGES.india.overall.urban * multiplier;

  const sizeKey =
    config.householdSize >= 6 ? "6+" : String(config.householdSize);
  const sizeMultiplier =
    (NATIONAL_AVERAGES.india.byHouseholdSize as Record<string, number>)[
      sizeKey
    ] || 200;
  const adjustedBase = (sizeMultiplier + baseEmissions) / 2;

  for (let i = 0; i < count; i++) {
    const variation = (Math.random() - 0.5) * 0.6;
    const emissions = Math.max(50, adjustedBase * (1 + variation));

    const categoryEmissions: Record<string, number> = {
      transportation: emissions * (0.25 + Math.random() * 0.15),
      energy: emissions * (0.3 + Math.random() * 0.1),
      food: emissions * (0.2 + Math.random() * 0.1),
      waste: emissions * (0.08 + Math.random() * 0.07),
      consumption: emissions * (0.05 + Math.random() * 0.05),
    };

    users.push({
      id: `synthetic_${cohortKey}_${i}`,
      emissions: Math.round(emissions * 10) / 10,
      categoryEmissions,
      cohortKey,
    });
  }

  return users;
}

export function generateCohortKey(
  location: { country?: string; city?: string; region?: string },
  household: { size?: number; type?: string; income_bracket?: string }
): string {
  const country = (location?.country || "india")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-");
  const city = (location?.city || location?.region || "unknown")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-");
  const size = household?.size ?? 1;
  const income = household?.income_bracket?.toLowerCase()?.charAt(0) || "m";

  return `${country}_${city}_${size}p_${income}`;
}

export function parseCohortKey(cohortKey: string): CohortConfig {
  const parts = cohortKey.split("_");
  const sizePart = parts[2] || "1p";
  const size = parseInt(sizePart.replace("p", ""), 10) || 1;

  return {
    country: parts[0] || "india",
    city: parts[1] || "unknown",
    householdSize: size,
    incomeBracket:
      parts[3] === "l" ? "low" : parts[3] === "u" ? "high" : "middle",
  };
}

class EnhancedBenchmarkingService {
  async calculateBenchmark(
    userId: string,
    period: Date = new Date()
  ): Promise<BenchmarkResult | null> {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { location: true, household: true },
    });

    if (!user) return null;

    const location = user.location as {
      country?: string;
      city?: string;
      region?: string;
    } | null;
    const household = user.household as {
      size?: number;
      type?: string;
      income_bracket?: string;
    } | null;

    const cohortKey = generateCohortKey(location || {}, household || {});
    const config = parseCohortKey(cohortKey);

    const periodStart = new Date(period.getFullYear(), period.getMonth(), 1);
    const periodEnd = new Date(period.getFullYear(), period.getMonth() + 1, 1);

    const activities = await db.activityData.findMany({
      where: {
        userId,
        date: { gte: periodStart, lt: periodEnd },
      },
    });

    if (activities.length === 0) return null;

    const userValue = activities.reduce((sum, a) => sum + a.value, 0);
    const categoryEmissions: Record<string, number> = {};

    for (const activity of activities) {
      if (!categoryEmissions[activity.category]) {
        categoryEmissions[activity.category] = 0;
      }
      categoryEmissions[activity.category] += activity.value;
    }

    const realCohortMembers = await this.getRealCohortMembers(
      cohortKey,
      periodStart,
      periodEnd
    );

    const cohortData = [...realCohortMembers];
    if (cohortData.length < 50) {
      const syntheticUsers = generateSyntheticCohort(
        cohortKey,
        config,
        100 - cohortData.length
      );
      cohortData.push(
        ...syntheticUsers.map((s) => ({
          userId: s.id,
          totalEmissions: s.emissions,
          categoryEmissions: s.categoryEmissions,
          joinedAt: new Date(),
        }))
      );
    }

    const allValues = cohortData.map((m) => m.totalEmissions);
    const cohortAverage =
      allValues.reduce((a, b) => a + b, 0) / allValues.length;

    const sortedValues = [...allValues].sort((a, b) => a - b);
    const userIndex = sortedValues.findIndex((v) => v >= userValue);
    const percentile = Math.round(
      ((sortedValues.length - userIndex) / sortedValues.length) * 100
    );

    const rank = userIndex + 1;

    const nationalAverage = this.getNationalAverage(config);

    const globalComparison = {
      vsNational: Math.round(
        ((userValue - nationalAverage) / nationalAverage) * 100
      ),
      vsWorld: Math.round(
        ((userValue - NATIONAL_AVERAGES.global.overall.world) /
          NATIONAL_AVERAGES.global.overall.world) *
          100
      ),
      vsSustainable: Math.round(
        ((userValue - NATIONAL_AVERAGES.global.overall.sustainable) /
          NATIONAL_AVERAGES.global.overall.sustainable) *
          100
      ),
    };

    const top10Avg =
      sortedValues
        .slice(0, Math.max(1, Math.floor(sortedValues.length * 0.1)))
        .reduce((a, b) => a + b, 0) /
      Math.max(1, Math.floor(sortedValues.length * 0.1));
    const improvementPotential = Math.max(0, userValue - top10Avg);

    const categoryBreakdown = await this.calculateCategoryBenchmarks(
      categoryEmissions,
      cohortData,
      config
    );

    await this.saveBenchmark({
      userId,
      period: periodStart,
      cohortKey,
      userValue: Math.round(userValue * 100) / 100,
      cohortAverage: Math.round(cohortAverage * 100) / 100,
      percentile,
      rank,
      totalInCohort: cohortData.length,
    });

    return {
      userId,
      period: periodStart,
      cohortKey,
      userValue: Math.round(userValue * 100) / 100,
      cohortAverage: Math.round(cohortAverage * 100) / 100,
      percentile,
      rank,
      totalInCohort: cohortData.length,
      nationalAverage,
      globalComparison,
      improvementPotential: Math.round(improvementPotential * 100) / 100,
      categoryBreakdown,
    };
  }

  private async getRealCohortMembers(
    cohortKey: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<CohortMember[]> {
    const config = parseCohortKey(cohortKey);

    const users = await db.user.findMany({
      select: { id: true, location: true, household: true, createdAt: true },
    });

    const matchedUsers = users.filter((user) => {
      const loc = user.location as {
        country?: string;
        city?: string;
        region?: string;
      } | null;
      const hh = user.household as {
        size?: number;
        type?: string;
        income_bracket?: string;
      } | null;
      const userKey = generateCohortKey(loc || {}, hh || {});
      return userKey === cohortKey;
    });

    const members: CohortMember[] = [];

    for (const user of matchedUsers) {
      const activities = await db.activityData.findMany({
        where: {
          userId: user.id,
          date: { gte: periodStart, lt: periodEnd },
        },
      });

      if (activities.length > 0) {
        const totalEmissions = activities.reduce((sum, a) => sum + a.value, 0);
        const categoryEmissions: Record<string, number> = {};

        for (const activity of activities) {
          if (!categoryEmissions[activity.category]) {
            categoryEmissions[activity.category] = 0;
          }
          categoryEmissions[activity.category] += activity.value;
        }

        members.push({
          userId: user.id,
          totalEmissions,
          categoryEmissions,
          joinedAt: user.createdAt,
        });
      }
    }

    return members;
  }

  private getNationalAverage(config: CohortConfig): number {
    let base = NATIONAL_AVERAGES.india.overall.urban;

    const cityData =
      NATIONAL_AVERAGES.india.byCity[config.city?.toLowerCase() || ""];
    if (cityData) {
      base = cityData.avg;
    }

    const sizeKey =
      config.householdSize >= 6 ? "6+" : String(config.householdSize);
    const sizeAvg = (
      NATIONAL_AVERAGES.india.byHouseholdSize as Record<string, number>
    )[sizeKey];
    if (sizeAvg) {
      base = (base + sizeAvg) / 2;
    }

    if (config.incomeBracket) {
      const incomeMultiplier =
        {
          low: 0.7,
          middle: 1.0,
          upper_middle: 1.2,
          high: 1.5,
        }[config.incomeBracket] || 1;
      base *= incomeMultiplier;
    }

    return Math.round(base);
  }

  private async calculateCategoryBenchmarks(
    userCategoryEmissions: Record<string, number>,
    cohortData: CohortMember[],
    config: CohortConfig
  ): Promise<CategoryBenchmark[]> {
    const categories = [
      "transportation",
      "energy",
      "food",
      "waste",
      "consumption",
    ];
    const results: CategoryBenchmark[] = [];

    for (const category of categories) {
      const userValue = userCategoryEmissions[category] || 0;

      const cohortValues = cohortData
        .map((m) => m.categoryEmissions[category] || 0)
        .filter((v) => v > 0);

      if (cohortValues.length === 0) continue;

      const sortedValues = [...cohortValues].sort((a, b) => a - b);
      const cohortAverage =
        sortedValues.reduce((a, b) => a + b, 0) / sortedValues.length;

      const nationalAvg =
        NATIONAL_AVERAGES.india.byCategory[
          category as keyof typeof NATIONAL_AVERAGES.india.byCategory
        ]?.national || 0;

      const userIndex = sortedValues.findIndex((v) => v >= userValue);
      const percentile = Math.round(
        ((sortedValues.length - userIndex) / sortedValues.length) * 100
      );

      const top10Count = Math.max(1, Math.floor(sortedValues.length * 0.1));
      const topPerformers =
        sortedValues.slice(0, top10Count).reduce((a, b) => a + b, 0) /
        top10Count;

      results.push({
        category,
        userValue: Math.round(userValue * 100) / 100,
        cohortAverage: Math.round(cohortAverage * 100) / 100,
        nationalAverage: nationalAvg,
        percentile,
        improvementPotential:
          Math.round(Math.max(0, userValue - topPerformers) * 100) / 100,
        topPerformers: Math.round(topPerformers * 100) / 100,
      });
    }

    return results;
  }

  private async saveBenchmark(result: {
    userId: string;
    period: Date;
    cohortKey: string;
    userValue: number;
    cohortAverage: number;
    percentile: number;
    rank: number | null;
    totalInCohort: number;
  }): Promise<void> {
    await db.benchmark.create({
      data: {
        userId: result.userId,
        period: result.period,
        cohortKey: result.cohortKey,
        cohortAverage: result.cohortAverage,
        userValue: result.userValue,
        percentile: result.percentile,
        rank: result.rank,
        totalInCohort: result.totalInCohort,
      },
    });
  }

  async getHistoricalBenchmarks(
    userId: string,
    months: number = 12
  ): Promise<BenchmarkResult[]> {
    const benchmarks = await db.benchmark.findMany({
      where: { userId },
      orderBy: { period: "desc" },
      take: months,
    });

    const results: BenchmarkResult[] = [];

    for (const b of benchmarks) {
      const config = parseCohortKey(b.cohortKey);
      const nationalAverage = this.getNationalAverage(config);

      results.push({
        userId: b.userId,
        period: b.period,
        cohortKey: b.cohortKey,
        userValue: b.userValue,
        cohortAverage: b.cohortAverage,
        percentile: b.percentile,
        rank: b.rank,
        totalInCohort: b.totalInCohort,
        nationalAverage,
        globalComparison: {
          vsNational: Math.round(
            ((b.userValue - nationalAverage) / nationalAverage) * 100
          ),
          vsWorld: Math.round(
            ((b.userValue - NATIONAL_AVERAGES.global.overall.world) /
              NATIONAL_AVERAGES.global.overall.world) *
              100
          ),
          vsSustainable: Math.round(
            ((b.userValue - NATIONAL_AVERAGES.global.overall.sustainable) /
              NATIONAL_AVERAGES.global.overall.sustainable) *
              100
          ),
        },
        improvementPotential: Math.max(0, b.userValue - b.cohortAverage * 0.7),
        categoryBreakdown: [],
      });
    }

    return results.reverse();
  }

  async getCohortLeaderboard(
    cohortKey: string,
    limit: number = 10
  ): Promise<
    Array<{
      rank: number;
      userId: string;
      value: number;
      isCurrentUser?: boolean;
    }>
  > {
    const benchmarks = await db.benchmark.findMany({
      where: { cohortKey },
      orderBy: { userValue: "asc" },
      take: limit,
    });

    return benchmarks.map((b, index) => ({
      rank: index + 1,
      userId: b.userId.startsWith("synthetic_") ? "Anonymous User" : b.userId,
      value: b.userValue,
    }));
  }

  async runMonthlyBenchmarkCalculation(): Promise<void> {
    const users = await db.user.findMany({
      select: { id: true },
    });

    let processed = 0;
    for (const user of users) {
      try {
        await this.calculateBenchmark(user.id);
        processed++;
      } catch (error) {}
    }
  }

  async getComparisonSummary(userId: string): Promise<{
    yourEmissions: number;
    cohortAverage: number;
    nationalAverage: number;
    worldAverage: number;
    sustainableTarget: number;
    percentile: number;
    rankInCohort: number | null;
    cohortSize: number;
    topCategory: { category: string; improvementPotential: number };
    worstCategory: { category: string; percentage: number };
  } | null> {
    const benchmark = await this.calculateBenchmark(userId);

    if (!benchmark) return null;

    const categories = benchmark.categoryBreakdown;
    const sortedByPotential = [...categories].sort(
      (a, b) => b.improvementPotential - a.improvementPotential
    );

    const topCategory = sortedByPotential[0] || {
      category: "general",
      improvementPotential: 0,
    };
    const worstCategory = [...categories].sort(
      (a, b) => b.userValue - a.userValue
    )[0] || { category: "general", userValue: 0 };

    return {
      yourEmissions: benchmark.userValue,
      cohortAverage: benchmark.cohortAverage,
      nationalAverage: benchmark.nationalAverage,
      worldAverage: NATIONAL_AVERAGES.global.overall.world,
      sustainableTarget: NATIONAL_AVERAGES.global.overall.sustainable,
      percentile: benchmark.percentile,
      rankInCohort: benchmark.rank,
      cohortSize: benchmark.totalInCohort,
      topCategory: {
        category: topCategory.category,
        improvementPotential: topCategory.improvementPotential,
      },
      worstCategory: {
        category: worstCategory.category,
        percentage: worstCategory.percentile,
      },
    };
  }
}

export const benchmarkingService = new EnhancedBenchmarkingService();
export { EnhancedBenchmarkingService };
