import { prisma } from "@/lib/prisma";

export interface AchievementDefinition {
  key: string;
  title: string;
  description: string;
  icon: string;
  category: "milestone" | "streak" | "impact" | "exploration";
}

export interface UserAchievement {
  key: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  unlocked: boolean;
  unlockedAt?: Date;
  progress?: number;
  progressLabel?: string;
}

export const ACHIEVEMENT_DEFINITIONS: AchievementDefinition[] = [
  {
    key: "early_adopter",
    title: "Early Adopter",
    description: "Welcome to Aura! Your sustainability journey begins",
    icon: "🌱",
    category: "milestone",
  },
  {
    key: "first_calculation",
    title: "First Steps",
    description: "Complete your first carbon calculation",
    icon: "👣",
    category: "milestone",
  },
  {
    key: "five_calculations",
    title: "Getting Serious",
    description: "Complete 5 carbon calculations",
    icon: "📊",
    category: "milestone",
  },
  {
    key: "first_goal",
    title: "Goal Setter",
    description: "Create your first reduction goal",
    icon: "🎯",
    category: "milestone",
  },

  {
    key: "first_scenario",
    title: "What-If Explorer",
    description: "Create your first what-if scenario",
    icon: "🔮",
    category: "exploration",
  },
  {
    key: "all_categories",
    title: "Well-Rounded",
    description: "Log activities in all 4 categories",
    icon: "🌍",
    category: "exploration",
  },

  {
    key: "streak_3",
    title: "3-Day Streak",
    description: "Track emissions for 3 consecutive days",
    icon: "🔥",
    category: "streak",
  },
  {
    key: "streak_7",
    title: "Week Warrior",
    description: "Track emissions for 7 consecutive days",
    icon: "⚡",
    category: "streak",
  },
  {
    key: "streak_30",
    title: "Monthly Champion",
    description: "Track emissions for 30 consecutive days",
    icon: "🏆",
    category: "streak",
  },

  {
    key: "carbon_saver_10",
    title: "Carbon Cutter",
    description: "Reduce emissions by 10% vs your baseline",
    icon: "✂️",
    category: "impact",
  },
  {
    key: "carbon_saver_25",
    title: "Green Champion",
    description: "Reduce emissions by 25% vs your baseline",
    icon: "💚",
    category: "impact",
  },
  {
    key: "benchmark_top_25",
    title: "Top Quarter",
    description: "Rank in the top 25% of your peer cohort",
    icon: "🥇",
    category: "impact",
  },
];

export function calculateStreak(activityDates: Date[]): number {
  if (activityDates.length === 0) return 0;

  const uniqueDays = Array.from(
    new Set(
      activityDates.map((d) => {
        const dt = new Date(d);
        return `${dt.getFullYear()}-${dt.getMonth()}-${dt.getDate()}`;
      })
    )
  )
    .sort()
    .reverse();

  if (uniqueDays.length === 0) return 0;

  const today = new Date();
  const todayKey = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayKey = `${yesterday.getFullYear()}-${yesterday.getMonth()}-${yesterday.getDate()}`;

  if (uniqueDays[0] !== todayKey && uniqueDays[0] !== yesterdayKey) {
    return 0;
  }

  let streak = 1;
  for (let i = 1; i < uniqueDays.length; i++) {
    const [y1, m1, d1] = uniqueDays[i - 1].split("-").map(Number);
    const [y2, m2, d2] = uniqueDays[i].split("-").map(Number);
    const date1 = new Date(y1, m1, d1);
    const date2 = new Date(y2, m2, d2);
    const diffMs = date1.getTime() - date2.getTime();
    const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays === 1) {
      streak++;
    } else {
      break;
    }
  }

  return streak;
}

export function getUniqueCategories(categories: string[]): Set<string> {
  const normalized = new Set<string>();
  for (const cat of categories) {
    const key = cat.toLowerCase().trim();
    if (
      key.includes("transport") ||
      key.includes("travel") ||
      key.includes("vehicle")
    )
      normalized.add("transportation");
    else if (
      key.includes("energy") ||
      key.includes("electric") ||
      key.includes("power")
    )
      normalized.add("energy");
    else if (key.includes("food") || key.includes("diet"))
      normalized.add("food");
    else if (key.includes("waste") || key.includes("recycl"))
      normalized.add("waste");
  }
  return normalized;
}

export async function checkAndUnlockAchievements(
  userId: string
): Promise<UserAchievement[]> {
  const [
    existingAchievements,
    calculationCount,
    goalCount,
    scenarioCount,
    activityDates,
    activityCategories,
    benchmarks,
    calculations,
  ] = await Promise.all([
    prisma.achievement.findMany({ where: { userId } }),
    prisma.carbonCalculation.count({ where: { userId } }),
    prisma.goal.count({ where: { userId } }),
    prisma.scenario.count({ where: { userId } }),
    prisma.activityData.findMany({
      where: { userId },
      select: { date: true },
      orderBy: { date: "desc" },
    }),
    prisma.activityData.findMany({
      where: { userId },
      select: { category: true },
    }),
    prisma.benchmark.findMany({
      where: { userId },
      select: { percentile: true },
      orderBy: { createdAt: "desc" },
      take: 1,
    }),
    prisma.carbonCalculation.findMany({
      where: { userId },
      select: { totalEmissions: true, periodStart: true },
      orderBy: { periodStart: "asc" },
    }),
  ]);

  const unlockedKeys = new Set(existingAchievements.map((a) => a.key));
  const streak = calculateStreak(activityDates.map((a) => a.date));
  const uniqueCategories = getUniqueCategories(
    activityCategories.map((a) => a.category)
  );

  let reductionPercent = 0;
  if (calculations.length >= 2) {
    const firstThree = calculations.slice(0, Math.min(3, calculations.length));
    const lastThree = calculations.slice(-Math.min(3, calculations.length));
    const avgFirst =
      firstThree.reduce((s, c) => s + c.totalEmissions, 0) / firstThree.length;
    const avgLast =
      lastThree.reduce((s, c) => s + c.totalEmissions, 0) / lastThree.length;
    if (avgFirst > 0) {
      reductionPercent = ((avgFirst - avgLast) / avgFirst) * 100;
    }
  }

  const bestPercentile = benchmarks.length > 0 ? benchmarks[0].percentile : 0;

  const toUnlock: AchievementDefinition[] = [];

  for (const def of ACHIEVEMENT_DEFINITIONS) {
    if (unlockedKeys.has(def.key)) continue;

    let earned = false;
    switch (def.key) {
      case "early_adopter":
        earned = true;
        break;
      case "first_calculation":
        earned = calculationCount >= 1;
        break;
      case "five_calculations":
        earned = calculationCount >= 5;
        break;
      case "first_goal":
        earned = goalCount >= 1;
        break;
      case "first_scenario":
        earned = scenarioCount >= 1;
        break;
      case "all_categories":
        earned = uniqueCategories.size >= 4;
        break;
      case "streak_3":
        earned = streak >= 3;
        break;
      case "streak_7":
        earned = streak >= 7;
        break;
      case "streak_30":
        earned = streak >= 30;
        break;
      case "carbon_saver_10":
        earned = reductionPercent >= 10;
        break;
      case "carbon_saver_25":
        earned = reductionPercent >= 25;
        break;
      case "benchmark_top_25":
        earned = bestPercentile >= 75;
        break;
    }

    if (earned) {
      toUnlock.push(def);
    }
  }

  if (toUnlock.length > 0) {
    await prisma.achievement.createMany({
      data: toUnlock.map((def) => ({
        userId,
        key: def.key,
        title: def.title,
        description: def.description,
        icon: def.icon,
      })),
    });
  }

  const refreshed = await prisma.achievement.findMany({ where: { userId } });
  const unlockedMap = new Map(refreshed.map((a) => [a.key, a]));

  return ACHIEVEMENT_DEFINITIONS.map((def) => {
    const unlocked = unlockedMap.has(def.key);
    const achievement: UserAchievement = {
      key: def.key,
      title: def.title,
      description: def.description,
      icon: def.icon,
      category: def.category,
      unlocked,
      unlockedAt: unlocked ? unlockedMap.get(def.key)!.unlockedAt : undefined,
    };

    if (!unlocked) {
      switch (def.key) {
        case "five_calculations":
          achievement.progress = Math.min(100, (calculationCount / 5) * 100);
          achievement.progressLabel = `${Math.min(calculationCount, 5)}/5`;
          break;
        case "streak_3":
          achievement.progress = Math.min(100, (streak / 3) * 100);
          achievement.progressLabel = `${Math.min(streak, 3)}/3 days`;
          break;
        case "streak_7":
          achievement.progress = Math.min(100, (streak / 7) * 100);
          achievement.progressLabel = `${Math.min(streak, 7)}/7 days`;
          break;
        case "streak_30":
          achievement.progress = Math.min(100, (streak / 30) * 100);
          achievement.progressLabel = `${Math.min(streak, 30)}/30 days`;
          break;
        case "all_categories":
          achievement.progress = (uniqueCategories.size / 4) * 100;
          achievement.progressLabel = `${uniqueCategories.size}/4`;
          break;
        case "carbon_saver_10":
          achievement.progress = Math.min(
            100,
            (Math.max(0, reductionPercent) / 10) * 100
          );
          achievement.progressLabel = `${Math.max(0, Math.round(reductionPercent))}%/10%`;
          break;
        case "carbon_saver_25":
          achievement.progress = Math.min(
            100,
            (Math.max(0, reductionPercent) / 25) * 100
          );
          achievement.progressLabel = `${Math.max(0, Math.round(reductionPercent))}%/25%`;
          break;
      }
    }

    return achievement;
  });
}

export async function getUserAchievements(
  userId: string
): Promise<UserAchievement[]> {
  const existing = await prisma.achievement.findMany({ where: { userId } });
  const unlockedMap = new Map(existing.map((a) => [a.key, a]));

  return ACHIEVEMENT_DEFINITIONS.map((def) => ({
    key: def.key,
    title: def.title,
    description: def.description,
    icon: def.icon,
    category: def.category,
    unlocked: unlockedMap.has(def.key),
    unlockedAt: unlockedMap.get(def.key)?.unlockedAt,
  }));
}
