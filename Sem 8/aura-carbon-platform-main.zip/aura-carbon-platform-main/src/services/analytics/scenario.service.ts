import { prisma } from "@/lib/prisma";

export interface ScenarioModification {
  category: string;
  action: "reduce" | "replace" | "eliminate";
  percentage: number;
  description?: string;
}

export interface CategoryBreakdown {
  category: string;
  emissions: number;
}

export interface ScenarioResult {
  name: string;
  description?: string;
  modifications: ScenarioModification[];
  baselineEmissions: number;
  projectedEmissions: number;
  savingsAbsolute: number;
  savingsPercentage: number;
  breakdownBefore: CategoryBreakdown[];
  breakdownAfter: CategoryBreakdown[];
}

export interface SavedScenario {
  id: string;
  name: string;
  description: string | null;
  modifications: ScenarioModification[];
  baselineEmissions: number;
  projectedEmissions: number;
  savingsPercentage: number;
  createdAt: Date;
}

export async function calculateBaseline(
  userId: string
): Promise<CategoryBreakdown[]> {
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

  const activities = await prisma.activityData.findMany({
    where: {
      userId,
      date: { gte: threeMonthsAgo },
    },
    select: {
      category: true,
      value: true,
      date: true,
    },
  });

  if (activities.length === 0) return [];

  const categoryTotals = new Map<string, number>();
  for (const activity of activities) {
    const cat = normalizeCategory(activity.category);
    categoryTotals.set(cat, (categoryTotals.get(cat) || 0) + activity.value);
  }

  const months = new Set(
    activities.map((a) => `${a.date.getFullYear()}-${a.date.getMonth()}`)
  ).size;
  const divisor = Math.max(1, months);

  return Array.from(categoryTotals.entries())
    .map(([category, total]) => ({
      category,
      emissions: Math.round((total / divisor) * 100) / 100,
    }))
    .sort((a, b) => b.emissions - a.emissions);
}

export function normalizeCategory(category: string): string {
  const key = category.toLowerCase().trim();
  if (
    key.includes("transport") ||
    key.includes("travel") ||
    key.includes("vehicle") ||
    key.includes("commut")
  )
    return "transportation";
  if (
    key.includes("energy") ||
    key.includes("electric") ||
    key.includes("power") ||
    key.includes("gas")
  )
    return "energy";
  if (key.includes("food") || key.includes("diet") || key.includes("meal"))
    return "food";
  if (key.includes("waste") || key.includes("recycl") || key.includes("trash"))
    return "waste";
  if (key.includes("water")) return "water";
  return key || "other";
}

export function applyModifications(
  baseline: CategoryBreakdown[],
  modifications: ScenarioModification[]
): CategoryBreakdown[] {
  const projected = baseline.map((b) => ({ ...b }));

  for (const mod of modifications) {
    const target = projected.find(
      (p) => p.category === normalizeCategory(mod.category)
    );
    if (!target) continue;

    const reductionFactor = Math.max(0, Math.min(100, mod.percentage)) / 100;

    switch (mod.action) {
      case "eliminate":
        target.emissions = 0;
        break;
      case "reduce":
        target.emissions =
          Math.round(target.emissions * (1 - reductionFactor) * 100) / 100;
        break;
      case "replace":
        target.emissions =
          Math.round(target.emissions * (1 - reductionFactor) * 100) / 100;
        break;
    }
  }

  return projected;
}

export function calculateTotal(breakdown: CategoryBreakdown[]): number {
  return (
    Math.round(breakdown.reduce((sum, b) => sum + b.emissions, 0) * 100) / 100
  );
}

export function calculateSavings(
  baselineTotal: number,
  projectedTotal: number
): { absolute: number; percentage: number } {
  const absolute = Math.round((baselineTotal - projectedTotal) * 100) / 100;
  const percentage =
    baselineTotal > 0
      ? Math.round((absolute / baselineTotal) * 10000) / 100
      : 0;
  return { absolute, percentage };
}

export async function createScenario(
  userId: string,
  name: string,
  modifications: ScenarioModification[],
  description?: string
): Promise<ScenarioResult> {
  const baseline = await calculateBaseline(userId);
  const baselineTotal = calculateTotal(baseline);

  const projected = applyModifications(baseline, modifications);
  const projectedTotal = calculateTotal(projected);

  const savings = calculateSavings(baselineTotal, projectedTotal);

  return {
    name,
    description,
    modifications,
    baselineEmissions: baselineTotal,
    projectedEmissions: projectedTotal,
    savingsAbsolute: savings.absolute,
    savingsPercentage: savings.percentage,
    breakdownBefore: baseline,
    breakdownAfter: projected,
  };
}

export async function saveScenario(
  userId: string,
  result: ScenarioResult
): Promise<SavedScenario> {
  const saved = await prisma.scenario.create({
    data: {
      userId,
      name: result.name,
      description: result.description || null,
      modifications: result.modifications as any,
      baselineEmissions: result.baselineEmissions,
      projectedEmissions: result.projectedEmissions,
      savingsPercentage: result.savingsPercentage,
    },
  });

  return {
    id: saved.id,
    name: saved.name,
    description: saved.description,
    modifications: saved.modifications as unknown as ScenarioModification[],
    baselineEmissions: saved.baselineEmissions,
    projectedEmissions: saved.projectedEmissions,
    savingsPercentage: saved.savingsPercentage,
    createdAt: saved.createdAt,
  };
}

export async function getUserScenarios(
  userId: string
): Promise<SavedScenario[]> {
  const scenarios = await prisma.scenario.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });

  return scenarios.map((s) => ({
    id: s.id,
    name: s.name,
    description: s.description,
    modifications: s.modifications as unknown as ScenarioModification[],
    baselineEmissions: s.baselineEmissions,
    projectedEmissions: s.projectedEmissions,
    savingsPercentage: s.savingsPercentage,
    createdAt: s.createdAt,
  }));
}

export async function getScenarioById(
  id: string
): Promise<SavedScenario | null> {
  const s = await prisma.scenario.findUnique({ where: { id } });
  if (!s) return null;

  return {
    id: s.id,
    name: s.name,
    description: s.description,
    modifications: s.modifications as unknown as ScenarioModification[],
    baselineEmissions: s.baselineEmissions,
    projectedEmissions: s.projectedEmissions,
    savingsPercentage: s.savingsPercentage,
    createdAt: s.createdAt,
  };
}

export async function deleteScenario(id: string): Promise<boolean> {
  try {
    await prisma.scenario.delete({ where: { id } });
    return true;
  } catch {
    return false;
  }
}
