import { db } from "@/lib/db";

export interface AnomalyDetectionResult {
  id: string;
  date: Date;
  category: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: "low" | "medium" | "high";
  type: "spike" | "drop" | "pattern_change";
  confidence: number;
  possibleCauses: string[];
  suggestedActions: string[];
}

export interface HistoricalDataPoint {
  date: Date;
  value: number;
  category: string;
  subcategory?: string;
}

class AnomalyDetectionService {
  private readonly LOW_THRESHOLD = 1.5;
  private readonly MEDIUM_THRESHOLD = 2.0;
  private readonly HIGH_THRESHOLD = 3.0;

  async detectAnomalies(
    userId: string,
    options: {
      categories?: string[];
      daysBack?: number;
      minDataPoints?: number;
    } = {}
  ): Promise<AnomalyDetectionResult[]> {
    const { categories, daysBack = 90, minDataPoints = 14 } = options;

    const historicalData = await this.fetchHistoricalData(
      userId,
      daysBack,
      categories
    );

    if (historicalData.length < minDataPoints) {
      return [];
    }

    const groupedData = this.groupByCategory(historicalData);

    const anomalies: AnomalyDetectionResult[] = [];

    for (const [category, data] of Object.entries(groupedData)) {
      if (data.length < minDataPoints) continue;

      const categoryAnomalies = this.detectCategoryAnomalies(category, data);
      anomalies.push(...categoryAnomalies);
    }

    await this.saveAnomalies(userId, anomalies);

    return anomalies;
  }

  private async fetchHistoricalData(
    userId: string,
    daysBack: number,
    categories?: string[]
  ): Promise<HistoricalDataPoint[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);

    const whereClause: {
      userId: string;
      date: { gte: Date };
      category?: { in: string[] };
    } = {
      userId,
      date: { gte: cutoffDate },
    };

    if (categories && categories.length > 0) {
      whereClause.category = { in: categories };
    }

    const activities = await db.activityData.findMany({
      where: whereClause,
      orderBy: { date: "asc" },
    });

    return activities.map((a) => ({
      date: a.date,
      value: a.value,
      category: a.category,
      subcategory: a.subcategory,
    }));
  }

  private groupByCategory(
    data: HistoricalDataPoint[]
  ): Record<string, HistoricalDataPoint[]> {
    return data.reduce(
      (acc, point) => {
        if (!acc[point.category]) {
          acc[point.category] = [];
        }
        acc[point.category].push(point);
        return acc;
      },
      {} as Record<string, HistoricalDataPoint[]>
    );
  }

  private detectCategoryAnomalies(
    category: string,
    data: HistoricalDataPoint[]
  ): AnomalyDetectionResult[] {
    const anomalies: AnomalyDetectionResult[] = [];

    const sorted = [...data].sort(
      (a, b) => a.date.getTime() - b.date.getTime()
    );

    const zScoreAnomalies = this.detectZScoreAnomalies(category, sorted);
    anomalies.push(...zScoreAnomalies);

    const maAnomalies = this.detectMovingAverageAnomalies(category, sorted);
    anomalies.push(...maAnomalies);

    const seasonalAnomalies = this.detectSeasonalAnomalies(category, sorted);
    anomalies.push(...seasonalAnomalies);

    return this.deduplicateAnomalies(anomalies);
  }

  private detectZScoreAnomalies(
    category: string,
    data: HistoricalDataPoint[]
  ): AnomalyDetectionResult[] {
    const values = data.map((d) => d.value);
    const mean = this.calculateMean(values);
    const stdDev = this.calculateStdDev(values, mean);

    if (stdDev === 0) return [];

    const anomalies: AnomalyDetectionResult[] = [];

    const recentData = data.slice(-14);

    for (const point of recentData) {
      const zScore = Math.abs((point.value - mean) / stdDev);

      if (zScore >= this.LOW_THRESHOLD) {
        anomalies.push({
          id: `anomaly-zscore-${category}-${point.date.toISOString()}`,
          date: point.date,
          category,
          expectedValue: mean,
          actualValue: point.value,
          deviation: zScore,
          severity: this.getSeverity(zScore),
          type: point.value > mean ? "spike" : "drop",
          confidence: Math.min(0.95, 0.5 + zScore * 0.15),
          possibleCauses: this.identifyPossibleCauses(
            category,
            point.value > mean
          ),
          suggestedActions: this.suggestActions(category, point.value > mean),
        });
      }
    }

    return anomalies;
  }

  private detectMovingAverageAnomalies(
    category: string,
    data: HistoricalDataPoint[]
  ): AnomalyDetectionResult[] {
    if (data.length < 7) return [];

    const windowSize = 7;
    const anomalies: AnomalyDetectionResult[] = [];

    for (let i = windowSize; i < data.length; i++) {
      const window = data.slice(i - windowSize, i);
      const windowValues = window.map((d) => d.value);
      const ma = this.calculateMean(windowValues);
      const maStdDev = this.calculateStdDev(windowValues, ma);

      const upperBound = ma + 2 * maStdDev;
      const lowerBound = ma - 2 * maStdDev;

      const current = data[i];

      if (current.value > upperBound || current.value < lowerBound) {
        const deviation = Math.abs(current.value - ma) / (maStdDev || 1);

        anomalies.push({
          id: `anomaly-ma-${category}-${current.date.toISOString()}`,
          date: current.date,
          category,
          expectedValue: ma,
          actualValue: current.value,
          deviation,
          severity: this.getSeverity(deviation),
          type: current.value > ma ? "spike" : "drop",
          confidence: 0.8,
          possibleCauses: this.identifyPossibleCauses(
            category,
            current.value > ma
          ),
          suggestedActions: this.suggestActions(category, current.value > ma),
        });
      }
    }

    return anomalies;
  }

  private detectSeasonalAnomalies(
    category: string,
    data: HistoricalDataPoint[]
  ): AnomalyDetectionResult[] {
    if (data.length < 30) return [];

    const anomalies: AnomalyDetectionResult[] = [];

    const dayOfWeekGroups: Record<number, number[]> = {};

    for (const point of data) {
      const dayOfWeek = point.date.getDay();
      if (!dayOfWeekGroups[dayOfWeek]) {
        dayOfWeekGroups[dayOfWeek] = [];
      }
      dayOfWeekGroups[dayOfWeek].push(point.value);
    }

    const dayOfWeekStats: Record<number, { mean: number; stdDev: number }> = {};

    for (const [day, values] of Object.entries(dayOfWeekGroups)) {
      const mean = this.calculateMean(values);
      const stdDev = this.calculateStdDev(values, mean);
      dayOfWeekStats[Number(day)] = { mean, stdDev };
    }

    const recentData = data.slice(-7);

    for (const point of recentData) {
      const dayOfWeek = point.date.getDay();
      const stats = dayOfWeekStats[dayOfWeek];

      if (!stats || stats.stdDev === 0) continue;

      const deviation = Math.abs((point.value - stats.mean) / stats.stdDev);

      if (deviation >= this.MEDIUM_THRESHOLD) {
        anomalies.push({
          id: `anomaly-seasonal-${category}-${point.date.toISOString()}`,
          date: point.date,
          category,
          expectedValue: stats.mean,
          actualValue: point.value,
          deviation,
          severity: this.getSeverity(deviation),
          type: "pattern_change",
          confidence: 0.75,
          possibleCauses: [
            "Unusual activity for this day of week",
            "Schedule change or special event",
            "Data entry error",
          ],
          suggestedActions: [
            "Verify if activity was unusual",
            "Check for data entry errors",
            "Update your regular schedule in settings",
          ],
        });
      }
    }

    return anomalies;
  }

  private calculateMean(values: number[]): number {
    if (values.length === 0) return 0;
    return values.reduce((sum, v) => sum + v, 0) / values.length;
  }

  private calculateStdDev(values: number[], mean: number): number {
    if (values.length === 0) return 0;
    const squaredDiffs = values.map((v) => Math.pow(v - mean, 2));
    return Math.sqrt(this.calculateMean(squaredDiffs));
  }

  private getSeverity(zScore: number): "low" | "medium" | "high" {
    if (zScore >= this.HIGH_THRESHOLD) return "high";
    if (zScore >= this.MEDIUM_THRESHOLD) return "medium";
    return "low";
  }

  private identifyPossibleCauses(category: string, isSpike: boolean): string[] {
    const causes: Record<string, { spike: string[]; drop: string[] }> = {
      transportation: {
        spike: [
          "Long-distance trip or vacation",
          "Vehicle maintenance issues",
          "Changed commute route",
          "Rental car usage",
        ],
        drop: [
          "Working from home more",
          "Switched to public transport",
          "Carpooling",
          "Vehicle was unused",
        ],
      },
      energy: {
        spike: [
          "Extreme weather (AC/heating)",
          "Guests staying over",
          "New appliance usage",
          "Meter reading error",
        ],
        drop: [
          "Away from home",
          "Energy efficiency improvements",
          "Solar panel generation",
          "Reduced appliance usage",
        ],
      },
      food: {
        spike: [
          "Special occasions/dining out",
          "High-impact food choices",
          "Food waste",
          "Bulk purchasing",
        ],
        drop: [
          "Dietary changes",
          "Reduced food waste",
          "More plant-based meals",
          "Eating out less",
        ],
      },
      waste: {
        spike: [
          "Home renovation",
          "Decluttering/spring cleaning",
          "Package deliveries",
          "Special disposal needs",
        ],
        drop: [
          "Better recycling habits",
          "Reduced consumption",
          "Composting",
          "Reusing items",
        ],
      },
    };

    const categoryCauses = causes[category] || {
      spike: ["Unusual activity"],
      drop: ["Reduced activity"],
    };

    return isSpike ? categoryCauses.spike : categoryCauses.drop;
  }

  private suggestActions(category: string, isSpike: boolean): string[] {
    if (isSpike) {
      return [
        `Review your ${category} activities for this period`,
        "Check if this was a one-time event or pattern",
        "Consider offsetting if needed",
        "Set a reminder to track more carefully",
      ];
    } else {
      return [
        "Great job reducing emissions!",
        "Keep up the good habits",
        "Consider sharing your tips with others",
        "Set this as a new baseline goal",
      ];
    }
  }

  private deduplicateAnomalies(
    anomalies: AnomalyDetectionResult[]
  ): AnomalyDetectionResult[] {
    const seen = new Map<string, AnomalyDetectionResult>();

    for (const anomaly of anomalies) {
      const key = `${anomaly.category}-${anomaly.date.toISOString().split("T")[0]}`;
      const existing = seen.get(key);

      if (!existing || anomaly.deviation > existing.deviation) {
        seen.set(key, anomaly);
      }
    }

    return Array.from(seen.values());
  }

  private async saveAnomalies(
    userId: string,
    anomalies: AnomalyDetectionResult[]
  ): Promise<void> {
    for (const anomaly of anomalies) {
      const existing = await db.anomaly.findFirst({
        where: {
          userId,
          category: anomaly.category,
          date: anomaly.date,
        },
      });

      if (!existing) {
        await db.anomaly.create({
          data: {
            userId,
            date: anomaly.date,
            category: anomaly.category,
            expectedValue: anomaly.expectedValue,
            actualValue: anomaly.actualValue,
            deviation: anomaly.deviation,
            severity: anomaly.severity,
            acknowledged: false,
          },
        });
      }
    }
  }

  async getUnacknowledgedAnomalies(
    userId: string
  ): Promise<AnomalyDetectionResult[]> {
    const dbAnomalies = await db.anomaly.findMany({
      where: {
        userId,
        acknowledged: false,
      },
      orderBy: { date: "desc" },
    });

    return dbAnomalies.map((a) => ({
      id: a.id,
      date: a.date,
      category: a.category,
      expectedValue: a.expectedValue,
      actualValue: a.actualValue,
      deviation: a.deviation,
      severity: a.severity as "low" | "medium" | "high",
      type: a.actualValue > a.expectedValue ? "spike" : "drop",
      confidence: 0.8,
      possibleCauses: this.identifyPossibleCauses(
        a.category,
        a.actualValue > a.expectedValue
      ),
      suggestedActions: this.suggestActions(
        a.category,
        a.actualValue > a.expectedValue
      ),
    }));
  }

  async acknowledgeAnomaly(userId: string, anomalyId: string): Promise<void> {
    await db.anomaly.update({
      where: { id: anomalyId, userId },
      data: { acknowledged: true },
    });
  }

  async runDailyDetection(): Promise<void> {
    const users = await db.user.findMany({
      select: { id: true },
      where: {
        activityData: {
          some: {},
        },
      },
    });

    for (const user of users) {
      try {
        await this.detectAnomalies(user.id);
      } catch (error) {}
    }
  }
}

export const anomalyDetectionService = new AnomalyDetectionService();
export { AnomalyDetectionService };
