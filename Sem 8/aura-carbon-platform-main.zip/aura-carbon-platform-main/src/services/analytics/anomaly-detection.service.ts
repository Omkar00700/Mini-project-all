export function calculateMean(values: number[]): number {
  if (values.length === 0) return 0;
  const sum = values.reduce((acc, val) => acc + val, 0);
  return sum / values.length;
}

export function calculateStdDev(values: number[], mean?: number): number {
  if (values.length === 0) return 0;

  const avg = mean ?? calculateMean(values);
  const squaredDiffs = values.map((val) => Math.pow(val - avg, 2));
  const variance = calculateMean(squaredDiffs);

  return Math.sqrt(variance);
}

export function calculateQuartiles(values: number[]): {
  q1: number;
  q2: number;
  q3: number;
  iqr: number;
} {
  if (values.length === 0) {
    return { q1: 0, q2: 0, q3: 0, iqr: 0 };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;

  const q1Index = Math.floor(n * 0.25);
  const q2Index = Math.floor(n * 0.5);
  const q3Index = Math.floor(n * 0.75);

  const q1 = sorted[q1Index];
  const q2 = sorted[q2Index];
  const q3 = sorted[q3Index];
  const iqr = q3 - q1;

  return { q1, q2, q3, iqr };
}

export function detectAnomalyZScore(
  value: number,
  mean: number,
  stdDev: number,
  threshold: number = 2
): {
  isAnomaly: boolean;
  deviation: number;
  severity: "low" | "medium" | "high";
} {
  if (stdDev === 0) {
    return { isAnomaly: false, deviation: 0, severity: "low" };
  }

  const deviation = Math.abs((value - mean) / stdDev);
  const isAnomaly = deviation > threshold;

  let severity: "low" | "medium" | "high" = "low";
  if (deviation > 3) {
    severity = "high";
  } else if (deviation > 2.5) {
    severity = "medium";
  }

  return { isAnomaly, deviation, severity };
}

export function detectAnomalyIQR(
  value: number,
  q1: number,
  q3: number,
  iqr: number,
  multiplier: number = 1.5
): {
  isAnomaly: boolean;
  deviation: number;
  severity: "low" | "medium" | "high";
} {
  if (iqr === 0) {
    return { isAnomaly: false, deviation: 0, severity: "low" };
  }

  const lowerBound = q1 - multiplier * iqr;
  const upperBound = q3 + multiplier * iqr;

  const isAnomaly = value < lowerBound || value > upperBound;

  let deviation = 0;
  if (value < lowerBound) {
    deviation = (lowerBound - value) / iqr;
  } else if (value > upperBound) {
    deviation = (value - upperBound) / iqr;
  }

  let severity: "low" | "medium" | "high" = "low";
  if (deviation > 3) {
    severity = "high";
  } else if (deviation > 2) {
    severity = "medium";
  }

  return { isAnomaly, deviation, severity };
}

export function calculateRollingStats(
  values: { date: Date; value: number }[],
  windowSize: number = 30
): {
  mean: number;
  stdDev: number;
  q1: number;
  q3: number;
  iqr: number;
} {
  const sorted = [...values].sort(
    (a, b) => b.date.getTime() - a.date.getTime()
  );

  const window = sorted.slice(0, windowSize).map((v) => v.value);

  const mean = calculateMean(window);
  const stdDev = calculateStdDev(window, mean);
  const quartiles = calculateQuartiles(window);

  return {
    mean,
    stdDev,
    ...quartiles,
  };
}

import { PrismaClient } from "../../../generated/prisma";

const prisma = new PrismaClient();

export interface TimeSeriesDataPoint {
  date: Date;
  value: number;
  category?: string;
}

export async function getUserEmissionsTimeSeries(
  userId: string,
  category?: string,
  daysBack: number = 90
): Promise<TimeSeriesDataPoint[]> {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysBack);

  const activityData = await prisma.activityData.findMany({
    where: {
      userId,
      date: {
        gte: cutoffDate,
      },
      ...(category ? { category } : {}),
    },
    orderBy: {
      date: "asc",
    },
  });

  const dailyEmissions = new Map<
    string,
    { date: Date; total: number; category?: string }
  >();

  for (const activity of activityData) {
    const dateKey = activity.date.toISOString().split("T")[0];

    if (!dailyEmissions.has(dateKey)) {
      dailyEmissions.set(dateKey, {
        date: activity.date,
        total: activity.value,
        category: activity.category,
      });
    } else {
      const existing = dailyEmissions.get(dateKey)!;
      existing.total += activity.value;
    }
  }

  return Array.from(dailyEmissions.values()).map((d) => ({
    date: d.date,
    value: d.total,
    category: d.category,
  }));
}

export interface AnomalyDetectionResult {
  isAnomaly: boolean;
  date: Date;
  category: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: "low" | "medium" | "high";
  method: "zscore" | "iqr";
}

export async function detectAnomaliesForUser(
  userId: string,
  category: string,
  method: "zscore" | "iqr" = "zscore",
  windowSize: number = 30
): Promise<AnomalyDetectionResult[]> {
  const timeSeries = await getUserEmissionsTimeSeries(userId, category);

  if (timeSeries.length < 10) {
    return [];
  }

  const anomalies: AnomalyDetectionResult[] = [];

  for (let i = windowSize; i < timeSeries.length; i++) {
    const currentPoint = timeSeries[i];
    const historicalWindow = timeSeries.slice(Math.max(0, i - windowSize), i);

    const stats = calculateRollingStats(historicalWindow, windowSize);

    let detectionResult;

    if (method === "zscore") {
      detectionResult = detectAnomalyZScore(
        currentPoint.value,
        stats.mean,
        stats.stdDev
      );
    } else {
      detectionResult = detectAnomalyIQR(
        currentPoint.value,
        stats.q1,
        stats.q3,
        stats.iqr
      );
    }

    if (detectionResult.isAnomaly) {
      anomalies.push({
        isAnomaly: true,
        date: currentPoint.date,
        category,
        expectedValue: stats.mean,
        actualValue: currentPoint.value,
        deviation: detectionResult.deviation,
        severity: detectionResult.severity,
        method,
      });
    }
  }

  return anomalies;
}

export async function saveAnomalyToDatabase(
  userId: string,
  anomaly: AnomalyDetectionResult
): Promise<void> {
  await prisma.anomaly.create({
    data: {
      userId,
      date: anomaly.date,
      category: anomaly.category,
      expectedValue: anomaly.expectedValue,
      actualValue: anomaly.actualValue,
      deviation: anomaly.deviation,
      severity: anomaly.severity,
      acknowledged: false,
    },
  });
}

export async function runAnomalyDetectionForUser(
  userId: string,
  categories: string[] = ["energy", "transportation", "food", "waste"]
): Promise<{ detected: number; saved: number }> {
  let totalDetected = 0;
  let totalSaved = 0;

  for (const category of categories) {
    const anomalies = await detectAnomaliesForUser(userId, category);
    totalDetected += anomalies.length;

    for (const anomaly of anomalies) {
      const existing = await prisma.anomaly.findFirst({
        where: {
          userId,
          date: anomaly.date,
          category,
        },
      });

      if (!existing) {
        await saveAnomalyToDatabase(userId, anomaly);
        totalSaved++;
      }
    }
  }

  return { detected: totalDetected, saved: totalSaved };
}
