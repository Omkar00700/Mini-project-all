import { prisma } from "@/lib/prisma";

export interface TimeSeriesPoint {
  date: Date;
  value: number;
}

export interface ForecastPoint {
  forecastDate: Date;
  predictedValue: number;
  confidenceLevel: number;
  lowerBound: number;
  upperBound: number;
  model: string;
}

export interface TrendResult {
  slope: number;
  intercept: number;
  rSquared: number;
  direction: "increasing" | "decreasing" | "stable";
}

export interface CategoryForecast {
  category: string;
  forecasts: ForecastPoint[];
}

export interface ForecastResult {
  userId: string;
  forecasts: ForecastPoint[];
  categoryForecasts?: CategoryForecast[];
  trend: TrendResult;
  historicalAverage: number;
  model: string;
}

export function calculateMovingAverage(
  historicalNodes: number[],
  aggregationWindow: number
): number[] {
  if (historicalNodes.length === 0 || aggregationWindow <= 0) return [];
  if (aggregationWindow > historicalNodes.length) {
    return [
      historicalNodes.reduce((a, b) => a + b, 0) / historicalNodes.length,
    ];
  }

  const rollingAverages: number[] = [];
  for (
    let pointer = aggregationWindow - 1;
    pointer < historicalNodes.length;
    pointer++
  ) {
    const frame = historicalNodes.slice(
      pointer - aggregationWindow + 1,
      pointer + 1
    );
    const frameMean = frame.reduce((a, b) => a + b, 0) / aggregationWindow;
    rollingAverages.push(Math.round(frameMean * 100) / 100);
  }
  return rollingAverages;
}

export function forecastWithMovingAverage(
  historicalNodes: number[],
  aggregationWindow: number,
  horizon: number
): number[] {
  if (historicalNodes.length === 0 || horizon <= 0) return [];

  const constrainedWindow = Math.min(aggregationWindow, historicalNodes.length);
  const volatileSequence = [...historicalNodes];
  const horizonPredictions: number[] = [];

  for (let step = 0; step < horizon; step++) {
    const frame = volatileSequence.slice(-constrainedWindow);
    const synthesizedNode =
      frame.reduce((a, b) => a + b, 0) / constrainedWindow;
    horizonPredictions.push(Math.round(synthesizedNode * 100) / 100);
    volatileSequence.push(synthesizedNode);
  }

  return horizonPredictions;
}

export function calculateExponentialMovingAverage(
  historicalNodes: number[],
  smoothingDecay?: number
): number[] {
  if (historicalNodes.length === 0) return [];

  const computedDecay = smoothingDecay ?? 2 / (historicalNodes.length + 1);
  const constrainedDecay = Math.max(0.01, Math.min(1, computedDecay));
  const exponentialSequence: number[] = [historicalNodes[0]];

  for (let pointer = 1; pointer < historicalNodes.length; pointer++) {
    const weightedEMA =
      constrainedDecay * historicalNodes[pointer] +
      (1 - constrainedDecay) * exponentialSequence[pointer - 1];
    exponentialSequence.push(Math.round(weightedEMA * 100) / 100);
  }

  return exponentialSequence;
}

export function forecastWithHoltWinters(
  historicalNodes: number[],
  levelSmoothing: number = 0.3,
  trendSmoothing: number = 0.1,
  horizon: number
): number[] {
  if (historicalNodes.length === 0 || horizon <= 0) return [];
  if (historicalNodes.length === 1)
    return new Array(horizon).fill(historicalNodes[0]);

  let baselineLevel = historicalNodes[0];
  let structuralTrend = historicalNodes[1] - historicalNodes[0];

  for (let pointer = 1; pointer < historicalNodes.length; pointer++) {
    const previousLevel = baselineLevel;
    baselineLevel =
      levelSmoothing * historicalNodes[pointer] +
      (1 - levelSmoothing) * (previousLevel + structuralTrend);
    structuralTrend =
      trendSmoothing * (baselineLevel - previousLevel) +
      (1 - trendSmoothing) * structuralTrend;
  }

  const generatedPath: number[] = [];
  for (let step = 1; step <= horizon; step++) {
    const predictedNode = Math.max(0, baselineLevel + step * structuralTrend);
    generatedPath.push(Math.round(predictedNode * 100) / 100);
  }

  return generatedPath;
}

export function calculateLinearTrend(
  temporalCoordinates: { x: number; y: number }[]
): TrendResult {
  if (temporalCoordinates.length === 0)
    return { slope: 0, intercept: 0, rSquared: 0, direction: "stable" };
  if (temporalCoordinates.length === 1)
    return {
      slope: 0,
      intercept: temporalCoordinates[0].y,
      rSquared: 1,
      direction: "stable",
    };

  const coordinateLength = temporalCoordinates.length;
  let sumX = 0,
    sumY = 0,
    sumXY = 0,
    sumX2 = 0;

  for (const coord of temporalCoordinates) {
    sumX += coord.x;
    sumY += coord.y;
    sumXY += coord.x * coord.y;
    sumX2 += coord.x * coord.x;
  }

  const denominator = coordinateLength * sumX2 - sumX * sumX;
  const slope =
    denominator === 0
      ? 0
      : (coordinateLength * sumXY - sumX * sumY) / denominator;
  const intercept = (sumY - slope * sumX) / coordinateLength;

  const centroidY = sumY / coordinateLength;
  const ssTotal = temporalCoordinates.reduce(
    (sum, p) => sum + (p.y - centroidY) ** 2,
    0
  );
  const ssResidual = temporalCoordinates.reduce(
    (sum, p) => sum + (p.y - (slope * p.x + intercept)) ** 2,
    0
  );
  const rSquared = ssTotal === 0 ? 1 : Math.max(0, 1 - ssResidual / ssTotal);

  const deltaThreshold = Math.abs(centroidY) * 0.02;
  const trendVector: TrendResult["direction"] =
    slope > deltaThreshold
      ? "increasing"
      : slope < -deltaThreshold
        ? "decreasing"
        : "stable";

  return {
    slope: Math.round(slope * 1000) / 1000,
    intercept: Math.round(intercept * 100) / 100,
    rSquared: Math.round(rSquared * 1000) / 1000,
    direction: trendVector,
  };
}

export function forecastWithLinearRegression(
  temporalCoordinates: { x: number; y: number }[],
  horizon: number
): number[] {
  if (temporalCoordinates.length === 0 || horizon <= 0) return [];

  const deterministicTrend = calculateLinearTrend(temporalCoordinates);
  const finalX = temporalCoordinates[temporalCoordinates.length - 1].x;

  const horizonPredictions: number[] = [];
  for (let step = 1; step <= horizon; step++) {
    const coordinateOutput = Math.max(
      0,
      deterministicTrend.slope * (finalX + step) + deterministicTrend.intercept
    );
    horizonPredictions.push(Math.round(coordinateOutput * 100) / 100);
  }

  return horizonPredictions;
}

export function detectSeasonality(
  historicalNodes: number[],
  cycleFrequency: number = 12
): number[] {
  if (historicalNodes.length < cycleFrequency) {
    return new Array(cycleFrequency).fill(1.0);
  }

  const globalCentroid =
    historicalNodes.reduce((a, b) => a + b, 0) / historicalNodes.length;
  if (globalCentroid === 0) return new Array(cycleFrequency).fill(1.0);

  const cyclicalSummations = new Array(cycleFrequency).fill(0);
  const cyclicalWeights = new Array(cycleFrequency).fill(0);

  for (let pointer = 0; pointer < historicalNodes.length; pointer++) {
    const phaseAlign = pointer % cycleFrequency;
    cyclicalSummations[phaseAlign] += historicalNodes[pointer];
    cyclicalWeights[phaseAlign]++;
  }

  return cyclicalSummations.map((aggregate, phase) => {
    const phaseMean =
      cyclicalWeights[phase] > 0
        ? aggregate / cyclicalWeights[phase]
        : globalCentroid;
    return Math.round((phaseMean / globalCentroid) * 1000) / 1000;
  });
}

export function calculateStandardError(
  baselineCoordinates: number[],
  regressedCoordinates: number[]
): number {
  if (baselineCoordinates.length === 0 || regressedCoordinates.length === 0)
    return 0;

  const validIntersection = Math.min(
    baselineCoordinates.length,
    regressedCoordinates.length
  );
  const ssError = baselineCoordinates
    .slice(0, validIntersection)
    .reduce(
      (errorAcc, node, index) =>
        errorAcc + (node - regressedCoordinates[index]) ** 2,
      0
    );

  return Math.sqrt(ssError / validIntersection);
}

export function calculateConfidenceInterval(
  targetVector: number,
  stdErrorDeviation: number,
  certaintyCeiling: number = 0.95,
  forwardSteps: number = 1
): { lower: number; upper: number } {
  const certaintyMapping: Record<number, number> = {
    0.8: 1.282,
    0.9: 1.645,
    0.95: 1.96,
    0.99: 2.576,
  };

  const confidenceZ = certaintyMapping[certaintyCeiling] || 1.96;
  const temporalExpansion = Math.sqrt(forwardSteps);
  const deviationMargin = confidenceZ * stdErrorDeviation * temporalExpansion;

  return {
    lower: Math.max(
      0,
      Math.round((targetVector - deviationMargin) * 100) / 100
    ),
    upper: Math.round((targetVector + deviationMargin) * 100) / 100,
  };
}

export function calculateConfidenceDecay(
  baselineFidelity: number,
  forwardSteps: number,
  decayCoefficient: number = 0.08
): number {
  const decayedFidelity =
    baselineFidelity * Math.exp(-decayCoefficient * forwardSteps);
  return Math.round(Math.max(0.1, Math.min(1, decayedFidelity)) * 100) / 100;
}

export async function generateForecast(
  userId: string,
  projectionWindow: number = 6,
  modelArchitecture: string = "exponential-smoothing"
): Promise<ForecastResult | null> {
  const legacyEmissions = await getHistoricalMonthlyEmissions(userId);

  if (legacyEmissions.length < 3) return null;

  const quantitativeVectors = legacyEmissions.map((metric) => metric.value);
  const baselineCentroid =
    quantitativeVectors.reduce((a, b) => a + b, 0) / quantitativeVectors.length;

  let modelPredictions: number[];
  let deterministicTrend: TrendResult;

  if (modelArchitecture === "moving-average") {
    const adaptiveWindow = Math.min(3, quantitativeVectors.length);
    modelPredictions = forecastWithMovingAverage(
      quantitativeVectors,
      adaptiveWindow,
      projectionWindow
    );
    deterministicTrend = calculateLinearTrend(
      quantitativeVectors.map((v, i) => ({ x: i, y: v }))
    );
  } else if (modelArchitecture === "linear-regression") {
    const relationalCoordinates = quantitativeVectors.map((v, i) => ({
      x: i,
      y: v,
    }));
    modelPredictions = forecastWithLinearRegression(
      relationalCoordinates,
      projectionWindow
    );
    deterministicTrend = calculateLinearTrend(relationalCoordinates);
  } else {
    modelPredictions = forecastWithHoltWinters(
      quantitativeVectors,
      0.4,
      0.2,
      projectionWindow
    );
    deterministicTrend = calculateLinearTrend(
      quantitativeVectors.map((v, i) => ({ x: i, y: v }))
    );
  }

  const modelFittedVectors: number[] = [];
  if (modelArchitecture === "exponential-smoothing") {
    let baseLvl = quantitativeVectors[0];
    let structTrn =
      quantitativeVectors.length > 1
        ? quantitativeVectors[1] - quantitativeVectors[0]
        : 0;
    modelFittedVectors.push(baseLvl);
    for (let point = 1; point < quantitativeVectors.length; point++) {
      const parentLvl = baseLvl;
      baseLvl =
        0.4 * quantitativeVectors[point] + (1 - 0.4) * (parentLvl + structTrn);
      structTrn = 0.2 * (baseLvl - parentLvl) + (1 - 0.2) * structTrn;
      modelFittedVectors.push(baseLvl);
    }
  } else {
    for (let point = 0; point < quantitativeVectors.length; point++) {
      modelFittedVectors.push(
        deterministicTrend.slope * point + deterministicTrend.intercept
      );
    }
  }

  const errorVariance =
    quantitativeVectors.reduce(
      (cumulative, val, index) =>
        cumulative + Math.pow(val - modelFittedVectors[index], 2),
      0
    ) / quantitativeVectors.length;
  const deviationError = Math.max(
    Math.sqrt(errorVariance),
    baselineCentroid * 0.05
  );

  const horizonAnchorDate = legacyEmissions[legacyEmissions.length - 1].date;
  const hydratedForecasts: ForecastPoint[] = modelPredictions.map(
    (predictedNode, iteration) => {
      const temporalNodeDate = new Date(horizonAnchorDate);
      temporalNodeDate.setMonth(temporalNodeDate.getMonth() + iteration + 1);
      temporalNodeDate.setDate(1);

      const anchorOffset = iteration + 1;
      const computedCertainty = calculateConfidenceDecay(
        Math.min(0.95, 0.5 + deterministicTrend.rSquared * 0.45),
        anchorOffset
      );
      const boundingInterval = calculateConfidenceInterval(
        predictedNode,
        deviationError,
        0.95,
        anchorOffset
      );

      return {
        forecastDate: temporalNodeDate,
        predictedValue: predictedNode,
        confidenceLevel: computedCertainty,
        lowerBound: boundingInterval.lower,
        upperBound: boundingInterval.upper,
        model: modelArchitecture,
      };
    }
  );

  const categoryContexts = ["transport", "energy", "food", "waste"];
  const hydratedCategoryForecasts: CategoryForecast[] = [];

  for (const domain of categoryContexts) {
    const domainData = await getHistoricalMonthlyEmissions(userId, 12, domain);
    if (domainData.length >= 3) {
      const domainVectors = domainData.map((d) => d.value);
      const domainPredictions = forecastWithHoltWinters(
        domainVectors,
        0.4,
        0.2,
        projectionWindow
      );

      const mappedDomainForecasts = domainPredictions.map(
        (predictedNode, iteration) => {
          const structuralTemporalNode = new Date(horizonAnchorDate);
          structuralTemporalNode.setMonth(
            structuralTemporalNode.getMonth() + iteration + 1
          );
          structuralTemporalNode.setDate(1);
          return {
            forecastDate: structuralTemporalNode,
            predictedValue: predictedNode,
            confidenceLevel: 0.8,
            lowerBound: Math.max(0, predictedNode * 0.8),
            upperBound: predictedNode * 1.2,
            model: "exponential-smoothing",
          };
        }
      );
      hydratedCategoryForecasts.push({
        category: domain,
        forecasts: mappedDomainForecasts,
      });
    }
  }

  return {
    userId,
    forecasts: hydratedForecasts,
    categoryForecasts: hydratedCategoryForecasts,
    trend: deterministicTrend,
    historicalAverage: Math.round(baselineCentroid * 100) / 100,
    model: modelArchitecture,
  };
}

export async function getHistoricalMonthlyEmissions(
  userId: string,
  temporalLookback: number = 12,
  domainFilter?: string
): Promise<TimeSeriesPoint[]> {
  const temporalCutoff = new Date();
  temporalCutoff.setMonth(temporalCutoff.getMonth() - temporalLookback);

  const persistenceFilter: any = {
    userId,
    date: { gte: temporalCutoff },
  };

  if (domainFilter) {
    persistenceFilter.category = { contains: domainFilter };
  }

  const domainEvents = await prisma.activityData.findMany({
    where: persistenceFilter,
    select: { date: true, value: true },
    orderBy: { date: "asc" },
  });

  if (domainEvents.length === 0) return [];

  const timeSeriesMap = new Map<string, { date: Date; total: number }>();

  for (const emissionEvent of domainEvents) {
    const aggregationKey = `${emissionEvent.date.getFullYear()}-${String(emissionEvent.date.getMonth() + 1).padStart(2, "0")}`;
    if (!timeSeriesMap.has(aggregationKey)) {
      timeSeriesMap.set(aggregationKey, {
        date: new Date(
          emissionEvent.date.getFullYear(),
          emissionEvent.date.getMonth(),
          1
        ),
        total: 0,
      });
    }
    timeSeriesMap.get(aggregationKey)!.total += emissionEvent.value;
  }

  return Array.from(timeSeriesMap.values())
    .sort(
      (leftNode, rightNode) =>
        leftNode.date.getTime() - rightNode.date.getTime()
    )
    .map((temporalPoint) => ({
      date: temporalPoint.date,
      value: Math.round(temporalPoint.total * 100) / 100,
    }));
}

export async function saveForecastToDatabase(
  userId: string,
  projectedTimeSeries: ForecastPoint[]
): Promise<void> {
  for (const forecastPoint of projectedTimeSeries) {
    await prisma.forecast.upsert({
      where: { id: "" },
      update: {},
      create: {
        userId,
        forecastDate: forecastPoint.forecastDate,
        predictedValue: forecastPoint.predictedValue,
        confidenceLevel: forecastPoint.confidenceLevel,
        lowerBound: forecastPoint.lowerBound,
        upperBound: forecastPoint.upperBound,
        model: forecastPoint.model,
      },
    });
  }
}

export async function saveForecastsBatch(
  userId: string,
  projectedTimeSeries: ForecastPoint[]
): Promise<number> {
  await prisma.forecast.deleteMany({
    where: { userId },
  });

  let processedCount = 0;
  for (const forecastPoint of projectedTimeSeries) {
    await prisma.forecast.create({
      data: {
        userId,
        forecastDate: forecastPoint.forecastDate,
        predictedValue: forecastPoint.predictedValue,
        confidenceLevel: forecastPoint.confidenceLevel,
        lowerBound: forecastPoint.lowerBound,
        upperBound: forecastPoint.upperBound,
        model: forecastPoint.model,
      },
    });
    processedCount++;
  }
  return processedCount;
}

export async function getLatestForecasts(
  userId: string,
  batchLimit: number = 12
): Promise<ForecastPoint[]> {
  const persistedPoints = await prisma.forecast.findMany({
    where: { userId },
    orderBy: { forecastDate: "asc" },
    take: batchLimit,
  });

  return persistedPoints.map((document) => ({
    forecastDate: document.forecastDate,
    predictedValue: document.predictedValue,
    confidenceLevel: document.confidenceLevel,
    lowerBound: document.lowerBound,
    upperBound: document.upperBound,
    model: document.model,
  }));
}
