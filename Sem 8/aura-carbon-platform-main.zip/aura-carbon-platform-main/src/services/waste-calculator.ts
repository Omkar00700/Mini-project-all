interface WasteStream {
  type:
    | "general"
    | "organic"
    | "recyclable"
    | "electronic"
    | "hazardous"
    | "textile"
    | "plastic"
    | "paper"
    | "glass"
    | "metal";
  weight: number;
  treatment:
    | "landfill"
    | "incineration"
    | "recycling"
    | "composting"
    | "anaerobic_digestion"
    | "reuse";
  region: string;
}

interface WasteTreatmentFactor {
  treatment: string;
  wasteType: string;
  emissionFactor: number;
  unit: string;
  source: string;
  region: string;
  confidence: number;
  avoidedEmissions?: number;
}

interface WasteCalculationResult {
  totalEmissions: number;
  totalWaste: number;
  treatmentBreakdown: Record<string, number>;
  wasteTypeBreakdown: Record<string, number>;
  details: Array<{
    wasteType: string;
    treatment: string;
    weight: number;
    emissionFactor: number;
    emissions: number;
    avoidedEmissions?: number;
    netEmissions: number;
    confidence: number;
  }>;
  diversionRate: number;
  recyclingRate: number;
  recommendations: string[];
  methodology: string;
}

class WasteCalculatorService {
  private treatmentFactors: Map<string, WasteTreatmentFactor> = new Map();

  constructor() {
    this.initializeWasteTreatmentFactors();
  }

  private initializeWasteTreatmentFactors(): void {
    const factors: WasteTreatmentFactor[] = [
      {
        treatment: "landfill",
        wasteType: "general",
        emissionFactor: 0.57,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
      },
      {
        treatment: "landfill",
        wasteType: "organic",
        emissionFactor: 0.89,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.9,
      },
      {
        treatment: "landfill",
        wasteType: "paper",
        emissionFactor: 0.45,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.8,
      },
      {
        treatment: "landfill",
        wasteType: "plastic",
        emissionFactor: 0.02,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.7,
      },

      {
        treatment: "incineration",
        wasteType: "general",
        emissionFactor: 0.7,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
      },
      {
        treatment: "incineration",
        wasteType: "plastic",
        emissionFactor: 2.3,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.9,
      },
      {
        treatment: "incineration",
        wasteType: "paper",
        emissionFactor: 0.9,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
      },

      {
        treatment: "recycling",
        wasteType: "paper",
        emissionFactor: 0.1,
        avoidedEmissions: -1.2,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.8,
      },
      {
        treatment: "recycling",
        wasteType: "plastic",
        emissionFactor: 0.3,
        avoidedEmissions: -1.8,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.75,
      },
      {
        treatment: "recycling",
        wasteType: "glass",
        emissionFactor: 0.05,
        avoidedEmissions: -0.5,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
      },
      {
        treatment: "recycling",
        wasteType: "metal",
        emissionFactor: 0.2,
        avoidedEmissions: -4.5,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.9,
      },
      {
        treatment: "recycling",
        wasteType: "electronic",
        emissionFactor: 0.5,
        avoidedEmissions: -3.2,
        unit: "kg CO2e/kg",
        source: "UN E-waste Monitor 2020",
        region: "global",
        confidence: 0.75,
      },

      {
        treatment: "composting",
        wasteType: "organic",
        emissionFactor: 0.1,
        avoidedEmissions: -0.3,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
      },

      {
        treatment: "anaerobic_digestion",
        wasteType: "organic",
        emissionFactor: -0.2,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.8,
      },

      {
        treatment: "reuse",
        wasteType: "general",
        emissionFactor: 0.01,
        avoidedEmissions: -2.0,
        unit: "kg CO2e/kg",
        source: "Ellen MacArthur Foundation 2019",
        region: "global",
        confidence: 0.7,
      },
      {
        treatment: "reuse",
        wasteType: "textile",
        emissionFactor: 0.02,
        avoidedEmissions: -15.0,
        unit: "kg CO2e/kg",
        source: "Ellen MacArthur Foundation 2019",
        region: "global",
        confidence: 0.75,
      },
    ];

    factors.forEach((factor) => {
      const key = `${factor.treatment}_${factor.wasteType}`;
      this.treatmentFactors.set(key, factor);
    });
  }

  async calculateWasteEmissions(
    wasteStreams: WasteStream[]
  ): Promise<WasteCalculationResult> {
    try {
      let totalEmissions = 0;
      let totalWaste = 0;
      const treatmentBreakdown: Record<string, number> = {};
      const wasteTypeBreakdown: Record<string, number> = {};
      const details: any[] = [];
      const recommendations: string[] = [];

      let totalLandfillWaste = 0;
      let totalRecycledWaste = 0;

      for (const stream of wasteStreams) {
        const key = `${stream.treatment}_${stream.type}`;
        const factor = this.treatmentFactors.get(key);

        if (!factor) {
          continue;
        }

        const directEmissions = stream.weight * factor.emissionFactor;
        const avoidedEmissions = factor.avoidedEmissions
          ? stream.weight * factor.avoidedEmissions
          : 0;
        const netEmissions = directEmissions + avoidedEmissions;

        totalEmissions += netEmissions;
        totalWaste += stream.weight;

        treatmentBreakdown[stream.treatment] =
          (treatmentBreakdown[stream.treatment] || 0) + netEmissions;

        wasteTypeBreakdown[stream.type] =
          (wasteTypeBreakdown[stream.type] || 0) + netEmissions;

        if (stream.treatment === "landfill") {
          totalLandfillWaste += stream.weight;
        } else if (stream.treatment === "recycling") {
          totalRecycledWaste += stream.weight;
        }

        details.push({
          wasteType: stream.type,
          treatment: stream.treatment,
          weight: stream.weight,
          emissionFactor: factor.emissionFactor,
          emissions: directEmissions,
          avoidedEmissions,
          netEmissions,
          confidence: factor.confidence,
        });

        if (stream.treatment === "landfill" && stream.weight > 10) {
          recommendations.push(
            `Consider diverting ${stream.type} waste from landfill through recycling or composting`
          );
        }

        if (stream.type === "organic" && stream.treatment === "landfill") {
          recommendations.push(
            "Organic waste in landfills produces methane - consider composting instead"
          );
        }

        if (stream.type === "electronic" && stream.treatment !== "recycling") {
          recommendations.push(
            "E-waste should be recycled at certified facilities to recover valuable materials"
          );
        }
      }

      const diversionRate =
        totalWaste > 0
          ? ((totalWaste - totalLandfillWaste) / totalWaste) * 100
          : 0;
      const recyclingRate =
        totalWaste > 0 ? (totalRecycledWaste / totalWaste) * 100 : 0;

      const overallRecommendations = this.generateWasteRecommendations(
        diversionRate,
        recyclingRate,
        treatmentBreakdown,
        wasteTypeBreakdown,
        totalEmissions
      );
      recommendations.push(...overallRecommendations);

      return {
        totalEmissions,
        totalWaste,
        treatmentBreakdown,
        wasteTypeBreakdown,
        details,
        diversionRate,
        recyclingRate,
        recommendations: Array.from(new Set(recommendations)),
        methodology:
          "EPA waste emission factors with lifecycle avoided emissions accounting",
      };
    } catch (error) {
      throw new Error("Failed to calculate waste emissions");
    }
  }

  private generateWasteRecommendations(
    diversionRate: number,
    recyclingRate: number,
    treatmentBreakdown: Record<string, number>,
    wasteTypeBreakdown: Record<string, number>,
    totalEmissions: number
  ): string[] {
    const recommendations: string[] = [];

    if (diversionRate < 50) {
      recommendations.push(
        "Aim to divert at least 50% of waste from landfills through recycling and composting"
      );
    } else if (diversionRate < 75) {
      recommendations.push(
        "Good waste diversion! Try to reach 75% diversion through improved sorting"
      );
    }

    if (recyclingRate < 30) {
      recommendations.push(
        "Increase recycling rate - many materials can be recycled instead of landfilled"
      );
    }

    if (
      treatmentBreakdown.landfill &&
      treatmentBreakdown.landfill > totalEmissions * 0.5
    ) {
      recommendations.push(
        "Landfilling is your highest emission source - focus on waste reduction and diversion"
      );
    }

    if (
      treatmentBreakdown.incineration &&
      treatmentBreakdown.incineration > 0
    ) {
      recommendations.push(
        "Consider waste-to-energy facilities that capture energy from incineration"
      );
    }

    if (wasteTypeBreakdown.organic && wasteTypeBreakdown.organic > 0) {
      recommendations.push(
        "Set up home composting or use municipal organic waste collection"
      );
    }

    if (
      wasteTypeBreakdown.plastic &&
      wasteTypeBreakdown.plastic > totalEmissions * 0.3
    ) {
      recommendations.push(
        "Reduce single-use plastics and ensure proper recycling of plastic waste"
      );
    }

    if (totalEmissions > 50) {
      recommendations.push(
        "Consider adopting zero waste principles: refuse, reduce, reuse, recycle, rot"
      );
    }

    return recommendations;
  }

  async calculateWasteReductionScenario(
    currentWaste: WasteStream[],
    reductionActions: {
      wasteReduction?: number;
      increasedRecycling?: number;
      organicDiversion?: number;
      reuseRate?: number;
    }
  ): Promise<{
    currentEmissions: number;
    scenarioEmissions: number;
    emissionReduction: number;
    reductionPercentage: number;
    actionBreakdown: Record<string, number>;
    recommendations: string[];
  }> {
    const currentResult = await this.calculateWasteEmissions(currentWaste);
    const currentEmissions = currentResult.totalEmissions;

    const scenarioWaste: WasteStream[] = JSON.parse(
      JSON.stringify(currentWaste)
    );
    const actionBreakdown: Record<string, number> = {};

    if (reductionActions.wasteReduction) {
      const reductionFactor = 1 - reductionActions.wasteReduction / 100;
      scenarioWaste.forEach((stream) => {
        stream.weight *= reductionFactor;
      });
      actionBreakdown.wasteReduction =
        currentEmissions * (reductionActions.wasteReduction / 100) * 0.8;
    }

    if (reductionActions.increasedRecycling) {
      const landfillStreams = scenarioWaste.filter(
        (s) => s.treatment === "landfill"
      );
      const recyclingIncrease = reductionActions.increasedRecycling / 100;

      landfillStreams.forEach((stream) => {
        const moveToRecycling = stream.weight * recyclingIncrease;
        stream.weight -= moveToRecycling;

        scenarioWaste.push({
          type: stream.type,
          weight: moveToRecycling,
          treatment: "recycling",
          region: stream.region,
        });
      });

      actionBreakdown.increasedRecycling =
        currentEmissions * recyclingIncrease * 0.6;
    }

    if (reductionActions.organicDiversion) {
      const organicLandfillStreams = scenarioWaste.filter(
        (s) => s.type === "organic" && s.treatment === "landfill"
      );
      const diversionRate = reductionActions.organicDiversion / 100;

      organicLandfillStreams.forEach((stream) => {
        const moveToComposting = stream.weight * diversionRate;
        stream.weight -= moveToComposting;

        scenarioWaste.push({
          type: "organic",
          weight: moveToComposting,
          treatment: "composting",
          region: stream.region,
        });
      });

      actionBreakdown.organicDiversion = currentEmissions * diversionRate * 0.4;
    }

    if (reductionActions.reuseRate) {
      const reuseRate = reductionActions.reuseRate / 100;
      const totalCurrentWaste = scenarioWaste.reduce(
        (sum, s) => sum + s.weight,
        0
      );
      const reuseWeight = totalCurrentWaste * reuseRate;

      scenarioWaste.forEach((stream) => {
        stream.weight *= 1 - reuseRate;
      });

      scenarioWaste.push({
        type: "general",
        weight: reuseWeight,
        treatment: "reuse",
        region: "global",
      });

      actionBreakdown.reuseRate = currentEmissions * reuseRate * 0.9;
    }

    const scenarioResult = await this.calculateWasteEmissions(scenarioWaste);
    const scenarioEmissions = scenarioResult.totalEmissions;

    const emissionReduction = currentEmissions - scenarioEmissions;
    const reductionPercentage = (emissionReduction / currentEmissions) * 100;

    const recommendations = [
      "Implement a comprehensive waste sorting system",
      "Set up home composting for organic waste",
      "Choose products with minimal packaging",
      "Repair and reuse items before disposing",
      "Support businesses with take-back programs",
    ];

    return {
      currentEmissions,
      scenarioEmissions,
      emissionReduction,
      reductionPercentage,
      actionBreakdown,
      recommendations,
    };
  }

  async analyzeWasteComposition(wasteStreams: WasteStream[]): Promise<{
    composition: Record<string, { weight: number; percentage: number }>;
    treatmentDistribution: Record<
      string,
      { weight: number; percentage: number }
    >;
    improvementPotential: Array<{
      action: string;
      currentWeight: number;
      potentialReduction: number;
      emissionSavings: number;
    }>;
    benchmarks: {
      diversionRate: { current: number; target: number; best_practice: number };
      recyclingRate: { current: number; target: number; best_practice: number };
    };
  }> {
    const totalWeight = wasteStreams.reduce(
      (sum, stream) => sum + stream.weight,
      0
    );

    const composition: Record<string, { weight: number; percentage: number }> =
      {};
    const treatmentDistribution: Record<
      string,
      { weight: number; percentage: number }
    > = {};

    wasteStreams.forEach((stream) => {
      if (!composition[stream.type]) {
        composition[stream.type] = { weight: 0, percentage: 0 };
      }
      composition[stream.type].weight += stream.weight;

      if (!treatmentDistribution[stream.treatment]) {
        treatmentDistribution[stream.treatment] = { weight: 0, percentage: 0 };
      }
      treatmentDistribution[stream.treatment].weight += stream.weight;
    });

    Object.values(composition).forEach((item) => {
      item.percentage = (item.weight / totalWeight) * 100;
    });
    Object.values(treatmentDistribution).forEach((item) => {
      item.percentage = (item.weight / totalWeight) * 100;
    });

    const improvementPotential = [];

    const organicLandfill = wasteStreams
      .filter((s) => s.type === "organic" && s.treatment === "landfill")
      .reduce((sum, s) => sum + s.weight, 0);

    if (organicLandfill > 0) {
      improvementPotential.push({
        action: "Divert organic waste to composting",
        currentWeight: organicLandfill,
        potentialReduction: organicLandfill,
        emissionSavings: organicLandfill * (0.89 - 0.1),
      });
    }

    const recyclableLandfill = wasteStreams
      .filter(
        (s) =>
          ["paper", "plastic", "glass", "metal"].includes(s.type) &&
          s.treatment === "landfill"
      )
      .reduce((sum, s) => sum + s.weight, 0);

    if (recyclableLandfill > 0) {
      improvementPotential.push({
        action: "Increase recycling of recyclable materials",
        currentWeight: recyclableLandfill,
        potentialReduction: recyclableLandfill * 0.8,
        emissionSavings: recyclableLandfill * 0.8 * 1.5,
      });
    }

    const landfillWeight = treatmentDistribution.landfill?.weight || 0;
    const recyclingWeight = treatmentDistribution.recycling?.weight || 0;
    const diversionRate = ((totalWeight - landfillWeight) / totalWeight) * 100;
    const recyclingRate = (recyclingWeight / totalWeight) * 100;

    const benchmarks = {
      diversionRate: {
        current: diversionRate,
        target: 75,
        best_practice: 90,
      },
      recyclingRate: {
        current: recyclingRate,
        target: 50,
        best_practice: 70,
      },
    };

    return {
      composition,
      treatmentDistribution,
      improvementPotential,
      benchmarks,
    };
  }

  getTreatmentFactor(
    treatment: string,
    wasteType: string
  ): WasteTreatmentFactor | undefined {
    const key = `${treatment}_${wasteType}`;
    return this.treatmentFactors.get(key);
  }

  getTreatmentFactors(): Map<string, WasteTreatmentFactor> {
    return new Map(this.treatmentFactors);
  }
}

export const wasteCalculator = new WasteCalculatorService();
