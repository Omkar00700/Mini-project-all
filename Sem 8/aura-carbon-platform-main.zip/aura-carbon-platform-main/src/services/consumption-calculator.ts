import type { ConsumptionData } from "@/types/carbon";

interface ConsumptionEmissionFactor {
  category: string;
  subcategory: string;
  emissionFactor: number;
  unit: string;
  source: string;
  region: string;
  confidence: number;
  lifecycle_stage:
    | "production"
    | "transport"
    | "use"
    | "disposal"
    | "full_lifecycle";
}

interface ConsumptionCalculationResult {
  totalEmissions: number;
  breakdown: {
    shopping: number;
    services: number;
    waste: number;
  };
  details: Array<{
    category: string;
    subcategory: string;
    consumption: number;
    unit: string;
    emissionFactor: number;
    emissions: number;
    confidence: number;
    lifecycle_stage: string;
  }>;
  methodology: string;
  recommendations: string[];
}

class ConsumptionCalculatorService {
  private consumptionDatabase: Map<string, ConsumptionEmissionFactor> =
    new Map();

  constructor() {
    this.initializeConsumptionDatabase();
  }

  private initializeConsumptionDatabase(): void {
    const shoppingFactors: ConsumptionEmissionFactor[] = [
      {
        category: "consumption",
        subcategory: "clothing",
        emissionFactor: 33.4,
        unit: "kg CO2e/item",
        source: "Ellen MacArthur Foundation 2017",
        region: "global",
        confidence: 0.8,
        lifecycle_stage: "full_lifecycle",
      },
      {
        category: "consumption",
        subcategory: "electronics",
        emissionFactor: 300.0,
        unit: "kg CO2e/item",
        source: "EPA 2021",
        region: "global",
        confidence: 0.75,
        lifecycle_stage: "full_lifecycle",
      },
      {
        category: "consumption",
        subcategory: "furniture",
        emissionFactor: 150.0,
        unit: "kg CO2e/item",
        source: "DEFRA 2021",
        region: "UK",
        confidence: 0.7,
        lifecycle_stage: "full_lifecycle",
      },
      {
        category: "consumption",
        subcategory: "books",
        emissionFactor: 8.85,
        unit: "kg CO2e/item",
        source: "Book Industry Study Group 2020",
        region: "US",
        confidence: 0.8,
        lifecycle_stage: "full_lifecycle",
      },
      {
        category: "consumption",
        subcategory: "other_goods",
        emissionFactor: 0.5,
        unit: "kg CO2e/USD",
        source: "EPA EEIO 2021",
        region: "US",
        confidence: 0.6,
        lifecycle_stage: "full_lifecycle",
      },
    ];

    const servicesFactors: ConsumptionEmissionFactor[] = [
      {
        category: "consumption",
        subcategory: "banking",
        emissionFactor: 0.15,
        unit: "kg CO2e/USD",
        source: "Banking Environment Initiative 2020",
        region: "global",
        confidence: 0.7,
        lifecycle_stage: "use",
      },
      {
        category: "consumption",
        subcategory: "insurance",
        emissionFactor: 0.08,
        unit: "kg CO2e/USD",
        source: "Insurance Industry Climate Coalition 2021",
        region: "global",
        confidence: 0.65,
        lifecycle_stage: "use",
      },
      {
        category: "consumption",
        subcategory: "telecommunications",
        emissionFactor: 0.12,
        unit: "kg CO2e/USD",
        source: "ITU 2020",
        region: "global",
        confidence: 0.75,
        lifecycle_stage: "use",
      },
      {
        category: "consumption",
        subcategory: "entertainment",
        emissionFactor: 0.25,
        unit: "kg CO2e/USD",
        source: "EPA EEIO 2021",
        region: "US",
        confidence: 0.6,
        lifecycle_stage: "use",
      },
    ];

    const wasteFactors: ConsumptionEmissionFactor[] = [
      {
        category: "consumption",
        subcategory: "general_waste",
        emissionFactor: 0.57,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.85,
        lifecycle_stage: "disposal",
      },
      {
        category: "consumption",
        subcategory: "recycling",
        emissionFactor: -0.2,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.8,
        lifecycle_stage: "disposal",
      },
      {
        category: "consumption",
        subcategory: "organic_waste",
        emissionFactor: 0.89,
        unit: "kg CO2e/kg",
        source: "EPA 2020",
        region: "US",
        confidence: 0.9,
        lifecycle_stage: "disposal",
      },
      {
        category: "consumption",
        subcategory: "electronic_waste",
        emissionFactor: 1.2,
        unit: "kg CO2e/kg",
        source: "UN E-waste Monitor 2020",
        region: "global",
        confidence: 0.75,
        lifecycle_stage: "disposal",
      },
    ];

    [...shoppingFactors, ...servicesFactors, ...wasteFactors].forEach(
      (factor) => {
        this.consumptionDatabase.set(factor.subcategory, factor);
      }
    );
  }

  async calculateConsumptionEmissions(
    data: ConsumptionData
  ): Promise<ConsumptionCalculationResult> {
    try {
      let totalEmissions = 0;
      const breakdown = {
        shopping: 0,
        services: 0,
        waste: 0,
      };
      const details: any[] = [];
      const recommendations: string[] = [];

      if (data.shopping) {
        const shoppingEmissions = await this.calculateShoppingEmissions(
          data.shopping
        );
        breakdown.shopping = shoppingEmissions.total;
        totalEmissions += shoppingEmissions.total;
        details.push(...shoppingEmissions.details);
        recommendations.push(...shoppingEmissions.recommendations);
      }

      if (data.services) {
        const servicesEmissions = await this.calculateServicesEmissions(
          data.services
        );
        breakdown.services = servicesEmissions.total;
        totalEmissions += servicesEmissions.total;
        details.push(...servicesEmissions.details);
        recommendations.push(...servicesEmissions.recommendations);
      }

      if (data.waste) {
        const wasteEmissions = await this.calculateWasteEmissions(data.waste);
        breakdown.waste = wasteEmissions.total;
        totalEmissions += wasteEmissions.total;
        details.push(...wasteEmissions.details);
        recommendations.push(...wasteEmissions.recommendations);
      }

      const overallRecommendations = this.generateConsumptionRecommendations(
        breakdown,
        totalEmissions
      );
      recommendations.push(...overallRecommendations);

      return {
        totalEmissions,
        breakdown,
        details,
        methodology:
          "Lifecycle assessment with EPA EEIO and industry-specific emission factors",
        recommendations: Array.from(new Set(recommendations)),
      };
    } catch (error) {
      throw new Error("Failed to calculate consumption emissions");
    }
  }

  private async calculateShoppingEmissions(
    shopping: NonNullable<ConsumptionData["shopping"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, consumption] of Object.entries(shopping)) {
      if (consumption && consumption > 0) {
        const factor = this.consumptionDatabase.get(type);
        if (factor) {
          const emissions = consumption * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "consumption",
            subcategory: type,
            consumption,
            unit: factor.unit.includes("item") ? "items" : "USD",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
            lifecycle_stage: factor.lifecycle_stage,
          });

          if (type === "clothing" && consumption > 10) {
            recommendations.push(
              "Consider buying fewer, higher-quality clothing items and explore second-hand options"
            );
          }
          if (type === "electronics" && consumption > 2) {
            recommendations.push(
              "Electronics have high carbon footprints - buy only when necessary and consider refurbished options"
            );
          }
          if (type === "other_goods" && consumption > 500) {
            recommendations.push(
              "Consider reducing impulse purchases and focus on buying durable, long-lasting products"
            );
          }
        }
      }
    }

    return { total, details, recommendations };
  }

  private async calculateServicesEmissions(
    services: NonNullable<ConsumptionData["services"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, spending] of Object.entries(services)) {
      if (spending && spending > 0) {
        const factor = this.consumptionDatabase.get(type);
        if (factor) {
          const emissions = spending * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "consumption",
            subcategory: type,
            consumption: spending,
            unit: "USD",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
            lifecycle_stage: factor.lifecycle_stage,
          });

          if (type === "banking" && spending > 100) {
            recommendations.push(
              "Consider choosing banks with strong environmental commitments and green investment policies"
            );
          }
          if (type === "telecommunications" && spending > 200) {
            recommendations.push(
              "Look for telecom providers that use renewable energy for their data centers"
            );
          }
        }
      }
    }

    return { total, details, recommendations };
  }

  private async calculateWasteEmissions(
    waste: NonNullable<ConsumptionData["waste"]>
  ) {
    let total = 0;
    const details: any[] = [];
    const recommendations: string[] = [];

    for (const [type, weight] of Object.entries(waste)) {
      if (weight && weight > 0) {
        const factor = this.consumptionDatabase.get(type);
        if (factor) {
          const emissions = weight * factor.emissionFactor;
          total += emissions;

          details.push({
            category: "consumption",
            subcategory: type,
            consumption: weight,
            unit: "kg",
            emissionFactor: factor.emissionFactor,
            emissions,
            confidence: factor.confidence,
            lifecycle_stage: factor.lifecycle_stage,
          });

          if (type === "general_waste" && weight > 50) {
            recommendations.push(
              "Try to reduce general waste by composting organic materials and increasing recycling"
            );
          }
          if (type === "organic_waste" && weight > 20) {
            recommendations.push(
              "Consider home composting to reduce methane emissions from organic waste"
            );
          }
          if (type === "electronic_waste" && weight > 5) {
            recommendations.push(
              "Take e-waste to certified recycling centers to minimize environmental impact"
            );
          }
        }
      }
    }

    const recyclingWeight = waste.recycling || 0;
    const generalWasteWeight = waste.general_waste || 0;
    const recyclingRatio =
      recyclingWeight / (recyclingWeight + generalWasteWeight);

    if (recyclingRatio < 0.3) {
      recommendations.push(
        "Increase your recycling rate - aim for at least 50% of waste to be recycled"
      );
    }

    return { total, details, recommendations };
  }

  private generateConsumptionRecommendations(
    breakdown: any,
    totalEmissions: number
  ): string[] {
    const recommendations: string[] = [];

    const shoppingPercentage = (breakdown.shopping / totalEmissions) * 100;
    const servicesPercentage = (breakdown.services / totalEmissions) * 100;
    const wastePercentage = (breakdown.waste / totalEmissions) * 100;

    if (shoppingPercentage > 70) {
      recommendations.push(
        "Your consumption is shopping-heavy. Consider adopting a minimalist approach and buying only what you need"
      );
    }

    if (wastePercentage > 30) {
      recommendations.push(
        "Focus on waste reduction through the 5 R's: Refuse, Reduce, Reuse, Recycle, Rot (compost)"
      );
    }

    if (totalEmissions > 300) {
      recommendations.push(
        "Consider adopting a circular economy mindset: buy less, use longer, share more"
      );
    }

    recommendations.push(
      "Look for products with environmental certifications like Energy Star, EPEAT, or Cradle to Cradle"
    );
    recommendations.push(
      "Consider the sharing economy for items you use infrequently (tools, equipment, vehicles)"
    );

    return recommendations;
  }

  async calculateProductLifecycleEmissions(
    productType: string,
    quantity: number,
    lifecycleStages: {
      production?: boolean;
      transport?: boolean;
      use?: boolean;
      disposal?: boolean;
    } = { production: true, transport: true, use: true, disposal: true }
  ): Promise<{
    totalEmissions: number;
    stageBreakdown: Record<string, number>;
    details: any[];
  }> {
    const baseFactor = this.consumptionDatabase.get(productType);
    if (!baseFactor) {
      throw new Error(`Unknown product type: ${productType}`);
    }

    const stageDistribution = {
      production: 0.6,
      transport: 0.1,
      use: 0.2,
      disposal: 0.1,
    };

    let totalEmissions = 0;
    const stageBreakdown: Record<string, number> = {};
    const details: any[] = [];

    for (const [stage, enabled] of Object.entries(lifecycleStages)) {
      if (enabled && stage in stageDistribution) {
        const stageEmissions =
          quantity *
          baseFactor.emissionFactor *
          stageDistribution[stage as keyof typeof stageDistribution];
        stageBreakdown[stage] = stageEmissions;
        totalEmissions += stageEmissions;

        details.push({
          lifecycle_stage: stage,
          emissions: stageEmissions,
          percentage:
            stageDistribution[stage as keyof typeof stageDistribution] * 100,
        });
      }
    }

    return {
      totalEmissions,
      stageBreakdown,
      details,
    };
  }

  getEmissionFactor(
    subcategory: string
  ): ConsumptionEmissionFactor | undefined {
    return this.consumptionDatabase.get(subcategory);
  }

  getConsumptionDatabase(): Map<string, ConsumptionEmissionFactor> {
    return new Map(this.consumptionDatabase);
  }

  async calculateCircularEconomyImpact(
    originalConsumption: ConsumptionData,
    circularActions: {
      repairInsteadOfBuy?: number;
      buySecondHand?: number;
      shareInsteadOfOwn?: number;
      recycleRate?: number;
    }
  ): Promise<{
    originalEmissions: number;
    circularEmissions: number;
    emissionReduction: number;
    reductionPercentage: number;
    recommendations: string[];
  }> {
    const originalResult =
      await this.calculateConsumptionEmissions(originalConsumption);
    const originalEmissions = originalResult.totalEmissions;

    let circularEmissions = originalEmissions;
    const recommendations: string[] = [];

    if (circularActions.repairInsteadOfBuy) {
      const repairReduction =
        originalResult.breakdown.shopping *
        (circularActions.repairInsteadOfBuy / 100) *
        0.8;
      circularEmissions -= repairReduction;
      recommendations.push(
        `Repairing items instead of buying new could save ${repairReduction.toFixed(1)} kg CO2e`
      );
    }

    if (circularActions.buySecondHand) {
      const secondHandReduction =
        originalResult.breakdown.shopping *
        (circularActions.buySecondHand / 100) *
        0.7;
      circularEmissions -= secondHandReduction;
      recommendations.push(
        `Buying second-hand could save ${secondHandReduction.toFixed(1)} kg CO2e`
      );
    }

    if (circularActions.shareInsteadOfOwn) {
      const sharingReduction =
        originalResult.breakdown.shopping *
        (circularActions.shareInsteadOfOwn / 100) *
        0.6;
      circularEmissions -= sharingReduction;
      recommendations.push(
        `Sharing instead of owning could save ${sharingReduction.toFixed(1)} kg CO2e`
      );
    }

    if (circularActions.recycleRate) {
      const currentRecyclingRate = 0.3;
      const improvementFactor =
        circularActions.recycleRate / 100 - currentRecyclingRate;
      if (improvementFactor > 0) {
        const recyclingReduction =
          originalResult.breakdown.waste * improvementFactor * 0.5;
        circularEmissions -= recyclingReduction;
        recommendations.push(
          `Improving recycling rate could save ${recyclingReduction.toFixed(1)} kg CO2e`
        );
      }
    }

    const emissionReduction = originalEmissions - circularEmissions;
    const reductionPercentage = (emissionReduction / originalEmissions) * 100;

    return {
      originalEmissions,
      circularEmissions,
      emissionReduction,
      reductionPercentage,
      recommendations,
    };
  }
}

export const consumptionCalculator = new ConsumptionCalculatorService();
