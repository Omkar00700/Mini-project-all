import { db } from "@/lib/db";

export interface ExportOptions {
  userId: string;
  format: "csv" | "pdf" | "json" | "html";
  dateRange?: {
    start: Date;
    end: Date;
  };
  includeActivities: boolean;
  includeCalculations: boolean;
  includePredictions: boolean;
  includeRecommendations: boolean;
}

export interface ExportData {
  user: {
    name: string;
    email: string;
    location?: string;
    householdSize?: number;
  };
  generatedAt: Date;
  dateRange: { start: Date; end: Date };
  summary: {
    totalEmissions: number;
    averageMonthly: number;
    dataPoints: number;
    categories: Record<string, number>;
  };
  activities: Array<{
    date: Date;
    category: string;
    subcategory: string;
    value: number;
    unit: string;
    emissions: number;
  }>;
  calculations: Array<{
    period: string;
    totalEmissions: number;
    breakdown: Record<string, number>;
  }>;
  predictions: Array<{
    month: string;
    predicted: number;
    confidence: number;
  }>;
  recommendations: Array<{
    title: string;
    category: string;
    impact: number;
    status: string;
  }>;
}

class ExportService {
  async generateExportData(options: ExportOptions): Promise<ExportData> {
    const {
      userId,
      dateRange,
      includeActivities,
      includeCalculations,
      includePredictions,
      includeRecommendations,
    } = options;

    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        name: true,
        email: true,
        location: true,
        household: true,
      },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const startDate =
      dateRange?.start || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
    const endDate = dateRange?.end || new Date();

    let activities: ExportData["activities"] = [];
    if (includeActivities) {
      const activityData = await db.activityData.findMany({
        where: {
          userId,
          date: { gte: startDate, lte: endDate },
        },
        orderBy: { date: "asc" },
      });

      activities = activityData.map((a) => ({
        date: a.date,
        category: a.category,
        subcategory: a.subcategory,
        value: a.value,
        unit: a.unit,
        emissions: a.value,
      }));
    }

    let calculations: ExportData["calculations"] = [];
    if (includeCalculations) {
      const calcData = await db.carbonCalculation.findMany({
        where: {
          userId,
          periodStart: { gte: startDate, lte: endDate },
        },
        orderBy: { periodStart: "asc" },
      });

      calculations = calcData.map((c) => ({
        period: c.periodStart.toLocaleDateString("en-IN", {
          month: "short",
          year: "numeric",
        }),
        totalEmissions: c.totalEmissions,
        breakdown: c.breakdown as Record<string, number>,
      }));
    }

    let predictions: ExportData["predictions"] = [];
    if (includePredictions) {
      const predData = await db.forecast.findMany({
        where: { userId },
        orderBy: { forecastDate: "asc" },
        take: 12,
      });

      predictions = predData.map((p) => ({
        month: p.forecastDate.toLocaleDateString("en-IN", {
          month: "short",
          year: "numeric",
        }),
        predicted: p.predictedValue,
        confidence: p.confidenceLevel,
      }));
    }

    let recommendations: ExportData["recommendations"] = [];
    if (includeRecommendations) {
      const recData = await db.recommendation.findMany({
        where: { userId },
        orderBy: { createdAt: "desc" },
        take: 20,
      });

      recommendations = recData.map((r) => ({
        title: r.title,
        category: r.category,
        impact: r.impactEstimate,
        status: r.status,
      }));
    }

    const totalEmissions = activities.reduce((sum, a) => sum + a.emissions, 0);
    const categoryEmissions: Record<string, number> = {};

    activities.forEach((a) => {
      if (!categoryEmissions[a.category]) {
        categoryEmissions[a.category] = 0;
      }
      categoryEmissions[a.category] += a.emissions;
    });

    return {
      user: {
        name: user.name || "User",
        email: user.email,
        location: (user.location as { city?: string })?.city,
        householdSize: (user.household as { size?: number })?.size,
      },
      generatedAt: new Date(),
      dateRange: { start: startDate, end: endDate },
      summary: {
        totalEmissions,
        averageMonthly:
          totalEmissions /
          Math.max(
            1,
            Math.ceil(
              (endDate.getTime() - startDate.getTime()) /
                (30 * 24 * 60 * 60 * 1000)
            )
          ),
        dataPoints: activities.length,
        categories: categoryEmissions,
      },
      activities,
      calculations,
      predictions,
      recommendations,
    };
  }

  generateCSV(data: ExportData): string {
    const lines: string[] = [];

    lines.push("Aura Carbon Footprint Report");
    lines.push(`Generated: ${data.generatedAt.toISOString()}`);
    lines.push(`User: ${data.user.name} (${data.user.email})`);
    lines.push("");

    lines.push("SUMMARY");
    lines.push(
      `Total Emissions (kg CO2),${data.summary.totalEmissions.toFixed(2)}`
    );
    lines.push(
      `Average Monthly (kg CO2),${data.summary.averageMonthly.toFixed(2)}`
    );
    lines.push(`Data Points,${data.summary.dataPoints}`);
    lines.push("");

    lines.push("CATEGORY BREAKDOWN");
    lines.push("Category,Emissions (kg CO2)");
    Object.entries(data.summary.categories).forEach(([cat, val]) => {
      lines.push(`${cat},${val.toFixed(2)}`);
    });
    lines.push("");

    if (data.activities.length > 0) {
      lines.push("ACTIVITIES");
      lines.push("Date,Category,Subcategory,Value,Unit,Emissions (kg CO2)");
      data.activities.forEach((a) => {
        lines.push(
          `${a.date.toISOString().split("T")[0]},${a.category},${a.subcategory},${a.value},${a.unit},${a.emissions.toFixed(2)}`
        );
      });
      lines.push("");
    }

    if (data.calculations.length > 0) {
      lines.push("CALCULATIONS");
      lines.push("Period,Total Emissions (kg CO2)");
      data.calculations.forEach((c) => {
        lines.push(`${c.period},${c.totalEmissions.toFixed(2)}`);
      });
      lines.push("");
    }

    if (data.predictions.length > 0) {
      lines.push("PREDICTIONS");
      lines.push("Month,Predicted (kg CO2),Confidence");
      data.predictions.forEach((p) => {
        lines.push(
          `${p.month},${p.predicted.toFixed(2)},${(p.confidence * 100).toFixed(0)}%`
        );
      });
      lines.push("");
    }

    if (data.recommendations.length > 0) {
      lines.push("RECOMMENDATIONS");
      lines.push("Title,Category,Impact (kg CO2/year),Status");
      data.recommendations.forEach((r) => {
        lines.push(
          `"${r.title}",${r.category},${r.impact.toFixed(2)},${r.status}`
        );
      });
    }

    return lines.join("\n");
  }

  generateJSON(data: ExportData): string {
    return JSON.stringify(data, null, 2);
  }

  generateHTMLReport(data: ExportData): string {
    const categoryRows = Object.entries(data.summary.categories)
      .map(
        ([cat, val]) => `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${cat}</td>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${val.toFixed(2)} kg</td>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${((val / data.summary.totalEmissions) * 100).toFixed(1)}%</td>
        </tr>
      `
      )
      .join("");

    const activityRows = data.activities
      .slice(0, 50)
      .map(
        (a) => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${a.date.toLocaleDateString()}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${a.category}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${a.subcategory}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${a.emissions.toFixed(2)}</td>
      </tr>
    `
      )
      .join("");

    const recommendationRows = data.recommendations
      .slice(0, 10)
      .map(
        (r) => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${r.title}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${r.category}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${r.impact.toFixed(2)} kg/year</td>
      </tr>
    `
      )
      .join("");

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Aura Carbon Footprint Report</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px; }
    .header { text-align: center; margin-bottom: 40px; }
    .logo { color: #059669; font-size: 28px; font-weight: bold; }
    .subtitle { color: #6b7280; font-size: 14px; }
    h1 { font-size: 24px; margin-bottom: 8px; }
    h2 { font-size: 18px; margin-top: 32px; padding-bottom: 8px; border-bottom: 2px solid #059669; }
    .summary-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 20px 0; }
    .summary-card { background: #f9fafb; padding: 16px; border-radius: 8px; text-align: center; }
    .summary-value { font-size: 24px; font-weight: bold; color: #059669; }
    .summary-label { font-size: 12px; color: #6b7280; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    th { background: #f3f4f6; padding: 12px 8px; text-align: left; font-weight: 600; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; text-align: center; color: #6b7280; font-size: 12px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">🌿 Aura</div>
    <div class="subtitle">Carbon Footprint Report</div>
  </div>
  
  <h1>Report for ${data.user.name}</h1>
  <p style="color: #6b7280;">
    ${data.user.location ? `Location: ${data.user.location} | ` : ""}
    ${data.user.householdSize ? `Household: ${data.user.householdSize} members | ` : ""}
    Generated: ${data.generatedAt.toLocaleDateString("en-IN", { dateStyle: "long" })}
  </p>
  
  <h2>Summary</h2>
  <div class="summary-grid">
    <div class="summary-card">
      <div class="summary-value">${data.summary.totalEmissions.toFixed(1)} kg</div>
      <div class="summary-label">Total CO2 Emissions</div>
    </div>
    <div class="summary-card">
      <div class="summary-value">${data.summary.averageMonthly.toFixed(1)} kg</div>
      <div class="summary-label">Monthly Average</div>
    </div>
    <div class="summary-card">
      <div class="summary-value">${data.summary.dataPoints}</div>
      <div class="summary-label">Activities Logged</div>
    </div>
  </div>
  
  <h2>Emissions by Category</h2>
  <table>
    <thead>
      <tr>
        <th>Category</th>
        <th style="text-align: right;">Emissions</th>
        <th style="text-align: right;">Percentage</th>
      </tr>
    </thead>
    <tbody>
      ${categoryRows}
    </tbody>
  </table>
  
  ${
    data.activities.length > 0
      ? `
    <h2>Recent Activities</h2>
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Category</th>
          <th>Activity</th>
          <th style="text-align: right;">Emissions (kg CO2)</th>
        </tr>
      </thead>
      <tbody>
        ${activityRows}
      </tbody>
    </table>
    ${data.activities.length > 50 ? `<p style="color: #6b7280; font-size: 12px;">Showing 50 of ${data.activities.length} activities</p>` : ""}
  `
      : ""
  }
  
  ${
    data.recommendations.length > 0
      ? `
    <h2>Recommendations</h2>
    <table>
      <thead>
        <tr>
          <th>Recommendation</th>
          <th>Category</th>
          <th style="text-align: right;">Potential Impact</th>
        </tr>
      </thead>
      <tbody>
        ${recommendationRows}
      </tbody>
    </table>
  `
      : ""
  }
  
  <div class="footer">
    <p>Generated by Aura - India's Carbon Footprint Tracker</p>
    <p>https://aura.co.in</p>
  </div>
</body>
</html>
    `.trim();
  }
}

export const exportService = new ExportService();
