export interface CarbonProfile {
  totalEmissions: number;
  breakdown: {
    transport?: number;
    energy?: number;
    food?: number;
    waste?: number;
    [key: string]: number | undefined;
  };
  location?: string;
  householdSize?: number;
  userLevel?: number;
  activityCount?: number;
  recentHistory?: { month: string; emissions: number }[];
}

export interface AIRecommendation {
  id: string;
  title: string;
  description: string;
  category: string;
  impactEstimate: number;
  difficulty: "easy" | "medium" | "hard";
  costEstimate: "free" | "low" | "medium" | "high";
  actionSteps: string[];
  priority: number;
}

export interface AIInsight {
  type: "trend" | "prediction" | "alert" | "achievement";
  message: string;
  data?: any;
  confidence: number;
}

interface RetryOptions {
  maxRetries?: number;
  retryDelay?: number;
  timeout?: number;
}

class OpenAIRecommendationsService {
  private apiKey: string;
  private baseURL: string;
  private model: string;
  private maxRetries: number;
  private retryDelay: number;
  private timeout: number;

  constructor() {
    this.apiKey = process.env.OPENAI_API_KEY || "";
    const base = process.env.OPENAI_BASE_URL || "";
    this.baseURL = base ? base.replace(/\/$/, "") : "";
    this.model = process.env.OPENAI_MODEL || "";
    this.maxRetries = 3;
    this.retryDelay = 1000;
    this.timeout = 30000;
  }

  isConfigured(): boolean {
    return (
      !!this.apiKey && this.apiKey !== "" && !!this.baseURL && !!this.model
    );
  }

  async generateRecommendations(
    profile: CarbonProfile,
    limit: number = 5
  ): Promise<AIRecommendation[]> {
    const prompt = this.buildRecommendationPrompt(profile, limit);
    const response = await this.callOpenAIWithRetry(prompt, {
      temperature: 0.7,
      maxTokens: 2000,
    });

    const recommendations = this.parseRecommendations(response, limit);

    if (recommendations.length === 0) {
      throw new Error("AI returned an empty response. Could not generate recommendations.");
    }

    return recommendations;
  }

  async generateInsights(
    profile: CarbonProfile,
    historicalData?: any[]
  ): Promise<AIInsight[]> {
    const prompt = this.buildInsightsPrompt(profile, historicalData);
    const response = await this.callOpenAIWithRetry(prompt, {
      temperature: 0.5,
      maxTokens: 1500,
    });

    const insights = this.parseInsights(response);

    if (insights.length === 0) {
      throw new Error("AI returned an empty response. Could not generate insights.");
    }

    return insights;
  }

  async predictEmissions(
    historicalData: { month: string; total: number }[]
  ): Promise<{ month: string; predicted: number; confidence: number }[]> {
    const prompt = this.buildPredictionPrompt(historicalData);
    const response = await this.callOpenAIWithRetry(prompt, {
      temperature: 0.3,
      maxTokens: 1000,
    });

    const predictions = this.parsePredictions(response);

    if (predictions.length === 0) {
       throw new Error("AI returned an empty response. Could not generate predictions.");
    }

    return predictions;
  }

  private async callOpenAIWithRetry(
    prompt: string,
    options: { temperature?: number; maxTokens?: number } = {},
    retryOptions?: RetryOptions
  ): Promise<string> {
    const maxRetries = retryOptions?.maxRetries ?? this.maxRetries;
    const retryDelay = retryOptions?.retryDelay ?? this.retryDelay;
    const timeout = retryOptions?.timeout ?? this.timeout;

    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        const requestBody: any = {
          model: this.model,
          messages: [
            {
              role: "system",
              content:
                "You are an expert carbon footprint analyst specializing in India. Provide practical, data-driven, and actionable recommendations. Always return valid, well-structured JSON. Consider Indian context: climate, infrastructure, culture, and economic factors.",
            },
            { role: "user", content: prompt },
          ],
          temperature: options.temperature ?? 0.7,
          max_tokens: options.maxTokens ?? 2000,
        };

        if (this.baseURL.includes("api.openai.com")) {
          requestBody.response_format = { type: "json_object" };
        }

        const response = await fetch(`${this.baseURL}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.apiKey}`,

            ...(this.baseURL.includes("openrouter.ai") && {
              "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL ?? "",
              "X-Title": "Aura",
            }),
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const errorMessage = errorData.error?.message || response.statusText;

          if (
            response.status >= 400 &&
            response.status < 500 &&
            response.status !== 429
          ) {
            throw new Error(
              `OpenAI API client error: ${errorMessage} (${response.status})`
            );
          }

          if (response.status === 429 || response.status >= 500) {
            throw new Error(
              `OpenAI API server error: ${errorMessage} (${response.status})`
            );
          }

          throw new Error(
            `OpenAI API error: ${errorMessage} (${response.status})`
          );
        }

        const data = await response.json();
        const content = data.choices[0]?.message?.content || "";

        if (!content) {
          throw new Error("Empty response from OpenAI API");
        }

        return content;
      } catch (error: any) {
        lastError = error;

        if (error.name === "AbortError") {
          throw new Error(`Request timeout after ${timeout}ms`);
        }

        if (error.message?.includes("client error")) {
          throw error;
        }

        if (attempt === maxRetries) {
          throw error;
        }

        const delay = retryDelay * Math.pow(2, attempt);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    throw lastError || new Error("Failed to call OpenAI API");
  }

  private buildRecommendationPrompt(
    profile: CarbonProfile,
    limit: number
  ): string {
    const topCategory = Object.keys(profile.breakdown).reduce((a, b) =>
      (profile.breakdown[a] || 0) > (profile.breakdown[b] || 0) ? a : b
    );
    const topCategoryEmissions = profile.breakdown[topCategory] || 0;
    const topCategoryPercentage = Math.round(
      (topCategoryEmissions / profile.totalEmissions) * 100
    );

    const trend =
      profile.recentHistory && profile.recentHistory.length >= 2
        ? profile.recentHistory[0].emissions -
          profile.recentHistory[profile.recentHistory.length - 1].emissions
        : 0;
    const trendText = profile.recentHistory && profile.recentHistory.length >= 2 ? (trend > 0 ? `Increasing by ${trend.toFixed(1)} kg CO₂ recently` : (trend < 0 ? `Decreasing by ${Math.abs(trend).toFixed(1)} kg CO₂ recently` : "Stable")) : "Not enough data for trend";

    return `You are a carbon footprint reduction expert analyzing data for an Indian household.

CARBON FOOTPRINT DATA:
- Total Monthly Emissions: ${profile.totalEmissions.toFixed(2)} kg CO₂
- Transport: ${(profile.breakdown.transport || 0).toFixed(2)} kg CO₂
- Energy: ${(profile.breakdown.energy || 0).toFixed(2)} kg CO₂
- Food: ${(profile.breakdown.food || 0).toFixed(2)} kg CO₂
- Waste: ${(profile.breakdown.waste || 0).toFixed(2)} kg CO₂
- Location: ${profile.location || "India"}
- Household Size: ${profile.householdSize || 1} person(s)
- User Level: ${profile.userLevel ?? 1} (experience level on the platform)
- Activities Logged: ${profile.activityCount ?? 0}
${profile.recentHistory && profile.recentHistory.length > 0 ? `- Recent Emission History: ${JSON.stringify(profile.recentHistory)}` : ""}

ANALYSIS:
- Highest emission category: ${topCategory} (${topCategoryPercentage}% of total)
- Recent Trend: ${trendText}
- Average Indian household: ~150 kg CO₂/month
- ${profile.totalEmissions > 150 ? `This user emits ${(profile.totalEmissions - 150).toFixed(0)} kg MORE than the Indian average — focus on high-impact reductions` : `This user emits ${(150 - profile.totalEmissions).toFixed(0)} kg LESS than the Indian average — suggest advanced optimizations`}
- ${(profile.activityCount ?? 0) > 50 ? "Experienced user — give advanced recommendations" : "Newer user — start with easier, beginner-friendly actions"}

TASK:
Generate exactly ${limit} personalized, actionable carbon reduction recommendations specifically for India. Prioritize recommendations that:
1. Target the highest emission categories first
2. Are practical and achievable in Indian context
3. Consider Indian infrastructure, climate, and culture
4. Provide realistic impact estimates
5. Are tailored to this specific user's emission profile and experience level

REQUIREMENTS:
- Each recommendation must have a realistic impactEstimate (kg CO₂ saved per month)
- Include 2-4 specific, actionable steps
- Consider Indian context (public transport, solar potential, local foods, etc.)
- Vary difficulty levels (mix of easy, medium, hard)
- Vary cost estimates (mix of free, low, medium, high)

Return ONLY a valid JSON object with this exact structure:
{
  "recommendations": [
    {
      "id": "rec-1",
      "title": "Short, actionable title (max 8 words)",
      "description": "Detailed 2-3 sentence description explaining the recommendation and why it matters",
      "category": "transport|energy|food|waste",
      "impactEstimate": 25.5,
      "difficulty": "easy|medium|hard",
      "costEstimate": "free|low|medium|high",
      "actionSteps": ["Specific step 1", "Specific step 2", "Specific step 3"],
      "priority": 1
    }
  ]
}

Focus on practical, India-specific solutions. Be specific and actionable.`;
  }

  private buildInsightsPrompt(
    profile: CarbonProfile,
    historicalData?: any[]
  ): string {
    const avgIndianFootprint = 150;
    const comparison = profile.totalEmissions - avgIndianFootprint;
    const trend =
      historicalData && historicalData.length >= 2
        ? historicalData[historicalData.length - 1].total -
          historicalData[0].total
        : 0;

    return `You are a carbon footprint analyst providing insights for an Indian household.

CURRENT DATA:
- Monthly Emissions: ${profile.totalEmissions.toFixed(2)} kg CO₂
- Transport: ${(profile.breakdown.transport || 0).toFixed(2)} kg CO₂ (${Math.round(((profile.breakdown.transport || 0) / profile.totalEmissions) * 100)}%)
- Energy: ${(profile.breakdown.energy || 0).toFixed(2)} kg CO₂ (${Math.round(((profile.breakdown.energy || 0) / profile.totalEmissions) * 100)}%)
- Food: ${(profile.breakdown.food || 0).toFixed(2)} kg CO₂ (${Math.round(((profile.breakdown.food || 0) / profile.totalEmissions) * 100)}%)
- Waste: ${(profile.breakdown.waste || 0).toFixed(2)} kg CO₂ (${Math.round(((profile.breakdown.waste || 0) / profile.totalEmissions) * 100)}%)

${
  historicalData && historicalData.length > 0
    ? `HISTORICAL TREND:
${JSON.stringify(historicalData.slice(-6), null, 2)}
- Trend: ${trend > 0 ? "Increasing" : trend < 0 ? "Decreasing" : "Stable"}
`
    : ""
}

CONTEXT:
- Average Indian household: ~${avgIndianFootprint} kg CO₂/month
- This household: ${comparison > 0 ? `${comparison.toFixed(1)} kg above` : comparison < 0 ? `${Math.abs(comparison).toFixed(1)} kg below` : "at"} average

TASK:
Generate 3-4 insightful, data-driven observations about this carbon footprint. Include:
1. A trend analysis (if historical data available)
2. A comparison to Indian average
3. A prediction or alert about high-impact areas
4. An achievement or warning based on performance

Return ONLY a valid JSON object:
{
  "insights": [
    {
      "type": "trend|prediction|alert|achievement",
      "message": "Clear, specific insight message (1-2 sentences)",
      "confidence": 0.85
    }
  ]
}

Be specific, data-driven, and actionable.`;
  }

  private buildPredictionPrompt(
    historicalData: { month: string; total: number }[]
  ): string {
    const recentData = historicalData.slice(-6);
    const avg =
      recentData.reduce((sum, d) => sum + d.total, 0) / recentData.length;
    const trend =
      recentData.length >= 2
        ? recentData[recentData.length - 1].total - recentData[0].total
        : 0;

    return `You are a carbon footprint prediction analyst.

HISTORICAL DATA (Monthly kg CO₂):
${JSON.stringify(recentData, null, 2)}

STATISTICS:
- Average: ${avg.toFixed(2)} kg CO₂/month
- Trend: ${trend > 0 ? `+${trend.toFixed(2)}` : trend.toFixed(2)} kg CO₂ (${trend > 0 ? "increasing" : trend < 0 ? "decreasing" : "stable"})
- Data points: ${recentData.length} months

TASK:
Predict the next 3 months' carbon emissions based on historical patterns, trends, and seasonality. Consider:
- Recent trend direction
- Seasonal variations (if applicable)
- Statistical patterns

Return ONLY a valid JSON object:
{
  "predictions": [
    {
      "month": "Dec 2024",
      "predicted": 145.5,
      "confidence": 0.75
    }
  ]
}

Provide realistic predictions with appropriate confidence scores (0.5-0.9).`;
  }

  private parseRecommendations(
    response: string,
    limit: number
  ): AIRecommendation[] {
    try {
      let parsed: any;

      const cleaned = response
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();

      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = cleaned.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          const objMatch = cleaned.match(/\{[\s\S]*\}/);
          if (objMatch) {
            parsed = JSON.parse(objMatch[0]);
          } else {
            throw new Error("No JSON found in response");
          }
        }
      }

      let recommendations: any[] = [];
      if (Array.isArray(parsed)) {
        recommendations = parsed;
      } else if (
        parsed.recommendations &&
        Array.isArray(parsed.recommendations)
      ) {
        recommendations = parsed.recommendations;
      } else if (parsed.data && Array.isArray(parsed.data)) {
        recommendations = parsed.data;
      }

      const validRecommendations = recommendations
        .slice(0, limit)
        .map((rec, index) => ({
          id: rec.id || `rec-${index + 1}`,
          title: rec.title || "Untitled Recommendation",
          description: rec.description || "",
          category: rec.category || "other",
          impactEstimate:
            typeof rec.impactEstimate === "number" ? rec.impactEstimate : 0,
          difficulty: ["easy", "medium", "hard"].includes(rec.difficulty)
            ? rec.difficulty
            : "medium",
          costEstimate: ["free", "low", "medium", "high"].includes(
            rec.costEstimate
          )
            ? rec.costEstimate
            : "low",
          actionSteps: Array.isArray(rec.actionSteps) ? rec.actionSteps : [],
          priority: typeof rec.priority === "number" ? rec.priority : index + 1,
        }))
        .filter((rec) => rec.title && rec.description);

      return validRecommendations;
    } catch (error: any) {
      return [];
    }
  }

  private parseInsights(response: string): AIInsight[] {
    try {
      const cleaned = response
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();

      let parsed: any;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = cleaned.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          const objMatch = cleaned.match(/\{[\s\S]*\}/);
          if (objMatch) {
            parsed = JSON.parse(objMatch[0]);
          } else {
            throw new Error("No JSON found in response");
          }
        }
      }

      let insights: any[] = [];
      if (Array.isArray(parsed)) {
        insights = parsed;
      } else if (parsed.insights && Array.isArray(parsed.insights)) {
        insights = parsed.insights;
      } else if (parsed.data && Array.isArray(parsed.data)) {
        insights = parsed.data;
      }

      const validInsights = insights
        .map((insight) => ({
          type: ["trend", "prediction", "alert", "achievement"].includes(
            insight.type
          )
            ? insight.type
            : "trend",
          message: insight.message || "",
          confidence:
            typeof insight.confidence === "number" &&
            insight.confidence >= 0 &&
            insight.confidence <= 1
              ? insight.confidence
              : 0.8,
          data: insight.data,
        }))
        .filter((insight) => insight.message);

      return validInsights;
    } catch (error: any) {
      return [];
    }
  }

  private parsePredictions(
    response: string
  ): { month: string; predicted: number; confidence: number }[] {
    try {
      const cleaned = response
        .replace(/```json\n?/g, "")
        .replace(/```\n?/g, "")
        .trim();

      let parsed: any;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        const jsonMatch = cleaned.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          parsed = JSON.parse(jsonMatch[0]);
        } else {
          const objMatch = cleaned.match(/\{[\s\S]*\}/);
          if (objMatch) {
            parsed = JSON.parse(objMatch[0]);
          } else {
            throw new Error("No JSON found");
          }
        }
      }

      let predictions: any[] = [];
      if (Array.isArray(parsed)) {
        predictions = parsed;
      } else if (parsed.predictions && Array.isArray(parsed.predictions)) {
        predictions = parsed.predictions;
      } else if (parsed.data && Array.isArray(parsed.data)) {
        predictions = parsed.data;
      }

      return predictions
        .map((pred) => ({
          month: pred.month || "",
          predicted: typeof pred.predicted === "number" ? pred.predicted : 0,
          confidence:
            typeof pred.confidence === "number" &&
            pred.confidence >= 0 &&
            pred.confidence <= 1
              ? pred.confidence
              : 0.7,
        }))
        .filter((pred) => pred.month && pred.predicted > 0);
    } catch {
      return [];
    }
  }
}

export const aiRecommendationsService = new OpenAIRecommendationsService();
