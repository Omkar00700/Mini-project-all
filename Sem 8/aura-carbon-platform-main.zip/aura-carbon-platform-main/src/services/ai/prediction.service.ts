import { prisma } from "@/lib/prisma";

export interface PredictionData {
  month: string;
  predictedEmissions: number;
  confidence: number;
  lowerBound: number;
  upperBound: number;
}

export interface TrendData {
  slope: number;
  intercept: number;
  averageEmissions: number;
}

export class PredictionService {
  async generatePredictions(
    userId: string,
    monthsAhead: number = 6
  ): Promise<PredictionData[]> {
    const historicalData = await this.getHistoricalData(userId);

    if (historicalData.length === 0) {
      return this.generateDemoPredictions(monthsAhead);
    }

    const trend = this.calculateTrend(historicalData);

    const predictions: PredictionData[] = [];
    const now = new Date();

    for (let i = 1; i <= monthsAhead; i++) {
      const futureDate = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const monthName = futureDate.toLocaleDateString("en-US", {
        month: "short",
        year: "numeric",
      });

      const baselinePrediction =
        trend.slope * (historicalData.length + i) + trend.intercept;

      const seasonalFactor =
        1 + Math.sin((futureDate.getMonth() / 12) * Math.PI * 2) * 0.1;
      const predictedEmissions = Math.max(
        0,
        baselinePrediction * seasonalFactor
      );

      const confidence = this.estimateConfidence(historicalData.length, i);

      const uncertainty = 0.15;
      const lowerBound = Math.max(0, predictedEmissions * (1 - uncertainty));
      const upperBound = predictedEmissions * (1 + uncertainty);

      predictions.push({
        month: monthName,
        predictedEmissions: Math.round(predictedEmissions * 100) / 100,
        confidence: Math.round(confidence * 100) / 100,
        lowerBound: Math.round(lowerBound * 100) / 100,
        upperBound: Math.round(upperBound * 100) / 100,
      });
    }

    return predictions;
  }

  private async getHistoricalData(
    userId: string
  ): Promise<Array<{ month: number; emissions: number }>> {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const calculations = await prisma.carbonCalculation.findMany({
      where: {
        userId,
        periodStart: {
          gte: sixMonthsAgo,
        },
      },
      orderBy: {
        periodStart: "asc",
      },
      select: {
        periodStart: true,
        totalEmissions: true,
      },
    });

    return calculations.map((calc, index) => ({
      month: index,
      emissions: calc.totalEmissions,
    }));
  }

  calculateTrend(data: Array<{ month: number; emissions: number }>): TrendData {
    if (data.length === 0) {
      return { slope: 0, intercept: 300, averageEmissions: 300 };
    }

    const n = data.length;
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumX2 = 0;

    data.forEach((point) => {
      sumX += point.month;
      sumY += point.emissions;
      sumXY += point.month * point.emissions;
      sumX2 += point.month * point.month;
    });

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    const averageEmissions = sumY / n;

    return {
      slope: isNaN(slope) ? 0 : slope,
      intercept: isNaN(intercept) ? averageEmissions : intercept,
      averageEmissions,
    };
  }

  estimateConfidence(dataPoints: number, monthsAhead: number): number {
    const dataConfidence = Math.min(dataPoints / 6, 1) * 0.9;

    const distanceReduction = Math.max(0, 1 - monthsAhead * 0.1);

    return Math.max(0.5, dataConfidence * distanceReduction);
  }

  private generateDemoPredictions(monthsAhead: number): PredictionData[] {
    const predictions: PredictionData[] = [];
    const now = new Date();
    const baseEmissions = 320;

    for (let i = 1; i <= monthsAhead; i++) {
      const futureDate = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const monthName = futureDate.toLocaleDateString("en-US", {
        month: "short",
        year: "numeric",
      });

      const trendFactor = 1 - i * 0.02;
      const seasonalFactor =
        1 + Math.sin((futureDate.getMonth() / 12) * Math.PI * 2) * 0.1;
      const predictedEmissions = baseEmissions * trendFactor * seasonalFactor;

      const confidence = 0.65 - i * 0.05;
      const lowerBound = predictedEmissions * 0.85;
      const upperBound = predictedEmissions * 1.15;

      predictions.push({
        month: monthName,
        predictedEmissions: Math.round(predictedEmissions * 100) / 100,
        confidence: Math.max(0.5, Math.round(confidence * 100) / 100),
        lowerBound: Math.round(lowerBound * 100) / 100,
        upperBound: Math.round(upperBound * 100) / 100,
      });
    }

    return predictions;
  }

  async getHistoricalEmissions(
    userId: string
  ): Promise<Array<{ month: string; emissions: number }>> {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const calculations = await prisma.carbonCalculation.findMany({
      where: {
        userId,
        periodStart: {
          gte: sixMonthsAgo,
        },
      },
      orderBy: {
        periodStart: "asc",
      },
      select: {
        periodStart: true,
        totalEmissions: true,
      },
    });

    if (calculations.length === 0) {
      return this.generateDemoHistoricalData();
    }

    return calculations.map((calc) => ({
      month: calc.periodStart.toLocaleDateString("en-US", {
        month: "short",
        year: "numeric",
      }),
      emissions: Math.round(calc.totalEmissions * 100) / 100,
    }));
  }

  private generateDemoHistoricalData(): Array<{
    month: string;
    emissions: number;
  }> {
    const data: Array<{ month: string; emissions: number }> = [];
    const now = new Date();
    const baseEmissions = 350;

    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthName = date.toLocaleDateString("en-US", {
        month: "short",
        year: "numeric",
      });

      const variation = (Math.random() - 0.5) * 40;
      const emissions = baseEmissions + variation;

      data.push({
        month: monthName,
        emissions: Math.round(emissions * 100) / 100,
      });
    }

    return data;
  }
}

export const predictionService = new PredictionService();
