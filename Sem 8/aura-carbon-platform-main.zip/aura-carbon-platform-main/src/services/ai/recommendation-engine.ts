import OpenAI from "openai";
import { db } from "@/lib/db";
import type { CarbonFootprintResult } from "@/types/carbon";

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })
  : null;

export interface Recommendation {
  id: string;
  title: string;
  description: string;
  category:
    | "transportation"
    | "energy"
    | "food"
    | "waste"
    | "consumption"
    | "general";
  impact: {
    co2Saved: number;
    percentageReduction: number;
  };
  feasibility: {
    score: number;
    cost: "free" | "low" | "medium" | "high";
    effort: "easy" | "moderate" | "difficult";
    timeRequired: string;
  };
  personalized: boolean;
  reasoning: string;
  actionable: boolean;
  steps: string[];
}

export interface UserProfile {
  id: string;
  location: {
    country: string;
    region: string;
    city: string;
  };
  household: {
    size: number;
    type: "individual" | "family" | "shared";
  };
  preferences: {
    budget: "minimal" | "moderate" | "flexible";
    lifestyle: "urban" | "suburban" | "rural";
    priorities: string[];
  };
}

export interface CarbonAnalysis {
  totalEmissions: number;
  breakdown: {
    transportation: number;
    energy: number;
    food: number;
    waste: number;
    consumption: number;
  };
  topEmitters: Array<{
    category: string;
    subcategory: string;
    emissions: number;
    percentage: number;
  }>;
}

class RecommendationEngine {
  async generateRecommendations(
    userId: string,
    carbonAnalysis: CarbonAnalysis,
    userProfile: UserProfile,
    options: {
      maxRecommendations?: number;
      categories?: string[];
      minImpact?: number;
    } = {}
  ): Promise<Recommendation[]> {
    const { maxRecommendations = 10, categories, minImpact = 0 } = options;

    const previousRecommendations =
      await this.getPreviousRecommendations(userId);

    const ruleBasedRecommendations = this.generateRuleBasedRecommendations(
      carbonAnalysis,
      userProfile
    );

    let aiRecommendations: Recommendation[] = [];
    if (openai) {
      try {
        aiRecommendations = await this.generateAIRecommendations(
          carbonAnalysis,
          userProfile,
          previousRecommendations
        );
      } catch (error) {}
    }

    const allRecommendations = this.mergeRecommendations(
      ruleBasedRecommendations,
      aiRecommendations,
      previousRecommendations
    );

    const filtered = allRecommendations.filter((r) => {
      if (minImpact > 0 && r.impact.co2Saved < minImpact) return false;
      if (
        categories &&
        categories.length > 0 &&
        !categories.includes(r.category)
      )
        return false;
      return true;
    });

    filtered.sort((a, b) => {
      const scoreA = a.impact.co2Saved * (a.feasibility.score / 5);
      const scoreB = b.impact.co2Saved * (b.feasibility.score / 5);
      return scoreB - scoreA;
    });

    await this.saveRecommendations(
      userId,
      filtered.slice(0, maxRecommendations)
    );

    return filtered.slice(0, maxRecommendations);
  }

  private generateRuleBasedRecommendations(
    analysis: CarbonAnalysis,
    profile: UserProfile
  ): Recommendation[] {
    const recommendations: Recommendation[] = [];

    if (analysis.breakdown.transportation > analysis.totalEmissions * 0.25) {
      recommendations.push({
        id: `rec-transport-${Date.now()}-1`,
        title: "Switch to Public Transportation",
        description:
          "Your transportation emissions are high. Consider using public transport for your daily commute.",
        category: "transportation",
        impact: {
          co2Saved: analysis.breakdown.transportation * 0.4,
          percentageReduction: 10,
        },
        feasibility: {
          score: 4,
          cost: "free",
          effort: "moderate",
          timeRequired: "Immediate",
        },
        personalized: true,
        reasoning: `Transportation accounts for ${Math.round(
          (analysis.breakdown.transportation / analysis.totalEmissions) * 100
        )}% of your carbon footprint.`,
        actionable: true,
        steps: [
          "Research local public transport routes",
          "Get a monthly pass for cost savings",
          "Start with 2-3 days per week",
          "Track your savings with our app",
        ],
      });

      recommendations.push({
        id: `rec-transport-${Date.now()}-2`,
        title: "Consider an Electric Vehicle",
        description:
          "Electric vehicles produce significantly lower emissions, especially in India where the grid is improving.",
        category: "transportation",
        impact: {
          co2Saved: analysis.breakdown.transportation * 0.6,
          percentageReduction: 15,
        },
        feasibility: {
          score: 2,
          cost: "high",
          effort: "difficult",
          timeRequired: "1-3 months",
        },
        personalized: true,
        reasoning:
          "Long-term investment that significantly reduces your carbon footprint.",
        actionable: true,
        steps: [
          "Research EV models available in India",
          "Check government subsidies (FAME II)",
          "Calculate total cost of ownership",
          "Test drive at local dealerships",
        ],
      });
    }

    if (analysis.breakdown.energy > analysis.totalEmissions * 0.2) {
      recommendations.push({
        id: `rec-energy-${Date.now()}-1`,
        title: "Switch to LED Lighting",
        description:
          "LED bulbs use 75% less energy than incandescent bulbs and last 25 times longer.",
        category: "energy",
        impact: {
          co2Saved: 200,
          percentageReduction: 5,
        },
        feasibility: {
          score: 5,
          cost: "low",
          effort: "easy",
          timeRequired: "1 day",
        },
        personalized: true,
        reasoning:
          "Quick win with immediate energy savings. Great ROI within months.",
        actionable: true,
        steps: [
          "Count the bulbs in your home",
          "Purchase LED replacements",
          "Replace bulbs room by room",
          "Dispose of old bulbs properly",
        ],
      });

      recommendations.push({
        id: `rec-energy-${Date.now()}-2`,
        title: "Install a Smart Thermostat",
        description:
          "Smart thermostats can reduce heating and cooling costs by 10-15% through automated scheduling.",
        category: "energy",
        impact: {
          co2Saved: analysis.breakdown.energy * 0.15,
          percentageReduction: 4,
        },
        feasibility: {
          score: 4,
          cost: "medium",
          effort: "moderate",
          timeRequired: "1 week",
        },
        personalized: true,
        reasoning:
          "Energy consumption patterns show potential for optimization.",
        actionable: true,
        steps: [
          "Research compatible smart thermostats",
          "Check for utility rebates",
          "Install or hire professional",
          "Configure schedules and preferences",
        ],
      });
    }

    if (analysis.breakdown.food > analysis.totalEmissions * 0.15) {
      recommendations.push({
        id: `rec-food-${Date.now()}-1`,
        title: "Reduce Meat Consumption",
        description:
          "Reducing meat consumption by half can cut your food-related emissions by up to 35%.",
        category: "food",
        impact: {
          co2Saved: analysis.breakdown.food * 0.35,
          percentageReduction: 7,
        },
        feasibility: {
          score: 4,
          cost: "free",
          effort: "moderate",
          timeRequired: "Ongoing",
        },
        personalized: true,
        reasoning: `Food emissions are ${Math.round(
          (analysis.breakdown.food / analysis.totalEmissions) * 100
        )}% of your total footprint.`,
        actionable: true,
        steps: [
          "Start with Meatless Mondays",
          "Explore Indian vegetarian recipes",
          "Try plant-based protein alternatives",
          "Plan meals in advance",
        ],
      });

      recommendations.push({
        id: `rec-food-${Date.now()}-2`,
        title: "Buy Local and Seasonal Produce",
        description:
          "Local produce has lower transportation emissions and supports local farmers.",
        category: "food",
        impact: {
          co2Saved: 100,
          percentageReduction: 3,
        },
        feasibility: {
          score: 5,
          cost: "low",
          effort: "easy",
          timeRequired: "Immediate",
        },
        personalized: true,
        reasoning:
          "Seasonal produce in India is fresher, cheaper, and more sustainable.",
        actionable: true,
        steps: [
          "Find local farmers markets",
          "Learn what's in season",
          "Plan meals around seasonal items",
          "Consider joining a CSA program",
        ],
      });
    }

    if (analysis.breakdown.waste > 0) {
      recommendations.push({
        id: `rec-waste-${Date.now()}-1`,
        title: "Start Composting",
        description:
          "Composting organic waste reduces methane emissions and creates nutrient-rich soil.",
        category: "waste",
        impact: {
          co2Saved: 150,
          percentageReduction: 4,
        },
        feasibility: {
          score: 4,
          cost: "low",
          effort: "moderate",
          timeRequired: "2 weeks",
        },
        personalized: true,
        reasoning:
          "Organic waste makes up a significant portion of household waste.",
        actionable: true,
        steps: [
          "Get a compost bin or pile",
          "Learn what can be composted",
          "Start with kitchen scraps",
          "Use compost for garden/plants",
        ],
      });

      recommendations.push({
        id: `rec-waste-${Date.now()}-2`,
        title: "Reduce Single-Use Plastics",
        description:
          "Carry reusable bags, bottles, and containers to reduce plastic waste.",
        category: "waste",
        impact: {
          co2Saved: 50,
          percentageReduction: 1,
        },
        feasibility: {
          score: 5,
          cost: "low",
          effort: "easy",
          timeRequired: "Immediate",
        },
        personalized: true,
        reasoning:
          "Small lifestyle changes add up to significant impact over time.",
        actionable: true,
        steps: [
          "Get a reusable water bottle",
          "Keep cloth bags in your car",
          "Decline single-use items",
          "Choose products with less packaging",
        ],
      });
    }

    recommendations.push({
      id: `rec-general-${Date.now()}-1`,
      title: "Calculate Your Carbon Footprint Monthly",
      description:
        "Regular tracking helps identify trends and measure the impact of your actions.",
      category: "general",
      impact: {
        co2Saved: 0,
        percentageReduction: 0,
      },
      feasibility: {
        score: 5,
        cost: "free",
        effort: "easy",
        timeRequired: "5 minutes/month",
      },
      personalized: false,
      reasoning: "Awareness is the first step to reduction.",
      actionable: true,
      steps: [
        "Set a monthly reminder",
        "Update your activity data",
        "Review your trends",
        "Celebrate improvements",
      ],
    });

    return recommendations;
  }

  private async generateAIRecommendations(
    analysis: CarbonAnalysis,
    profile: UserProfile,
    previousRecommendations: string[]
  ): Promise<Recommendation[]> {
    if (!openai) return [];

    const prompt = `You are a carbon footprint advisor for a user in ${profile.location.city}, ${profile.location.country}.

User Profile:
- Household: ${profile.household.size} people (${profile.household.type})
- Budget preference: ${profile.preferences.budget}
- Lifestyle: ${profile.preferences.lifestyle}
- Priorities: ${profile.preferences.priorities.join(", ")}

Carbon Footprint Analysis:
- Total emissions: ${analysis.totalEmissions.toFixed(1)} kg CO2/month
- Transportation: ${analysis.breakdown.transportation.toFixed(1)} kg (${(
      (analysis.breakdown.transportation / analysis.totalEmissions) *
      100
    ).toFixed(1)}%)
- Energy: ${analysis.breakdown.energy.toFixed(1)} kg (${(
      (analysis.breakdown.energy / analysis.totalEmissions) *
      100
    ).toFixed(1)}%)
- Food: ${analysis.breakdown.food.toFixed(1)} kg (${(
      (analysis.breakdown.food / analysis.totalEmissions) *
      100
    ).toFixed(1)}%)
- Waste: ${analysis.breakdown.waste.toFixed(1)} kg (${(
      (analysis.breakdown.waste / analysis.totalEmissions) *
      100
    ).toFixed(1)}%)

Top emitters: ${analysis.topEmitters
      .map((e) => `${e.subcategory} (${e.percentage.toFixed(1)}%)`)
      .join(", ")}

Previously suggested recommendations (avoid duplicates):
${previousRecommendations.slice(0, 10).join("\n")}

Generate 3 personalized, actionable recommendations to reduce carbon footprint.
Consider Indian context (e.g., local transportation options, energy sources, food habits).

Respond in JSON format:
{
  "recommendations": [
    {
      "title": "string",
      "description": "string",
      "category": "transportation|energy|food|waste|consumption|general",
      "impact_co2_saved": number,
      "feasibility_score": 1-5,
      "cost": "free|low|medium|high",
      "effort": "easy|moderate|difficult",
      "reasoning": "string",
      "steps": ["step1", "step2", ...]
    }
  ]
}`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are an expert environmental advisor specializing in carbon footprint reduction for Indian households. Always respond with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 1500,
        response_format: { type: "json_object" },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) return [];

      const parsed = JSON.parse(content);
      const aiRecs = parsed.recommendations || [];

      return aiRecs.map(
        (rec: Record<string, unknown>, index: number): Recommendation => ({
          id: `rec-ai-${Date.now()}-${index}`,
          title: String(rec.title || ""),
          description: String(rec.description || ""),
          category: String(
            rec.category || "general"
          ) as Recommendation["category"],
          impact: {
            co2Saved: Number(rec.impact_co2_saved || 0),
            percentageReduction: Number(
              ((rec.impact_co2_saved as number) / analysis.totalEmissions) * 100
            ),
          },
          feasibility: {
            score: Number(rec.feasibility_score || 3),
            cost: String(
              rec.cost || "low"
            ) as Recommendation["feasibility"]["cost"],
            effort: String(
              rec.effort || "moderate"
            ) as Recommendation["feasibility"]["effort"],
            timeRequired: "Varies",
          },
          personalized: true,
          reasoning: String(rec.reasoning || ""),
          actionable: true,
          steps: Array.isArray(rec.steps) ? rec.steps.map(String) : [],
        })
      );
    } catch (error) {
      return [];
    }
  }

  private async getPreviousRecommendations(userId: string): Promise<string[]> {
    const recommendations = await db.recommendation.findMany({
      where: { userId, status: "active" },
      select: { title: true },
      orderBy: { createdAt: "desc" },
      take: 20,
    });

    return recommendations.map((r) => r.title);
  }

  private mergeRecommendations(
    ruleBased: Recommendation[],
    aiGenerated: Recommendation[],
    previousTitles: string[]
  ): Recommendation[] {
    const all = [...ruleBased, ...aiGenerated];
    const seen = new Set(previousTitles.map((t) => t.toLowerCase()));

    return all.filter((rec) => {
      const titleLower = rec.title.toLowerCase();
      if (seen.has(titleLower)) return false;
      seen.add(titleLower);
      return true;
    });
  }

  private async saveRecommendations(
    userId: string,
    recommendations: Recommendation[]
  ): Promise<void> {
    for (const rec of recommendations) {
      await db.recommendation.create({
        data: {
          userId,
          title: rec.title,
          description: rec.description,
          category: rec.category,
          impactEstimate: rec.impact.co2Saved,
          costEstimate:
            rec.feasibility.cost === "free"
              ? 0
              : rec.feasibility.cost === "low"
                ? 50
                : rec.feasibility.cost === "medium"
                  ? 200
                  : 1000,
          difficultyScore: rec.feasibility.score,
          confidenceScore: rec.personalized ? 0.85 : 0.7,
          status: "active",
          userFeedback: {
            steps: rec.steps,
            reasoning: rec.reasoning,
            effort: rec.feasibility.effort,
            timeRequired: rec.feasibility.timeRequired,
          },
        },
      });
    }
  }

  async trackImplementation(
    userId: string,
    recommendationId: string,
    implemented: boolean,
    feedback?: string
  ): Promise<void> {
    await db.recommendation.update({
      where: { id: recommendationId, userId },
      data: {
        status: implemented ? "implemented" : "dismissed",
        userFeedback: {
          feedback,
          implementedAt: implemented ? new Date().toISOString() : null,
        },
      },
    });
  }

  async getEffectivenessMetrics(userId: string): Promise<{
    totalRecommendations: number;
    implemented: number;
    potentialSavings: number;
    actualSavings: number;
  }> {
    const recommendations = await db.recommendation.findMany({
      where: { userId },
    });

    const implemented = recommendations.filter(
      (r) => r.status === "implemented"
    );
    const totalPotential = recommendations.reduce(
      (sum, r) => sum + r.impactEstimate,
      0
    );
    const actualSavings = implemented.reduce(
      (sum, r) => sum + r.impactEstimate,
      0
    );

    return {
      totalRecommendations: recommendations.length,
      implemented: implemented.length,
      potentialSavings: totalPotential,
      actualSavings,
    };
  }
}

export const recommendationEngine = new RecommendationEngine();
export { RecommendationEngine };
