import { prisma } from "@/lib/db";
import { DashboardConfig, DashboardWidget } from "@/types/user";

export class DashboardService {
  async getUserDashboard(userId: string): Promise<DashboardConfig | null> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { dashboardConfig: true },
      });

      const config = user?.dashboardConfig;
      if (!config || typeof config !== "object") {
        return null;
      }

      return config as unknown as DashboardConfig;
    } catch (error) {
      return null;
    }
  }

  async updateDashboardConfig(
    userId: string,
    config: Partial<DashboardConfig>
  ): Promise<DashboardConfig> {
    try {
      const user = await prisma.user.update({
        where: { id: userId },
        data: {
          dashboardConfig: JSON.parse(JSON.stringify(config)),
        },
        select: { dashboardConfig: true },
      });

      return user.dashboardConfig as unknown as DashboardConfig;
    } catch (error) {
      throw new Error("Failed to update dashboard configuration");
    }
  }

  async resetDashboardToDefault(userId: string): Promise<DashboardConfig> {
    try {
      const { defaultDashboardConfig } = await import(
        "@/config/default-dashboard"
      );

      const user = await prisma.user.update({
        where: { id: userId },
        data: {
          dashboardConfig: JSON.parse(JSON.stringify(defaultDashboardConfig)),
        },
        select: { dashboardConfig: true },
      });

      return user.dashboardConfig as unknown as DashboardConfig;
    } catch (error) {
      throw new Error("Failed to reset dashboard to default");
    }
  }

  async updateWidget(
    userId: string,
    widgetId: string,
    updates: Partial<DashboardWidget>
  ): Promise<DashboardConfig> {
    try {
      const currentConfig = await this.getUserDashboard(userId);
      if (!currentConfig) {
        throw new Error("Dashboard configuration not found");
      }

      const updatedWidgets = currentConfig.widgets.map((widget) =>
        widget.id === widgetId ? { ...widget, ...updates } : widget
      );

      return this.updateDashboardConfig(userId, {
        ...currentConfig,
        widgets: updatedWidgets,
      });
    } catch (error) {
      throw new Error("Failed to update widget configuration");
    }
  }
}

export const dashboardService = new DashboardService();
