import { db } from "@/lib/db";
import type { EmissionFactor } from "@/types/carbon";

export interface EmissionFactorInput {
  category: string;
  subcategory: string;
  region: string;
  value: number;
  unit: string;
  source: string;
  confidenceLevel?: number;
}

export interface EmissionFactorSearchOptions {
  category?: string;
  region?: string;
  query?: string;
  limit?: number;
  offset?: number;
}

export interface EmissionFactorStats {
  totalCount: number;
  categoriesCount: number;
  regionsCount: number;
  lastUpdated: Date | null;
  averageConfidence: number;
}

class EmissionFactorsService {
  async initializeEmissionFactors(): Promise<void> {
    const count = await db.emissionFactor.count();

    if (count === 0) {
      const defaultFactors = this.getDefaultEmissionFactors();

      for (const factor of defaultFactors) {
        await db.emissionFactor.create({
          data: {
            category: factor.category,
            subcategory: factor.subcategory,
            region: factor.region,
            value: factor.value,
            unit: factor.unit,
            source: factor.source,
            confidenceLevel: factor.confidenceLevel ?? null,
            validFrom: new Date(),
            validTo: null,
          },
        });
      }
    }
  }

  async getEmissionFactor(
    category: string,
    subcategory: string,
    region = "India",
    fuelType?: string
  ): Promise<EmissionFactor | null> {
    const now = new Date();

    let ef: any = null;

    ef = await db.emissionFactor.findFirst({
      where: {
        category,
        subcategory,
        region,
        validFrom: { lte: now },
        OR: [{ validTo: null }, { validTo: { gte: now } }],
      },
      orderBy: { validFrom: "desc" },
    });

    if (!ef && region !== "global") {
      ef = await db.emissionFactor.findFirst({
        where: {
          category,
          subcategory,
          region: "global",
          validFrom: { lte: now },
          OR: [{ validTo: null }, { validTo: { gte: now } }],
        },
        orderBy: { validFrom: "desc" },
      });
    }

    if (!ef) {
      return null;
    }

    return this.mapToEmissionFactor(ef);
  }

  async updateEmissionFactor(
    id: string,
    data: Partial<EmissionFactorInput>
  ): Promise<EmissionFactor> {
    const updated = await db.emissionFactor.update({
      where: { id },
      data: {
        category: data.category,
        subcategory: data.subcategory,
        region: data.region,
        value: data.value,
        unit: data.unit,
        source: data.source,
        confidenceLevel: data.confidenceLevel ?? null,
      },
    });

    return this.mapToEmissionFactor(updated);
  }

  async getEmissionFactorsByCategory(
    category: string
  ): Promise<EmissionFactor[]> {
    const factors = await db.emissionFactor.findMany({
      where: {
        category,
        validFrom: { lte: new Date() },
        OR: [{ validTo: null }, { validTo: { gte: new Date() } }],
      },
      orderBy: [{ subcategory: "asc" }, { region: "asc" }],
    });

    return factors.map((ef) => this.mapToEmissionFactor(ef));
  }

  async searchEmissionFactors(
    options: EmissionFactorSearchOptions
  ): Promise<EmissionFactor[]> {
    const { category, region, query, limit = 50, offset = 0 } = options;

    const whereClause: any = {
      validFrom: { lte: new Date() },
    };

    if (category) {
      whereClause.category = category;
    }

    if (region) {
      whereClause.region = region;
    }

    if (query) {
      whereClause.OR = [
        { category: { contains: query } },
        { subcategory: { contains: query } },
        { source: { contains: query } },
      ];
    }

    const factors = await db.emissionFactor.findMany({
      where: whereClause,
      take: limit,
      skip: offset,
      orderBy: [{ category: "asc" }, { subcategory: "asc" }],
    });

    return factors.map((ef) => this.mapToEmissionFactor(ef));
  }

  async getEmissionFactorsStats(): Promise<EmissionFactorStats> {
    const [totalCount, categories, regions, lastUpdated, avgConfidence] =
      await Promise.all([
        db.emissionFactor.count(),
        db.emissionFactor.groupBy({
          by: ["category"],
          _count: true,
        }),
        db.emissionFactor.groupBy({
          by: ["region"],
          _count: true,
        }),
        db.emissionFactor.findFirst({
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        }),
        db.emissionFactor.aggregate({
          _avg: { confidenceLevel: true },
        }),
      ]);

    return {
      totalCount,
      categoriesCount: categories.length,
      regionsCount: regions.length,
      lastUpdated: lastUpdated?.createdAt ?? null,
      averageConfidence: avgConfidence._avg.confidenceLevel ?? 0,
    };
  }

  validateEmissionFactor(factor: Partial<EmissionFactorInput>): {
    valid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];

    if (!factor.category || factor.category.trim() === "") {
      errors.push("Category is required");
    }

    if (!factor.subcategory || factor.subcategory.trim() === "") {
      errors.push("Subcategory is required");
    }

    if (!factor.region || factor.region.trim() === "") {
      errors.push("Region is required");
    }

    if (factor.value === undefined || factor.value === null) {
      errors.push("Value is required");
    } else if (factor.value < -100) {
      errors.push(
        "Value must be greater than -100 (unreasonable for carbon-negative processes)"
      );
    }

    if (!factor.unit || factor.unit.trim() === "") {
      errors.push("Unit is required");
    }

    if (!factor.source || factor.source.trim() === "") {
      errors.push("Source is required");
    }

    if (
      factor.confidenceLevel !== undefined &&
      factor.confidenceLevel !== null
    ) {
      if (factor.confidenceLevel < 0 || factor.confidenceLevel > 1) {
        errors.push("Confidence level must be between 0 and 1");
      }
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  private mapToEmissionFactor(ef: any): EmissionFactor {
    return {
      id: ef.id,
      category: ef.category,
      subcategory: ef.subcategory,
      region: ef.region,
      value: ef.value,
      unit: ef.unit,
      source: ef.source,
      confidenceLevel: ef.confidenceLevel ?? undefined,
      validFrom: ef.validFrom,
      validTo: ef.validTo ?? undefined,
      createdAt: ef.createdAt,
    };
  }

  private getDefaultEmissionFactors(): EmissionFactorInput[] {
    return [
      {
        category: "transportation",
        subcategory: "personal_vehicle_gasoline",
        region: "India",
        value: 2.27193,
        unit: "kg CO2/liter",
        source: "India Road Transport Emission Factors",
        confidenceLevel: 0.9,
      },
      {
        category: "transportation",
        subcategory: "personal_vehicle_diesel",
        region: "India",
        value: 2.6444,
        unit: "kg CO2/liter",
        source: "India Road Transport Emission Factors",
        confidenceLevel: 0.9,
      },
      {
        category: "transportation",
        subcategory: "cng",
        region: "India",
        value: 2.692,
        unit: "kg CO2/kg",
        source: "India Road Transport Emission Factors",
        confidenceLevel: 0.85,
      },
      {
        category: "transportation",
        subcategory: "auto_rickshaw",
        region: "India",
        value: 0.085,
        unit: "kg CO2/km",
        source: "India Three-Wheeler Emission Factors",
        confidenceLevel: 0.8,
      },
      {
        category: "transportation",
        subcategory: "bus",
        region: "India",
        value: 0.089,
        unit: "kg CO2/km",
        source: "India Public Transport Emission Factors",
        confidenceLevel: 0.85,
      },
      {
        category: "transportation",
        subcategory: "train",
        region: "India",
        value: 0.041,
        unit: "kg CO2/km",
        source: "Indian Railways Emission Factors",
        confidenceLevel: 0.9,
      },
      {
        category: "transportation",
        subcategory: "motorcycle",
        region: "India",
        value: 0.056,
        unit: "kg CO2/km",
        source: "India Two-Wheeler Emission Factors",
        confidenceLevel: 0.85,
      },
      {
        category: "energy",
        subcategory: "electricity",
        region: "India",
        value: 0.82,
        unit: "kg CO2/kWh",
        source: "Central Electricity Authority India",
        confidenceLevel: 0.95,
      },
      {
        category: "energy",
        subcategory: "lpg",
        region: "India",
        value: 2.983,
        unit: "kg CO2/kg",
        source: "GHG Protocol Derived Values",
        confidenceLevel: 0.9,
      },
      {
        category: "food",
        subcategory: "rice",
        region: "India",
        value: 4.0,
        unit: "kg CO2/kg",
        source: "India Rice Production Emission Factors",
        confidenceLevel: 0.85,
      },
      {
        category: "food",
        subcategory: "wheat",
        region: "India",
        value: 1.8,
        unit: "kg CO2/kg",
        source: "India Wheat Production Emission Factors",
        confidenceLevel: 0.85,
      },
      {
        category: "food",
        subcategory: "chicken",
        region: "India",
        value: 6.9,
        unit: "kg CO2/kg",
        source: "India Poultry Emission Factors",
        confidenceLevel: 0.8,
      },
      {
        category: "food",
        subcategory: "beef",
        region: "global",
        value: 27.0,
        unit: "kg CO2/kg",
        source: "IPCC Global Emission Factors",
        confidenceLevel: 0.9,
      },
      {
        category: "food",
        subcategory: "vegetables",
        region: "India",
        value: 1.4,
        unit: "kg CO2/kg",
        source: "India Agriculture Emission Factors",
        confidenceLevel: 0.8,
      },
      {
        category: "waste",
        subcategory: "landfill",
        region: "India",
        value: 0.586,
        unit: "kg CO2/kg",
        source: "India Waste Management Emission Factors",
        confidenceLevel: 0.75,
      },
      {
        category: "waste",
        subcategory: "recycling",
        region: "global",
        value: -0.07,
        unit: "kg CO2/kg",
        source: "EPA Waste Reduction Model",
        confidenceLevel: 0.8,
      },
    ];
  }
}

export const emissionFactorsService = new EmissionFactorsService();

export { EmissionFactorsService };

export async function getFactor(
  category: string,
  subcategory: string,
  region?: string,
  fuelType?: string
): Promise<EmissionFactor | null> {
  return emissionFactorsService.getEmissionFactor(
    category,
    subcategory,
    region,
    fuelType
  );
}

export async function getAvailableCategories(): Promise<string[]> {
  const factors = await emissionFactorsService.searchEmissionFactors({
    limit: 1000,
  });
  const categorySet = new Set<string>();
  factors.forEach((f) => categorySet.add(f.category));
  return Array.from(categorySet);
}
