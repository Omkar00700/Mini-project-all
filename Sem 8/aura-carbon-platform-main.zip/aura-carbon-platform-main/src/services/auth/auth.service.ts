import { db } from "@/lib/db";
import { randomBytes, createHash } from "crypto";
import bcrypt from "bcryptjs";

const SALT_ROUNDS = 12;
const TOKEN_EXPIRY = 24 * 60 * 60 * 1000;
const RESET_TOKEN_EXPIRY = 60 * 60 * 1000;

export interface User {
  id: string;
  email: string;
  name: string;
  emailVerified: Date | null;
  image: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuthResult {
  success: boolean;
  user?: User;
  error?: string;
  requiresVerification?: boolean;
}

export interface RegisterInput {
  email: string;
  password: string;
  name?: string;
}

export interface ResetPasswordInput {
  token: string;
  newPassword: string;
}

class AuthService {
  async register(input: RegisterInput): Promise<AuthResult> {
    const { email, password, name } = input;

    if (!email || !password) {
      return { success: false, error: "Email and password are required" };
    }

    if (!this.isValidEmail(email)) {
      return { success: false, error: "Invalid email address" };
    }

    if (!this.isStrongPassword(password)) {
      return {
        success: false,
        error:
          "Password must be at least 8 characters with uppercase, lowercase, and number",
      };
    }

    try {
      const existingUser = await db.user.findUnique({
        where: { email: email.toLowerCase() },
      });

      if (existingUser) {
        return {
          success: false,
          error: "An account with this email already exists",
        };
      }

      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      const verificationToken = this.generateToken();

      const user = await db.user.create({
        data: {
          email: email.toLowerCase(),
          name: name || email.split("@")[0],
          passwordHash: hashedPassword,
          emailVerified: null,
          image: null,
          location: {},
          household: { size: 1, type: "individual" },
          preferences: { notifications: true },
          subscription: { tier: "free" },
        },
      });

      await db.verificationToken.create({
        data: {
          identifier: email.toLowerCase(),
          token: this.hashToken(verificationToken),
          expires: new Date(Date.now() + TOKEN_EXPIRY),
        },
      });

      return {
        success: true,
        user: this.sanitizeUser(user),
        requiresVerification: true,
      };
    } catch (error) {
      return {
        success: false,
        error: "Failed to create account. Please try again.",
      };
    }
  }

  async login(email: string, password: string): Promise<AuthResult> {
    if (!email || !password) {
      return { success: false, error: "Email and password are required" };
    }

    try {
      const user = await db.user.findUnique({
        where: { email: email.toLowerCase() },
      });

      if (!user || !user.passwordHash) {
        return { success: false, error: "Invalid email or password" };
      }

      const isValid = await bcrypt.compare(password, user.passwordHash);

      if (!isValid) {
        return { success: false, error: "Invalid email or password" };
      }

      if (!user.emailVerified) {
        return {
          success: false,
          error: "Please verify your email address before logging in",
          requiresVerification: true,
        };
      }

      return {
        success: true,
        user: this.sanitizeUser(user),
      };
    } catch (error) {
      return { success: false, error: "Failed to login. Please try again." };
    }
  }

  async verifyEmail(token: string): Promise<AuthResult> {
    if (!token) {
      return { success: false, error: "Verification token is required" };
    }

    try {
      const hashedToken = this.hashToken(token);

      const verificationToken = await db.verificationToken.findFirst({
        where: {
          token: hashedToken,
          expires: { gt: new Date() },
        },
      });

      if (!verificationToken) {
        return {
          success: false,
          error: "Invalid or expired verification token",
        };
      }

      const user = await db.user.update({
        where: { email: verificationToken.identifier },
        data: { emailVerified: new Date() },
      });

      await db.verificationToken.delete({
        where: {
          identifier_token: {
            identifier: verificationToken.identifier,
            token: hashedToken,
          },
        },
      });

      return {
        success: true,
        user: this.sanitizeUser(user),
      };
    } catch (error) {
      return {
        success: false,
        error: "Failed to verify email. Please try again.",
      };
    }
  }

  async requestPasswordReset(
    email: string
  ): Promise<{ success: boolean; error?: string }> {
    if (!email) {
      return { success: false, error: "Email is required" };
    }

    try {
      const user = await db.user.findUnique({
        where: { email: email.toLowerCase() },
      });

      if (!user) {
        return { success: true };
      }

      const resetToken = this.generateToken();
      const hashedToken = this.hashToken(resetToken);

      await db.verificationToken.deleteMany({
        where: { identifier: `reset:${email.toLowerCase()}` },
      });

      await db.verificationToken.create({
        data: {
          identifier: `reset:${email.toLowerCase()}`,
          token: hashedToken,
          expires: new Date(Date.now() + RESET_TOKEN_EXPIRY),
        },
      });

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: "Failed to process request. Please try again.",
      };
    }
  }

  async resetPassword(input: ResetPasswordInput): Promise<AuthResult> {
    const { token, newPassword } = input;

    if (!token || !newPassword) {
      return { success: false, error: "Token and new password are required" };
    }

    if (!this.isStrongPassword(newPassword)) {
      return {
        success: false,
        error:
          "Password must be at least 8 characters with uppercase, lowercase, and number",
      };
    }

    try {
      const hashedToken = this.hashToken(token);

      const resetToken = await db.verificationToken.findFirst({
        where: {
          token: hashedToken,
          expires: { gt: new Date() },
        },
      });

      if (!resetToken || !resetToken.identifier.startsWith("reset:")) {
        return { success: false, error: "Invalid or expired reset token" };
      }

      const email = resetToken.identifier.replace("reset:", "");
      const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

      const user = await db.user.update({
        where: { email },
        data: {
          passwordHash: hashedPassword,
          emailVerified: new Date(),
        },
      });

      await db.verificationToken.delete({
        where: {
          identifier_token: {
            identifier: resetToken.identifier,
            token: hashedToken,
          },
        },
      });

      return {
        success: true,
        user: this.sanitizeUser(user),
      };
    } catch (error) {
      return {
        success: false,
        error: "Failed to reset password. Please try again.",
      };
    }
  }

  async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string
  ): Promise<AuthResult> {
    if (!currentPassword || !newPassword) {
      return {
        success: false,
        error: "Current and new passwords are required",
      };
    }

    if (!this.isStrongPassword(newPassword)) {
      return {
        success: false,
        error:
          "New password must be at least 8 characters with uppercase, lowercase, and number",
      };
    }

    try {
      const user = await db.user.findUnique({
        where: { id: userId },
      });

      if (!user || !user.passwordHash) {
        return { success: false, error: "User not found" };
      }

      const isValid = await bcrypt.compare(currentPassword, user.passwordHash);

      if (!isValid) {
        return { success: false, error: "Current password is incorrect" };
      }

      const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

      const updatedUser = await db.user.update({
        where: { id: userId },
        data: { passwordHash: hashedPassword },
      });

      return {
        success: true,
        user: this.sanitizeUser(updatedUser),
      };
    } catch (error) {
      return {
        success: false,
        error: "Failed to change password. Please try again.",
      };
    }
  }

  generateAuthToken(userId: string): string {
    const payload = {
      userId,
      iat: Date.now(),
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
    };
    return Buffer.from(JSON.stringify(payload)).toString("base64url");
  }

  verifyAuthToken(token: string): { userId: string } | null {
    try {
      const payload = JSON.parse(Buffer.from(token, "base64url").toString());
      if (payload.exp < Date.now()) {
        return null;
      }
      return { userId: payload.userId };
    } catch {
      return null;
    }
  }

  private generateToken(): string {
    return randomBytes(32).toString("hex");
  }

  private hashToken(token: string): string {
    return createHash("sha256").update(token).digest("hex");
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isStrongPassword(password: string): boolean {
    const minLength = 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    return (
      password.length >= minLength && hasUppercase && hasLowercase && hasNumber
    );
  }

  private sanitizeUser(user: any): User {
    return {
      id: user.id,
      email: user.email,
      name: user.name,
      emailVerified: user.emailVerified,
      image: user.image,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };
  }
}

export const authService = new AuthService();
