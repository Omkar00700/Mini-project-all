import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { DashboardConfig } from "@/types/user";

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error(
    "JWT_SECRET environment variable is not set. Add it to .env.local"
  );
}
const JWT_EXPIRY = "7d";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: string;
  currentStreak?: number;
  longestStreak?: number;
  streakLastMaintained?: Date | string | null;
  currentLevel?: number;
  totalXp?: number;
  image?: string | null;
}

export interface LoginResponse {
  user: AuthUser;
  token: string;
}

export class SimpleAuthService {
  async hashPassword(password: string): Promise<string> {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
  }

  async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  generateToken(userId: string): string {
    return jwt.sign({ userId }, JWT_SECRET as string, {
      expiresIn: JWT_EXPIRY,
    });
  }

  verifyToken(token: string): string | null {
    try {
      const decoded = jwt.verify(token, JWT_SECRET as string) as {
        userId: string;
      };
      return decoded.userId;
    } catch (error) {
      return null;
    }
  }

  async register(
    email: string,
    password: string,
    name: string
  ): Promise<AuthUser> {
    const { defaultDashboardConfig } = await import(
      "@/config/default-dashboard"
    );

    const dashboardConfig: DashboardConfig = {
      ...defaultDashboardConfig,
      widgets: defaultDashboardConfig.widgets.map((widget) => ({
        ...widget,
        config: widget.config || {},
      })),
    };

    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      throw new Error("User with this email already exists");
    }

    const passwordHash = await this.hashPassword(password);

    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        name,
        location: { country: "India", region: "", city: "" },
        household: { size: 1, type: "individual" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: true,
          language: "en",
          timezone: "Asia/Kolkata",
          currency: "INR",
        },
        subscription: {
          tier: "free",
          features: ["basic_tracking", "monthly_reports"],
        },
        dashboardConfig: dashboardConfig as any,
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
      },
    });

    return user as AuthUser;
  }

  async login(email: string, password: string): Promise<LoginResponse> {
    const user = await prisma.user.findUnique({
      where: { email },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        passwordHash: true,
      },
    });

    if (!user || !user.passwordHash) {
      throw new Error("Invalid email or password");
    }

    const isValidPassword = await this.comparePassword(
      password,
      user.passwordHash
    );

    if (!isValidPassword) {
      throw new Error("Invalid email or password");
    }

    const token = this.generateToken(user.id);

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await this.createSession(user.id, token, expiresAt);

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await this.cleanupExpiredSessions(user.id);

    return {
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      token,
    };
  }

  async createSession(
    userId: string,
    token: string,
    expiresAt: Date
  ): Promise<void> {
    await prisma.session.create({
      data: {
        userId,
        sessionToken: token,
        expires: expiresAt,
      },
    });
  }

  async logout(token: string): Promise<void> {
    await prisma.session.deleteMany({
      where: { sessionToken: token },
    });
  }

  async verifyTokenAndGetUser(token: string): Promise<AuthUser | null> {
    const userId = this.verifyToken(token);
    if (!userId) {
      return null;
    }

    const session = await prisma.session.findUnique({
      where: { sessionToken: token },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
            currentStreak: true,
            longestStreak: true,
            streakLastMaintained: true,
            currentLevel: true,
            totalXp: true,
            image: true,
          },
        },
      },
    });

    if (!session || session.expires < new Date()) {
      if (session) {
        await prisma.session.delete({ where: { sessionToken: token } });
      }
      return null;
    }

    return session.user as AuthUser;
  }

  private async cleanupExpiredSessions(userId: string): Promise<void> {
    await prisma.session.deleteMany({
      where: {
        userId,
        expires: {
          lt: new Date(),
        },
      },
    });
  }
}

export const authService = new SimpleAuthService();
