import { emissionFactorsService } from "./emission-factors";

interface ElectricityData {
  consumption: number;
  gridRegion: string;
  renewablePercentage?: number;
  sourceMix?: {
    coal?: number;
    naturalGas?: number;
    nuclear?: number;
    hydro?: number;
    wind?: number;
    solar?: number;
    other?: number;
  };
  timeOfUse?: {
    peak: number;
    offPeak: number;
  };
  utilityProvider?: string;
}

interface HeatingData {
  naturalGas?: number;
  heatingOil?: number;
  propane?: number;
  wood?: number;
  districtHeating?: number;
  heatPump?: {
    electricity: number;
    cop: number;
    heatSource: "air" | "ground" | "water";
  };
  systemEfficiency?: number;
  heatedArea?: number;
}

interface CoolingData {
  electricity: number;
  systemType: "central_ac" | "window_ac" | "heat_pump" | "evaporative";
  seer?: number;
  cooledArea?: number;
  climateZone?: string;
}

interface RenewableData {
  solarGenerated?: number;
  windGenerated?: number;
  hydroGenerated?: number;
  geothermalGenerated?: number;
  batteryStorage?: {
    capacity: number;
    cycleEfficiency: number;
  };
  netMetering?: boolean;
}

interface GridEmissionFactor {
  region: string;
  timestamp: Date;
  emissionFactor: number;
  renewablePercentage: number;
  sourceMix: {
    coal: number;
    naturalGas: number;
    nuclear: number;
    hydro: number;
    wind: number;
    solar: number;
    other: number;
  };
  marginalEmissionFactor?: number;
}

class EnergyCalculator {
  async calculateElectricityEmissions(data: ElectricityData): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      renewableAdjustment: number;
      timeOfUseAdjustment: number;
      sourceMixAdjustment: number;
    };
    gridData: GridEmissionFactor;
    methodology: string;
  }> {
    try {
      const gridData = await this.getRealTimeGridData(data.gridRegion);

      const baseEmissions = data.consumption * gridData.emissionFactor;

      let renewableAdjustment = 0;
      if (data.renewablePercentage !== undefined) {
        const renewableFactor = data.renewablePercentage / 100;
        renewableAdjustment = -baseEmissions * renewableFactor;
      }

      let timeOfUseAdjustment = 0;
      if (data.timeOfUse && gridData.marginalEmissionFactor) {
        const peakEmissions =
          data.timeOfUse.peak * gridData.marginalEmissionFactor;
        const offPeakEmissions =
          data.timeOfUse.offPeak * gridData.emissionFactor;
        const standardEmissions = data.consumption * gridData.emissionFactor;
        timeOfUseAdjustment =
          peakEmissions + offPeakEmissions - standardEmissions;
      }

      let sourceMixAdjustment = 0;
      if (data.sourceMix) {
        const customEmissions = await this.calculateCustomSourceMixEmissions(
          data.consumption,
          data.sourceMix
        );
        sourceMixAdjustment = customEmissions - baseEmissions;
      }

      const totalEmissions =
        baseEmissions +
        renewableAdjustment +
        timeOfUseAdjustment +
        sourceMixAdjustment;

      return {
        totalEmissions: Math.max(0, totalEmissions),
        breakdown: {
          baseEmissions,
          renewableAdjustment,
          timeOfUseAdjustment,
          sourceMixAdjustment,
        },
        gridData,
        methodology:
          "Real-time grid emission factors with renewable adjustments",
      };
    } catch (error) {
      throw new Error("Failed to calculate electricity emissions");
    }
  }

  async calculateHeatingEmissions(data: HeatingData): Promise<{
    totalEmissions: number;
    breakdown: {
      naturalGasEmissions: number;
      heatingOilEmissions: number;
      propaneEmissions: number;
      woodEmissions: number;
      districtHeatingEmissions: number;
      heatPumpEmissions: number;
      efficiencyAdjustment: number;
    };
    methodology: string;
  }> {
    try {
      let totalEmissions = 0;
      const breakdown = {
        naturalGasEmissions: 0,
        heatingOilEmissions: 0,
        propaneEmissions: 0,
        woodEmissions: 0,
        districtHeatingEmissions: 0,
        heatPumpEmissions: 0,
        efficiencyAdjustment: 0,
      };

      if (data.naturalGas) {
        const factor = await emissionFactorsService.getEmissionFactor(
          "energy",
          "heating",
          "global",
          "natural_gas"
        );
        if (factor) {
          breakdown.naturalGasEmissions = data.naturalGas * factor.value;
        }
      }

      if (data.heatingOil) {
        const factor = await emissionFactorsService.getEmissionFactor(
          "energy",
          "heating",
          "global",
          "heating_oil"
        );
        if (factor) {
          breakdown.heatingOilEmissions = data.heatingOil * factor.value;
        }
      }

      if (data.propane) {
        const factor = await emissionFactorsService.getEmissionFactor(
          "energy",
          "heating",
          "global",
          "propane"
        );
        if (factor) {
          breakdown.propaneEmissions = data.propane * factor.value;
        }
      }

      if (data.wood) {
        breakdown.woodEmissions = data.wood * 0.1;
      }

      if (data.districtHeating) {
        const factor = await emissionFactorsService.getEmissionFactor(
          "energy",
          "heating",
          "global",
          "district_heating"
        );
        if (factor) {
          breakdown.districtHeatingEmissions =
            data.districtHeating * factor.value;
        } else {
          const gridData = await this.getRealTimeGridData("global");
          breakdown.districtHeatingEmissions =
            data.districtHeating * gridData.emissionFactor * 0.8;
        }
      }

      if (data.heatPump) {
        const gridData = await this.getRealTimeGridData("global");
        const heatPumpEfficiency =
          data.heatPump.cop || this.getDefaultCOP(data.heatPump.heatSource);
        const effectiveElectricity =
          data.heatPump.electricity / heatPumpEfficiency;
        breakdown.heatPumpEmissions =
          effectiveElectricity * gridData.emissionFactor;
      }

      const baseTotal = Object.values(breakdown).reduce(
        (sum, value) => sum + value,
        0
      );

      const systemEfficiency = data.systemEfficiency || 0.85;
      breakdown.efficiencyAdjustment = baseTotal * (1 / systemEfficiency - 1);

      totalEmissions = baseTotal + breakdown.efficiencyAdjustment;

      return {
        totalEmissions,
        breakdown,
        methodology:
          "Fuel-specific emission factors with efficiency adjustments",
      };
    } catch (error) {
      throw new Error("Failed to calculate heating emissions");
    }
  }

  async calculateCoolingEmissions(data: CoolingData): Promise<{
    totalEmissions: number;
    breakdown: {
      baseEmissions: number;
      efficiencyAdjustment: number;
      climateAdjustment: number;
    };
    methodology: string;
  }> {
    try {
      const gridData = await this.getRealTimeGridData("global");

      const baseEmissions = data.electricity * gridData.emissionFactor;

      let efficiencyAdjustment = 0;
      if (data.seer) {
        const standardSEER = this.getStandardSEER(data.systemType);
        const efficiencyRatio = standardSEER / data.seer;
        efficiencyAdjustment = baseEmissions * (efficiencyRatio - 1);
      }

      let climateAdjustment = 0;
      if (data.climateZone) {
        const climateMultiplier = this.getClimateMultiplier(data.climateZone);
        climateAdjustment = baseEmissions * (climateMultiplier - 1);
      }

      const totalEmissions =
        baseEmissions + efficiencyAdjustment + climateAdjustment;

      return {
        totalEmissions: Math.max(0, totalEmissions),
        breakdown: {
          baseEmissions,
          efficiencyAdjustment,
          climateAdjustment,
        },
        methodology:
          "Grid electricity factors with SEER efficiency adjustments",
      };
    } catch (error) {
      throw new Error("Failed to calculate cooling emissions");
    }
  }

  async calculateRenewableCredits(data: RenewableData): Promise<{
    totalCredits: number;
    breakdown: {
      solarCredits: number;
      windCredits: number;
      hydroCredits: number;
      geothermalCredits: number;
      batteryEfficiencyLoss: number;
    };
    methodology: string;
  }> {
    try {
      const gridData = await this.getRealTimeGridData("global");

      const breakdown = {
        solarCredits: 0,
        windCredits: 0,
        hydroCredits: 0,
        geothermalCredits: 0,
        batteryEfficiencyLoss: 0,
      };

      if (data.solarGenerated) {
        breakdown.solarCredits = -data.solarGenerated * gridData.emissionFactor;
      }

      if (data.windGenerated) {
        breakdown.windCredits = -data.windGenerated * gridData.emissionFactor;
      }

      if (data.hydroGenerated) {
        breakdown.hydroCredits = -data.hydroGenerated * gridData.emissionFactor;
      }

      if (data.geothermalGenerated) {
        breakdown.geothermalCredits =
          -data.geothermalGenerated * gridData.emissionFactor;
      }

      if (data.batteryStorage) {
        const totalGeneration =
          (data.solarGenerated || 0) +
          (data.windGenerated || 0) +
          (data.hydroGenerated || 0) +
          (data.geothermalGenerated || 0);
        const storedEnergy = Math.min(
          totalGeneration,
          data.batteryStorage.capacity
        );
        const efficiencyLoss =
          storedEnergy * (1 - data.batteryStorage.cycleEfficiency);
        breakdown.batteryEfficiencyLoss =
          efficiencyLoss * gridData.emissionFactor;
      }

      const totalCredits = Object.values(breakdown).reduce(
        (sum, value) => sum + value,
        0
      );

      return {
        totalCredits,
        breakdown,
        methodology: "Grid displacement method for renewable energy credits",
      };
    } catch (error) {
      throw new Error("Failed to calculate renewable credits");
    }
  }

  async calculateEnergyFootprint(data: {
    electricity?: ElectricityData;
    heating?: HeatingData;
    cooling?: CoolingData;
    renewable?: RenewableData;
  }): Promise<{
    totalEmissions: number;
    breakdown: {
      electricity: number;
      heating: number;
      cooling: number;
      renewableCredits: number;
    };
    details: any[];
    methodology: string;
    recommendations: string[];
  }> {
    try {
      const details = [];
      let electricityEmissions = 0;
      let heatingEmissions = 0;
      let coolingEmissions = 0;
      let renewableCredits = 0;

      if (data.electricity) {
        const result = await this.calculateElectricityEmissions(
          data.electricity
        );
        electricityEmissions = result.totalEmissions;
        details.push({ type: "electricity", ...result });
      }

      if (data.heating) {
        const result = await this.calculateHeatingEmissions(data.heating);
        heatingEmissions = result.totalEmissions;
        details.push({ type: "heating", ...result });
      }

      if (data.cooling) {
        const result = await this.calculateCoolingEmissions(data.cooling);
        coolingEmissions = result.totalEmissions;
        details.push({ type: "cooling", ...result });
      }

      if (data.renewable) {
        const result = await this.calculateRenewableCredits(data.renewable);
        renewableCredits = result.totalCredits;
        details.push({ type: "renewable", ...result });
      }

      const totalEmissions =
        electricityEmissions +
        heatingEmissions +
        coolingEmissions +
        renewableCredits;

      const recommendations = await this.generateEnergyRecommendations(data);

      return {
        totalEmissions: Math.max(0, totalEmissions),
        breakdown: {
          electricity: electricityEmissions,
          heating: heatingEmissions,
          cooling: coolingEmissions,
          renewableCredits,
        },
        details,
        methodology:
          "Comprehensive energy calculator with real-time grid factors",
        recommendations,
      };
    } catch (error) {
      throw new Error("Failed to calculate energy footprint");
    }
  }

  private async getRealTimeGridData(
    region: string
  ): Promise<GridEmissionFactor> {
    try {
      const baseFactors: Record<string, number> = {
        US: 0.386,
        EU: 0.276,
        UK: 0.193,
        global: 0.475,
      };

      const baseFactor = baseFactors[region] || baseFactors["global"];

      const variation = (Math.random() - 0.5) * 0.4;
      const currentFactor = baseFactor * (1 + variation);

      return {
        region,
        timestamp: new Date(),
        emissionFactor: currentFactor,
        renewablePercentage: Math.random() * 40 + 20,
        sourceMix: {
          coal: Math.random() * 30,
          naturalGas: Math.random() * 40,
          nuclear: Math.random() * 20,
          hydro: Math.random() * 15,
          wind: Math.random() * 25,
          solar: Math.random() * 15,
          other: Math.random() * 10,
        },
        marginalEmissionFactor: currentFactor * 1.2,
      };
    } catch (error) {
      return {
        region,
        timestamp: new Date(),
        emissionFactor: 0.475,
        renewablePercentage: 30,
        sourceMix: {
          coal: 25,
          naturalGas: 35,
          nuclear: 15,
          hydro: 10,
          wind: 10,
          solar: 3,
          other: 2,
        },
      };
    }
  }

  private async calculateCustomSourceMixEmissions(
    consumption: number,
    sourceMix: ElectricityData["sourceMix"]
  ): Promise<number> {
    const sourceEmissionFactors = {
      coal: 0.82,
      naturalGas: 0.35,
      nuclear: 0.012,
      hydro: 0.024,
      wind: 0.011,
      solar: 0.041,
      other: 0.5,
    };

    let totalEmissions = 0;
    let totalPercentage = 0;

    for (const [source, percentage] of Object.entries(sourceMix || {})) {
      if (
        percentage &&
        sourceEmissionFactors[source as keyof typeof sourceEmissionFactors]
      ) {
        const factor =
          sourceEmissionFactors[source as keyof typeof sourceEmissionFactors];
        totalEmissions += consumption * (percentage / 100) * factor;
        totalPercentage += percentage;
      }
    }

    if (totalPercentage > 0 && totalPercentage !== 100) {
      totalEmissions = totalEmissions * (100 / totalPercentage);
    }

    return totalEmissions;
  }

  private getDefaultCOP(heatSource: string): number {
    const defaultCOPs = {
      air: 3.0,
      ground: 4.0,
      water: 4.5,
    };
    return defaultCOPs[heatSource as keyof typeof defaultCOPs] || 3.0;
  }

  private getStandardSEER(systemType: string): number {
    const standardSEERs = {
      central_ac: 14,
      window_ac: 10,
      heat_pump: 15,
      evaporative: 25,
    };
    return standardSEERs[systemType as keyof typeof standardSEERs] || 13;
  }

  private getClimateMultiplier(climateZone: string): number {
    const climateMultipliers = {
      hot_humid: 1.2,
      hot_dry: 1.1,
      mixed_humid: 1.0,
      mixed_dry: 0.9,
      cold: 0.7,
      very_cold: 0.5,
    };
    return (
      climateMultipliers[climateZone as keyof typeof climateMultipliers] || 1.0
    );
  }

  private async generateEnergyRecommendations(data: {
    electricity?: ElectricityData;
    heating?: HeatingData;
    cooling?: CoolingData;
    renewable?: RenewableData;
  }): Promise<string[]> {
    const recommendations: string[] = [];

    if (data.electricity) {
      const gridData = await this.getRealTimeGridData(
        data.electricity.gridRegion
      );

      if (gridData.renewablePercentage < 50) {
        recommendations.push(
          "Consider switching to a renewable energy plan from your utility provider"
        );
      }

      if (
        !data.electricity.renewablePercentage ||
        data.electricity.renewablePercentage < 20
      ) {
        recommendations.push(
          "Install solar panels or purchase renewable energy certificates"
        );
      }

      if (data.electricity.consumption > 1000) {
        recommendations.push(
          "Implement energy efficiency measures like LED lighting and ENERGY STAR appliances"
        );
      }
    }

    if (data.heating) {
      if (data.heating.naturalGas && !data.heating.heatPump) {
        recommendations.push(
          "Consider upgrading to a high-efficiency heat pump for heating"
        );
      }

      if (data.heating.heatingOil) {
        recommendations.push(
          "Replace oil heating with electric heat pump or natural gas for lower emissions"
        );
      }

      if (
        !data.heating.systemEfficiency ||
        data.heating.systemEfficiency < 0.8
      ) {
        recommendations.push(
          "Improve heating system efficiency with regular maintenance and upgrades"
        );
      }
    }

    if (data.cooling) {
      if (!data.cooling.seer || data.cooling.seer < 16) {
        recommendations.push(
          "Upgrade to a high-efficiency cooling system (SEER 16+ rating)"
        );
      }

      if (data.cooling.systemType === "window_ac") {
        recommendations.push(
          "Consider upgrading to a central heat pump system for better efficiency"
        );
      }
    }

    if (
      !data.renewable ||
      (!data.renewable.solarGenerated && !data.renewable.windGenerated)
    ) {
      recommendations.push(
        "Explore on-site renewable energy generation like rooftop solar"
      );
    }

    return recommendations;
  }
}

export const energyCalculator = new EnergyCalculator();
