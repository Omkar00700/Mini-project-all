import { db } from "@/lib/db";

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  emissions: number;
  change: number;
  isCurrentUser: boolean;
  achievements: number;
  streak: number;
}

export interface LeaderboardOptions {
  type: "weekly" | "monthly" | "all-time";
  category?: string;
  region?: string;
  limit?: number;
}

export interface ShareableContent {
  title: string;
  description: string;
  imageUrl?: string;
  url: string;
  achievements?: string[];
  stats?: {
    totalEmissions: number;
    rank?: number;
    achievementsUnlocked: number;
    streak: number;
  };
}

class SocialService {
  async getLeaderboard(
    userId: string,
    options: LeaderboardOptions
  ): Promise<LeaderboardEntry[]> {
    const { type, category, limit = 50 } = options;

    const now = new Date();
    let startDate: Date;

    switch (type) {
      case "weekly":
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case "monthly":
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case "all-time":
      default:
        startDate = new Date(2020, 0, 1);
    }

    const users = await db.user.findMany({
      where: {
        activityData: {
          some: {
            date: { gte: startDate },
          },
        },
      },
      select: {
        id: true,
        name: true,
        activityData: {
          where: {
            date: { gte: startDate },
            ...(category && { category }),
          },
          select: { value: true },
        },
        achievements: {
          select: { id: true },
        },
      },
    });

    const leaderboard = users
      .map((user) => {
        const totalEmissions = user.activityData.reduce(
          (sum, a) => sum + a.value,
          0
        );
        const achievementCount = user.achievements.length;

        return {
          userId: user.id,
          userName: user.name || "Anonymous",
          emissions: totalEmissions,
          achievements: achievementCount,
          streak: 0,
        };
      })
      .filter((u) => u.emissions > 0)
      .sort((a, b) => a.emissions - b.emissions)
      .slice(0, limit);

    return leaderboard.map((entry, index) => ({
      rank: index + 1,
      ...entry,
      change: 0,
      isCurrentUser: entry.userId === userId,
    }));
  }

  async getUserRank(
    userId: string,
    type: "weekly" | "monthly" | "all-time" = "monthly"
  ): Promise<{ rank: number; total: number; percentile: number }> {
    const leaderboard = await this.getLeaderboard(userId, {
      type,
      limit: 1000,
    });
    const userEntry = leaderboard.find((e) => e.userId === userId);

    if (!userEntry) {
      return { rank: 0, total: leaderboard.length, percentile: 0 };
    }

    return {
      rank: userEntry.rank,
      total: leaderboard.length,
      percentile: Math.round((1 - userEntry.rank / leaderboard.length) * 100),
    };
  }

  async generateAchievementShare(
    userId: string,
    achievementId: string
  ): Promise<ShareableContent> {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { name: true },
    });

    const achievement = await db.achievement.findFirst({
      where: { userId, key: achievementId },
    });

    if (!achievement || !user) {
      throw new Error("Achievement not found");
    }

    return {
      title: `I unlocked "${achievement.title}" on Aura!`,
      description: `${achievement.description} Track your carbon footprint and earn achievements at aura.co.in`,
      url: `https://aura.co.in/share/achievement/${achievementId}`,
      achievements: [achievement.icon],
    };
  }

  async generateProfileShare(userId: string): Promise<ShareableContent> {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        name: true,
        activityData: {
          select: { value: true },
        },
        achievements: {
          select: { icon: true },
        },
      },
    });

    if (!user) {
      throw new Error("User not found");
    }

    const totalEmissions = user.activityData.reduce(
      (sum, a) => sum + a.value,
      0
    );
    const { rank } = await this.getUserRank(userId);

    return {
      title: `${user.name}'s Carbon Footprint Journey`,
      description: `I've tracked ${totalEmissions.toFixed(1)} kg CO2 on Aura. Rank #${rank}! Join me in reducing emissions.`,
      url: `https://aura.co.in/share/profile/${userId}`,
      achievements: user.achievements.map((a) => a.icon),
      stats: {
        totalEmissions,
        rank,
        achievementsUnlocked: user.achievements.length,
        streak: 0,
      },
    };
  }

  async generateMilestoneShare(
    userId: string,
    milestone: string,
    value: number
  ): Promise<ShareableContent> {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { name: true },
    });

    const templates: Record<string, string> = {
      co2_saved: `I've saved ${value.toFixed(1)} kg of CO2!`,
      streak: `${value} day tracking streak! 📅`,
      rank: `I'm ranked #${value} on Aura!`,
      goal_completed: `Achieved my carbon reduction goal! 🎯`,
    };

    return {
      title: `${user?.name || "I"} reached a milestone on Aura!`,
      description: templates[milestone] || `Milestone: ${milestone}`,
      url: `https://aura.co.in/share/milestone/${milestone}/${value}`,
    };
  }

  async compareWithUser(
    userId: string,
    otherUserId: string
  ): Promise<{
    you: { emissions: number; achievements: number; rank: number };
    them: { emissions: number; achievements: number; rank: number };
    comparison: {
      emissionsDiff: number;
      achievementsDiff: number;
      better: "you" | "them" | "equal";
    };
  }> {
    const [yourData, theirData] = await Promise.all([
      this.getUserSummary(userId),
      this.getUserSummary(otherUserId),
    ]);

    return {
      you: yourData,
      them: theirData,
      comparison: {
        emissionsDiff: yourData.emissions - theirData.emissions,
        achievementsDiff: yourData.achievements - theirData.achievements,
        better:
          yourData.emissions < theirData.emissions
            ? "you"
            : yourData.emissions > theirData.emissions
              ? "them"
              : "equal",
      },
    };
  }

  async getSimilarUsers(
    userId: string,
    limit: number = 5
  ): Promise<
    Array<{
      emissions: number;
      percentile: number;
      description: string;
    }>
  > {
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        location: true,
        household: true,
        activityData: { select: { value: true } },
      },
    });

    if (!user) {
      return [];
    }

    const userEmissions = user.activityData.reduce(
      (sum, a) => sum + a.value,
      0
    );

    const similarUsers = await db.user.findMany({
      where: {
        id: { not: userId },
      },
      select: {
        id: true,
        activityData: { select: { value: true } },
      },
      take: limit * 2,
    });

    const allEmissions = similarUsers.map((u) =>
      u.activityData.reduce((sum: number, a) => sum + a.value, 0)
    );

    const sortedEmissions = allEmissions.sort((a, b) => a - b);
    const percentiles = [25, 50, 75];

    return percentiles.map((p) => {
      const index = Math.floor((p / 100) * sortedEmissions.length);
      const emissions = sortedEmissions[index] || 0;

      return {
        emissions,
        percentile: p,
        description: this.getPercentileDescription(p, emissions),
      };
    });
  }

  private async getUserSummary(userId: string): Promise<{
    emissions: number;
    achievements: number;
    rank: number;
  }> {
    const [activityData, achievements, { rank }] = await Promise.all([
      db.activityData.findMany({
        where: { userId },
        select: { value: true },
      }),
      db.achievement.count({ where: { userId } }),
      this.getUserRank(userId),
    ]);

    return {
      emissions: activityData.reduce((sum, a) => sum + a.value, 0),
      achievements,
      rank,
    };
  }

  private getPercentileDescription(
    percentile: number,
    emissions: number
  ): string {
    const descriptions: Record<number, string> = {
      25: `Top performers: ${emissions.toFixed(1)} kg CO2/month`,
      50: `Average: ${emissions.toFixed(1)} kg CO2/month`,
      75: `Higher emitters: ${emissions.toFixed(1)} kg CO2/month`,
    };

    return descriptions[percentile] || `${emissions.toFixed(1)} kg CO2/month`;
  }
}

export const socialService = new SocialService();
