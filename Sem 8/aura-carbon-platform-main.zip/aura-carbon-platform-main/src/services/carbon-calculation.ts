import { db } from "@/lib/db";
import { carbonOrchestrator } from "./carbon-orchestrator";
import type {
  CarbonCalculation,
  EmissionFactor,
  TransportationData,
  EnergyData,
  FoodData,
  ConsumptionData,
  CarbonFootprintInput,
  CarbonFootprintResult,
} from "@/types/carbon";

class CarbonCalculationService {
  async calculateTransportationEmissions(
    userId: string,
    transportPayload: TransportationData
  ): Promise<number> {
    try {
      let aggregatedEmissions = 0;

      if (transportPayload.personal_vehicles) {
        const {
          distance,
          fuel_type,
          efficiency = 10,
        } = transportPayload.personal_vehicles;
        const emissionFactor = await this.resolveFactor(
          "transportation",
          "personal_vehicle",
          fuel_type
        );

        if (emissionFactor) {
          const expectedFuelVolume = distance / efficiency;
          aggregatedEmissions += expectedFuelVolume * emissionFactor.value;
        }
      }

      if (transportPayload.public_transport) {
        const publicNetworks = [
          { key: "bus_distance", type: "bus" },
          { key: "train_distance", type: "train" },
          { key: "subway_distance", type: "subway" },
          { key: "tram_distance", type: "tram" },
        ];

        for (const { key, type } of publicNetworks) {
          const commuteDistance =
            transportPayload.public_transport[
              key as keyof typeof transportPayload.public_transport
            ];
          if (commuteDistance) {
            const factor = await this.resolveFactor(
              "transportation",
              "public_transport",
              type
            );
            if (factor) aggregatedEmissions += commuteDistance * factor.value;
          }
        }
      }

      if (transportPayload.flights) {
        const aviationCategories = [
          { key: "domestic_short", type: "domestic_short" },
          { key: "domestic_medium", type: "domestic_medium" },
          { key: "domestic_long", type: "domestic_long" },
          { key: "international_short", type: "international_short" },
          { key: "international_long", type: "international_long" },
        ];

        for (const { key, type } of aviationCategories) {
          const flightDistance =
            transportPayload.flights[
              key as keyof typeof transportPayload.flights
            ];
          if (typeof flightDistance === "number") {
            const factor = await this.resolveFactor(
              "transportation",
              "aviation",
              type
            );

            if (factor) {
              const radiativeForcingMultiplier = 1.9;
              let classPremiumMultiplier = 1.0;

              if (transportPayload.flights.class === "business")
                classPremiumMultiplier = 1.5;
              else if (transportPayload.flights.class === "first")
                classPremiumMultiplier = 2.0;

              const genericEmissions = flightDistance * factor.value;
              aggregatedEmissions +=
                genericEmissions *
                radiativeForcingMultiplier *
                classPremiumMultiplier;
            }
          }
        }
      }

      return aggregatedEmissions;
    } catch (operationError) {
      throw new Error("Unable to synthesize transportation emissions");
    }
  }

  async calculateEnergyEmissions(
    userId: string,
    energyPayload: EnergyData
  ): Promise<number> {
    try {
      let aggregatedEmissions = 0;

      if (energyPayload.electricity) {
        const {
          consumption,
          grid_region,
          renewable_percentage = 0,
        } = energyPayload.electricity;
        const gridFactor = await this.resolveFactor(
          "energy",
          "electricity",
          grid_region
        );

        if (gridFactor) {
          const baseEmissions = consumption * gridFactor.value;
          const adjustedEmissions =
            baseEmissions * (1 - renewable_percentage / 100);
          aggregatedEmissions += adjustedEmissions;
        }
      }

      if (energyPayload.heating) {
        const thermalModes = [
          { key: "natural_gas", type: "natural_gas" },
          { key: "heating_oil", type: "heating_oil" },
          { key: "propane", type: "propane" },
          { key: "wood", type: "wood" },
          { key: "district_heating", type: "district_heating" },
        ];

        for (const { key, type } of thermalModes) {
          const capacity =
            energyPayload.heating[key as keyof typeof energyPayload.heating];
          if (capacity) {
            const factor = await this.resolveFactor("energy", "heating", type);

            if (factor) {
              const STANDARD_EFFICIENCY_RATIO = 0.8;
              const normalizedCapacity = capacity / STANDARD_EFFICIENCY_RATIO;
              aggregatedEmissions += normalizedCapacity * factor.value;
            }
          }
        }
      }

      if (energyPayload.cooling) {
        const { electricity, efficiency_rating } = energyPayload.cooling;
        const chillerFactor = await this.resolveFactor(
          "energy",
          "electricity",
          "cooling"
        );

        if (chillerFactor) {
          let energyModifier = 1.0;
          switch (efficiency_rating) {
            case "A+++":
              energyModifier = 0.7;
              break;
            case "A++":
              energyModifier = 0.8;
              break;
            case "A+":
              energyModifier = 0.9;
              break;
            case "A":
              energyModifier = 1.0;
              break;
            case "B":
              energyModifier = 1.1;
              break;
            case "C":
              energyModifier = 1.2;
              break;
          }

          const dynamicLoad = electricity * energyModifier;
          aggregatedEmissions += dynamicLoad * chillerFactor.value;
        }
      }

      return aggregatedEmissions;
    } catch (operationError) {
      throw new Error("Unable to synthesize energy emissions");
    }
  }

  async calculateFoodEmissions(
    userId: string,
    dietaryPayload: FoodData
  ): Promise<number> {
    try {
      let aggregatedEmissions = 0;
      const macronutrientCategories = [
        "meat",
        "dairy",
        "plant_based",
        "beverages",
        "dining_out",
      ];

      for (const macronutrient of macronutrientCategories) {
        const specificDietData =
          dietaryPayload[macronutrient as keyof FoodData];
        if (specificDietData && typeof specificDietData === "object") {
          for (const [ingredientType, parsedVolume] of Object.entries(
            specificDietData
          )) {
            if (typeof parsedVolume === "number" && parsedVolume > 0) {
              const factor = await this.resolveFactor(
                "food",
                macronutrient,
                ingredientType
              );
              if (factor) {
                aggregatedEmissions += parsedVolume * factor.value;
              }
            }
          }
        }
      }

      return aggregatedEmissions;
    } catch (operationError) {
      throw new Error("Unable to synthesize food emissions");
    }
  }

  async calculateConsumptionEmissions(
    userId: string,
    consumptionPayload: ConsumptionData
  ): Promise<number> {
    try {
      let aggregatedEmissions = 0;

      if (consumptionPayload.shopping) {
        const retailVerticals = [
          "clothing",
          "electronics",
          "furniture",
          "books",
          "other_goods",
        ];
        for (const vertical of retailVerticals) {
          const expenditure =
            consumptionPayload.shopping[
              vertical as keyof typeof consumptionPayload.shopping
            ];
          if (typeof expenditure === "number" && expenditure > 0) {
            const factor = await this.resolveFactor(
              "consumption",
              "shopping",
              vertical
            );
            if (factor) aggregatedEmissions += expenditure * factor.value;
          }
        }
      }

      if (consumptionPayload.services) {
        const genericServices = [
          "banking",
          "insurance",
          "telecommunications",
          "entertainment",
        ];
        for (const service of genericServices) {
          const utilityLoad =
            consumptionPayload.services[
              service as keyof typeof consumptionPayload.services
            ];
          if (typeof utilityLoad === "number" && utilityLoad > 0) {
            const factor = await this.resolveFactor(
              "consumption",
              "services",
              service
            );
            if (factor) aggregatedEmissions += utilityLoad * factor.value;
          }
        }
      }

      if (consumptionPayload.waste) {
        const wasteStreams = [
          "general_waste",
          "recycling",
          "organic_waste",
          "electronic_waste",
        ];
        for (const stream of wasteStreams) {
          const disposalWeight =
            consumptionPayload.waste[
              stream as keyof typeof consumptionPayload.waste
            ];
          if (typeof disposalWeight === "number" && disposalWeight > 0) {
            const factor = await this.resolveFactor(
              "waste",
              "disposal",
              stream
            );
            if (factor) aggregatedEmissions += disposalWeight * factor.value;
          }
        }
      }

      return aggregatedEmissions;
    } catch (operationError) {
      throw new Error("Unable to synthesize consumption emissions");
    }
  }

  async calculateTotalFootprint(
    userId: string,
    data: {
      transportation?: TransportationData;
      energy?: EnergyData;
      food?: FoodData;
      consumption?: ConsumptionData;
    },
    periodStart?: Date,
    periodEnd?: Date
  ): Promise<CarbonFootprintResult> {
    try {
      const footprintConfiguration: CarbonFootprintInput = {
        user_id: userId,
        period: {
          start:
            periodStart ||
            new Date(new Date().getFullYear(), new Date().getMonth(), 1),
          end: periodEnd || new Date(),
        },
        categories: data,
      };

      return await carbonOrchestrator.calculateCarbonFootprint(
        footprintConfiguration
      );
    } catch (orchestrationError) {
      throw new Error("Unable to compile unified total footprint");
    }
  }

  async calculateComprehensiveFootprint(
    input: CarbonFootprintInput
  ): Promise<CarbonFootprintResult> {
    try {
      return await carbonOrchestrator.calculateCarbonFootprint(input);
    } catch (orchestrationError) {
      throw new Error("Unable to construct comprehensive carbon resolution");
    }
  }

  private async resolveFactor(
    category: string,
    subcategory: string,
    region: string = "global"
  ): Promise<EmissionFactor | null> {
    try {
      const dbFactor = await db.emissionFactor.findFirst({
        where: {
          category,
          subcategory,
          region,
          validFrom: { lte: new Date() },
          OR: [{ validTo: null }, { validTo: { gte: new Date() } }],
        },
        orderBy: { validFrom: "desc" },
      });

      return dbFactor as EmissionFactor | null;
    } catch (databaseQueryError) {
      return null;
    }
  }

  async getReductionRecommendations(
    userId: string,
    historyProfile: CarbonCalculation
  ): Promise<
    Array<{
      category: string;
      action: string;
      potentialReduction: number;
      difficulty: "easy" | "medium" | "hard";
      cost: "low" | "medium" | "high";
    }>
  > {
    const tailoredSuggestions = [];
    const internalBreakdown = historyProfile.breakdown as any;

    if (internalBreakdown.transportation > 2000) {
      tailoredSuggestions.push({
        category: "transportation",
        action: "Switch to electric vehicle or increase public transport usage",
        potentialReduction: internalBreakdown.transportation * 0.6,
        difficulty: "medium" as const,
        cost: "high" as const,
      });
    }

    if (internalBreakdown.energy > 3000) {
      tailoredSuggestions.push({
        category: "energy",
        action: "Install solar panels or switch to renewable energy provider",
        potentialReduction: internalBreakdown.energy * 0.8,
        difficulty: "medium" as const,
        cost: "high" as const,
      });
    }

    if (internalBreakdown.food > 1500) {
      tailoredSuggestions.push({
        category: "food",
        action: "Reduce meat consumption by 2 days per week",
        potentialReduction: internalBreakdown.food * 0.3,
        difficulty: "easy" as const,
        cost: "low" as const,
      });
    }

    return tailoredSuggestions;
  }
}

export const carbonCalculationService = new CarbonCalculationService();
