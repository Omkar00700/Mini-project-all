import { carbonOrchestrator } from "../carbon-orchestrator";
import type { CarbonFootprintInput } from "@/types/carbon";

jest.mock("@/lib/db", () => ({
  db: {
    carbonCalculation: {
      create: jest.fn().mockResolvedValue({
        id: "test-calculation-id",
        userId: "test-user",
        totalEmissions: 1000,
        breakdown: {
          transportation: 400,
          energy: 300,
          food: 200,
          consumption: 100,
        },
        confidenceScore: 0.85,
        createdAt: new Date(),
      }),
    },
  },
}));

jest.mock("../transportation-calculator", () => ({
  transportationCalculator: {
    calculateTransportationFootprint: jest.fn().mockResolvedValue({
      totalEmissions: 500,
      breakdown: { personal_vehicles: 400, flights: 100 },
      details: [{ type: "personal_vehicle", emissions: 400 }],
      methodology: "IPCC Guidelines with real-world adjustments",
    }),
  },
}));

jest.mock("../energy-calculator", () => ({
  energyCalculator: {
    calculateEnergyFootprint: jest.fn().mockResolvedValue({
      totalEmissions: 300,
      breakdown: { electricity: 200, heating: 100 },
      details: [{ type: "electricity", emissions: 200 }],
      methodology: "Real-time grid emission factors",
      recommendations: ["Switch to renewable energy"],
    }),
  },
}));

jest.mock("../food-calculator", () => ({
  foodCalculator: {
    calculateFoodEmissions: jest.fn().mockResolvedValue({
      totalEmissions: 200,
      breakdown: { meat: 120, dairy: 50, plant_based: 30 },
      details: [{ type: "meat", emissions: 120 }],
      methodology: "FAO emission factors",
      recommendations: ["Reduce meat consumption"],
    }),
  },
}));

jest.mock("../consumption-calculator", () => ({
  consumptionCalculator: {
    calculateConsumptionEmissions: jest.fn().mockResolvedValue({
      totalEmissions: 150,
      breakdown: { shopping: 100, services: 50 },
      details: [{ type: "shopping", emissions: 100 }],
      methodology: "EPA EEIO lifecycle assessment",
      recommendations: ["Buy less, choose sustainable products"],
    }),
  },
}));

jest.mock("../waste-calculator", () => ({
  wasteCalculator: {
    calculateWasteEmissions: jest.fn().mockResolvedValue({
      totalEmissions: 50,
      breakdown: { general_waste: 30, recycling: 20 },
      details: [{ type: "general_waste", emissions: 30 }],
      methodology: "EPA waste emission factors",
      recommendations: ["Increase recycling"],
    }),
  },
}));

describe("CarbonOrchestrator", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("calculateCarbonFootprint", () => {
    it("should calculate comprehensive carbon footprint with all categories", async () => {
      const input: CarbonFootprintInput = {
        user_id: "test-user-123",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          transportation: {
            personal_vehicles: {
              distance: 1000,
              fuel_type: "gasoline",
              vehicle_class: "midsize",
              efficiency: 12,
            },
            flights: {
              domestic_short: 2,
              class: "economy",
            },
          },
          energy: {
            electricity: {
              consumption: 500,
              grid_region: "US",
              renewable_percentage: 20,
            },
            heating: {
              natural_gas: 200,
            },
          },
          food: {
            meat: {
              beef: 2,
              chicken: 3,
            },
            dairy: {
              milk: 10,
            },
            plant_based: {
              vegetables: 15,
            },
          },
          consumption: {
            shopping: {
              clothing: 5,
              electronics: 2,
            },
            services: {
              banking: 100,
            },
            waste: {
              general_waste: 20,
              recycling: 10,
            },
          },
        },
      };

      const result = await carbonOrchestrator.calculateCarbonFootprint(input);

      expect(result).toHaveProperty("total_emissions");
      expect(result).toHaveProperty("breakdown");
      expect(result).toHaveProperty("confidence_score");
      expect(result).toHaveProperty("calculation_metadata");
      expect(result).toHaveProperty("detailed_breakdown");

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(result.breakdown).toHaveProperty("transportation");
      expect(result.breakdown).toHaveProperty("energy");
      expect(result.breakdown).toHaveProperty("food");
      expect(result.breakdown).toHaveProperty("consumption");

      expect(result.confidence_score).toBeGreaterThan(0);
      expect(result.confidence_score).toBeLessThanOrEqual(1);

      expect(result.calculation_metadata).toHaveProperty(
        "calculation_method",
        "ghg_protocol"
      );
      expect(result.calculation_metadata).toHaveProperty(
        "emission_factors_version"
      );
      expect(result.calculation_metadata).toHaveProperty("data_completeness");
      expect(result.calculation_metadata).toHaveProperty(
        "calculation_timestamp"
      );
      expect(result.calculation_metadata).toHaveProperty("confidence_factors");
      expect(result.calculation_metadata).toHaveProperty("assumptions");
      expect(result.calculation_metadata).toHaveProperty("data_sources");

      expect(result.detailed_breakdown).toHaveProperty("transportation");
      expect(result.detailed_breakdown).toHaveProperty("energy");
      expect(result.detailed_breakdown).toHaveProperty("food");
      expect(result.detailed_breakdown).toHaveProperty("consumption");
    });

    it("should handle partial data gracefully", async () => {
      const input: CarbonFootprintInput = {
        user_id: "test-user-456",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          energy: {
            electricity: {
              consumption: 300,
              grid_region: "US",
            },
          },
        },
      };

      const result = await carbonOrchestrator.calculateCarbonFootprint(input);

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(result.breakdown).toHaveProperty("energy");
      expect(result.breakdown.energy).toBeGreaterThan(0);

      expect(result.breakdown.transportation).toBeUndefined();
      expect(result.breakdown.food).toBeUndefined();
      expect(result.breakdown.consumption).toBeUndefined();

      expect(result.confidence_score).toBeGreaterThan(0);
      expect(result.confidence_score).toBeLessThan(1);
    });

    it("should calculate appropriate confidence scores", async () => {
      const completeInput: CarbonFootprintInput = {
        user_id: "test-user-789",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          transportation: {
            personal_vehicles: {
              distance: 1000,
              fuel_type: "gasoline",
              vehicle_class: "midsize",
              efficiency: 12,
            },
          },
          energy: {
            electricity: {
              consumption: 500,
              grid_region: "US",
              renewable_percentage: 20,
            },
          },
          food: {
            meat: { beef: 2 },
            dairy: { milk: 10 },
          },
          consumption: {
            shopping: { clothing: 5 },
          },
        },
      };

      const partialInput: CarbonFootprintInput = {
        user_id: "test-user-partial",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          energy: {
            electricity: {
              consumption: 500,
              grid_region: "US",
            },
          },
        },
      };

      const completeResult =
        await carbonOrchestrator.calculateCarbonFootprint(completeInput);
      const partialResult =
        await carbonOrchestrator.calculateCarbonFootprint(partialInput);

      expect(completeResult.confidence_score).toBeGreaterThan(
        partialResult.confidence_score
      );
    });

    it("should include appropriate recommendations in metadata", async () => {
      const input: CarbonFootprintInput = {
        user_id: "test-user-recommendations",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          energy: {
            electricity: {
              consumption: 1000,
              grid_region: "US",
            },
          },
          food: {
            meat: {
              beef: 10,
            },
          },
        },
      };

      const result = await carbonOrchestrator.calculateCarbonFootprint(input);

      expect(result.calculation_metadata.assumptions).toContain(
        "Switch to renewable energy"
      );
      expect(result.calculation_metadata.assumptions).toContain(
        "Reduce meat consumption"
      );
    });

    it("should handle calculation errors gracefully", async () => {
      const mockError = new Error("Calculation failed");
      jest
        .mocked(
          require("../energy-calculator").energyCalculator
            .calculateEnergyFootprint
        )
        .mockRejectedValueOnce(mockError);

      const input: CarbonFootprintInput = {
        user_id: "test-user-error",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          energy: {
            electricity: {
              consumption: 500,
              grid_region: "US",
            },
          },
          transportation: {
            personal_vehicles: {
              distance: 1000,
              fuel_type: "gasoline",
              vehicle_class: "midsize",
            },
          },
        },
      };

      const result = await carbonOrchestrator.calculateCarbonFootprint(input);

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(result.breakdown.transportation).toBeGreaterThan(0);
      expect(result.breakdown.energy).toBe(0);

      expect(result.confidence_score).toBeLessThan(0.8);
    });

    it("should generate detailed breakdown with subcategories", async () => {
      const input: CarbonFootprintInput = {
        user_id: "test-user-detailed",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          transportation: {
            personal_vehicles: {
              distance: 1000,
              fuel_type: "gasoline",
              vehicle_class: "midsize",
            },
          },
          energy: {
            electricity: {
              consumption: 500,
              grid_region: "US",
            },
          },
        },
      };

      const result = await carbonOrchestrator.calculateCarbonFootprint(input);

      expect(result.detailed_breakdown).toHaveProperty("transportation");
      expect(result.detailed_breakdown).toHaveProperty("energy");

      const transportationDetails = result.detailed_breakdown!.transportation;
      expect(transportationDetails).toHaveProperty("personal_vehicles");
      expect(transportationDetails.personal_vehicles).toHaveProperty(
        "emissions"
      );
      expect(transportationDetails.personal_vehicles).toHaveProperty(
        "unit",
        "kg CO2e"
      );
      expect(transportationDetails.personal_vehicles).toHaveProperty(
        "confidence"
      );
      expect(transportationDetails.personal_vehicles).toHaveProperty(
        "methodology"
      );

      const energyDetails = result.detailed_breakdown!.energy;
      expect(energyDetails).toHaveProperty("electricity");
      expect(energyDetails.electricity).toHaveProperty("emissions");
      expect(energyDetails.electricity).toHaveProperty("unit", "kg CO2e");
    });
  });
});
