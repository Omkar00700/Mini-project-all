import { carbonCalculationService } from "../carbon-calculation";
import type {
  TransportationData,
  EnergyData,
  FoodData,
  ConsumptionData,
  EmissionFactor,
} from "@/types/carbon";

jest.mock("@/lib/db", () => ({
  db: {
    emissionFactor: {
      findFirst: jest.fn(),
    },
    carbonCalculation: {
      findMany: jest.fn(),
      create: jest.fn(),
    },
  },
}));

jest.mock("../carbon-orchestrator", () => ({
  carbonOrchestrator: {
    calculateCarbonFootprint: jest.fn(),
  },
}));

const { db } = require("@/lib/db");
const { carbonOrchestrator } = require("../carbon-orchestrator");

describe("Carbon Calculation Unit Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("Transportation Emissions Calculation", () => {
    it("should calculate personal vehicle emissions with valid emission factor", async () => {
      db.emissionFactor.findFirst.mockResolvedValue({
        id: "1",
        category: "transportation",
        subcategory: "personal_vehicle",
        region: "global",
        co2_per_unit: 2.31,
        unit: "kg CO2/liter",
        source: "IPCC",
        validFrom: new Date(),
        createdAt: new Date(),
      });

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 10,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBeCloseTo(231, 0);
      expect(db.emissionFactor.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            category: "transportation",
            subcategory: "personal_vehicle",
          }),
        })
      );
    });

    it("should return zero emissions when no emission factor is found", async () => {
      db.emissionFactor.findFirst.mockResolvedValue(null);

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 10,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBe(0);
    });

    it("should handle multiple transportation modes", async () => {
      db.emissionFactor.findFirst
        .mockResolvedValueOnce({
          co2_per_unit: 2.31,
        })
        .mockResolvedValueOnce({
          co2_per_unit: 0.089,
        })
        .mockResolvedValueOnce({
          co2_per_unit: 0.255,
        });

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 500,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 10,
        },
        public_transport: { bus_distance: 200 },
        flights: { domestic_short: 1, class: "economy" },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBeGreaterThan(600);
      expect(result).toBeLessThan(650);
    });

    it("should handle database errors gracefully", async () => {
      db.emissionFactor.findFirst.mockRejectedValue(
        new Error("Database error")
      );

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 10,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );
      expect(result).toBe(0);
    });
  });

  describe("Energy Emissions Calculation", () => {
    it("should calculate electricity emissions with renewable adjustment", async () => {
      db.emissionFactor.findFirst.mockResolvedValue({
        co2_per_unit: 0.386,
      });

      const energyData: EnergyData = {
        electricity: {
          consumption: 1000,
          grid_region: "US",
          renewable_percentage: 20,
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeCloseTo(308.8, 1);
    });

    it("should calculate heating emissions", async () => {
      db.emissionFactor.findFirst.mockResolvedValue({
        co2_per_unit: 0.185,
      });

      const energyData: EnergyData = {
        heating: { natural_gas: 500 },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeCloseTo(115.6, 1);
    });

    it("should handle zero consumption", async () => {
      db.emissionFactor.findFirst.mockResolvedValue({
        co2_per_unit: 0.386,
      });

      const energyData: EnergyData = {
        electricity: {
          consumption: 0,
          grid_region: "US",
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeNaN();
    });
  });

  describe("Food Emissions Calculation", () => {
    it("should calculate meat consumption emissions", async () => {
      db.emissionFactor.findFirst
        .mockResolvedValueOnce({
          co2_per_unit: 60.0,
        })
        .mockResolvedValueOnce({
          co2_per_unit: 6.9,
        });

      const foodData: FoodData = {
        meat: {
          beef: 2,
          chicken: 3,
        },
      };

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBeCloseTo(140.7, 1);
    });

    it("should handle empty food data", async () => {
      const foodData: FoodData = {};

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBe(0);
    });
  });

  describe("Consumption Emissions Calculation", () => {
    it("should calculate shopping emissions", async () => {
      db.emissionFactor.findFirst
        .mockResolvedValueOnce({
          co2_per_unit: 8.0,
        })
        .mockResolvedValueOnce({
          co2_per_unit: 70.0,
        });

      const consumptionData: ConsumptionData = {
        shopping: {
          clothing: 5,
          electronics: 1,
        },
      };

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionData
        );

      expect(result).toBeCloseTo(110, 0);
    });

    it("should handle digital services emissions", async () => {
      db.emissionFactor.findFirst
        .mockResolvedValueOnce({
          co2_per_unit: 0.006,
        })
        .mockResolvedValueOnce({
          co2_per_unit: 0.036,
        });

      const consumptionData: ConsumptionData = {
        services: { telecommunications: 100, entertainment: 50 },
      };

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionData
        );

      expect(result).toBeCloseTo(2.4, 1);
    });
  });

  describe("Total Footprint Calculation", () => {
    it("should delegate to orchestrator and return result", async () => {
      const mockResult = {
        total_emissions: 1000,
        breakdown: {
          transportation: 400,
          energy: 300,
          food: 200,
          consumption: 100,
        },
        confidence_score: 0.85,
        calculation_metadata: {
          calculation_method: "ghg_protocol" as const,
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(mockResult);

      const data = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
        energy: {
          electricity: {
            consumption: 800,
            grid_region: "US",
          },
        },
      };

      const result = await carbonCalculationService.calculateTotalFootprint(
        "test-user",
        data
      );

      expect(result).toEqual(mockResult);
      expect(carbonOrchestrator.calculateCarbonFootprint).toHaveBeenCalledWith(
        expect.objectContaining({
          user_id: "test-user",
          categories: data,
        })
      );
    });

    it("should handle orchestrator errors", async () => {
      carbonOrchestrator.calculateCarbonFootprint.mockRejectedValue(
        new Error("Orchestrator failed")
      );

      const data = {
        energy: {
          electricity: {
            consumption: 500,
            grid_region: "US",
          },
        },
      };

      await expect(
        carbonCalculationService.calculateTotalFootprint("test-user", data)
      ).rejects.toThrow("Failed to calculate carbon footprint");
    });
  });

  describe("Recommendation Generation", () => {
    it("should generate recommendations for high emissions", async () => {
      const calculation = {
        id: "test-calc",
        userId: "test-user",
        periodStart: new Date(),
        periodEnd: new Date(),
        totalEmissions: 8000,
        breakdown: {
          transportation: 3000,
          energy: 4000,
          food: 1000,
          consumption: 500,
        },
        confidenceScore: 0.8,
        metadata: {
          calculation_method: "ghg_protocol" as const,
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
        createdAt: new Date(),
      };

      const recommendations =
        await carbonCalculationService.getReductionRecommendations(
          "test-user",
          calculation
        );

      expect(recommendations).toHaveLength(2);

      const transportationRec = recommendations.find(
        (r) => r.category === "transportation"
      );
      expect(transportationRec).toBeDefined();
      expect(transportationRec?.potentialReduction).toBeCloseTo(1800, 0);

      const energyRec = recommendations.find((r) => r.category === "energy");
      expect(energyRec).toBeDefined();
      expect(energyRec?.potentialReduction).toBeCloseTo(3200, 0);
    });

    it("should not generate recommendations for low emissions", async () => {
      const calculation = {
        id: "test-calc",
        userId: "test-user",
        periodStart: new Date(),
        periodEnd: new Date(),
        totalEmissions: 1000,
        breakdown: {
          transportation: 300,
          energy: 400,
          food: 200,
          consumption: 100,
        },
        confidenceScore: 0.8,
        metadata: {
          calculation_method: "ghg_protocol" as const,
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
        createdAt: new Date(),
      };

      const recommendations =
        await carbonCalculationService.getReductionRecommendations(
          "test-user",
          calculation
        );

      expect(recommendations).toHaveLength(0);
    });
  });

  describe("Performance Tests", () => {
    it("should complete calculations within performance threshold", async () => {
      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 1500,
        breakdown: { transportation: 1500, energy: 0, food: 0, consumption: 0 },
        confidence_score: 0.9,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.9,
        },
      });

      const data = {
        transportation: {
          personal_vehicles: {
            distance: 15000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
      };

      const startTime = Date.now();
      await carbonCalculationService.calculateTotalFootprint("test-user", data);
      const endTime = Date.now();

      expect(endTime - startTime).toBeLessThan(5000);
    });

    it("should handle concurrent calculations", async () => {
      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 1500,
        breakdown: { energy: 1500, transportation: 0, food: 0, consumption: 0 },
        confidence_score: 0.8,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
      });

      const data = {
        energy: {
          electricity: {
            consumption: 1000,
            grid_region: "US",
          },
        },
      };

      const promises = Array.from({ length: 5 }, (_, i) =>
        carbonCalculationService.calculateTotalFootprint(`user-${i}`, data)
      );

      const startTime = Date.now();
      const results = await Promise.all(promises);
      const endTime = Date.now();

      expect(results).toHaveLength(5);
      results.forEach((result) => {
        expect(result.total_emissions).toBe(500);
      });

      expect(endTime - startTime).toBeLessThan(2000);
    });
  });

  describe("Data Validation and Edge Cases", () => {
    it("should handle missing data gracefully", async () => {
      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          {}
        );

      expect(result).toBe(0);
    });

    it("should handle invalid numeric values", async () => {
      db.emissionFactor.findFirst.mockResolvedValue({
        co2_per_unit: 2.31,
      });

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: -100,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 0,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBe(-Infinity);
    });

    it("should validate confidence score calculation", async () => {
      const testData = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
        energy: {
          electricity: {
            consumption: 800,
            grid_region: "US",
          },
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 1000,
        breakdown: {
          transportation: 500,
          energy: 500,
          food: 0,
          consumption: 0,
        },
        confidence_score: 0.92,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.95,
        },
      });

      const result = await carbonCalculationService.calculateTotalFootprint(
        "test-user",
        testData
      );

      expect(result.confidence_score).toBeGreaterThan(0.9);
      expect(result.calculation_metadata.data_completeness).toBeGreaterThan(
        0.9
      );
    });
  });
});
