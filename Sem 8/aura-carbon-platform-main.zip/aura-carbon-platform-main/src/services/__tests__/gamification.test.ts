import {
  calculateStreak,
  getUniqueCategories,
  ACHIEVEMENT_DEFINITIONS,
} from "../analytics/gamification.service";

describe("Gamification Service", () => {
  describe("ACHIEVEMENT_DEFINITIONS", () => {
    it("should have 12 achievements", () => {
      expect(ACHIEVEMENT_DEFINITIONS).toHaveLength(12);
    });

    it("should have unique keys", () => {
      const keys = ACHIEVEMENT_DEFINITIONS.map((a) => a.key);
      expect(new Set(keys).size).toBe(keys.length);
    });

    it("should cover all categories", () => {
      const categories = new Set(
        ACHIEVEMENT_DEFINITIONS.map((a) => a.category)
      );
      expect(categories.has("milestone")).toBe(true);
      expect(categories.has("streak")).toBe(true);
      expect(categories.has("impact")).toBe(true);
      expect(categories.has("exploration")).toBe(true);
    });
  });

  describe("calculateStreak", () => {
    const today = new Date();
    const daysAgo = (n: number) => {
      const d = new Date(today);
      d.setDate(d.getDate() - n);
      return d;
    };

    it("should return 0 for empty dates", () => {
      expect(calculateStreak([])).toBe(0);
    });

    it("should return 1 for only today", () => {
      expect(calculateStreak([today])).toBe(1);
    });

    it("should return 3 for 3 consecutive days", () => {
      const dates = [today, daysAgo(1), daysAgo(2)];
      expect(calculateStreak(dates)).toBe(3);
    });

    it("should return 7 for a full week", () => {
      const dates = Array.from({ length: 7 }, (_, i) => daysAgo(i));
      expect(calculateStreak(dates)).toBe(7);
    });

    it("should break at gaps", () => {
      const dates = [today, daysAgo(1), daysAgo(3)];
      expect(calculateStreak(dates)).toBe(2);
    });

    it("should handle multiple activities per day", () => {
      const dates = [today, today, today, daysAgo(1), daysAgo(1)];
      expect(calculateStreak(dates)).toBe(2);
    });

    it("should return 0 if no recent activity", () => {
      const dates = [daysAgo(5), daysAgo(6)];
      expect(calculateStreak(dates)).toBe(0);
    });

    it("should count from yesterday", () => {
      const dates = [daysAgo(1), daysAgo(2), daysAgo(3)];
      expect(calculateStreak(dates)).toBe(3);
    });
  });

  describe("getUniqueCategories", () => {
    it("should normalize transport variants", () => {
      const result = getUniqueCategories([
        "Transportation",
        "transport",
        "Vehicle",
      ]);
      expect(result.size).toBe(1);
      expect(result.has("transportation")).toBe(true);
    });

    it("should normalize energy variants", () => {
      const result = getUniqueCategories(["Energy", "Electricity", "Power"]);
      expect(result.size).toBe(1);
      expect(result.has("energy")).toBe(true);
    });

    it("should count all 4 categories", () => {
      const result = getUniqueCategories([
        "Transportation",
        "Energy",
        "Food",
        "Waste",
      ]);
      expect(result.size).toBe(4);
    });

    it("should handle empty array", () => {
      expect(getUniqueCategories([]).size).toBe(0);
    });

    it("should ignore unknown categories", () => {
      const result = getUniqueCategories(["Shopping", "Unknown"]);
      expect(result.size).toBe(0);
    });
  });
});
