import { carbonCalculationService } from "../carbon-calculation";
import { carbonOrchestrator } from "../carbon-orchestrator";
import { emissionFactorsService } from "../emission-factors";
import type {
  CarbonFootprintInput,
  CarbonFootprintResult,
  TransportationData,
  EnergyData,
  FoodData,
  ConsumptionData,
  EmissionFactor,
} from "@/types/carbon";

jest.mock("@/lib/db", () => ({
  db: {
    emissionFactor: {
      findFirst: jest.fn(),
    },
    carbonCalculation: {
      findMany: jest.fn(),
    },
  },
}));

jest.mock("../carbon-orchestrator", () => ({
  carbonOrchestrator: {
    calculateCarbonFootprint: jest.fn(),
  },
}));

jest.mock("../emission-factors", () => ({
  emissionFactorsService: {
    getEmissionFactor: jest.fn(),
  },
}));

const mockCarbonOrchestrator = carbonOrchestrator as jest.Mocked<
  typeof carbonOrchestrator
>;
const mockEmissionFactorsService = emissionFactorsService as jest.Mocked<
  typeof emissionFactorsService
>;

describe("CarbonCalculationService", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockEmissionFactorsService.getEmissionFactor.mockImplementation(
      async (category, subcategory, region, fuelType) => {
        const mockFactors: Record<string, EmissionFactor> = {
          transportation_personal_vehicle_gasoline: {
            id: "1",
            category: "transportation",
            subcategory: "personal_vehicle",
            region: "global",
            value: 2.31,
            unit: "kg CO2/liter",
            source: "IPCC",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          transportation_public_transport_global_bus: {
            id: "2",
            category: "transportation",
            subcategory: "public_transport",
            region: "global",
            value: 0.089,
            unit: "kg CO2/km",
            source: "DEFRA",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          transportation_aviation_global_economy: {
            id: "3",
            category: "transportation",
            subcategory: "aviation",
            region: "global",
            value: 0.255,
            unit: "kg CO2/km",
            source: "DEFRA",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          energy_electricity_US: {
            id: "4",
            category: "energy",
            subcategory: "electricity",
            region: "US",
            value: 0.386,
            unit: "kg CO2/kWh",
            source: "EPA",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          energy_heating_global_natural_gas: {
            id: "5",
            category: "energy",
            subcategory: "heating",
            region: "global",
            value: 0.185,
            unit: "kg CO2/kWh",
            source: "DEFRA",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          food_dietary_global_beef: {
            id: "6",
            category: "food",
            subcategory: "dietary",
            region: "global",
            value: 60.0,
            unit: "kg CO2/kg",
            source: "Poore & Nemecek",
            validFrom: new Date(),
            createdAt: new Date(),
          },
          consumption_clothing_global_t_shirt: {
            id: "7",
            category: "consumption",
            subcategory: "clothing",
            region: "global",
            value: 8.0,
            unit: "kg CO2/item",
            source: "Ellen MacArthur Foundation",
            validFrom: new Date(),
            createdAt: new Date(),
          },
        };

        const key = fuelType
          ? `${category}_${subcategory}_${fuelType}`
          : `${category}_${subcategory}_${region}`;
        return mockFactors[key] || null;
      }
    );
  });

  describe("calculateTransportationEmissions", () => {
    it("should calculate personal vehicle emissions correctly", async () => {
      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 12,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBeCloseTo(192.5, 1);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "transportation",
        "personal_vehicle",
        "gasoline"
      );
    });

    it("should calculate public transport emissions correctly", async () => {
      const transportationData: TransportationData = {
        public_transport: {
          bus_distance: 500,
          train_distance: 300,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBeGreaterThan(0);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "transportation",
        "public_transport",
        "bus"
      );
    });

    it("should calculate flight emissions with radiative forcing", async () => {
      const transportationData: TransportationData = {
        flights: {
          domestic_short: 2,
          class: "economy",
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBeGreaterThan(0);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "transportation",
        "aviation",
        "economy"
      );
    });

    it("should handle missing emission factors gracefully", async () => {
      mockEmissionFactorsService.getEmissionFactor.mockResolvedValue(null);

      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 12,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        );

      expect(result).toBe(0);
    });

    it("should handle invalid input data", async () => {
      const transportationData: TransportationData = {
        personal_vehicles: {
          distance: -100,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 0,
        },
      };

      await expect(
        carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          transportationData
        )
      ).rejects.toThrow();
    });
  });

  describe("calculateEnergyEmissions", () => {
    it("should calculate electricity emissions correctly", async () => {
      const energyData: EnergyData = {
        electricity: {
          consumption: 1000,
          grid_region: "US",
          renewable_percentage: 20,
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeCloseTo(308.8, 1);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "energy",
        "electricity",
        "US"
      );
    });

    it("should calculate heating emissions correctly", async () => {
      const energyData: EnergyData = {
        heating: {
          natural_gas: 500,
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeCloseTo(92.5, 1);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "energy",
        "heating",
        "natural_gas"
      );
    });

    it("should apply heating system efficiency correctly", async () => {
      const energyData: EnergyData = {
        heating: {
          natural_gas: 500,
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeGreaterThan(0);
    });

    it("should handle multiple energy sources", async () => {
      const energyData: EnergyData = {
        electricity: {
          consumption: 800,
          grid_region: "US",
        },
        heating: {
          natural_gas: 300,
        },
        cooling: {
          electricity: 200,
          efficiency_rating: "16 SEER",
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBeGreaterThan(0);
      expect(
        mockEmissionFactorsService.getEmissionFactor
      ).toHaveBeenCalledTimes(3);
    });

    it("should handle zero consumption gracefully", async () => {
      const energyData: EnergyData = {
        electricity: {
          consumption: 0,
          grid_region: "US",
        },
      };

      const result = await carbonCalculationService.calculateEnergyEmissions(
        "test-user",
        energyData
      );

      expect(result).toBe(0);
    });
  });

  describe("calculateFoodEmissions", () => {
    it("should calculate meat consumption emissions correctly", async () => {
      const foodData: FoodData = {
        meat: {
          beef: 2,
          chicken: 3,
        },
      };

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBeGreaterThan(0);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalledWith(
        "food",
        "dietary",
        "beef"
      );
    });

    it("should calculate dairy consumption emissions correctly", async () => {
      const foodData: FoodData = {
        dairy: {
          milk: 10,
          cheese: 1,
        },
      };

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBeGreaterThan(0);
    });

    it("should calculate plant-based food emissions correctly", async () => {
      const foodData: FoodData = {
        plant_based: {
          vegetables: 15,
          fruits: 10,
          grains: 5,
        },
      };

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBeGreaterThan(0);
    });

    it("should handle food waste emissions", async () => {
      const foodData: FoodData = {
        meat: {
          beef: 1,
        },
      };

      const foodDataWithWaste = {
        ...foodData,
        foodWaste: {
          amount: 5,
          wasteType: "organic",
        },
      };

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodDataWithWaste as any
      );

      expect(result).toBeGreaterThan(0);
    });

    it("should handle empty food data", async () => {
      const foodData: FoodData = {};

      const result = await carbonCalculationService.calculateFoodEmissions(
        "test-user",
        foodData
      );

      expect(result).toBe(0);
    });
  });

  describe("calculateConsumptionEmissions", () => {
    it("should calculate shopping emissions correctly", async () => {
      const consumptionData: ConsumptionData = {
        shopping: {
          clothing: 5,
          electronics: 2,
        },
      };

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionData
        );

      expect(result).toBeGreaterThan(0);
      expect(mockEmissionFactorsService.getEmissionFactor).toHaveBeenCalled();
    });

    it("should calculate digital services emissions correctly", async () => {
      const consumptionData: ConsumptionData = {
        services: {
          telecommunications: 100,
        },
      };

      const consumptionDataWithDigital = {
        ...consumptionData,
        digitalServices: {
          dataUsage: 50,
          streamingHours: 100,
          cloudStorage: 1000,
        },
      };

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionDataWithDigital as any
        );

      expect(result).toBeGreaterThan(0);
    });

    it("should handle services emissions", async () => {
      const consumptionData: ConsumptionData = {
        services: {
          banking: 200,
          insurance: 150,
          telecommunications: 100,
        },
      };

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionData
        );

      expect(result).toBeGreaterThan(0);
    });

    it("should handle empty consumption data", async () => {
      const consumptionData: ConsumptionData = {};

      const result =
        await carbonCalculationService.calculateConsumptionEmissions(
          "test-user",
          consumptionData
        );

      expect(result).toBe(0);
    });
  });

  describe("calculateTotalFootprint", () => {
    it("should calculate comprehensive footprint using orchestrator", async () => {
      const mockResult: CarbonFootprintResult = {
        total_emissions: 1000,
        breakdown: {
          transportation: 400,
          energy: 300,
          food: 200,
          consumption: 100,
        },
        confidence_score: 0.85,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
          calculation_timestamp: new Date(),
        },
      };

      mockCarbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockResult
      );

      const data = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
        energy: {
          electricity: {
            consumption: 800,
            grid_region: "US",
          },
        },
        food: {
          meat: {
            beef: 2,
          },
        },
        consumption: {
          shopping: {
            clothing: 5,
          },
        },
      };

      const result = await carbonCalculationService.calculateTotalFootprint(
        "test-user",
        data
      );

      expect(result.total_emissions).toBe(1000);
      expect(result.breakdown.transportation).toBe(400);
      expect(result.breakdown.energy).toBe(300);
      expect(result.breakdown.food).toBe(200);
      expect(result.breakdown.consumption).toBe(100);
      expect(result.confidence_score).toBe(0.85);
      expect(
        mockCarbonOrchestrator.calculateCarbonFootprint
      ).toHaveBeenCalledWith(
        expect.objectContaining({
          user_id: "test-user",
          categories: data,
        })
      );
    });

    it("should handle orchestrator errors gracefully", async () => {
      mockCarbonOrchestrator.calculateCarbonFootprint.mockRejectedValue(
        new Error("Orchestrator failed")
      );

      const data = {
        energy: {
          electricity: {
            consumption: 500,
            grid_region: "US",
          },
        },
      };

      await expect(
        carbonCalculationService.calculateTotalFootprint("test-user", data)
      ).rejects.toThrow("Failed to calculate carbon footprint");
    });
  });

  describe("calculateComprehensiveFootprint", () => {
    it("should delegate to orchestrator correctly", async () => {
      const input: CarbonFootprintInput = {
        user_id: "test-user",
        period: {
          start: new Date("2024-01-01"),
          end: new Date("2024-01-31"),
        },
        categories: {
          transportation: {
            personal_vehicles: {
              distance: 1000,
              fuel_type: "gasoline",
              vehicle_class: "midsize",
              efficiency: 12,
            },
          },
        },
      };

      const mockResult: CarbonFootprintResult = {
        total_emissions: 500,
        breakdown: { transportation: 500, energy: 0, food: 0, consumption: 0 },
        confidence_score: 0.9,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.9,
        },
      };

      mockCarbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockResult
      );

      const result =
        await carbonCalculationService.calculateComprehensiveFootprint(input);

      expect(result).toEqual(mockResult);
      expect(
        mockCarbonOrchestrator.calculateCarbonFootprint
      ).toHaveBeenCalledWith(input);
    });
  });

  describe("getReductionRecommendations", () => {
    it("should generate appropriate recommendations based on emissions", async () => {
      const calculation = {
        id: "test-calc",
        userId: "test-user",
        periodStart: new Date(),
        periodEnd: new Date(),
        totalEmissions: 5000,
        breakdown: {
          transportation: 2500,
          energy: 3500,
          food: 1800,
          consumption: 500,
        },
        confidenceScore: 0.8,
        metadata: {
          calculation_method: "ghg_protocol" as const,
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
        createdAt: new Date(),
      };

      const recommendations =
        await carbonCalculationService.getReductionRecommendations(
          "test-user",
          calculation
        );

      expect(recommendations).toHaveLength(3);

      const transportationRec = recommendations.find(
        (r) => r.category === "transportation"
      );
      expect(transportationRec).toBeDefined();
      expect(transportationRec?.potentialReduction).toBeCloseTo(1500, 0);
      expect(transportationRec?.difficulty).toBe("medium");
      expect(transportationRec?.cost).toBe("high");

      const energyRec = recommendations.find((r) => r.category === "energy");
      expect(energyRec).toBeDefined();
      expect(energyRec?.potentialReduction).toBeCloseTo(2800, 0);
      expect(energyRec?.difficulty).toBe("medium");
      expect(energyRec?.cost).toBe("high");

      const foodRec = recommendations.find((r) => r.category === "food");
      expect(foodRec).toBeDefined();
      expect(foodRec?.potentialReduction).toBeCloseTo(540, 0);
      expect(foodRec?.difficulty).toBe("easy");
      expect(foodRec?.cost).toBe("low");
    });

    it("should not generate recommendations for low emissions", async () => {
      const calculation = {
        id: "test-calc",
        userId: "test-user",
        periodStart: new Date(),
        periodEnd: new Date(),
        totalEmissions: 1000,
        breakdown: {
          transportation: 500,
          energy: 800,
          food: 300,
          consumption: 200,
        },
        confidenceScore: 0.8,
        metadata: {
          calculation_method: "ghg_protocol" as const,
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
        createdAt: new Date(),
      };

      const recommendations =
        await carbonCalculationService.getReductionRecommendations(
          "test-user",
          calculation
        );

      expect(recommendations).toHaveLength(0);
    });
  });

  describe("Performance Tests", () => {
    it("should calculate emissions within performance threshold", async () => {
      const startTime = Date.now();

      const data = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
          flights: {
            domestic_short: 2,
            class: "economy" as const,
          },
        },
        energy: {
          electricity: {
            consumption: 800,
            grid_region: "US",
          },
          heating: {
            natural_gas: 300,
          },
        },
        food: {
          meat: {
            beef: 2,
            chicken: 3,
          },
          dairy: {
            milk: 10,
          },
        },
        consumption: {
          shopping: {
            clothing: 5,
            electronics: 2,
          },
        },
      };

      mockCarbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 1500,
        breakdown: {
          transportation: 600,
          energy: 400,
          food: 300,
          consumption: 200,
        },
        confidence_score: 0.85,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.85,
        },
      });

      await carbonCalculationService.calculateTotalFootprint("test-user", data);

      const endTime = Date.now();
      const executionTime = endTime - startTime;

      expect(executionTime).toBeLessThan(5000);
    });

    it("should handle large datasets efficiently", async () => {
      const largeData = {
        transportation: {
          personal_vehicles: {
            distance: 50000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
        energy: {
          electricity: {
            consumption: 20000,
            grid_region: "US",
          },
        },
      };

      mockCarbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 15000,
        breakdown: {
          transportation: 10000,
          energy: 5000,
          food: 0,
          consumption: 0,
        },
        confidence_score: 0.9,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.9,
        },
      });

      const startTime = Date.now();
      const result = await carbonCalculationService.calculateTotalFootprint(
        "test-user",
        largeData
      );
      const endTime = Date.now();

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(endTime - startTime).toBeLessThan(5000);
    });
  });

  describe("Edge Cases and Data Validation", () => {
    it("should handle null and undefined values", async () => {
      const dataWithNulls: any = {
        personal_vehicles: {
          distance: null,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
        },
      };

      await expect(
        carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          dataWithNulls
        )
      ).rejects.toThrow();
    });

    it("should handle extreme values", async () => {
      const extremeData = {
        personal_vehicles: {
          distance: 1000000,
          fuel_type: "gasoline" as const,
          vehicle_class: "midsize" as const,
          efficiency: 0.1,
        },
      };

      const result =
        await carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          extremeData
        );

      expect(result).toBeGreaterThan(0);
      expect(result).toBeLessThan(1000000);
    });

    it("should validate input data types", async () => {
      const invalidData = {
        personal_vehicles: {
          distance: "invalid" as any,
          fuel_type: "gasoline" as const,
          vehicle_class: "midsize" as const,
        },
      };

      await expect(
        carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          invalidData
        )
      ).rejects.toThrow();
    });

    it("should handle missing required fields", async () => {
      const incompleteData = {
        personal_vehicles: {
          fuel_type: "gasoline" as const,
          vehicle_class: "midsize" as const,
        },
      } as any;

      await expect(
        carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          incompleteData
        )
      ).rejects.toThrow();
    });

    it("should handle concurrent calculations", async () => {
      const data = {
        energy: {
          electricity: {
            consumption: 500,
            grid_region: "US",
          },
        },
      };

      mockCarbonOrchestrator.calculateCarbonFootprint.mockResolvedValue({
        total_emissions: 200,
        breakdown: { transportation: 0, energy: 200, food: 0, consumption: 0 },
        confidence_score: 0.8,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
        },
      });

      const promises = Array.from({ length: 10 }, (_, i) =>
        carbonCalculationService.calculateTotalFootprint(`test-user-${i}`, data)
      );

      const results = await Promise.all(promises);

      expect(results).toHaveLength(10);
      results.forEach((result) => {
        expect(result.total_emissions).toBe(200);
      });
    });
  });

  describe("Error Handling", () => {
    it("should handle database connection errors", async () => {
      mockEmissionFactorsService.getEmissionFactor.mockRejectedValue(
        new Error("Database connection failed")
      );

      const data: TransportationData = {
        personal_vehicles: {
          distance: 1000,
          fuel_type: "gasoline",
          vehicle_class: "midsize",
          efficiency: 12,
        },
      };

      await expect(
        carbonCalculationService.calculateTransportationEmissions(
          "test-user",
          data
        )
      ).rejects.toThrow("Failed to calculate transportation emissions");
    });

    it("should handle service timeouts", async () => {
      mockEmissionFactorsService.getEmissionFactor.mockImplementation(
        () =>
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error("Service timeout")), 100)
          )
      );

      const data: EnergyData = {
        electricity: {
          consumption: 500,
          grid_region: "US",
        },
      };

      await expect(
        carbonCalculationService.calculateEnergyEmissions("test-user", data)
      ).rejects.toThrow("Failed to calculate energy emissions");
    });

    it("should provide meaningful error messages", async () => {
      mockCarbonOrchestrator.calculateCarbonFootprint.mockRejectedValue(
        new Error("Invalid emission factor")
      );

      const data = {
        energy: {
          electricity: {
            consumption: 500,
            grid_region: "INVALID_REGION",
          },
        },
      };

      await expect(
        carbonCalculationService.calculateTotalFootprint("test-user", data)
      ).rejects.toThrow("Failed to calculate carbon footprint");
    });
  });
});
