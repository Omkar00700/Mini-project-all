import {
  normalizeCategory,
  applyModifications,
  calculateTotal,
  calculateSavings,
} from "../analytics/scenario.service";
import type {
  CategoryBreakdown,
  ScenarioModification,
} from "../analytics/scenario.service";

describe("Scenario Service", () => {
  describe("normalizeCategory", () => {
    it("should normalize transport variants", () => {
      expect(normalizeCategory("Transportation")).toBe("transportation");
      expect(normalizeCategory("transport")).toBe("transportation");
      expect(normalizeCategory("Travel")).toBe("transportation");
      expect(normalizeCategory("Vehicle Usage")).toBe("transportation");
      expect(normalizeCategory("Daily Commute")).toBe("transportation");
    });

    it("should normalize energy variants", () => {
      expect(normalizeCategory("Energy")).toBe("energy");
      expect(normalizeCategory("Electricity")).toBe("energy");
      expect(normalizeCategory("Power")).toBe("energy");
      expect(normalizeCategory("Natural Gas")).toBe("energy");
    });

    it("should normalize food variants", () => {
      expect(normalizeCategory("Food")).toBe("food");
      expect(normalizeCategory("Diet")).toBe("food");
      expect(normalizeCategory("Meals")).toBe("food");
    });

    it("should normalize waste variants", () => {
      expect(normalizeCategory("Waste")).toBe("waste");
      expect(normalizeCategory("Recycling")).toBe("waste");
      expect(normalizeCategory("Trash")).toBe("waste");
    });

    it("should normalize water", () => {
      expect(normalizeCategory("Water")).toBe("water");
    });

    it("should return lowercase for unknown categories", () => {
      expect(normalizeCategory("Shopping")).toBe("shopping");
    });

    it("should handle empty string", () => {
      expect(normalizeCategory("")).toBe("other");
    });
  });

  describe("applyModifications", () => {
    const baseline: CategoryBreakdown[] = [
      { category: "transportation", emissions: 200 },
      { category: "energy", emissions: 150 },
      { category: "food", emissions: 100 },
      { category: "waste", emissions: 50 },
    ];

    it("should reduce emissions by percentage", () => {
      const mods: ScenarioModification[] = [
        { category: "transportation", action: "reduce", percentage: 30 },
      ];
      const result = applyModifications(baseline, mods);
      const transport = result.find((r) => r.category === "transportation");
      expect(transport?.emissions).toBe(140);
    });

    it("should eliminate emissions completely", () => {
      const mods: ScenarioModification[] = [
        { category: "waste", action: "eliminate", percentage: 100 },
      ];
      const result = applyModifications(baseline, mods);
      const waste = result.find((r) => r.category === "waste");
      expect(waste?.emissions).toBe(0);
    });

    it("should handle replace action", () => {
      const mods: ScenarioModification[] = [
        { category: "energy", action: "replace", percentage: 50 },
      ];
      const result = applyModifications(baseline, mods);
      const energy = result.find((r) => r.category === "energy");
      expect(energy?.emissions).toBe(75);
    });

    it("should apply multiple modifications", () => {
      const mods: ScenarioModification[] = [
        { category: "transportation", action: "reduce", percentage: 50 },
        { category: "energy", action: "reduce", percentage: 20 },
      ];
      const result = applyModifications(baseline, mods);
      expect(
        result.find((r) => r.category === "transportation")?.emissions
      ).toBe(100);
      expect(result.find((r) => r.category === "energy")?.emissions).toBe(120);

      expect(result.find((r) => r.category === "food")?.emissions).toBe(100);
    });

    it("should not modify original baseline", () => {
      const mods: ScenarioModification[] = [
        { category: "transportation", action: "eliminate", percentage: 100 },
      ];
      applyModifications(baseline, mods);
      expect(
        baseline.find((b) => b.category === "transportation")?.emissions
      ).toBe(200);
    });

    it("should clamp percentage to 0-100", () => {
      const mods: ScenarioModification[] = [
        { category: "food", action: "reduce", percentage: 150 },
      ];
      const result = applyModifications(baseline, mods);
      const food = result.find((r) => r.category === "food");
      expect(food?.emissions).toBe(0);
    });

    it("should handle negative percentage", () => {
      const mods: ScenarioModification[] = [
        { category: "food", action: "reduce", percentage: -20 },
      ];
      const result = applyModifications(baseline, mods);
      const food = result.find((r) => r.category === "food");
      expect(food?.emissions).toBe(100);
    });

    it("should skip unknown categories", () => {
      const mods: ScenarioModification[] = [
        { category: "unknown-category", action: "reduce", percentage: 50 },
      ];
      const result = applyModifications(baseline, mods);
      expect(calculateTotal(result)).toBe(calculateTotal(baseline));
    });

    it("should handle empty modifications", () => {
      const result = applyModifications(baseline, []);
      expect(calculateTotal(result)).toBe(calculateTotal(baseline));
    });
  });

  describe("calculateTotal", () => {
    it("should sum all emissions", () => {
      const breakdown: CategoryBreakdown[] = [
        { category: "transportation", emissions: 200 },
        { category: "energy", emissions: 150 },
        { category: "food", emissions: 100 },
      ];
      expect(calculateTotal(breakdown)).toBe(450);
    });

    it("should return 0 for empty array", () => {
      expect(calculateTotal([])).toBe(0);
    });

    it("should handle single item", () => {
      expect(calculateTotal([{ category: "food", emissions: 42 }])).toBe(42);
    });
  });

  describe("calculateSavings", () => {
    it("should calculate absolute and percentage savings", () => {
      const result = calculateSavings(500, 350);
      expect(result.absolute).toBe(150);
      expect(result.percentage).toBe(30);
    });

    it("should handle zero baseline", () => {
      const result = calculateSavings(0, 0);
      expect(result.absolute).toBe(0);
      expect(result.percentage).toBe(0);
    });

    it("should handle negative savings (increase)", () => {
      const result = calculateSavings(100, 150);
      expect(result.absolute).toBe(-50);
      expect(result.percentage).toBe(-50);
    });

    it("should handle 100% reduction", () => {
      const result = calculateSavings(200, 0);
      expect(result.absolute).toBe(200);
      expect(result.percentage).toBe(100);
    });
  });
});
