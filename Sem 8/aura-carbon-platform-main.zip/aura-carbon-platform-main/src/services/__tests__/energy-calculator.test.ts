import { energyCalculator } from "../energy-calculator";
import { emissionFactorsService } from "../emission-factors";

jest.mock("../emission-factors");
const mockEmissionFactorsService = emissionFactorsService as jest.Mocked<
  typeof emissionFactorsService
>;

jest.mock("@/lib/db", () => ({
  db: {
    emissionFactor: {
      findFirst: jest.fn(),
    },
  },
}));

describe("EnergyCalculator", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockEmissionFactorsService.getEmissionFactor.mockImplementation(
      async (category, subcategory, region, fuelType) => {
        const factors: Record<string, any> = {
          energy_heating_global_natural_gas: {
            id: "1",
            category: "energy",
            subcategory: "heating",
            region: "global",
            co2_per_unit: 0.185,
            unit: "kWh",
            source: "DEFRA",
          },
          energy_heating_global_heating_oil: {
            id: "2",
            category: "energy",
            subcategory: "heating",
            region: "global",
            co2_per_unit: 2.52,
            unit: "liter",
            source: "DEFRA",
          },
          energy_heating_global_propane: {
            id: "3",
            category: "energy",
            subcategory: "heating",
            region: "global",
            co2_per_unit: 3.0,
            unit: "kg",
            source: "DEFRA",
          },
        };

        const key = `${category}_${subcategory}_${region}_${fuelType}`;
        return factors[key] || null;
      }
    );
  });

  describe("calculateElectricityEmissions", () => {
    it("should calculate basic electricity emissions", async () => {
      const electricityData = {
        consumption: 1000,
        gridRegion: "US",
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(electricityData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown).toHaveProperty("baseEmissions");
      expect(result.breakdown).toHaveProperty("renewableAdjustment");
      expect(result.gridData).toHaveProperty("emissionFactor");
      expect(result.methodology).toContain("Real-time grid emission factors");
    });

    it("should apply renewable percentage adjustment", async () => {
      const electricityData = {
        consumption: 1000,
        gridRegion: "US",
        renewablePercentage: 50,
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(electricityData);

      expect(result.breakdown.renewableAdjustment).toBeLessThan(0);
      expect(result.totalEmissions).toBeLessThan(
        result.breakdown.baseEmissions
      );
    });

    it("should handle custom source mix", async () => {
      const electricityData = {
        consumption: 1000,
        gridRegion: "US",
        sourceMix: {
          solar: 50,
          wind: 30,
          naturalGas: 20,
        },
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(electricityData);

      expect(result.breakdown.sourceMixAdjustment).not.toBe(0);
      expect(result.totalEmissions).toBeGreaterThan(0);
    });

    it("should handle time-of-use data", async () => {
      const electricityData = {
        consumption: 1000,
        gridRegion: "US",
        timeOfUse: {
          peak: 300,
          offPeak: 700,
        },
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(electricityData);

      expect(result.breakdown).toHaveProperty("timeOfUseAdjustment");
      expect(result.totalEmissions).toBeGreaterThan(0);
    });
  });

  describe("calculateHeatingEmissions", () => {
    it("should calculate natural gas heating emissions", async () => {
      const heatingData = {
        naturalGas: 500,
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.naturalGasEmissions).toBeGreaterThan(0);
      expect(result.breakdown.heatingOilEmissions).toBe(0);
      expect(result.methodology).toContain("Fuel-specific emission factors");
    });

    it("should calculate heating oil emissions", async () => {
      const heatingData = {
        heatingOil: 100,
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.heatingOilEmissions).toBeGreaterThan(0);
      expect(result.breakdown.naturalGasEmissions).toBe(0);
    });

    it("should calculate propane heating emissions", async () => {
      const heatingData = {
        propane: 50,
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.propaneEmissions).toBeGreaterThan(0);
    });

    it("should apply system efficiency adjustment", async () => {
      const heatingData = {
        naturalGas: 500,
        systemEfficiency: 0.8,
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.breakdown.efficiencyAdjustment).toBeGreaterThan(0);
      expect(result.totalEmissions).toBeGreaterThan(
        result.breakdown.naturalGasEmissions
      );
    });

    it("should handle heat pump calculations", async () => {
      const heatingData = {
        heatPump: {
          electricity: 200,
          cop: 3.5,
          heatSource: "air" as const,
        },
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.breakdown.heatPumpEmissions).toBeGreaterThan(0);
      expect(result.totalEmissions).toBeGreaterThan(0);
    });

    it("should handle multiple heating sources", async () => {
      const heatingData = {
        naturalGas: 300,
        heatingOil: 50,
        wood: 100,
      };

      const result =
        await energyCalculator.calculateHeatingEmissions(heatingData);

      expect(result.breakdown.naturalGasEmissions).toBeGreaterThan(0);
      expect(result.breakdown.heatingOilEmissions).toBeGreaterThan(0);
      expect(result.breakdown.woodEmissions).toBeGreaterThan(0);
      expect(result.totalEmissions).toBeGreaterThan(0);
    });
  });

  describe("calculateCoolingEmissions", () => {
    it("should calculate basic cooling emissions", async () => {
      const coolingData = {
        electricity: 800,
        systemType: "central_ac" as const,
      };

      const result =
        await energyCalculator.calculateCoolingEmissions(coolingData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.baseEmissions).toBeGreaterThan(0);
      expect(result.methodology).toContain("Grid electricity factors");
    });

    it("should apply SEER efficiency adjustment", async () => {
      const coolingData = {
        electricity: 800,
        systemType: "central_ac" as const,
        seer: 20,
      };

      const result =
        await energyCalculator.calculateCoolingEmissions(coolingData);

      expect(result.breakdown.efficiencyAdjustment).toBeLessThan(0);
      expect(result.totalEmissions).toBeLessThan(
        result.breakdown.baseEmissions
      );
    });

    it("should apply climate zone adjustment", async () => {
      const coolingData = {
        electricity: 800,
        systemType: "central_ac" as const,
        climateZone: "hot_humid" as const,
      };

      const result =
        await energyCalculator.calculateCoolingEmissions(coolingData);

      expect(result.breakdown.climateAdjustment).toBeGreaterThan(0);
      expect(result.totalEmissions).toBeGreaterThan(
        result.breakdown.baseEmissions
      );
    });
  });

  describe("calculateRenewableCredits", () => {
    it("should calculate solar generation credits", async () => {
      const renewableData = {
        solarGenerated: 1200,
      };

      const result =
        await energyCalculator.calculateRenewableCredits(renewableData);

      expect(result.totalCredits).toBeLessThan(0);
      expect(result.breakdown.solarCredits).toBeLessThan(0);
      expect(result.methodology).toContain("Grid displacement method");
    });

    it("should calculate wind generation credits", async () => {
      const renewableData = {
        windGenerated: 800,
      };

      const result =
        await energyCalculator.calculateRenewableCredits(renewableData);

      expect(result.totalCredits).toBeLessThan(0);
      expect(result.breakdown.windCredits).toBeLessThan(0);
    });

    it("should account for battery storage efficiency", async () => {
      const renewableData = {
        solarGenerated: 1000,
        batteryStorage: {
          capacity: 500,
          cycleEfficiency: 0.9,
        },
      };

      const result =
        await energyCalculator.calculateRenewableCredits(renewableData);

      expect(result.breakdown.batteryEfficiencyLoss).toBeGreaterThan(0);
      expect(result.totalCredits).toBeLessThan(0);
    });

    it("should handle multiple renewable sources", async () => {
      const renewableData = {
        solarGenerated: 800,
        windGenerated: 400,
        hydroGenerated: 200,
      };

      const result =
        await energyCalculator.calculateRenewableCredits(renewableData);

      expect(result.breakdown.solarCredits).toBeLessThan(0);
      expect(result.breakdown.windCredits).toBeLessThan(0);
      expect(result.breakdown.hydroCredits).toBeLessThan(0);
      expect(result.totalCredits).toBeLessThan(0);
    });
  });

  describe("calculateEnergyFootprint", () => {
    it("should calculate comprehensive energy footprint", async () => {
      const energyData = {
        electricity: {
          consumption: 1000,
          gridRegion: "US",
        },
        heating: {
          naturalGas: 500,
        },
        cooling: {
          electricity: 300,
          systemType: "central_ac" as const,
        },
        renewable: {
          solarGenerated: 600,
        },
      };

      const result =
        await energyCalculator.calculateEnergyFootprint(energyData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.electricity).toBeGreaterThan(0);
      expect(result.breakdown.heating).toBeGreaterThan(0);
      expect(result.breakdown.cooling).toBeGreaterThan(0);
      expect(result.breakdown.renewableCredits).toBeLessThan(0);
      expect(result.details).toHaveLength(4);
      expect(result.recommendations).toBeInstanceOf(Array);
      expect(result.methodology).toContain("Comprehensive energy calculator");
    });

    it("should handle electricity-only calculation", async () => {
      const energyData = {
        electricity: {
          consumption: 1200,
          gridRegion: "EU",
          renewablePercentage: 30,
        },
      };

      const result =
        await energyCalculator.calculateEnergyFootprint(energyData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.electricity).toBeGreaterThan(0);
      expect(result.breakdown.heating).toBe(0);
      expect(result.breakdown.cooling).toBe(0);
      expect(result.breakdown.renewableCredits).toBe(0);
      expect(result.details).toHaveLength(1);
    });

    it("should ensure non-negative total emissions", async () => {
      const energyData = {
        electricity: {
          consumption: 100,
          gridRegion: "global",
        },
        renewable: {
          solarGenerated: 2000,
        },
      };

      const result =
        await energyCalculator.calculateEnergyFootprint(energyData);

      expect(result.totalEmissions).toBeGreaterThanOrEqual(0);
    });

    it("should generate appropriate recommendations", async () => {
      const energyData = {
        electricity: {
          consumption: 2000,
          gridRegion: "US",
        },
        heating: {
          heatingOil: 200,
        },
      };

      const result =
        await energyCalculator.calculateEnergyFootprint(energyData);

      expect(result.recommendations).toEqual(
        expect.arrayContaining([expect.stringContaining("renewable energy")])
      );
      expect(result.recommendations).toEqual(
        expect.arrayContaining([expect.stringContaining("heat pump")])
      );
    });
  });

  describe("Error handling", () => {
    it("should handle missing emission factors gracefully", async () => {
      const electricityData = {
        consumption: 1000,
        gridRegion: "unknown_region",
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(electricityData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.gridData.region).toBe("unknown_region");
    });

    it("should handle edge case input data", async () => {
      const edgeCaseData = {
        consumption: 0,
        gridRegion: "global",
      };

      const result =
        await energyCalculator.calculateElectricityEmissions(edgeCaseData);

      expect(result.totalEmissions).toBe(0);
      expect(result.breakdown.baseEmissions).toBe(0);
    });
  });
});
