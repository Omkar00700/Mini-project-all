import { consumptionCalculator } from "../consumption-calculator";
import type { ConsumptionData } from "@/types/carbon";

describe("ConsumptionCalculator", () => {
  describe("calculateConsumptionEmissions", () => {
    it("should calculate shopping emissions correctly", async () => {
      const consumptionData: ConsumptionData = {
        shopping: {
          clothing: 5,
          electronics: 2,
          other_goods: 200,
        },
      };

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.shopping).toBeGreaterThan(0);
      expect(result.breakdown.shopping).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(3);
      expect(result.recommendations.length).toBeGreaterThan(0);
    });

    it("should calculate services emissions correctly", async () => {
      const consumptionData: ConsumptionData = {
        services: {
          banking: 50,
          telecommunications: 100,
          entertainment: 150,
        },
      };

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.services).toBeGreaterThan(0);
      expect(result.breakdown.services).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(3);
    });

    it("should calculate waste emissions correctly", async () => {
      const consumptionData: ConsumptionData = {
        waste: {
          general_waste: 30,
          recycling: 20,
          organic_waste: 15,
        },
      };

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.waste).toBeDefined();
      expect(result.breakdown.waste).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(3);

      const recyclingDetail = result.details.find(
        (d) => d.subcategory === "recycling"
      );
      expect(recyclingDetail?.emissions).toBeLessThan(0);
    });

    it("should calculate comprehensive consumption emissions", async () => {
      const consumptionData: ConsumptionData = {
        shopping: {
          clothing: 3,
          electronics: 1,
          other_goods: 100,
        },
        services: {
          banking: 30,
          telecommunications: 80,
        },
        waste: {
          general_waste: 25,
          recycling: 15,
          organic_waste: 10,
        },
      };

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.shopping).toBeGreaterThan(0);
      expect(result.breakdown.services).toBeGreaterThan(0);
      expect(result.breakdown.waste).toBeDefined();

      const totalBreakdown = Object.values(result.breakdown).reduce(
        (sum: number, val: any) => sum + val,
        0
      );
      expect(Math.abs(totalBreakdown - result.totalEmissions)).toBeLessThan(
        0.01
      );

      expect(result.details.length).toBeGreaterThan(0);
      expect(result.recommendations.length).toBeGreaterThan(0);
      expect(result.methodology).toContain("Lifecycle assessment");
    });

    it("should provide consumption recommendations based on patterns", async () => {
      const highShoppingData: ConsumptionData = {
        shopping: {
          clothing: 15,
          other_goods: 1000,
        },
        waste: {
          general_waste: 60,
          recycling: 5,
        },
      };

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          highShoppingData
        );

      expect(result.recommendations.some((r) => r.includes("clothing"))).toBe(
        true
      );
      expect(result.recommendations.some((r) => r.includes("recycling"))).toBe(
        true
      );
    });

    it("should handle empty consumption data", async () => {
      const consumptionData: ConsumptionData = {};

      const result =
        await consumptionCalculator.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBe(0);
      expect(result.breakdown.shopping).toBe(0);
      expect(result.breakdown.services).toBe(0);
      expect(result.breakdown.waste).toBe(0);
      expect(result.details).toHaveLength(0);
    });
  });

  describe("calculateProductLifecycleEmissions", () => {
    it("should calculate full lifecycle emissions", async () => {
      const result =
        await consumptionCalculator.calculateProductLifecycleEmissions(
          "electronics",
          2,
          { production: true, transport: true, use: true, disposal: true }
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.stageBreakdown.production).toBeGreaterThan(0);
      expect(result.stageBreakdown.transport).toBeGreaterThan(0);
      expect(result.stageBreakdown.use).toBeGreaterThan(0);
      expect(result.stageBreakdown.disposal).toBeGreaterThan(0);
      expect(result.details).toHaveLength(4);
    });

    it("should calculate partial lifecycle emissions", async () => {
      const result =
        await consumptionCalculator.calculateProductLifecycleEmissions(
          "clothing",
          3,
          { production: true, transport: false, use: false, disposal: true }
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.stageBreakdown.production).toBeGreaterThan(0);
      expect(result.stageBreakdown.disposal).toBeGreaterThan(0);
      expect(result.stageBreakdown.transport).toBeUndefined();
      expect(result.stageBreakdown.use).toBeUndefined();
      expect(result.details).toHaveLength(2);
    });

    it("should throw error for unknown product type", async () => {
      await expect(
        consumptionCalculator.calculateProductLifecycleEmissions(
          "unknown_product",
          1
        )
      ).rejects.toThrow("Unknown product type");
    });
  });

  describe("calculateCircularEconomyImpact", () => {
    it("should calculate circular economy emission reductions", async () => {
      const originalConsumption: ConsumptionData = {
        shopping: {
          clothing: 10,
          electronics: 3,
          other_goods: 500,
        },
        waste: {
          general_waste: 40,
          recycling: 10,
        },
      };

      const circularActions = {
        repairInsteadOfBuy: 20,
        buySecondHand: 30,
        shareInsteadOfOwn: 10,
        recycleRate: 60,
      };

      const result = await consumptionCalculator.calculateCircularEconomyImpact(
        originalConsumption,
        circularActions
      );

      expect(result.originalEmissions).toBeGreaterThan(0);
      expect(result.circularEmissions).toBeLessThan(result.originalEmissions);
      expect(result.emissionReduction).toBeGreaterThan(0);
      expect(result.reductionPercentage).toBeGreaterThan(0);
      expect(result.recommendations.length).toBeGreaterThan(0);
    });
  });

  describe("getEmissionFactor", () => {
    it("should return emission factor for known consumption items", () => {
      const clothingFactor =
        consumptionCalculator.getEmissionFactor("clothing");
      expect(clothingFactor).toBeDefined();
      expect(clothingFactor?.emissionFactor).toBeGreaterThan(0);
      expect(clothingFactor?.category).toBe("consumption");
      expect(clothingFactor?.subcategory).toBe("clothing");
    });

    it("should return undefined for unknown consumption items", () => {
      const unknownFactor =
        consumptionCalculator.getEmissionFactor("unknown_item");
      expect(unknownFactor).toBeUndefined();
    });
  });

  describe("getConsumptionDatabase", () => {
    it("should return the complete consumption database", () => {
      const database = consumptionCalculator.getConsumptionDatabase();
      expect(database.size).toBeGreaterThan(0);
      expect(database.has("clothing")).toBe(true);
      expect(database.has("electronics")).toBe(true);
      expect(database.has("general_waste")).toBe(true);
      expect(database.has("recycling")).toBe(true);
    });
  });
});
