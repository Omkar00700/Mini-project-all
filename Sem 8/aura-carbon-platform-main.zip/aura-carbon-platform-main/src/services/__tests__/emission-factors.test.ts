import {
  EmissionFactorsService,
  emissionFactorsService,
} from "../emission-factors";
import { db } from "@/lib/db";

jest.mock("@/lib/db", () => ({
  db: {
    emissionFactor: {
      count: jest.fn(),
      create: jest.fn(),
      findFirst: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
      groupBy: jest.fn(),
      aggregate: jest.fn(),
    },
  },
}));

const mockDb = db as jest.Mocked<typeof db>;

describe("EmissionFactorsService", () => {
  let service: EmissionFactorsService;

  beforeEach(() => {
    jest.clearAllMocks();
    service = new EmissionFactorsService();
  });

  describe("initializeEmissionFactors", () => {
    it("should initialize emission factors when database is empty", async () => {
      (mockDb.emissionFactor.count as jest.Mock).mockResolvedValue(0);
      (mockDb.emissionFactor.create as jest.Mock).mockResolvedValue({});

      await service.initializeEmissionFactors();

      expect(mockDb.emissionFactor.count).toHaveBeenCalled();
      expect(mockDb.emissionFactor.create).toHaveBeenCalled();
    });

    it("should skip initialization when factors already exist", async () => {
      (mockDb.emissionFactor.count as jest.Mock).mockResolvedValue(100);

      await service.initializeEmissionFactors();

      expect(mockDb.emissionFactor.count).toHaveBeenCalled();
      expect(mockDb.emissionFactor.create).not.toHaveBeenCalled();
    });
  });

  describe("getEmissionFactor", () => {
    const mockEmissionFactor = {
      id: "test-factor-1",
      category: "transportation",
      subcategory: "personal_vehicle_gasoline",
      region: "India",
      value: 2.27193,
      unit: "kg CO2/liter",
      source: "India Road Transport Emission Factors",
      confidenceLevel: 0.9,
      validFrom: new Date("2024-01-01"),
      validTo: null,
      createdAt: new Date(),
    };

    it("should retrieve emission factor by criteria", async () => {
      (mockDb.emissionFactor.findFirst as jest.Mock).mockResolvedValue(
        mockEmissionFactor
      );

      const result = await service.getEmissionFactor(
        "transportation",
        "personal_vehicle_gasoline",
        "India"
      );

      expect(result).not.toBeNull();
      expect(result?.category).toBe("transportation");
      expect(result?.value).toBe(2.27193);
    });

    it("should return null when no factor is found", async () => {
      (mockDb.emissionFactor.findFirst as jest.Mock).mockResolvedValue(null);

      const result = await service.getEmissionFactor(
        "nonexistent",
        "nonexistent",
        "nonexistent"
      );

      expect(result).toBeNull();
    });

    it("should fallback to global region when specific region not found", async () => {
      (mockDb.emissionFactor.findFirst as jest.Mock)
        .mockResolvedValueOnce(null)
        .mockResolvedValueOnce(mockEmissionFactor);

      const result = await service.getEmissionFactor(
        "transportation",
        "personal_vehicle_gasoline",
        "NonExistentRegion"
      );

      expect(mockDb.emissionFactor.findFirst).toHaveBeenCalledTimes(2);
      expect(result).not.toBeNull();
    });
  });

  describe("updateEmissionFactor", () => {
    it("should update emission factor successfully", async () => {
      const updatedFactor = {
        id: "test-id",
        category: "transportation",
        subcategory: "personal_vehicle_gasoline",
        region: "India",
        value: 2.5,
        unit: "kg CO2/liter",
        source: "Updated Source",
        confidenceLevel: 0.95,
        validFrom: new Date(),
        validTo: null,
        createdAt: new Date(),
      };

      (mockDb.emissionFactor.update as jest.Mock).mockResolvedValue(
        updatedFactor
      );

      const result = await service.updateEmissionFactor("test-id", {
        value: 2.5,
        source: "Updated Source",
      });

      expect(result.value).toBe(2.5);
      expect(result.source).toBe("Updated Source");
    });
  });

  describe("getEmissionFactorsByCategory", () => {
    it("should retrieve factors by category", async () => {
      const mockFactors = [
        {
          id: "1",
          category: "transportation",
          subcategory: "car",
          region: "India",
          value: 0.21,
          unit: "kg CO2/km",
          source: "Test",
          confidenceLevel: 0.9,
          validFrom: new Date(),
          validTo: null,
          createdAt: new Date(),
        },
        {
          id: "2",
          category: "transportation",
          subcategory: "bus",
          region: "India",
          value: 0.089,
          unit: "kg CO2/km",
          source: "Test",
          confidenceLevel: 0.85,
          validFrom: new Date(),
          validTo: null,
          createdAt: new Date(),
        },
      ];

      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue(
        mockFactors
      );

      const result =
        await service.getEmissionFactorsByCategory("transportation");

      expect(result).toHaveLength(2);
      expect(result[0].category).toBe("transportation");
    });

    it("should return empty array when no factors found", async () => {
      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue([]);

      const result = await service.getEmissionFactorsByCategory("nonexistent");

      expect(result).toHaveLength(0);
    });
  });

  describe("searchEmissionFactors", () => {
    it("should search factors by query", async () => {
      const mockFactors = [
        {
          id: "1",
          category: "transportation",
          subcategory: "car",
          region: "India",
          value: 0.21,
          unit: "kg CO2/km",
          source: "Test",
          confidenceLevel: 0.9,
          validFrom: new Date(),
          validTo: null,
          createdAt: new Date(),
        },
      ];

      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue(
        mockFactors
      );

      const result = await service.searchEmissionFactors({ query: "car" });

      expect(result).toHaveLength(1);
    });

    it("should filter by category and region", async () => {
      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue([]);

      await service.searchEmissionFactors({
        category: "transportation",
        region: "India",
      });

      expect(mockDb.emissionFactor.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            category: "transportation",
            region: "India",
          }),
        })
      );
    });
  });

  describe("getEmissionFactorsStats", () => {
    it("should return statistics", async () => {
      (mockDb.emissionFactor.count as jest.Mock).mockResolvedValue(100);
      (mockDb.emissionFactor.groupBy as jest.Mock)
        .mockResolvedValueOnce([
          { category: "transportation" },
          { category: "energy" },
        ])
        .mockResolvedValueOnce([{ region: "India" }, { region: "global" }]);
      (mockDb.emissionFactor.findFirst as jest.Mock).mockResolvedValue({
        createdAt: new Date(),
      });
      (mockDb.emissionFactor.aggregate as jest.Mock).mockResolvedValue({
        _avg: { confidenceLevel: 0.85 },
      });

      const stats = await service.getEmissionFactorsStats();

      expect(stats.totalCount).toBe(100);
      expect(stats.categoriesCount).toBe(2);
      expect(stats.regionsCount).toBe(2);
      expect(stats.averageConfidence).toBe(0.85);
    });

    it("should handle null last updated", async () => {
      (mockDb.emissionFactor.count as jest.Mock).mockResolvedValue(0);
      (mockDb.emissionFactor.groupBy as jest.Mock)
        .mockResolvedValueOnce([])
        .mockResolvedValueOnce([]);
      (mockDb.emissionFactor.findFirst as jest.Mock).mockResolvedValue(null);
      (mockDb.emissionFactor.aggregate as jest.Mock).mockResolvedValue({
        _avg: { confidenceLevel: null },
      });

      const stats = await service.getEmissionFactorsStats();

      expect(stats.lastUpdated).toBeNull();
      expect(stats.averageConfidence).toBe(0);
    });
  });

  describe("validateEmissionFactor", () => {
    it("should validate complete emission factor", () => {
      const result = service.validateEmissionFactor({
        category: "transportation",
        subcategory: "car",
        region: "India",
        value: 0.21,
        unit: "kg CO2/km",
        source: "Test Source",
        confidenceLevel: 0.9,
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should identify missing required fields", () => {
      const result = service.validateEmissionFactor({
        value: 0.21,
      } as never);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Category is required");
      expect(result.errors).toContain("Subcategory is required");
      expect(result.errors).toContain("Region is required");
      expect(result.errors).toContain("Unit is required");
      expect(result.errors).toContain("Source is required");
    });

    it("should validate confidence range", () => {
      const result = service.validateEmissionFactor({
        category: "test",
        subcategory: "test",
        region: "test",
        value: 1,
        unit: "kg",
        source: "test",
        confidenceLevel: 1.5,
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        "Confidence level must be between 0 and 1"
      );
    });

    it("should allow carbon-negative processes", () => {
      const result = service.validateEmissionFactor({
        category: "waste",
        subcategory: "recycling",
        region: "global",
        value: -0.07,
        unit: "kg CO2/kg",
        source: "EPA",
      });

      expect(result.valid).toBe(true);
    });
  });

  describe("Data Quality and Accuracy Tests", () => {
    it("should ensure emission factors are within reasonable ranges", async () => {
      const mockFactors = [
        {
          id: "1",
          category: "energy",
          subcategory: "electricity",
          region: "India",
          value: 0.82,
          unit: "kg CO2/kWh",
          source: "CEA",
          confidenceLevel: 0.95,
          validFrom: new Date(),
          validTo: null,
          createdAt: new Date(),
        },
      ];

      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue(
        mockFactors
      );

      const factors = await service.getEmissionFactorsByCategory("energy");

      for (const factor of factors) {
        expect(factor.value).toBeGreaterThan(-100);
        expect(factor.value).toBeLessThan(1000);
      }
    });
  });

  describe("Error Handling and Edge Cases", () => {
    it("should handle empty search results", async () => {
      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue([]);

      const result = await service.searchEmissionFactors({
        query: "nonexistent",
      });

      expect(result).toHaveLength(0);
    });

    it("should handle special characters in search queries", async () => {
      (mockDb.emissionFactor.findMany as jest.Mock).mockResolvedValue([]);

      const result = await service.searchEmissionFactors({ query: "test@#$%" });

      expect(mockDb.emissionFactor.findMany).toHaveBeenCalled();
    });
  });
});
