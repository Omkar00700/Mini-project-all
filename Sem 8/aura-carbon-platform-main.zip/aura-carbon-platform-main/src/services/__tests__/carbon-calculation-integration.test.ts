import { carbonCalculationService } from "../carbon-calculation";
import type {
  CarbonFootprintInput,
  CarbonFootprintResult,
  TransportationData,
  EnergyData,
  FoodData,
  ConsumptionData,
} from "@/types/carbon";

jest.mock("../carbon-orchestrator", () => ({
  carbonOrchestrator: {
    calculateCarbonFootprint: jest.fn(),
  },
}));

jest.mock("../emission-factors", () => ({
  emissionFactorsService: {
    getEmissionFactor: jest.fn(),
  },
}));

jest.mock("../transportation-calculator", () => ({
  transportationCalculator: {
    calculateTransportationFootprint: jest.fn(),
  },
}));

jest.mock("../energy-calculator", () => ({
  energyCalculator: {
    calculateEnergyFootprint: jest.fn(),
  },
}));

jest.mock("../food-calculator", () => ({
  foodCalculator: {
    calculateFoodEmissions: jest.fn(),
  },
}));

jest.mock("../consumption-calculator", () => ({
  consumptionCalculator: {
    calculateConsumptionEmissions: jest.fn(),
  },
}));

const { carbonOrchestrator } = require("../carbon-orchestrator");
const { emissionFactorsService } = require("../emission-factors");
const { transportationCalculator } = require("../transportation-calculator");
const { energyCalculator } = require("../energy-calculator");
const { foodCalculator } = require("../food-calculator");
const { consumptionCalculator } = require("../consumption-calculator");

describe("Carbon Calculation Integration Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("End-to-End Carbon Footprint Calculation", () => {
    it("should calculate comprehensive carbon footprint with real data flow", async () => {
      const mockTransportationResult = {
        totalEmissions: 2500,
        breakdown: {
          personal_vehicles: 2000,
          flights: 400,
          publicTransport: 100,
        },
        details: [
          {
            type: "personal_vehicle",
            emissions: 2000,
            distance: 15000,
            fuel_type: "gasoline",
            efficiency: 12,
          },
          {
            type: "flight",
            emissions: 400,
            distance: 2000,
            class: "economy",
            radiativeForcing: 1.9,
          },
        ],
        methodology: "IPCC Guidelines with real-world adjustments",
      };

      const mockEnergyResult = {
        totalEmissions: 1800,
        breakdown: {
          electricity: 1200,
          heating: 500,
          cooling: 100,
          renewableCredits: 0,
        },
        details: [
          {
            type: "electricity",
            emissions: 1200,
            consumption: 3000,
            grid_region: "US",
            emissionFactor: 0.4,
          },
        ],
        methodology: "Real-time grid emission factors",
        recommendations: ["Switch to renewable energy provider"],
      };

      const mockFoodResult = {
        totalEmissions: 1200,
        breakdown: {
          meat: 800,
          dairy: 250,
          plant_based: 100,
          beverages: 50,
        },
        details: [
          {
            type: "meat",
            emissions: 800,
            beef: 10,
            chicken: 5,
          },
        ],
        methodology: "FAO emission factors with regional adjustments",
        recommendations: ["Reduce meat consumption by 2 days per week"],
      };

      const mockConsumptionResult = {
        totalEmissions: 800,
        breakdown: {
          shopping: 500,
          services: 200,
          other_goods: 100,
        },
        details: [
          {
            type: "shopping",
            emissions: 500,
            clothing: 300,
            electronics: 200,
          },
        ],
        methodology: "EPA EEIO lifecycle assessment",
        recommendations: ["Buy less, choose sustainable products"],
      };

      transportationCalculator.calculateTransportationFootprint.mockResolvedValue(
        mockTransportationResult
      );
      energyCalculator.calculateEnergyFootprint.mockResolvedValue(
        mockEnergyResult
      );
      foodCalculator.calculateFoodEmissions.mockResolvedValue(mockFoodResult);
      consumptionCalculator.calculateConsumptionEmissions.mockResolvedValue(
        mockConsumptionResult
      );

      const mockOrchestratorResult: CarbonFootprintResult = {
        total_emissions: 6300,
        breakdown: {
          transportation: 2500,
          energy: 1800,
          food: 1200,
          consumption: 800,
        },
        confidence_score: 0.87,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.85,
          calculation_timestamp: new Date(),
          confidence_factors: {
            transportation: 0.9,
            energy: 0.95,
            food: 0.8,
            consumption: 0.75,
          },
          assumptions: [
            "GHG Protocol methodology applied across all categories",
            "Regional emission factors used where available",
            "Real-time grid data incorporated for electricity calculations",
            "Switch to renewable energy provider",
            "Reduce meat consumption by 2 days per week",
          ],
          data_sources: [
            "EPA emission factors database",
            "IEA energy statistics",
            "DEFRA conversion factors",
            "Real-time grid emission APIs",
            "manual",
            "api",
          ],
        },
        detailed_breakdown: {
          transportation: {
            personal_vehicles: {
              emissions: 2000,
              unit: "kg CO2e",
              confidence: 0.9,
              methodology: "IPCC Guidelines with real-world adjustments",
              data_quality: 0.9,
              activity_data: 0,
              emission_factor: 0,
            },
            flights: {
              emissions: 400,
              unit: "kg CO2e",
              confidence: 0.9,
              methodology: "IPCC Guidelines with real-world adjustments",
              data_quality: 0.9,
              activity_data: 0,
              emission_factor: 0,
            },
          },
          energy: {
            electricity: {
              emissions: 1200,
              unit: "kg CO2e",
              confidence: 0.95,
              methodology: "Real-time grid emission factors",
              data_quality: 0.95,
              activity_data: 0,
              emission_factor: 0,
            },
            heating: {
              emissions: 500,
              unit: "kg CO2e",
              confidence: 0.95,
              methodology: "Real-time grid emission factors",
              data_quality: 0.95,
              activity_data: 0,
              emission_factor: 0,
            },
          },
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockOrchestratorResult
      );

      const comprehensiveData = {
        transportation: {
          personal_vehicles: {
            distance: 15000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
          flights: {
            domestic_short: 1,
            domestic_medium: 1,
            international_short: 1,
            class: "economy" as const,
          },
          public_transport: {
            bus_distance: 500,
            train_distance: 300,
          },
        },
        energy: {
          electricity: {
            consumption: 3000,
            grid_region: "US",
            renewable_percentage: 15,
          },
          heating: {
            natural_gas: 2500,
          },
          cooling: {
            electricity: 800,
            efficiency_rating: "14 SEER",
          },
        },
        food: {
          meat: {
            beef: 10,
            chicken: 15,
            pork: 5,
          },
          dairy: {
            milk: 50,
            cheese: 3,
          },
          plant_based: {
            vegetables: 100,
            fruits: 80,
            grains: 50,
          },
        },
        consumption: {
          shopping: {
            clothing: 20,
            electronics: 3,
            furniture: 2,
          },
          services: {
            banking: 500,
            insurance: 300,
            telecommunications: 200,
          },
        },
      };

      const result = await carbonCalculationService.calculateTotalFootprint(
        "integration-test-user",
        comprehensiveData
      );

      expect(result.total_emissions).toBe(6300);
      expect(result.breakdown.transportation).toBe(2500);
      expect(result.breakdown.energy).toBe(1800);
      expect(result.breakdown.food).toBe(1200);
      expect(result.breakdown.consumption).toBe(800);

      expect(result.confidence_score).toBeCloseTo(0.87, 2);

      expect(result.calculation_metadata.calculation_method).toBe(
        "ghg_protocol"
      );
      expect(result.calculation_metadata.data_completeness).toBeGreaterThan(
        0.8
      );
      expect(result.calculation_metadata.confidence_factors).toHaveProperty(
        "transportation"
      );
      expect(result.calculation_metadata.confidence_factors).toHaveProperty(
        "energy"
      );
      expect(result.calculation_metadata.confidence_factors).toHaveProperty(
        "food"
      );
      expect(result.calculation_metadata.confidence_factors).toHaveProperty(
        "consumption"
      );

      expect(result.detailed_breakdown).toHaveProperty("transportation");
      expect(result.detailed_breakdown).toHaveProperty("energy");
      expect(result.detailed_breakdown?.transportation).toHaveProperty(
        "personal_vehicles"
      );
      expect(result.detailed_breakdown?.energy).toHaveProperty("electricity");

      expect(carbonOrchestrator.calculateCarbonFootprint).toHaveBeenCalledWith(
        expect.objectContaining({
          user_id: "integration-test-user",
          categories: comprehensiveData,
          period: expect.objectContaining({
            start: expect.any(Date),
            end: expect.any(Date),
          }),
        })
      );
    });

    it("should handle partial data and calculate confidence appropriately", async () => {
      const mockEnergyResult = {
        totalEmissions: 1500,
        breakdown: { electricity: 1500 },
        details: [{ type: "electricity", emissions: 1500 }],
        methodology: "Real-time grid emission factors",
        recommendations: [],
      };

      energyCalculator.calculateEnergyFootprint.mockResolvedValue(
        mockEnergyResult
      );

      const mockPartialResult: CarbonFootprintResult = {
        total_emissions: 1500,
        breakdown: { energy: 1500, transportation: 0, food: 0, consumption: 0 },
        confidence_score: 0.65,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.25,
          calculation_timestamp: new Date(),
          confidence_factors: { energy: 0.95 },
          assumptions: [
            "Limited data available - only energy consumption provided",
          ],
          data_sources: ["Real-time grid emission APIs"],
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockPartialResult
      );

      const partialData = {
        energy: {
          electricity: {
            consumption: 2000,
            grid_region: "US",
          },
        },
      };

      const result = await carbonCalculationService.calculateTotalFootprint(
        "partial-test-user",
        partialData
      );

      expect(result.total_emissions).toBe(1500);
      expect(result.breakdown.energy).toBe(1500);
      expect(result.breakdown.transportation).toBeUndefined();
      expect(result.breakdown.food).toBeUndefined();
      expect(result.breakdown.consumption).toBeUndefined();

      expect(result.confidence_score).toBeLessThan(0.8);
      expect(result.calculation_metadata.data_completeness).toBeLessThan(0.5);
    });

    it("should validate calculation accuracy across categories", async () => {
      const mockEmissionFactors = {
        gasoline: 2.31,
        electricity_us: 0.386,
        beef: 60.0,
        clothing: 8.0,
      };

      emissionFactorsService.getEmissionFactor.mockImplementation(
        async (
          category: string,
          subcategory: string,
          region: string,
          fuel_type: string
        ) => {
          const key = `${category}_${subcategory}_${region}_${fuel_type}`;
          const factorMap: Record<string, any> = {
            transportation_personal_vehicle_global_gasoline: {
              id: "1",
              value: mockEmissionFactors.gasoline,
              unit: "kg CO2/liter",
            },
            energy_electricity_US_undefined: {
              id: "2",
              value: mockEmissionFactors.electricity_us,
              unit: "kg CO2/kWh",
            },
            food_meatary_global_beef: {
              id: "3",
              value: mockEmissionFactors.beef,
              unit: "kg CO2/kg",
            },
            consumption_clothing_global_t_shirt: {
              id: "4",
              value: mockEmissionFactors.clothing,
              unit: "kg CO2/item",
            },
          };
          return factorMap[key] || null;
        }
      );

      const testData = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 10,
          },
        },
        energy: {
          electricity: {
            consumption: 1000,
            grid_region: "US",
          },
        },
        food: {
          meat: {
            beef: 5,
          },
        },
        consumption: {
          shopping: {
            clothing: 10,
          },
        },
      };

      const mockAccurateResult: CarbonFootprintResult = {
        total_emissions: 997,
        breakdown: {
          transportation: 231,
          energy: 386,
          food: 300,
          consumption: 80,
        },
        confidence_score: 0.9,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 1.0,
          calculation_timestamp: new Date(),
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockAccurateResult
      );

      const result = await carbonCalculationService.calculateTotalFootprint(
        "accuracy-test-user",
        testData
      );

      expect(result.total_emissions).toBeCloseTo(997, 0);
      expect(result.breakdown.transportation).toBeCloseTo(231, 0);
      expect(result.breakdown.energy).toBeCloseTo(386, 0);
      expect(result.breakdown.food).toBeCloseTo(300, 0);
      expect(result.breakdown.consumption).toBeCloseTo(80, 0);

      expect(result.confidence_score).toBeGreaterThan(0.85);
      expect(result.calculation_metadata.data_completeness).toBe(1.0);
    });
  });

  describe("Data Quality and Validation Integration", () => {
    it("should handle data quality assessment across the pipeline", async () => {
      const mixedQualityData = {
        transportation: {
          personal_vehicles: {
            distance: 15000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
        energy: {
          electricity: {
            consumption: 2000,
            grid_region: "US",
          },
        },
        food: {
          meat: {
            beef: 5,
          },
        },
      };

      const mockMixedQualityResult: CarbonFootprintResult = {
        total_emissions: 4200,
        breakdown: {
          transportation: 2500,
          energy: 1200,
          food: 500,
          consumption: 0,
        },
        confidence_score: 0.72,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.65,
          calculation_timestamp: new Date(),
          confidence_factors: {
            transportation: 0.9,
            energy: 0.75,
            food: 0.5,
          },
          assumptions: [
            "Some emission values estimated due to incomplete data",
            "Missing consumption category estimated as zero",
            "Food emissions may be underestimated due to limited data",
          ],
          data_sources: ["manual", "estimated"],
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockMixedQualityResult
      );

      const result = await carbonCalculationService.calculateTotalFootprint(
        "mixed-quality-user",
        mixedQualityData
      );

      expect(result.confidence_score).toBeGreaterThan(0.6);
      expect(result.confidence_score).toBeLessThan(0.8);
      expect(result.calculation_metadata.data_completeness).toBeLessThan(0.8);

      expect(
        result.calculation_metadata.confidence_factors?.transportation
      ).toBeGreaterThan(0.8);
      expect(
        result.calculation_metadata.confidence_factors?.energy
      ).toBeLessThan(0.8);
      expect(result.calculation_metadata.confidence_factors?.food).toBeLessThan(
        0.6
      );

      expect(result.calculation_metadata.assumptions).toEqual(
        expect.arrayContaining([
          expect.stringContaining("estimated"),
          expect.stringContaining("incomplete"),
        ])
      );
    });

    it("should validate input data and handle errors gracefully", async () => {
      const invalidData = {
        transportation: {
          personal_vehicles: {
            distance: -1000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 0,
          },
        },
        energy: {
          electricity: {
            consumption: "invalid" as any,
            grid_region: "US",
          },
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockRejectedValue(
        new Error("Invalid input data: distance cannot be negative")
      );

      await expect(
        carbonCalculationService.calculateTotalFootprint(
          "invalid-data-user",
          invalidData
        )
      ).rejects.toThrow("Failed to calculate carbon footprint");
    });

    it("should handle missing emission factors gracefully", async () => {
      emissionFactorsService.getEmissionFactor.mockResolvedValue(null);

      const dataWithMissingFactors = {
        transportation: {
          personal_vehicles: {
            distance: 1000,
            fuel_type: "hydrogen" as any,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
        },
      };

      const mockFallbackResult: CarbonFootprintResult = {
        total_emissions: 1500,
        breakdown: { transportation: 1500, energy: 0, food: 0, consumption: 0 },
        confidence_score: 0.1,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.0,
          calculation_timestamp: new Date(),
          assumptions: [
            "Some emission factors not available - calculations may be incomplete",
            "Consider updating emission factors database",
          ],
          data_sources: ["manual"],
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockFallbackResult
      );

      const result = await carbonCalculationService.calculateTotalFootprint(
        "missing-factors-user",
        dataWithMissingFactors
      );

      expect(result.total_emissions).toBe(0);
      expect(result.confidence_score).toBeLessThan(0.2);
      expect(result.calculation_metadata.assumptions).toEqual(
        expect.arrayContaining([expect.stringContaining("not available")])
      );
    });
  });

  describe("Performance and Scalability Integration", () => {
    it("should handle large-scale calculations efficiently", async () => {
      const largeScaleData = {
        transportation: {
          personal_vehicles: {
            distance: 50000,
            fuel_type: "gasoline" as const,
            vehicle_class: "midsize" as const,
            efficiency: 12,
          },
          flights: {
            domestic_short: 20,
            domestic_medium: 15,
            domestic_long: 10,
            international_short: 8,
            international_long: 5,
            class: "economy" as const,
          },
          public_transport: {
            bus_distance: 5000,
            train_distance: 8000,
            subway_distance: 2000,
          },
        },
        energy: {
          electricity: {
            consumption: 25000,
            grid_region: "US",
            renewable_percentage: 10,
          },
          heating: {
            natural_gas: 15000,
            heating_oil: 500,
          },
          cooling: {
            electricity: 8000,
            efficiency_rating: "12 SEER",
          },
        },
        food: {
          meat: {
            beef: 50,
            chicken: 80,
            pork: 30,
            fish: 40,
          },
          dairy: {
            milk: 200,
            cheese: 15,
            yogurt: 50,
          },
          plant_based: {
            vegetables: 500,
            fruits: 300,
            grains: 200,
            legumes: 100,
          },
        },
        consumption: {
          shopping: {
            clothing: 100,
            electronics: 20,
            furniture: 10,
          },
          services: {
            banking: 2000,
            insurance: 1500,
            telecommunications: 1000,
          },
        },
      };

      const mockLargeScaleResult: CarbonFootprintResult = {
        total_emissions: 45000,
        breakdown: {
          transportation: 25000,
          energy: 12000,
          food: 6000,
          consumption: 2000,
        },
        confidence_score: 0.88,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.95,
          calculation_timestamp: new Date(),
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockLargeScaleResult
      );

      const startTime = Date.now();
      const result = await carbonCalculationService.calculateTotalFootprint(
        "large-scale-user",
        largeScaleData
      );
      const endTime = Date.now();

      expect(endTime - startTime).toBeLessThan(5000);

      expect(result.total_emissions).toBe(45000);
      expect(result.confidence_score).toBeGreaterThan(0.8);
    });

    it("should handle concurrent user calculations", async () => {
      const userData = {
        energy: {
          electricity: {
            consumption: 1000,
            grid_region: "US",
          },
        },
      };

      const mockConcurrentResult: CarbonFootprintResult = {
        total_emissions: 1500,
        breakdown: { energy: 1500, transportation: 0, food: 0, consumption: 0 },
        confidence_score: 0.9,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.8,
          calculation_timestamp: new Date(),
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockConcurrentResult
      );

      const concurrentPromises = Array.from({ length: 20 }, (_, i) =>
        carbonCalculationService.calculateTotalFootprint(
          `concurrent-user-${i}`,
          userData
        )
      );

      const startTime = Date.now();
      const results = await Promise.all(concurrentPromises);
      const endTime = Date.now();

      expect(results).toHaveLength(20);
      results.forEach((result, index) => {
        expect(result.total_emissions).toBe(386);
        expect(result.confidence_score).toBe(0.9);
      });

      expect(endTime - startTime).toBeLessThan(10000);
    });
  });

  describe("Recommendation Generation Integration", () => {
    it("should generate contextual recommendations based on calculation results", async () => {
      const highEmissionData = {
        transportation: {
          personal_vehicles: {
            distance: 25000,
            fuel_type: "gasoline" as const,
            vehicle_class: "truck" as const,
            efficiency: 8,
          },
        },
        energy: {
          electricity: {
            consumption: 5000,
            grid_region: "US",
            renewable_percentage: 0,
          },
          heating: {
            heating_oil: 1000,
          },
        },
        food: {
          meat: {
            beef: 30,
            pork: 20,
          },
          dairy: {
            milk: 100,
            cheese: 10,
          },
        },
      };

      const mockHighEmissionResult: CarbonFootprintResult = {
        total_emissions: 15000,
        breakdown: {
          transportation: 8000,
          energy: 4000,
          food: 3000,
          consumption: 0,
        },
        confidence_score: 0.85,
        calculation_metadata: {
          calculation_method: "ghg_protocol",
          emission_factors_version: "2.0.0",
          data_completeness: 0.9,
          calculation_timestamp: new Date(),
          assumptions: [
            "Switch to electric vehicle or increase public transport usage",
            "Install solar panels or switch to renewable energy provider",
            "Reduce meat consumption by 3 days per week",
            "Consider heat pump installation",
            "Improve home insulation",
          ],
        },
      };

      carbonOrchestrator.calculateCarbonFootprint.mockResolvedValue(
        mockHighEmissionResult
      );

      const result = await carbonCalculationService.calculateTotalFootprint(
        "high-emission-user",
        highEmissionData
      );

      expect(result.calculation_metadata.assumptions).toEqual(
        expect.arrayContaining([
          expect.stringContaining("electric vehicle"),
          expect.stringContaining("renewable energy"),
          expect.stringContaining("meat consumption"),
        ])
      );

      const calculation = {
        id: "test-calc",
        userId: "high-emission-user",
        periodStart: new Date(),
        periodEnd: new Date(),
        totalEmissions: result.total_emissions,
        breakdown: result.breakdown,
        confidenceScore: result.confidence_score,
        metadata: result.calculation_metadata,
        createdAt: new Date(),
      };

      const recommendations =
        await carbonCalculationService.getReductionRecommendations(
          "high-emission-user",
          calculation
        );

      expect(recommendations.length).toBeGreaterThan(0);

      const transportationRec = recommendations.find(
        (r) => r.category === "transportation"
      );
      expect(transportationRec).toBeDefined();
      expect(transportationRec?.potentialReduction).toBeGreaterThan(1000);

      const energyRec = recommendations.find((r) => r.category === "energy");
      expect(energyRec).toBeDefined();
      expect(energyRec?.potentialReduction).toBeGreaterThan(500);

      const foodRec = recommendations.find((r) => r.category === "food");
      expect(foodRec).toBeDefined();
      expect(foodRec?.potentialReduction).toBeGreaterThan(300);
    });
  });
});
