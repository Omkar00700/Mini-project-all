import { distanceCalculator } from "../distance-calculator";

global.fetch = jest.fn();

describe("DistanceCalculator", () => {
  beforeEach(() => {
    jest.clearAllMocks();

    process.env.GOOGLE_MAPS_API_KEY = undefined;
  });

  describe("calculateHaversineDistance", () => {
    it("should calculate distance between two points", () => {
      const point1 = { latitude: 40.7128, longitude: -74.006 };
      const point2 = { latitude: 34.0522, longitude: -118.2437 };

      const distance = distanceCalculator.calculateHaversineDistance(
        point1,
        point2
      );

      expect(distance).toBeCloseTo(3936, 1);
    });

    it("should return 0 for same location", () => {
      const point = { latitude: 40.7128, longitude: -74.006 };

      const distance = distanceCalculator.calculateHaversineDistance(
        point,
        point
      );

      expect(distance).toBe(0);
    });
  });

  describe("calculateRouteDistance", () => {
    it("should fallback to Haversine when no API key", async () => {
      const origin = { latitude: 40.7128, longitude: -74.006 };
      const destination = { latitude: 34.0522, longitude: -118.2437 };

      const result = await distanceCalculator.calculateRouteDistance(
        origin,
        destination
      );

      expect(result.distance).toBeCloseTo(3936, 1);
      expect(result.duration).toBeGreaterThan(0);
      expect(result.fuelEfficiencyFactor).toBe(1.0);
    });

    it("should use Google Maps API when available", async () => {
      process.env.GOOGLE_MAPS_API_KEY = "test-api-key";

      const mockResponse = {
        status: "OK",
        routes: [
          {
            legs: [
              {
                distance: { value: 3944000 },
                duration: { value: 14400 },
              },
            ],
          },
        ],
      };

      (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const origin = { latitude: 40.7128, longitude: -74.006 };
      const destination = { latitude: 34.0522, longitude: -118.2437 };

      const result = await distanceCalculator.calculateRouteDistance(
        origin,
        destination
      );

      expect(result.distance).toBe(3944);
      expect(result.duration).toBe(240);
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining("maps.googleapis.com")
      );
    });

    it("should handle API errors gracefully", async () => {
      process.env.GOOGLE_MAPS_API_KEY = "test-api-key";

      (fetch as jest.Mock).mockRejectedValueOnce(new Error("API Error"));

      const origin = { latitude: 40.7128, longitude: -74.006 };
      const destination = { latitude: 34.0522, longitude: -118.2437 };

      const result = await distanceCalculator.calculateRouteDistance(
        origin,
        destination
      );

      expect(result.distance).toBeCloseTo(3936, 1);
      expect(result.fuelEfficiencyFactor).toBe(1.0);
    });
  });

  describe("geocodeAddress", () => {
    it("should return null when no API key", async () => {
      const result = await distanceCalculator.geocodeAddress("New York, NY");

      expect(result).toBeNull();
    });

    it("should geocode address when API key available", async () => {
      process.env.GOOGLE_MAPS_API_KEY = "test-api-key";

      const mockResponse = {
        status: "OK",
        results: [
          {
            geometry: {
              location: {
                lat: 40.7128,
                lng: -74.006,
              },
            },
            formatted_address: "New York, NY, USA",
            address_components: [
              { types: ["locality"], long_name: "New York" },
              { types: ["country"], long_name: "United States" },
            ],
          },
        ],
      };

      (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await distanceCalculator.geocodeAddress("New York, NY");

      expect(result).toEqual({
        latitude: 40.7128,
        longitude: -74.006,
        address: "New York, NY, USA",
        city: "New York",
        country: "United States",
      });
    });
  });

  describe("optimizeMultipleWaypoints", () => {
    it("should optimize route with waypoints", async () => {
      process.env.GOOGLE_MAPS_API_KEY = "test-api-key";

      const mockResponse = {
        status: "OK",
        routes: [
          {
            waypoint_order: [1, 0],
            legs: [
              { distance: { value: 100000 }, duration: { value: 3600 } },
              { distance: { value: 200000 }, duration: { value: 7200 } },
            ],
          },
        ],
      };

      (fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const origin = { latitude: 40.7128, longitude: -74.006 };
      const destination = { latitude: 34.0522, longitude: -118.2437 };
      const waypoints = [
        { latitude: 41.8781, longitude: -87.6298 },
        { latitude: 39.7392, longitude: -104.9903 },
      ];

      const result = await distanceCalculator.optimizeMultipleWaypoints(
        origin,
        destination,
        waypoints,
        { mode: "driving", optimize: true }
      );

      expect(result.distance).toBe(300);
      expect(result.duration).toBe(180);
      expect(result.optimizedOrder).toEqual([1, 0]);
    });

    it("should fallback when no waypoints", async () => {
      const origin = { latitude: 40.7128, longitude: -74.006 };
      const destination = { latitude: 34.0522, longitude: -118.2437 };

      const result = await distanceCalculator.optimizeMultipleWaypoints(
        origin,
        destination,
        []
      );

      expect(result.distance).toBeCloseTo(3936, 1);
    });
  });

  describe("calculateDistanceMatrix", () => {
    it("should calculate distance matrix without API", async () => {
      const origins = [
        { latitude: 40.7128, longitude: -74.006 },
        { latitude: 34.0522, longitude: -118.2437 },
      ];
      const destinations = [
        { latitude: 41.8781, longitude: -87.6298 },
        { latitude: 39.7392, longitude: -104.9903 },
      ];

      const result = await distanceCalculator.calculateDistanceMatrix(
        origins,
        destinations
      );

      expect(result.origins).toEqual(origins);
      expect(result.destinations).toEqual(destinations);
      expect(result.distances).toHaveLength(2);
      expect(result.distances[0]).toHaveLength(2);
      expect(result.durations).toHaveLength(2);
      expect(result.durations[0]).toHaveLength(2);

      result.distances.forEach((row) => {
        row.forEach((distance) => {
          expect(distance).toBeGreaterThan(0);
        });
      });
    });
  });
});
