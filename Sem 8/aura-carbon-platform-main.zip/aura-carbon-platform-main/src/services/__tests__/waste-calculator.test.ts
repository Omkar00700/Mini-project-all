import { wasteCalculator } from "../waste-calculator";

describe("WasteCalculator", () => {
  describe("calculateWasteEmissions", () => {
    it("should calculate landfill waste emissions", async () => {
      const wasteStreams = [
        {
          type: "general" as const,
          weight: 30,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "organic" as const,
          weight: 20,
          treatment: "landfill" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.calculateWasteEmissions(wasteStreams);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.totalWaste).toBe(50);
      expect(result.treatmentBreakdown.landfill).toBeGreaterThan(0);
      expect(result.wasteTypeBreakdown.general).toBeGreaterThan(0);
      expect(result.wasteTypeBreakdown.organic).toBeGreaterThan(0);
      expect(result.diversionRate).toBe(0);
      expect(result.recyclingRate).toBe(0);
      expect(result.details).toHaveLength(2);
    });

    it("should calculate recycling waste emissions with avoided emissions", async () => {
      const wasteStreams = [
        {
          type: "paper" as const,
          weight: 15,
          treatment: "recycling" as const,
          region: "US",
        },
        {
          type: "plastic" as const,
          weight: 10,
          treatment: "recycling" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.calculateWasteEmissions(wasteStreams);

      expect(result.totalEmissions).toBeLessThan(0);
      expect(result.totalWaste).toBe(25);
      expect(result.treatmentBreakdown.recycling).toBeLessThan(0);
      expect(result.diversionRate).toBe(100);
      expect(result.recyclingRate).toBe(100);
      expect(result.details).toHaveLength(2);

      result.details.forEach((detail) => {
        expect(detail.avoidedEmissions).toBeLessThan(0);
        expect(detail.netEmissions).toBeLessThan(0);
      });
    });

    it("should calculate composting emissions", async () => {
      const wasteStreams = [
        {
          type: "organic" as const,
          weight: 25,
          treatment: "composting" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.calculateWasteEmissions(wasteStreams);

      expect(result.totalEmissions).toBeLessThan(5);
      expect(result.totalWaste).toBe(25);
      expect(result.treatmentBreakdown.composting).toBeDefined();
      expect(result.diversionRate).toBe(100);
      expect(result.details).toHaveLength(1);
    });

    it("should calculate mixed waste stream emissions", async () => {
      const wasteStreams = [
        {
          type: "general" as const,
          weight: 20,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "paper" as const,
          weight: 15,
          treatment: "recycling" as const,
          region: "US",
        },
        {
          type: "organic" as const,
          weight: 10,
          treatment: "composting" as const,
          region: "US",
        },
        {
          type: "plastic" as const,
          weight: 5,
          treatment: "incineration" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.calculateWasteEmissions(wasteStreams);

      expect(result.totalWaste).toBe(50);
      expect(result.treatmentBreakdown.landfill).toBeGreaterThan(0);
      expect(result.treatmentBreakdown.recycling).toBeLessThan(0);
      expect(result.treatmentBreakdown.composting).toBeDefined();
      expect(result.treatmentBreakdown.incineration).toBeGreaterThan(0);
      expect(result.diversionRate).toBe(60);
      expect(result.recyclingRate).toBe(30);
      expect(result.details).toHaveLength(4);
      expect(result.recommendations.length).toBeGreaterThan(0);
    });

    it("should provide waste management recommendations", async () => {
      const wasteStreams = [
        {
          type: "general" as const,
          weight: 40,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "organic" as const,
          weight: 15,
          treatment: "landfill" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.calculateWasteEmissions(wasteStreams);

      expect(result.recommendations.some((r) => r.includes("divert"))).toBe(
        true
      );
      expect(result.recommendations.some((r) => r.includes("organic"))).toBe(
        true
      );
      expect(result.recommendations.some((r) => r.includes("compost"))).toBe(
        true
      );
    });
  });

  describe("calculateWasteReductionScenario", () => {
    it("should calculate emission reductions from waste reduction actions", async () => {
      const currentWaste = [
        {
          type: "general" as const,
          weight: 30,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "organic" as const,
          weight: 20,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "paper" as const,
          weight: 10,
          treatment: "landfill" as const,
          region: "US",
        },
      ];

      const reductionActions = {
        wasteReduction: 20,
        increasedRecycling: 50,
        organicDiversion: 80,
        reuseRate: 10,
      };

      const result = await wasteCalculator.calculateWasteReductionScenario(
        currentWaste,
        reductionActions
      );

      expect(result.currentEmissions).toBeGreaterThan(0);
      expect(result.scenarioEmissions).toBeLessThan(result.currentEmissions);
      expect(result.emissionReduction).toBeGreaterThan(0);
      expect(result.reductionPercentage).toBeGreaterThan(0);
      expect(result.actionBreakdown).toBeDefined();
      expect(result.recommendations.length).toBeGreaterThan(0);
    });
  });

  describe("analyzeWasteComposition", () => {
    it("should analyze waste composition and provide improvement suggestions", async () => {
      const wasteStreams = [
        {
          type: "general" as const,
          weight: 25,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "organic" as const,
          weight: 15,
          treatment: "landfill" as const,
          region: "US",
        },
        {
          type: "paper" as const,
          weight: 10,
          treatment: "recycling" as const,
          region: "US",
        },
        {
          type: "plastic" as const,
          weight: 5,
          treatment: "landfill" as const,
          region: "US",
        },
      ];

      const result =
        await wasteCalculator.analyzeWasteComposition(wasteStreams);

      expect(result.composition.general.weight).toBe(25);
      expect(result.composition.general.percentage).toBeCloseTo(45.45, 1);
      expect(result.treatmentDistribution.landfill.weight).toBe(45);
      expect(result.treatmentDistribution.recycling.weight).toBe(10);

      expect(result.improvementPotential.length).toBeGreaterThan(0);
      expect(
        result.improvementPotential.some((p) => p.action.includes("organic"))
      ).toBe(true);
      expect(
        result.improvementPotential.some((p) => p.action.includes("recycling"))
      ).toBe(true);

      expect(result.benchmarks.diversionRate.current).toBeCloseTo(18.18, 1);
      expect(result.benchmarks.recyclingRate.current).toBeCloseTo(18.18, 1);
      expect(result.benchmarks.diversionRate.target).toBe(75);
      expect(result.benchmarks.recyclingRate.target).toBe(50);
    });
  });

  describe("getTreatmentFactor", () => {
    it("should return treatment factor for known combinations", () => {
      const landfillGeneral = wasteCalculator.getTreatmentFactor(
        "landfill",
        "general"
      );
      expect(landfillGeneral).toBeDefined();
      expect(landfillGeneral?.emissionFactor).toBeGreaterThan(0);
      expect(landfillGeneral?.treatment).toBe("landfill");
      expect(landfillGeneral?.wasteType).toBe("general");

      const recyclingPaper = wasteCalculator.getTreatmentFactor(
        "recycling",
        "paper"
      );
      expect(recyclingPaper).toBeDefined();
      expect(recyclingPaper?.avoidedEmissions).toBeLessThan(0);
    });

    it("should return undefined for unknown combinations", () => {
      const unknown = wasteCalculator.getTreatmentFactor("unknown", "unknown");
      expect(unknown).toBeUndefined();
    });
  });

  describe("getTreatmentFactors", () => {
    it("should return the complete treatment factors database", () => {
      const factors = wasteCalculator.getTreatmentFactors();
      expect(factors.size).toBeGreaterThan(0);
      expect(factors.has("landfill_general")).toBe(true);
      expect(factors.has("recycling_paper")).toBe(true);
      expect(factors.has("composting_organic")).toBe(true);
    });
  });
});
