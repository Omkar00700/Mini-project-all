import { foodCalculator } from "../food-calculator";
import type { FoodData } from "@/types/carbon";

describe("FoodCalculator", () => {
  describe("calculateFoodEmissions", () => {
    it("should calculate meat emissions correctly", async () => {
      const foodData: FoodData = {
        meat: {
          beef: 2.0,
          chicken: 1.5,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.meat).toBeGreaterThan(0);
      expect(result.breakdown.meat).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(2);
      expect(result.recommendations.length).toBeGreaterThan(0);
    });

    it("should calculate dairy emissions correctly", async () => {
      const foodData: FoodData = {
        dairy: {
          milk: 10.0,
          cheese: 0.5,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.dairy).toBeGreaterThan(0);
      expect(result.breakdown.dairy).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(2);
    });

    it("should calculate plant-based emissions correctly", async () => {
      const foodData: FoodData = {
        plant_based: {
          vegetables: 5.0,
          fruits: 3.0,
          grains: 2.0,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.plant_based).toBeGreaterThan(0);
      expect(result.breakdown.plant_based).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(3);
    });

    it("should calculate beverage emissions correctly", async () => {
      const foodData: FoodData = {
        beverages: {
          coffee: 0.5,
          tea: 0.2,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.beverages).toBeGreaterThan(0);
      expect(result.breakdown.beverages).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(2);
    });

    it("should calculate dining out emissions correctly", async () => {
      const foodData: FoodData = {
        dining_out: {
          restaurant_meals: 8,
          fast_food_meals: 4,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.dining_out).toBeGreaterThan(0);
      expect(result.breakdown.dining_out).toBe(result.totalEmissions);
      expect(result.details).toHaveLength(2);
    });

    it("should calculate comprehensive food emissions", async () => {
      const foodData: FoodData = {
        meat: {
          beef: 1.0,
          chicken: 2.0,
        },
        dairy: {
          milk: 5.0,
          cheese: 0.3,
        },
        plant_based: {
          vegetables: 8.0,
          fruits: 4.0,
        },
        beverages: {
          coffee: 0.3,
        },
        dining_out: {
          restaurant_meals: 4,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.meat).toBeGreaterThan(0);
      expect(result.breakdown.dairy).toBeGreaterThan(0);
      expect(result.breakdown.plant_based).toBeGreaterThan(0);
      expect(result.breakdown.beverages).toBeGreaterThan(0);
      expect(result.breakdown.dining_out).toBeGreaterThan(0);

      const totalBreakdown = Object.values(result.breakdown).reduce(
        (sum: number, val: any) => sum + val,
        0
      );
      expect(Math.abs(totalBreakdown - result.totalEmissions)).toBeLessThan(
        0.01
      );

      expect(result.details.length).toBeGreaterThan(0);
      expect(result.recommendations.length).toBeGreaterThan(0);
      expect(result.methodology).toContain("FAO");
    });

    it("should provide meatary recommendations based on consumption patterns", async () => {
      const highMeatData: FoodData = {
        meat: {
          beef: 5.0,
        },
        plant_based: {
          vegetables: 1.0,
        },
      };

      const result = await foodCalculator.calculateFoodEmissions(highMeatData);

      expect(result.recommendations.some((r) => r.includes("beef"))).toBe(true);
      expect(result.recommendations.some((r) => r.includes("plant"))).toBe(
        true
      );
    });

    it("should handle empty food data", async () => {
      const foodData: FoodData = {};

      const result = await foodCalculator.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBe(0);
      expect(result.breakdown.meat).toBe(0);
      expect(result.breakdown.dairy).toBe(0);
      expect(result.breakdown.plant_based).toBe(0);
      expect(result.breakdown.beverages).toBe(0);
      expect(result.breakdown.dining_out).toBe(0);
      expect(result.details).toHaveLength(0);
    });
  });

  describe("getEmissionFactor", () => {
    it("should return emission factor for known food items", () => {
      const beefFactor = foodCalculator.getEmissionFactor("beef");
      expect(beefFactor).toBeDefined();
      expect(beefFactor?.emissionFactor).toBeGreaterThan(0);
      expect(beefFactor?.category).toBe("food");
      expect(beefFactor?.subcategory).toBe("beef");
    });

    it("should return undefined for unknown food items", () => {
      const unknownFactor = foodCalculator.getEmissionFactor("unknown_food");
      expect(unknownFactor).toBeUndefined();
    });
  });

  describe("getFoodDatabase", () => {
    it("should return the complete food database", () => {
      const database = foodCalculator.getFoodDatabase();
      expect(database.size).toBeGreaterThan(0);
      expect(database.has("beef")).toBe(true);
      expect(database.has("chicken")).toBe(true);
      expect(database.has("milk")).toBe(true);
      expect(database.has("vegetables")).toBe(true);
    });
  });
});
