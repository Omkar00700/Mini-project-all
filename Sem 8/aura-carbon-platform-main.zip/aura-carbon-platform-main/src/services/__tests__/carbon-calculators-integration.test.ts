import { carbonCalculatorsService } from "../carbon-calculators";
import type { FoodData, ConsumptionData } from "@/types/carbon";

jest.mock("@/lib/db", () => ({
  db: {
    carbonCalculation: {
      create: jest.fn().mockResolvedValue({
        id: "test-id",
        userId: "test-user",
        totalEmissions: 100,
        breakdown: {},
        confidenceScore: 0.8,
        metadata: {},
        createdAt: new Date(),
      }),
    },
  },
}));

describe("CarbonCalculators Integration", () => {
  describe("calculateFoodEmissions", () => {
    it("should integrate with food calculator correctly", async () => {
      const foodData: FoodData = {
        meat: {
          beef: 1.0,
          chicken: 2.0,
        },
        dairy: {
          milk: 5.0,
        },
        plant_based: {
          vegetables: 3.0,
        },
      };

      const result =
        await carbonCalculatorsService.calculateFoodEmissions(foodData);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.meat).toBeGreaterThan(0);
      expect(result.breakdown.dairy).toBeGreaterThan(0);
      expect(result.breakdown.plant_based).toBeGreaterThan(0);
      expect(result.details.length).toBeGreaterThan(0);
      expect(result.recommendations.length).toBeGreaterThan(0);
      expect(result.methodology).toContain("FAO");
    });
  });

  describe("calculateConsumptionEmissions", () => {
    it("should integrate with consumption calculator correctly", async () => {
      const consumptionData: ConsumptionData = {
        shopping: {
          clothing: 5,
          electronics: 2,
        },
        services: {
          banking: 50,
          telecommunications: 100,
        },
        waste: {
          general_waste: 30,
          recycling: 15,
        },
      };

      const result =
        await carbonCalculatorsService.calculateConsumptionEmissions(
          consumptionData
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.shopping).toBeGreaterThan(0);
      expect(result.breakdown.services).toBeGreaterThan(0);
      expect(result.breakdown.waste).toBeDefined();
      expect(result.details.length).toBeGreaterThan(0);
      expect(result.recommendations.length).toBeGreaterThan(0);
      expect(result.methodology).toContain("Lifecycle assessment");
    });
  });

  describe("calculateCarbonFootprint", () => {
    it("should calculate comprehensive carbon footprint including food and consumption", async () => {
      const data = {
        userId: "test-user",
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-01-31"),
        food: {
          meat: {
            beef: 1.0,
            chicken: 1.5,
          },
          dairy: {
            milk: 8.0,
          },
        } as FoodData,
        consumption: {
          shopping: {
            clothing: 3,
            other_goods: 200,
          },
          waste: {
            general_waste: 25,
            recycling: 10,
          },
        } as ConsumptionData,
      };

      const result =
        await carbonCalculatorsService.calculateCarbonFootprint(data);

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(result.breakdown.food).toBeGreaterThan(0);
      expect(result.breakdown.consumption).toBeDefined();
      expect(result.confidence_score).toBeGreaterThan(0);
      expect(result.confidence_score).toBeLessThanOrEqual(1);
      expect(result.detailed_breakdown!.food).toBeDefined();
      expect(result.detailed_breakdown!.consumption).toBeDefined();
      expect(result.calculation_metadata.data_sources).toContain(
        "FAO 2019 food emission factors"
      );
      expect(result.calculation_metadata.data_sources).toContain(
        "EPA EEIO and lifecycle assessment data"
      );
    });

    it("should handle partial data correctly", async () => {
      const data = {
        userId: "test-user",
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-01-31"),
        food: {
          meat: {
            chicken: 2.0,
          },
        } as FoodData,
      };

      const result =
        await carbonCalculatorsService.calculateCarbonFootprint(data);

      expect(result.total_emissions).toBeGreaterThan(0);
      expect(result.breakdown.food).toBeGreaterThan(0);
      expect(result.breakdown.consumption || 0).toBe(0);
      expect(result.confidence_score).toBeGreaterThan(0);
    });

    it("should calculate confidence score based on data completeness", async () => {
      const completeData = {
        userId: "test-user",
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-01-31"),
        food: {
          meat: { beef: 1.0, chicken: 1.0 },
          dairy: { milk: 5.0 },
          plant_based: { vegetables: 3.0 },
          beverages: { coffee: 0.3 },
        } as FoodData,
        consumption: {
          shopping: { clothing: 3, electronics: 1 },
          services: { banking: 50 },
          waste: { general_waste: 20, recycling: 10 },
        } as ConsumptionData,
      };

      const completeResult =
        await carbonCalculatorsService.calculateCarbonFootprint(completeData);

      const partialData = {
        userId: "test-user",
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-01-31"),
        food: {
          meat: { chicken: 1.0 },
        } as FoodData,
      };

      const partialResult =
        await carbonCalculatorsService.calculateCarbonFootprint(partialData);

      expect(completeResult.confidence_score).toBeGreaterThan(
        partialResult.confidence_score
      );
    });
  });
});
