import {
  calculateMovingAverage,
  forecastWithMovingAverage,
  calculateExponentialMovingAverage,
  forecastWithHoltWinters,
  calculateLinearTrend,
  forecastWithLinearRegression,
  detectSeasonality,
  calculateStandardError,
  calculateConfidenceInterval,
  calculateConfidenceDecay,
} from "../analytics/forecasting.service";

describe("Forecasting Service", () => {
  describe("calculateMovingAverage", () => {
    it("should calculate SMA correctly", () => {
      const result = calculateMovingAverage([10, 20, 30, 40, 50], 3);
      expect(result).toEqual([20, 30, 40]);
    });

    it("should return empty for empty input", () => {
      expect(calculateMovingAverage([], 3)).toEqual([]);
    });

    it("should return single average when window > data length", () => {
      const result = calculateMovingAverage([10, 20, 30], 5);
      expect(result).toEqual([20]);
    });

    it("should handle window size of 1", () => {
      const result = calculateMovingAverage([10, 20, 30], 1);
      expect(result).toEqual([10, 20, 30]);
    });

    it("should return empty for zero window", () => {
      expect(calculateMovingAverage([10, 20], 0)).toEqual([]);
    });
  });

  describe("forecastWithMovingAverage", () => {
    it("should forecast constant for flat data", () => {
      const result = forecastWithMovingAverage([100, 100, 100], 3, 3);
      expect(result).toEqual([100, 100, 100]);
    });

    it("should return empty for empty input", () => {
      expect(forecastWithMovingAverage([], 3, 3)).toEqual([]);
    });

    it("should return empty for zero steps", () => {
      expect(forecastWithMovingAverage([10, 20], 2, 0)).toEqual([]);
    });

    it("should forecast from small dataset", () => {
      const result = forecastWithMovingAverage([10, 20], 2, 2);
      expect(result.length).toBe(2);
      expect(result[0]).toBe(15);
    });
  });

  describe("calculateExponentialMovingAverage", () => {
    it("should return first value as first EMA", () => {
      const result = calculateExponentialMovingAverage([100, 110, 120], 0.5);
      expect(result[0]).toBe(100);
    });

    it("should apply exponential weighting", () => {
      const result = calculateExponentialMovingAverage([100, 200, 300], 0.5);

      expect(result).toEqual([100, 150, 225]);
    });

    it("should return empty for empty input", () => {
      expect(calculateExponentialMovingAverage([])).toEqual([]);
    });

    it("should handle single value", () => {
      expect(calculateExponentialMovingAverage([42])).toEqual([42]);
    });

    it("should return same length as input", () => {
      const input = [10, 20, 30, 40, 50];
      const result = calculateExponentialMovingAverage(input, 0.3);
      expect(result.length).toBe(input.length);
    });
  });

  describe("forecastWithHoltWinters", () => {
    it("should forecast future values", () => {
      const result = forecastWithHoltWinters([100, 110, 120], 0.3, 0.1, 3);
      expect(result.length).toBe(3);
      result.forEach((v: number) => expect(v).toBeGreaterThan(0));
    });

    it("should return empty for empty input", () => {
      expect(forecastWithHoltWinters([], 0.3, 0.1, 3)).toEqual([]);
    });
  });

  describe("calculateLinearTrend", () => {
    it("should detect positive slope for increasing data", () => {
      const data = [
        { x: 0, y: 100 },
        { x: 1, y: 200 },
        { x: 2, y: 300 },
        { x: 3, y: 400 },
        { x: 4, y: 500 },
      ];
      const result = calculateLinearTrend(data);
      expect(result.slope).toBeCloseTo(100, 0);
      expect(result.intercept).toBeCloseTo(100, 0);
      expect(result.rSquared).toBeCloseTo(1, 1);
      expect(result.direction).toBe("increasing");
    });

    it("should detect negative slope for decreasing data", () => {
      const data = [
        { x: 0, y: 500 },
        { x: 1, y: 400 },
        { x: 2, y: 300 },
        { x: 3, y: 200 },
        { x: 4, y: 100 },
      ];
      const result = calculateLinearTrend(data);
      expect(result.slope).toBeCloseTo(-100, 0);
      expect(result.direction).toBe("decreasing");
    });

    it("should detect stable trend for flat data", () => {
      const data = [
        { x: 0, y: 100 },
        { x: 1, y: 100 },
        { x: 2, y: 100 },
        { x: 3, y: 100 },
      ];
      const result = calculateLinearTrend(data);
      expect(result.slope).toBeCloseTo(0, 0);
      expect(result.direction).toBe("stable");
    });

    it("should return defaults for empty data", () => {
      const result = calculateLinearTrend([]);
      expect(result.slope).toBe(0);
      expect(result.rSquared).toBe(0);
      expect(result.direction).toBe("stable");
    });

    it("should handle single data point", () => {
      const result = calculateLinearTrend([{ x: 0, y: 42 }]);
      expect(result.intercept).toBe(42);
      expect(result.rSquared).toBe(1);
    });

    it("should have R² near 0 for random-looking data", () => {
      const data = [
        { x: 0, y: 500 },
        { x: 1, y: 100 },
        { x: 2, y: 400 },
        { x: 3, y: 50 },
        { x: 4, y: 300 },
      ];
      const result = calculateLinearTrend(data);
      expect(result.rSquared).toBeLessThan(0.5);
    });
  });

  describe("forecastWithLinearRegression", () => {
    it("should extrapolate linear trend", () => {
      const data = [
        { x: 0, y: 100 },
        { x: 1, y: 200 },
        { x: 2, y: 300 },
      ];
      const result = forecastWithLinearRegression(data, 3);
      expect(result[0]).toBeCloseTo(400, -1);
      expect(result[1]).toBeCloseTo(500, -1);
      expect(result[2]).toBeCloseTo(600, -1);
    });

    it("should never predict negative values", () => {
      const data = [
        { x: 0, y: 10 },
        { x: 1, y: 5 },
        { x: 2, y: 1 },
      ];
      const result = forecastWithLinearRegression(data, 5);
      result.forEach((v) => expect(v).toBeGreaterThanOrEqual(0));
    });

    it("should return empty for empty data", () => {
      expect(forecastWithLinearRegression([], 3)).toEqual([]);
    });
  });

  describe("detectSeasonality", () => {
    it("should return all 1.0 factors for insufficient data", () => {
      const result = detectSeasonality([10, 20, 30], 12);
      expect(result.length).toBe(12);
      result.forEach((f) => expect(f).toBe(1.0));
    });

    it("should detect seasonal pattern", () => {
      const values = [80, 70, 60, 50, 40, 30, 30, 40, 50, 60, 70, 80];
      const result = detectSeasonality(values, 12);
      expect(result.length).toBe(12);

      expect(result[0]).toBeGreaterThan(1);

      expect(result[5]).toBeLessThan(1);
    });

    it("should return 1.0 factors for constant data", () => {
      const values = new Array(12).fill(100);
      const result = detectSeasonality(values, 12);
      result.forEach((f) => expect(f).toBeCloseTo(1.0, 2));
    });
  });

  describe("calculateStandardError", () => {
    it("should return 0 for perfect predictions", () => {
      const actual = [10, 20, 30];
      const predicted = [10, 20, 30];
      expect(calculateStandardError(actual, predicted)).toBe(0);
    });

    it("should return positive value for imperfect predictions", () => {
      const actual = [10, 20, 30];
      const predicted = [12, 18, 33];
      expect(calculateStandardError(actual, predicted)).toBeGreaterThan(0);
    });

    it("should return 0 for empty arrays", () => {
      expect(calculateStandardError([], [])).toBe(0);
    });

    it("should handle mismatched lengths", () => {
      const actual = [10, 20, 30, 40];
      const predicted = [10, 20];
      const result = calculateStandardError(actual, predicted);
      expect(result).toBeGreaterThanOrEqual(0);
    });
  });

  describe("calculateConfidenceInterval", () => {
    it("should return wider interval for higher standard error", () => {
      const narrow = calculateConfidenceInterval(100, 5, 0.95, 1);
      const wide = calculateConfidenceInterval(100, 20, 0.95, 1);
      expect(wide.upper - wide.lower).toBeGreaterThan(
        narrow.upper - narrow.lower
      );
    });

    it("should return wider interval for further predictions", () => {
      const near = calculateConfidenceInterval(100, 10, 0.95, 1);
      const far = calculateConfidenceInterval(100, 10, 0.95, 6);
      expect(far.upper - far.lower).toBeGreaterThan(near.upper - near.lower);
    });

    it("should return wider interval for higher confidence level", () => {
      const low = calculateConfidenceInterval(100, 10, 0.8, 1);
      const high = calculateConfidenceInterval(100, 10, 0.95, 1);
      expect(high.upper - high.lower).toBeGreaterThan(low.upper - low.lower);
    });

    it("should never return negative lower bound", () => {
      const result = calculateConfidenceInterval(5, 100, 0.95, 1);
      expect(result.lower).toBeGreaterThanOrEqual(0);
    });

    it("should be symmetric around predicted value (when no floor)", () => {
      const result = calculateConfidenceInterval(1000, 10, 0.95, 1);
      const distUpper = result.upper - 1000;
      const distLower = 1000 - result.lower;
      expect(distUpper).toBeCloseTo(distLower, 0);
    });
  });

  describe("calculateConfidenceDecay", () => {
    it("should return base confidence at step 0", () => {
      const result = calculateConfidenceDecay(0.9, 0);
      expect(result).toBeCloseTo(0.9, 1);
    });

    it("should decrease with more steps ahead", () => {
      const step1 = calculateConfidenceDecay(0.9, 1);
      const step5 = calculateConfidenceDecay(0.9, 5);
      const step10 = calculateConfidenceDecay(0.9, 10);
      expect(step5).toBeLessThan(step1);
      expect(step10).toBeLessThan(step5);
    });

    it("should never go below 0.1", () => {
      const result = calculateConfidenceDecay(0.9, 100);
      expect(result).toBeGreaterThanOrEqual(0.1);
    });

    it("should never exceed 1", () => {
      const result = calculateConfidenceDecay(1.5, 0);
      expect(result).toBeLessThanOrEqual(1);
    });
  });
});
