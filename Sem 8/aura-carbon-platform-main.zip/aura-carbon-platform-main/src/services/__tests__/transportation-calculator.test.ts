import { transportationCalculator } from "../transportation-calculator";
import { distanceCalculator } from "../distance-calculator";

jest.mock("../emission-factors", () => ({
  emissionFactorsService: {
    getEmissionFactor: jest.fn().mockResolvedValue({
      co2_per_unit: 2.31,
    }),
  },
}));

jest.mock("../distance-calculator", () => ({
  distanceCalculator: {
    calculateRouteDistance: jest.fn().mockResolvedValue({
      distance: 100,
      duration: 120,
      fuelEfficiencyFactor: 1.0,
    }),
    calculateHaversineDistance: jest.fn().mockReturnValue(100),
    geocodeAddress: jest.fn().mockResolvedValue({
      latitude: 40.7128,
      longitude: -74.006,
      address: "New York, NY, USA",
    }),
  },
}));

describe("TransportationCalculator", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("calculatePersonalVehicleEmissions", () => {
    it("should calculate emissions for a basic trip", async () => {
      const vehicle = {
        make: "Toyota",
        model: "Camry",
        year: 2023,
        fuelType: "gasoline" as const,
        fuelEfficiency: 12,
        vehicleType: "midsize" as const,
      };

      const trip = {
        distance: 100,
        passengers: 1,
        trafficCondition: "moderate" as const,
        drivingStyle: "normal" as const,
      };

      const result =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          trip
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.baseEmissions).toBeGreaterThan(0);
      expect(result.methodology).toContain("IPCC Guidelines");
    });

    it("should calculate emissions with route optimization", async () => {
      const vehicle = {
        make: "Toyota",
        model: "Camry",
        year: 2023,
        fuelType: "gasoline" as const,
        fuelEfficiency: 12,
        vehicleType: "midsize" as const,
      };

      const trip = {
        origin: { latitude: 40.7128, longitude: -74.006 },
        destination: { latitude: 34.0522, longitude: -118.2437 },
        passengers: 1,
        trafficCondition: "moderate" as const,
        drivingStyle: "normal" as const,
      };

      const result =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          trip
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.routeInfo).toBeDefined();
      expect(distanceCalculator.calculateRouteDistance).toHaveBeenCalled();
    });

    it("should apply traffic and driving style adjustments", async () => {
      const vehicle = {
        make: "Toyota",
        model: "Camry",
        year: 2023,
        fuelType: "gasoline" as const,
        fuelEfficiency: 12,
        vehicleType: "midsize" as const,
      };

      const heavyTrafficTrip = {
        distance: 100,
        passengers: 1,
        trafficCondition: "heavy" as const,
        drivingStyle: "aggressive" as const,
      };

      const lightTrafficTrip = {
        distance: 100,
        passengers: 1,
        trafficCondition: "light" as const,
        drivingStyle: "eco" as const,
      };

      const heavyResult =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          heavyTrafficTrip
        );
      const lightResult =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          lightTrafficTrip
        );

      expect(heavyResult.totalEmissions).toBeGreaterThan(
        lightResult.totalEmissions
      );
    });

    it("should handle passenger sharing", async () => {
      const vehicle = {
        make: "Toyota",
        model: "Camry",
        year: 2023,
        fuelType: "gasoline" as const,
        fuelEfficiency: 12,
        vehicleType: "midsize" as const,
      };

      const singlePassengerTrip = {
        distance: 100,
        passengers: 1,
      };

      const multiPassengerTrip = {
        distance: 100,
        passengers: 4,
      };

      const singleResult =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          singlePassengerTrip
        );
      const multiResult =
        await transportationCalculator.calculatePersonalVehicleEmissions(
          vehicle,
          multiPassengerTrip
        );

      expect(multiResult.totalEmissions).toBeLessThan(
        singleResult.totalEmissions
      );
    });
  });

  describe("calculateFlightEmissions", () => {
    it("should calculate emissions for a flight with distance", async () => {
      const flight = {
        origin: "JFK",
        destination: "LAX",
        distance: 3944,
        class: "economy" as const,
        roundTrip: false,
      };

      const result =
        await transportationCalculator.calculateFlightEmissions(flight);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.radiativeForcing).toBeGreaterThan(0);
      expect(result.methodology).toContain("DEFRA");
    });

    it("should calculate distance for flights without distance", async () => {
      const flight = {
        origin: "JFK",
        destination: "LAX",
        class: "economy" as const,
        roundTrip: false,
      };

      const result =
        await transportationCalculator.calculateFlightEmissions(flight);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.flightDistance).toBeDefined();
    });

    it("should apply round trip multiplier", async () => {
      const oneWayFlight = {
        origin: "JFK",
        destination: "LAX",
        distance: 3944,
        class: "economy" as const,
        roundTrip: false,
      };

      const roundTripFlight = {
        ...oneWayFlight,
        roundTrip: true,
      };

      const oneWayResult =
        await transportationCalculator.calculateFlightEmissions(oneWayFlight);
      const roundTripResult =
        await transportationCalculator.calculateFlightEmissions(
          roundTripFlight
        );

      expect(roundTripResult.totalEmissions).toBeCloseTo(
        oneWayResult.totalEmissions * 2,
        1
      );
    });
  });

  describe("calculatePublicTransportEmissions", () => {
    it("should calculate emissions for public transport", async () => {
      const transport = {
        mode: "bus" as const,
        distance: 50,
        region: "US",
      };

      const result =
        await transportationCalculator.calculatePublicTransportEmissions(
          transport
        );

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.methodology).toContain("Regional emission factors");
    });
  });

  describe("calculateTransportationFootprint", () => {
    it("should calculate comprehensive transportation footprint", async () => {
      const data = {
        personalVehicle: {
          vehicle: {
            make: "Toyota",
            model: "Camry",
            year: 2023,
            fuelType: "gasoline" as const,
            fuelEfficiency: 12,
            vehicleType: "midsize" as const,
          },
          trips: [
            {
              distance: 100,
              passengers: 1,
            },
          ],
        },
        flights: [
          {
            origin: "JFK",
            destination: "LAX",
            distance: 3944,
            class: "economy" as const,
            roundTrip: false,
          },
        ],
        publicTransport: [
          {
            mode: "bus" as const,
            distance: 50,
            region: "US",
          },
        ],
      };

      const result =
        await transportationCalculator.calculateTransportationFootprint(data);

      expect(result.totalEmissions).toBeGreaterThan(0);
      expect(result.breakdown.personalVehicle).toBeGreaterThan(0);
      expect(result.breakdown.flights).toBeGreaterThan(0);
      expect(result.breakdown.publicTransport).toBeGreaterThan(0);
      expect(result.details).toHaveLength(3);
    });
  });

  describe("getVehicleRecommendations", () => {
    it("should provide vehicle recommendations", async () => {
      const currentVehicle = {
        make: "Ford",
        model: "F-150",
        year: 2020,
        fuelType: "gasoline" as const,
        fuelEfficiency: 8,
        vehicleType: "truck" as const,
      };

      const result = await transportationCalculator.getVehicleRecommendations(
        currentVehicle,
        15000
      );

      expect(result.recommendations).toHaveLength(2);
      expect(result.recommendations[0].potentialSavings).toBeGreaterThan(0);
    });
  });
});
