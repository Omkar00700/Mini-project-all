import {
  calculateMean,
  calculateStdDev,
  calculateQuartiles,
  detectAnomalyZScore,
  detectAnomalyIQR,
  calculateRollingStats,
} from "../analytics/anomaly-detection.service";

describe("Anomaly Detection Service", () => {
  const sampleData = [10, 12, 15, 14, 13, 16, 15, 14, 13, 12];
  const sampleDataWithOutlier = [10, 12, 15, 14, 13, 50, 15, 14, 13, 12];

  describe("calculateMean", () => {
    it("should calculate mean correctly", () => {
      const result = calculateMean(sampleData);
      expect(result).toBeCloseTo(13.4, 1);
    });

    it("should return 0 for empty array", () => {
      const result = calculateMean([]);
      expect(result).toBe(0);
    });

    it("should handle single value", () => {
      const result = calculateMean([5]);
      expect(result).toBe(5);
    });

    it("should handle negative values", () => {
      const result = calculateMean([-5, -10, -15]);
      expect(result).toBe(-10);
    });
  });

  describe("calculateStdDev", () => {
    it("should calculate standard deviation correctly", () => {
      const result = calculateStdDev(sampleData);
      expect(result).toBeGreaterThan(0);
      expect(result).toBeCloseTo(1.71, 1);
    });

    it("should return 0 for empty array", () => {
      const result = calculateStdDev([]);
      expect(result).toBe(0);
    });

    it("should return 0 for identical values", () => {
      const result = calculateStdDev([5, 5, 5, 5]);
      expect(result).toBe(0);
    });

    it("should handle single value", () => {
      const result = calculateStdDev([5]);
      expect(result).toBe(0);
    });

    it("should use provided mean if given", () => {
      const mean = calculateMean(sampleData);
      const result = calculateStdDev(sampleData, mean);
      expect(result).toBeGreaterThan(0);
    });
  });

  describe("calculateQuartiles", () => {
    it("should calculate quartiles correctly", () => {
      const result = calculateQuartiles(sampleData);

      expect(result.q1).toBeLessThan(result.q2);
      expect(result.q2).toBeLessThan(result.q3);
      expect(result.iqr).toBeGreaterThan(0);
      expect(result.iqr).toBe(result.q3 - result.q1);
    });

    it("should return zeros for empty array", () => {
      const result = calculateQuartiles([]);

      expect(result.q1).toBe(0);
      expect(result.q2).toBe(0);
      expect(result.q3).toBe(0);
      expect(result.iqr).toBe(0);
    });

    it("should handle single value", () => {
      const result = calculateQuartiles([10]);

      expect(result.q1).toBe(10);
      expect(result.q2).toBe(10);
      expect(result.q3).toBe(10);
      expect(result.iqr).toBe(0);
    });

    it("should sort values before calculating", () => {
      const unsorted = [50, 10, 30, 20, 40];
      const sorted = [10, 20, 30, 40, 50];

      const resultUnsorted = calculateQuartiles(unsorted);
      const resultSorted = calculateQuartiles(sorted);

      expect(resultUnsorted).toEqual(resultSorted);
    });
  });

  describe("detectAnomalyZScore", () => {
    const mean = calculateMean(sampleData);
    const stdDev = calculateStdDev(sampleData);

    it("should NOT detect anomaly for normal values", () => {
      const result = detectAnomalyZScore(14, mean, stdDev);

      expect(result.isAnomaly).toBe(false);
      expect(result.deviation).toBeLessThan(2);
      expect(result.severity).toBe("low");
    });

    it("should detect anomaly for outliers", () => {
      const outlier = 50;
      const result = detectAnomalyZScore(outlier, mean, stdDev);

      expect(result.isAnomaly).toBe(true);
      expect(result.deviation).toBeGreaterThan(2);
    });

    it("should classify severity correctly", () => {
      const highDeviation = mean + 3.5 * stdDev;
      const resultHigh = detectAnomalyZScore(highDeviation, mean, stdDev);
      expect(resultHigh.severity).toBe("high");

      const mediumDeviation = mean + 2.7 * stdDev;
      const resultMedium = detectAnomalyZScore(mediumDeviation, mean, stdDev);
      expect(resultMedium.severity).toBe("medium");

      const lowDeviation = mean + 1.5 * stdDev;
      const resultLow = detectAnomalyZScore(lowDeviation, mean, stdDev);
      expect(resultLow.severity).toBe("low");
    });

    it("should handle zero standard deviation", () => {
      const result = detectAnomalyZScore(10, 10, 0);

      expect(result.isAnomaly).toBe(false);
      expect(result.deviation).toBe(0);
      expect(result.severity).toBe("low");
    });

    it("should use custom threshold", () => {
      const customThreshold = 1.5;
      const value = mean + 1.8 * stdDev;

      const result = detectAnomalyZScore(value, mean, stdDev, customThreshold);
      expect(result.isAnomaly).toBe(true);
    });

    it("should handle negative deviations", () => {
      const lowValue = mean - 2.5 * stdDev;
      const result = detectAnomalyZScore(lowValue, mean, stdDev);

      expect(result.isAnomaly).toBe(true);
      expect(result.deviation).toBeGreaterThan(2);
    });
  });

  describe("detectAnomalyIQR", () => {
    const { q1, q3, iqr } = calculateQuartiles(sampleData);

    it("should NOT detect anomaly for normal values", () => {
      const result = detectAnomalyIQR(14, q1, q3, iqr);

      expect(result.isAnomaly).toBe(false);
      expect(result.deviation).toBe(0);
      expect(result.severity).toBe("low");
    });

    it("should detect anomaly for values beyond 1.5*IQR from quartiles", () => {
      const outlier = 50;
      const result = detectAnomalyIQR(outlier, q1, q3, iqr);

      expect(result.isAnomaly).toBe(true);
      expect(result.deviation).toBeGreaterThan(0);
    });

    it("should classify severity correctly", () => {
      const upperBound = q3 + 1.5 * iqr;

      const highOutlier = upperBound + 3.5 * iqr;
      const resultHigh = detectAnomalyIQR(highOutlier, q1, q3, iqr);
      expect(resultHigh.severity).toBe("high");

      const mediumOutlier = upperBound + 2.5 * iqr;
      const resultMedium = detectAnomalyIQR(mediumOutlier, q1, q3, iqr);
      expect(resultMedium.severity).toBe("medium");

      const lowOutlier = upperBound + 1.5 * iqr;
      const resultLow = detectAnomalyIQR(lowOutlier, q1, q3, iqr);
      expect(resultLow.severity).toBe("low");
    });

    it("should handle zero IQR", () => {
      const result = detectAnomalyIQR(10, 10, 10, 0);

      expect(result.isAnomaly).toBe(false);
      expect(result.deviation).toBe(0);
      expect(result.severity).toBe("low");
    });

    it("should use custom multiplier", () => {
      const customMultiplier = 1.0;
      const upperBound = q3 + customMultiplier * iqr;
      const value = upperBound + 0.5 * iqr;

      const result = detectAnomalyIQR(value, q1, q3, iqr, customMultiplier);
      expect(result.isAnomaly).toBe(true);
    });

    it("should detect lower bound anomalies", () => {
      const lowerBound = q1 - 1.5 * iqr;
      const lowOutlier = lowerBound - iqr;

      const result = detectAnomalyIQR(lowOutlier, q1, q3, iqr);
      expect(result.isAnomaly).toBe(true);
    });
  });

  describe("calculateRollingStats", () => {
    const timeSeriesData = [
      { date: new Date("2024-01-01"), value: 10 },
      { date: new Date("2024-01-02"), value: 12 },
      { date: new Date("2024-01-03"), value: 15 },
      { date: new Date("2024-01-04"), value: 14 },
      { date: new Date("2024-01-05"), value: 13 },
    ];

    it("should calculate rolling statistics correctly", () => {
      const result = calculateRollingStats(timeSeriesData, 5);

      expect(result.mean).toBeGreaterThan(0);
      expect(result.stdDev).toBeGreaterThan(0);
      expect(result.q1).toBeGreaterThan(0);
      expect(result.q3).toBeGreaterThan(0);
      expect(result.iqr).toBeGreaterThan(0);
    });

    it("should handle window size larger than data", () => {
      const result = calculateRollingStats(timeSeriesData, 100);

      expect(result.mean).toBeGreaterThan(0);
      expect(result.stdDev).toBeGreaterThan(0);
    });

    it("should use most recent data first", () => {
      const dataWithOldValue = [
        ...timeSeriesData,
        { date: new Date("2020-01-01"), value: 100 },
      ];

      const result = calculateRollingStats(dataWithOldValue, 5);

      expect(result.mean).toBeLessThan(20);
    });

    it("should handle small window size", () => {
      const result = calculateRollingStats(timeSeriesData, 2);

      expect(result.mean).toBeGreaterThan(0);
      expect(result.stdDev).toBeGreaterThanOrEqual(0);
    });

    it("should handle single data point", () => {
      const singlePoint = [{ date: new Date(), value: 10 }];
      const result = calculateRollingStats(singlePoint, 30);

      expect(result.mean).toBe(10);
      expect(result.stdDev).toBe(0);
    });
  });

  describe("Integration: End-to-End Anomaly Detection", () => {
    it("should detect outlier using both Z-score and IQR methods", () => {
      const dataWithOutlier = [10, 12, 15, 14, 13, 100, 15, 14, 13, 12];

      const mean = calculateMean(dataWithOutlier);
      const stdDev = calculateStdDev(dataWithOutlier);
      const zScoreResult = detectAnomalyZScore(100, mean, stdDev);

      const { q1, q3, iqr } = calculateQuartiles(dataWithOutlier);
      const iqrResult = detectAnomalyIQR(100, q1, q3, iqr);

      expect(zScoreResult.isAnomaly).toBe(true);
      expect(iqrResult.isAnomaly).toBe(true);
    });

    it("should handle real-world carbon emission scenario", () => {
      const monthlyUsage = [
        250, 260, 255, 248, 252, 258, 254, 251, 257, 253, 256, 249, 255, 252,
        600,
      ];

      const mean = calculateMean(monthlyUsage.slice(0, 14));
      const stdDev = calculateStdDev(monthlyUsage.slice(0, 14));

      const anomalyCheck = detectAnomalyZScore(600, mean, stdDev);

      expect(anomalyCheck.isAnomaly).toBe(true);
      expect(anomalyCheck.severity).toBe("high");
    });
  });
});
