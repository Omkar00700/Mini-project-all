import {
  generateCohortKey,
  parseCohortKey,
  calculatePercentile,
  calculateRank,
} from "../analytics/benchmarking.service";

describe("Benchmarking Service", () => {
  describe("generateCohortKey", () => {
    it("should generate key from country, city, and household size", () => {
      const key = generateCohortKey(
        { country: "India", city: "Mumbai" },
        { size: 4 }
      );
      expect(key).toBe("india_mumbai_4");
    });

    it("should handle missing city by falling back to region", () => {
      const key = generateCohortKey(
        { country: "India", region: "Maharashtra" },
        { size: 3 }
      );
      expect(key).toBe("india_maharashtra_3");
    });

    it("should handle completely missing location fields", () => {
      const key = generateCohortKey({}, {});
      expect(key).toBe("unknown_unknown_1");
    });

    it("should handle null location and household", () => {
      const key = generateCohortKey(
        {} as { country?: string; city?: string },
        {} as { size?: number }
      );
      expect(key).toBe("unknown_unknown_1");
    });

    it("should normalize spaces to dashes", () => {
      const key = generateCohortKey(
        { country: "United States", city: "New York" },
        { size: 2 }
      );
      expect(key).toBe("united-states_new-york_2");
    });

    it("should trim whitespace", () => {
      const key = generateCohortKey(
        { country: "  India  ", city: "  Delhi  " },
        { size: 5 }
      );
      expect(key).toBe("india_delhi_5");
    });

    it("should convert to lowercase", () => {
      const key = generateCohortKey(
        { country: "GERMANY", city: "BERLIN" },
        { size: 1 }
      );
      expect(key).toBe("germany_berlin_1");
    });

    it("should default household size to 1 when missing", () => {
      const key = generateCohortKey({ country: "UK", city: "London" }, {});
      expect(key).toBe("uk_london_1");
    });
  });

  describe("parseCohortKey", () => {
    it("should parse a valid cohort key", () => {
      const config = parseCohortKey("india_mumbai_4");
      expect(config).toEqual({
        country: "india",
        city: "mumbai",
        householdSize: 4,
      });
    });

    it("should handle dashes in segments", () => {
      const config = parseCohortKey("united-states_new-york_2");
      expect(config).toEqual({
        country: "united-states",
        city: "new-york",
        householdSize: 2,
      });
    });

    it("should handle malformed key gracefully", () => {
      const config = parseCohortKey("onlyone");
      expect(config.country).toBe("onlyone");
      expect(config.householdSize).toBe(1);
    });
  });

  describe("calculatePercentile", () => {
    it("should return 50 for single user in cohort", () => {
      const result = calculatePercentile(100, [100]);
      expect(result).toBe(50);
    });

    it("should return 50 for empty array", () => {
      const result = calculatePercentile(100, []);
      expect(result).toBe(50);
    });

    it("should return high percentile for low emissions (best performer)", () => {
      const values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
      const result = calculatePercentile(10, values);
      expect(result).toBe(90);
    });

    it("should return low percentile for high emissions (worst performer)", () => {
      const values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
      const result = calculatePercentile(100, values);
      expect(result).toBe(0);
    });

    it("should return ~50 percentile for middle values", () => {
      const values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
      const result = calculatePercentile(50, values);
      expect(result).toBe(50);
    });

    it("should handle tied values", () => {
      const values = [50, 50, 50, 50, 50];
      const result = calculatePercentile(50, values);
      expect(result).toBe(0);
    });

    it("should handle two users", () => {
      const values = [30, 70];
      const resultBetter = calculatePercentile(30, values);
      const resultWorse = calculatePercentile(70, values);
      expect(resultBetter).toBe(50);
      expect(resultWorse).toBe(0);
    });
  });

  describe("calculateRank", () => {
    it("should return 1 for empty array", () => {
      const result = calculateRank(100, []);
      expect(result).toBe(1);
    });

    it("should return rank 1 for lowest value (best)", () => {
      const values = [10, 20, 30, 40, 50];
      const result = calculateRank(10, values);
      expect(result).toBe(1);
    });

    it("should return last rank for highest value (worst)", () => {
      const values = [10, 20, 30, 40, 50];
      const result = calculateRank(50, values);
      expect(result).toBe(5);
    });

    it("should return correct rank for middle value", () => {
      const values = [10, 20, 30, 40, 50];
      const result = calculateRank(30, values);
      expect(result).toBe(3);
    });

    it("should handle tied values", () => {
      const values = [10, 20, 20, 30];
      const result = calculateRank(20, values);
      expect(result).toBe(2);
    });

    it("should handle single value", () => {
      const values = [42];
      const result = calculateRank(42, values);
      expect(result).toBe(1);
    });

    it("should handle unsorted input", () => {
      const values = [50, 10, 40, 20, 30];
      const result = calculateRank(30, values);
      expect(result).toBe(3);
    });
  });
});
