import { energyCalculator } from "./energy-calculator";
import { transportationCalculator } from "./transportation-calculator";
import { foodCalculator } from "./food-calculator";
import { consumptionCalculator } from "./consumption-calculator";
import { wasteCalculator } from "./waste-calculator";
import { db } from "@/lib/db";
import type {
  TransportationData,
  EnergyData,
  FoodData,
  ConsumptionData,
  CarbonFootprintResult,
} from "@/types/carbon";

class CarbonCalculatorsService {
  async calculateFoodEmissions(data: FoodData): Promise<{
    totalEmissions: number;
    breakdown: any;
    details: any[];
    methodology: string;
    recommendations: string[];
  }> {
    try {
      const result = await foodCalculator.calculateFoodEmissions(data);

      return {
        totalEmissions: result.totalEmissions,
        breakdown: result.breakdown,
        details: result.details,
        methodology: result.methodology,
        recommendations: result.recommendations,
      };
    } catch (error) {
      throw new Error("Failed to calculate food emissions");
    }
  }

  async calculateConsumptionEmissions(data: ConsumptionData): Promise<{
    totalEmissions: number;
    breakdown: any;
    details: any[];
    methodology: string;
    recommendations: string[];
  }> {
    try {
      const result =
        await consumptionCalculator.calculateConsumptionEmissions(data);

      return {
        totalEmissions: result.totalEmissions,
        breakdown: result.breakdown,
        details: result.details,
        methodology: result.methodology,
        recommendations: result.recommendations,
      };
    } catch (error) {
      throw new Error("Failed to calculate consumption emissions");
    }
  }

  async calculateEnergyEmissions(data: EnergyData): Promise<{
    totalEmissions: number;
    breakdown: any;
    details: any[];
    methodology: string;
    recommendations: string[];
  }> {
    try {
      const energyInput = {
        electricity: data.electricity
          ? {
              consumption: data.electricity.consumption,
              gridRegion: data.electricity.grid_region,
              renewablePercentage: data.electricity.renewable_percentage,
              sourceMix: data.electricity.source_mix,
            }
          : undefined,

        heating: data.heating
          ? {
              naturalGas: data.heating.natural_gas,
              heatingOil: data.heating.heating_oil,
              propane: data.heating.propane,
              wood: data.heating.wood,
              districtHeating: data.heating.district_heating,
            }
          : undefined,

        cooling: data.cooling
          ? {
              electricity: data.cooling.electricity,
              systemType: "central_ac" as const,
              seer: data.cooling.efficiency_rating
                ? parseFloat(data.cooling.efficiency_rating)
                : undefined,
            }
          : undefined,

        renewable: data.renewable
          ? {
              solarGenerated: data.renewable.solar_generated,
              windGenerated: data.renewable.wind_generated,
              hydroGenerated: data.renewable.other_generated,
            }
          : undefined,
      };

      const result =
        await energyCalculator.calculateEnergyFootprint(energyInput);

      return {
        totalEmissions: result.totalEmissions,
        breakdown: result.breakdown,
        details: result.details,
        methodology: result.methodology,
        recommendations: result.recommendations,
      };
    } catch (error) {
      throw new Error("Failed to calculate energy emissions");
    }
  }

  async calculateCarbonFootprint(data: {
    userId: string;
    periodStart: Date;
    periodEnd: Date;
    transportation?: TransportationData;
    energy?: EnergyData;
    food?: FoodData;
    consumption?: ConsumptionData;
  }): Promise<CarbonFootprintResult> {
    try {
      let totalEmissions = 0;
      const breakdown: any = {};
      const detailedBreakdown: any = {};
      const calculationMetadata: any = {
        calculation_method: "ghg_protocol",
        emission_factors_version: "1.0",
        data_completeness: 1.0,
        calculation_timestamp: new Date(),
        confidence_factors: {},
        assumptions: [],
        data_sources: [],
      };

      if (data.transportation) {
        breakdown.transportation = 0;
        detailedBreakdown.transportation = {};
      }

      if (data.energy) {
        const energyResult = await this.calculateEnergyEmissions(data.energy);
        breakdown.energy = energyResult.totalEmissions;
        detailedBreakdown.energy = energyResult.breakdown;
        totalEmissions += energyResult.totalEmissions;

        calculationMetadata.assumptions.push(...energyResult.recommendations);
        calculationMetadata.data_sources.push(
          "Real-time grid emission factors"
        );
      }

      if (data.food) {
        const foodResult = await this.calculateFoodEmissions(data.food);
        breakdown.food = foodResult.totalEmissions;
        detailedBreakdown.food = foodResult.breakdown;
        totalEmissions += foodResult.totalEmissions;

        calculationMetadata.assumptions.push(...foodResult.recommendations);
        calculationMetadata.data_sources.push("FAO 2019 food emission factors");
      }

      if (data.consumption) {
        const consumptionResult = await this.calculateConsumptionEmissions(
          data.consumption
        );
        breakdown.consumption = consumptionResult.totalEmissions;
        detailedBreakdown.consumption = consumptionResult.breakdown;
        totalEmissions += consumptionResult.totalEmissions;

        calculationMetadata.assumptions.push(
          ...consumptionResult.recommendations
        );
        calculationMetadata.data_sources.push(
          "EPA EEIO and lifecycle assessment data"
        );
      }

      const confidenceScore = this.calculateConfidenceScore(data);

      const carbonCalculation = await db.carbonCalculation.create({
        data: {
          userId: data.userId,
          periodStart: data.periodStart,
          periodEnd: data.periodEnd,
          totalEmissions,
          breakdown,
          confidenceScore,
          metadata: calculationMetadata,
        },
      });

      return {
        total_emissions: totalEmissions,
        breakdown,
        confidence_score: confidenceScore,
        calculation_metadata: calculationMetadata,
        detailed_breakdown: detailedBreakdown,
      };
    } catch (error) {
      throw new Error("Failed to calculate carbon footprint");
    }
  }

  private calculateConfidenceScore(data: any): number {
    let totalCategories = 0;
    let completedCategories = 0;
    let qualityScore = 0;

    if (data.transportation) {
      totalCategories++;
      if (this.hasCompleteTransportationData(data.transportation)) {
        completedCategories++;
        qualityScore += 0.9;
      } else {
        qualityScore += 0.6;
      }
    }

    if (data.energy) {
      totalCategories++;
      if (this.hasCompleteEnergyData(data.energy)) {
        completedCategories++;
        qualityScore += 0.95;
      } else {
        qualityScore += 0.7;
      }
    }

    if (data.food) {
      totalCategories++;
      if (this.hasCompleteFoodData(data.food)) {
        completedCategories++;
        qualityScore += 0.8;
      } else {
        qualityScore += 0.5;
      }
    }

    if (data.consumption) {
      totalCategories++;
      if (this.hasCompleteConsumptionData(data.consumption)) {
        completedCategories++;
        qualityScore += 0.7;
      } else {
        qualityScore += 0.4;
      }
    }

    const completenessScore =
      totalCategories > 0 ? completedCategories / totalCategories : 0;
    const averageQualityScore =
      totalCategories > 0 ? qualityScore / totalCategories : 0;

    return Math.min(1.0, completenessScore * 0.4 + averageQualityScore * 0.6);
  }

  private hasCompleteTransportationData(data: TransportationData): boolean {
    return !!(
      data.personal_vehicles?.distance ||
      data.public_transport?.bus_distance ||
      data.flights?.domestic_short ||
      data.ride_sharing?.distance
    );
  }

  private hasCompleteEnergyData(data: EnergyData): boolean {
    return !!(
      data.electricity?.consumption ||
      data.heating?.natural_gas ||
      data.cooling?.electricity
    );
  }

  private hasCompleteFoodData(data: FoodData): boolean {
    return !!(
      data.meat?.chicken ||
      data.dairy?.milk ||
      data.plant_based?.vegetables ||
      data.beverages?.coffee
    );
  }

  private hasCompleteConsumptionData(data: ConsumptionData): boolean {
    return !!(
      data.shopping?.clothing ||
      data.services?.banking ||
      data.waste?.general_waste
    );
  }

  async getEnergyRecommendations(userId: string): Promise<{
    recommendations: Array<{
      title: string;
      description: string;
      category: string;
      impactEstimate: number;
      costEstimate?: number;
      difficultyScore: number;
    }>;
  }> {
    try {
      const latestCalculation = await db.carbonCalculation.findFirst({
        where: { userId },
        orderBy: { createdAt: "desc" },
      });

      if (!latestCalculation) {
        return { recommendations: [] };
      }

      const recommendations = [];

      if (!latestCalculation.breakdown) {
        return { recommendations: [] };
      }
      const breakdown = latestCalculation.breakdown as Record<string, unknown>;
      const energyBreakdown =
        (breakdown.energy as Record<string, number>) || {};

      if (energyBreakdown.electricity > energyBreakdown.heating) {
        recommendations.push({
          title: "Switch to Renewable Energy",
          description:
            "Consider switching to a renewable energy plan or installing solar panels",
          category: "energy",
          impactEstimate: energyBreakdown.electricity * 0.8,
          costEstimate: 15000,
          difficultyScore: 3,
        });
      }

      if (energyBreakdown.heating > 1000) {
        recommendations.push({
          title: "Upgrade to Heat Pump",
          description:
            "Replace your current heating system with an efficient heat pump",
          category: "energy",
          impactEstimate: energyBreakdown.heating * 0.6,
          costEstimate: 8000,
          difficultyScore: 4,
        });
      }

      if (energyBreakdown.cooling > 500) {
        recommendations.push({
          title: "Improve Home Insulation",
          description:
            "Add insulation and seal air leaks to reduce cooling needs",
          category: "energy",
          impactEstimate: energyBreakdown.cooling * 0.3,
          costEstimate: 3000,
          difficultyScore: 2,
        });
      }

      return { recommendations };
    } catch (error) {
      throw new Error("Failed to generate energy recommendations");
    }
  }
}

export const carbonCalculatorsService = new CarbonCalculatorsService();
