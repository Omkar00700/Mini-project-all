"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from "react";
import { useRouter } from "next/navigation";
import type { AuthUser } from "@/types/auth";

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  signIn: (credentials: {
    email: string;
    password: string;
  }) => Promise<{ error?: { message: string } }>;
  signUp: (credentials: {
    email: string;
    password: string;
    fullName: string;
    confirmPassword?: string;
  }) => Promise<{ error?: { message: string } }>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
  signInWithOAuth: (
    provider: string
  ) => Promise<{ error?: { message: string } }>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const signIn = async (credentials: { email: string; password: string }) => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        return { error: { message: data.error || "Login failed" } };
      }
      setUser(data.user);
      router.push("/dashboard");
      return {};
    } catch {
      return { error: { message: "Login failed. Please try again." } };
    }
  };

  const signUp = async (credentials: {
    email: string;
    password: string;
    fullName: string;
    confirmPassword?: string;
  }) => {
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: credentials.email,
          password: credentials.password,
          name: credentials.fullName,
        }),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        return { error: { message: data.error || "Registration failed" } };
      }
      setUser(data.user);
      router.push("/dashboard");
      return {};
    } catch {
      return { error: { message: "Registration failed. Please try again." } };
    }
  };

  const signOut = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });
    } finally {
      setUser(null);
      router.push("/login");
    }
  };

  const signInWithOAuth = async (provider: string) => {
    try {
      const res = await fetch(`/api/auth/${provider}`);
      const data = await res.json();
      if (!res.ok) {
        return { error: { message: data.error || `${provider} OAuth failed` } };
      }
      if (data.url) {
        window.location.href = data.url;
      }
      return {};
    } catch {
      return {
        error: { message: `${provider} OAuth failed. Please try again.` },
      };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        signIn,
        signUp,
        signOut,
        refresh,
        signInWithOAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used inside <AuthProvider>");
  }
  return ctx;
}
