"use client";

import React, { createContext, useContext } from "react";

interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface AuthSession {
  user: AuthUser;
  access_token: string;
}

interface LoginCredentials {
  email: string;
  password: string;
}

interface RegisterCredentials {
  email: string;
  password: string;
  name: string;
}

interface AuthContextType {
  user: AuthUser | null;
  session: AuthSession | null;
  loading: boolean;
  signIn: (
    credentials: LoginCredentials
  ) => Promise<{ error?: { message: string } }>;
  signUp: (
    credentials: RegisterCredentials
  ) => Promise<{ error?: { message: string } }>;
  signOut: () => Promise<void>;
  signInWithOAuth: (
    provider: string
  ) => Promise<{ error?: { message: string } }>;
  updatePassword?: (data: any) => Promise<{ error?: { message: string } }>;
  resetPassword?: (email: string) => Promise<{ error?: { message: string } }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    return {
      user: null,
      session: null,
      loading: false,
      signIn: async () => ({ error: { message: "Demo mode - auth disabled" } }),
      signUp: async () => ({ error: { message: "Demo mode - auth disabled" } }),
      signOut: async () => {},
      signInWithOAuth: async () => ({
        error: { message: "Demo mode - auth disabled" },
      }),
      updatePassword: async () => ({
        error: { message: "Demo mode - auth disabled" },
      }),
      resetPassword: async () => ({
        error: { message: "Demo mode - auth disabled" },
      }),
    };
  }
  return context;
}

interface AuthProviderProps {
  children: React.ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const value: AuthContextType = {
    user: null,
    session: null,
    loading: false,
    signIn: async () => ({ error: { message: "Demo mode - auth disabled" } }),
    signUp: async () => ({ error: { message: "Demo mode - auth disabled" } }),
    signOut: async () => {},
    signInWithOAuth: async () => ({
      error: { message: "Demo mode - auth disabled" },
    }),
    updatePassword: async () => ({
      error: { message: "Demo mode - auth disabled" },
    }),
    resetPassword: async () => ({
      error: { message: "Demo mode - auth disabled" },
    }),
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
