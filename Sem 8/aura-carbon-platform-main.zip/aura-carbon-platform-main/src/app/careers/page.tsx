"use client";

import { motion } from "framer-motion";
import { Mail, Code2, BarChart3, Palette } from "lucide-react";

const roles = [
  {
    icon: Code2,
    title: "Full-Stack Engineer",
    stack: "Next.js · TypeScript · Prisma · PostgreSQL",
    desc: "You&apos;ll work on everything from the carbon calculation engine to the AI What-If analyzer. We ship fast and care deeply about correctness — one wrong emission factor affects real decisions.",
    color: "text-blue-500",
    bg: "bg-blue-500/10",
    border: "border-blue-500/20",
  },
  {
    icon: BarChart3,
    title: "Climate Data Analyst",
    stack: "Python · R · IPCC/MoEFCC data",
    desc: "Maintain and expand our India-specific emission factor database. Translate government reports and IPCC AR6 findings into structured, application-ready data.",
    color: "text-emerald-500",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/20",
  },
  {
    icon: Palette,
    title: "UX Designer",
    stack: "Figma · Systems thinking · Carbon literacy",
    desc: "Design interfaces that make complex environmental data feel intuitive. We believe good UX makes people actually use sustainability tools — and that has real-world impact.",
    color: "text-purple-500",
    bg: "bg-purple-500/10",
    border: "border-purple-500/20",
  },
];

const perks = [
  {
    emoji: "🌿",
    label: "Climate mission first",
    desc: "Every line of code we write has a climate reason for existing.",
  },
  {
    emoji: "🏡",
    label: "Remote-friendly",
    desc: "Based in Bangalore, but we hire for skill, not geography.",
  },
  {
    emoji: "📚",
    label: "Deep learning culture",
    desc: "We read IPCC reports, argue about emission factors, and think in systems.",
  },
  {
    emoji: "⚡",
    label: "Move fast, break little",
    desc: "Small team, fast cycles. Your work ships to users within days, not quarters.",
  },
];

export default function CareersPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-0 left-1/3 w-[500px] h-[500px] bg-orange-500/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10">
        {}
        <section className="container mx-auto px-6 pt-32 pb-20 max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="text-6xl mb-8">🚀</div>
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6 leading-tight">
              Work at the intersection of{" "}
              <span className="text-orange-500">
                technology and climate action.
              </span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              We&apos;re a small, focused team that believes the best climate
              software is built by people who genuinely care about the problem —
              not just the product.
            </p>
          </motion.div>
        </section>

        {}
        <section className="container mx-auto px-6 pb-24 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="p-8 rounded-3xl border border-border/50 bg-secondary/20 space-y-5 text-muted-foreground leading-relaxed"
          >
            <p>
              We work in deep focus blocks, ship fast, and argue loudly about
              emission factors over chai. We have a policy: if you can&apos;t
              explain what your feature does for a user&apos;s carbon footprint,
              it doesn&apos;t go in.
            </p>
            <p>
              Right now we&apos;re a team of three. That means your work visibly
              matters, your opinions change decisions, and you&apos;ll touch
              every part of the stack. It also means no bureaucracy, no
              permission slips, and no six-week design reviews for a button
              label change.
            </p>
            <p className="font-medium text-foreground dark:text-white">
              We don&apos;t hire for &quot;culture fit.&quot; We hire for craft,
              curiosity, and a real stake in whether the planet gets warmer.
            </p>
          </motion.div>
        </section>

        {}
        <section className="border-y border-border/50">
          <div className="container mx-auto px-6 py-16 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-2xl font-bold mb-8 text-center">
                What we look for in everyone
              </h2>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                {[
                  {
                    emoji: "🌍",
                    label: "Climate conviction",
                    desc: "You care about this problem — not as a résumé line, but as a reason to get up in the morning.",
                  },
                  {
                    emoji: "🔍",
                    label: "Rigorous thinking",
                    desc: "You can hold complexity without flattening it. You check your sources. You push back when numbers feel off.",
                  },
                  {
                    emoji: "🛠️",
                    label: "Builder mentality",
                    desc: "You write code, design systems, or analyse data that you'd be proud to show in 2035 when it still matters.",
                  },
                ].map((item, i) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 + 0.4 }}
                    className="p-6 rounded-2xl border border-border/50 bg-secondary/10"
                  >
                    <div className="text-4xl mb-3">{item.emoji}</div>
                    <h3 className="font-bold mb-2">{item.label}</h3>
                    <p className="text-muted-foreground text-sm">{item.desc}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {}
        <section className="container mx-auto px-6 py-24 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-3xl font-bold mb-2 text-center">Open roles</h2>
            <p className="text-center text-muted-foreground mb-12">
              No open positions right now — but here&apos;s what we&apos;ll be
              hiring for as we grow. Send us a note and we&apos;ll reach out
              when these open up.
            </p>
            <div className="space-y-4">
              {roles.map((role, i) => (
                <motion.div
                  key={role.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 + 0.5 }}
                  className={`p-6 rounded-2xl border ${role.bg} ${role.border} flex items-start gap-5`}
                >
                  <div className={`p-3 rounded-xl ${role.bg} shrink-0`}>
                    <role.icon className={`w-6 h-6 ${role.color}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between flex-wrap gap-2 mb-1">
                      <h3 className="font-bold text-lg">{role.title}</h3>
                      <span className="text-xs px-3 py-1 bg-secondary rounded-full text-muted-foreground">
                        Future Opening
                      </span>
                    </div>
                    <p
                      className={`text-xs font-mono mb-2 ${role.color} opacity-80`}
                    >
                      {role.stack}
                    </p>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {role.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {}
        <section className="border-t border-border/50">
          <div className="container mx-auto px-6 py-20 max-w-4xl">
            <h2 className="text-2xl font-bold text-center mb-12">
              What working here looks like
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {perks.map((perk, i) => (
                <motion.div
                  key={perk.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 + 0.5 }}
                  className="text-center p-5 rounded-2xl border border-border/50 bg-secondary/10"
                >
                  <div className="text-3xl mb-3">{perk.emoji}</div>
                  <h3 className="font-semibold mb-1 text-sm">{perk.label}</h3>
                  <p className="text-muted-foreground text-xs">{perk.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {}
        <section className="border-t border-border/50">
          <div className="container mx-auto px-6 py-20 max-w-2xl text-center">
            <div className="text-4xl mb-6">📬</div>
            <h2 className="text-3xl font-bold mb-3">
              Interested? Send us a note.
            </h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Write to us about what you&apos;re working on, what you care
              about, and why Aura&apos;s problem space matters to you. We read
              every email — no automated responses, no form submissions into the
              void.
            </p>
            <a
              href="mailto:careers@auraplatform.in"
              className="inline-flex items-center gap-2 px-8 py-4 bg-orange-500 hover:bg-orange-600 text-white font-semibold rounded-2xl transition-colors shadow-[0_0_30px_rgba(249,115,22,0.3)]"
            >
              <Mail className="w-5 h-5" />
              careers@auraplatform.in
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}
