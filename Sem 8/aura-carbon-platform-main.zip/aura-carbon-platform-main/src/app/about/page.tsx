"use client";

import { motion } from "framer-motion";
import {
  Leaf,
  Globe2,
  ShieldCheck,
  Heart,
  Sparkles,
  Users,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

const values = [
  {
    icon: Globe2,
    title: "Radical Transparency",
    description:
      "We believe the climate crisis requires an honest, data-driven approach. No greenwashing. Aura relies on scientifically-backed emission factors and uncompromised methodologies.",
  },
  {
    icon: Users,
    title: "Community Intelligence",
    description:
      "Your impact becomes exponentially more powerful in a network. By gamifying sustainability and competing with peers globally, we turn individual drops into a tidal wave.",
  },
  {
    icon: Sparkles,
    title: "Actionable AI",
    description:
      "Instead of overwhelming you with charts, our predictive intelligence connects the dots. We simulate your lifestyle swaps allowing you to make optimal climate interventions.",
  },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border/40" />

      <main className="flex-1 pt-32 pb-20 mt-10">
        <div className="container mx-auto px-6 max-w-6xl">
          {}
          <div className="text-center mb-24 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center justify-center p-4 bg-emerald-500/10 rounded-full mb-6"
            >
              <Leaf className="w-12 h-12 text-emerald-500" />
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="text-5xl md:text-7xl font-extrabold tracking-tight mb-8"
            >
              Balancing Technology <br className="hidden md:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-teal-400">
                & The Planet.
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="text-xl md:text-2xl text-muted-foreground leading-relaxed font-medium"
            >
              We started Aura because the climate crisis shouldn't feel
              abstract. Our mission is to bridge the gap between microscopic
              daily habits and magnificent global change.
            </motion.p>
          </div>

          {}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="grid md:grid-cols-2 gap-16 items-center mb-32 bg-secondary/20 p-8 md:p-12 rounded-[2.5rem] border border-border/50"
          >
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Our Genesis
              </h2>
              <p>
                The world isn&apos;t lacking climate data—it&apos;s lacking{" "}
                <strong className="text-emerald-500">translation</strong>.
                Thousands of academic papers outline how transport, diets, and
                energy impact the carbon cycle, but they remain locked away from
                everyday consumers.
              </p>
              <p>
                Aura was built as the translation engine. By fusing Next-Gen Web
                Technologies, Artificial Intelligence, and beautiful user
                interfaces, we built a tool that takes your boring electricity
                bill or road trip and converts it into a visceral, actionable
                dashboard.
              </p>
            </div>
            <div className="relative h-[400px] rounded-3xl overflow-hidden bg-gradient-to-br from-emerald-900/40 to-black/20 flex flex-col items-center justify-center border border-emerald-500/10 shadow-2xl">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30" />
              <Heart className="w-32 h-32 text-emerald-500/80 mb-6 drop-shadow-[0_0_30px_rgba(16,185,129,0.5)]" />
              <p className="text-xl font-bold text-emerald-100 z-10 text-center px-6">
                "Microscopic choices. <br /> Magnificent change."
              </p>
            </div>
          </motion.div>

          {}
          <div className="mb-20">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-extrabold mb-4">Our Core Values</h2>
              <p className="text-xl text-muted-foreground">
                The philosophies that drive our architecture.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  className="p-8 rounded-3xl bg-background border border-border/60 shadow-xl hover:shadow-emerald-500/10 hover:border-emerald-500/30 transition-all group"
                >
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                    <value.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{value.title}</h3>
                  <p className="text-muted-foreground text-lg leading-relaxed">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
