import { Globe } from "lucide-react";

export default function ImpactPage() {
  return (
    <div className="container mx-auto px-6 py-32 min-h-[60vh] flex flex-col items-center justify-center text-center">
      <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center mb-8 relative">
        <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full animate-pulse" />
        <Globe className="w-12 h-12 text-blue-500 relative z-10" />
      </div>
      <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-500">
        Global Impact
      </h1>
      <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-12 font-light">
        Aura users have collectively offset over{" "}
        <strong className="text-emerald-500 font-bold">12,450 tonnes</strong> of
        CO2 this year.
      </p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 w-full max-w-4xl">
        {[
          { label: "Active Users", value: "24.5K" },
          { label: "Trees Planted (Eq)", value: "1.2M" },
          { label: "Goals Met", value: "89%" },
          { label: "Regions", value: "14" },
        ].map((stat, i) => (
          <div
            key={i}
            className="p-6 border border-border rounded-2xl bg-secondary/10"
          >
            <div className="text-3xl font-black text-foreground mb-2">
              {stat.value}
            </div>
            <div className="text-sm text-muted-foreground">{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
