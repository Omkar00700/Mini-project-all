import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/sonner";
import { NextAuthProvider } from "@/components/next-auth-provider";
import { RewardOverlay } from "@/components/gamification/RewardOverlay";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Aura - Carbon Footprint Tracker",
    template: "%s | Aura",
  },
  description:
    "Track, analyze, and reduce your carbon footprint with India's leading sustainability platform.",
  keywords: [
    "carbon footprint",
    "sustainability",
    "environmental impact",
    "climate change",
    "India",
    "green technology",
  ],
  authors: [{ name: "Aura Team" }],
  creator: "Aura",
  openGraph: {
    type: "website",
    locale: "en_IN",
    url: "https://aura.co.in",
    title: "Aura - Carbon Footprint Tracker",
    description:
      "Track, analyze, and reduce your carbon footprint with India's leading sustainability platform.",
    siteName: "Aura",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <NextAuthProvider>
            {children}
            <Toaster />
            <RewardOverlay />
          </NextAuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
