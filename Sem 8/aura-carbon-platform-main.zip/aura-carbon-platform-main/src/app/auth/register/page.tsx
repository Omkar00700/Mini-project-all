import { Metadata } from "next";
import { RegisterForm } from "@/components/auth/register-form";

export const metadata: Metadata = {
  title: "Sign Up | Aura",
  description:
    "Create your Aura account to start tracking your carbon footprint",
};

export default function RegisterPage() {
  return <RegisterForm />;
}
