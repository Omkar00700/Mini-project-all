import { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = {
  title: "Sign In | Aura",
  description: "Sign in to your Aura account to track your carbon footprint",
};

export default function LoginPage() {
  return <LoginForm />;
}
