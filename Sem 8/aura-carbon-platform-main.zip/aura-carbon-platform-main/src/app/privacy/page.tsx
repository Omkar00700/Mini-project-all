"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Shield,
  Eye,
  Lock,
  Database,
  UserCheck,
  AlertTriangle,
} from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <Shield className="h-8 w-8 text-green-600" />
          <h1 className="text-3xl font-bold">Privacy Policy</h1>
        </div>
        <p className="text-muted-foreground">Last updated: January 1, 2025</p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Our Commitment to Privacy</CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <p>
              At Aura, we are committed to protecting your privacy and ensuring
              the security of your personal information. This Privacy Policy
              explains how we collect, use, disclose, and safeguard your
              information when you use our carbon footprint tracking platform.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Database className="h-5 w-5" />
              <CardTitle>Information We Collect</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Personal Information</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Name, email address, and contact information</li>
                <li>Location data (country, region, city)</li>
                <li>Household information (size, type, income bracket)</li>
                <li>Account preferences and settings</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Carbon Footprint Data</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Transportation activities and fuel consumption</li>
                <li>Energy usage and utility consumption</li>
                <li>Food consumption patterns and dietary preferences</li>
                <li>Waste generation and disposal methods</li>
                <li>Purchase history and consumption data</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Technical Information</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Device information and browser type</li>
                <li>IP address and location data</li>
                <li>Usage patterns and feature interactions</li>
                <li>Performance and error logs</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <CardTitle>How We Use Your Information</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside text-sm space-y-2 text-muted-foreground">
              <li>
                Calculate accurate carbon footprints using India-specific
                emission factors
              </li>
              <li>
                Provide personalized recommendations for reducing environmental
                impact
              </li>
              <li>
                Generate reports and analytics on your sustainability progress
              </li>
              <li>
                Send notifications about goals, achievements, and platform
                updates
              </li>
              <li>Improve our algorithms and add new features</li>
              <li>Ensure platform security and prevent fraud</li>
              <li>Comply with legal obligations and regulatory requirements</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Lock className="h-5 w-5" />
              <CardTitle>Data Security</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Encryption & Protection</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>All data is encrypted in transit using TLS 1.3</li>
                <li>Personal information is encrypted at rest using AES-256</li>
                <li>Regular security audits and penetration testing</li>
                <li>Multi-factor authentication for account access</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Access Controls</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Role-based access control for our team members</li>
                <li>Regular access reviews and permission audits</li>
                <li>Secure development practices and code reviews</li>
                <li>Incident response procedures and breach notifications</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <UserCheck className="h-5 w-5" />
              <CardTitle>Your Rights</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Data Access & Control</h4>
                <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                  <li>
                    <strong>Access:</strong> Request a copy of all personal data
                    we hold about you
                  </li>
                  <li>
                    <strong>Correction:</strong> Update or correct inaccurate
                    personal information
                  </li>
                  <li>
                    <strong>Deletion:</strong> Request deletion of your account
                    and all associated data
                  </li>
                  <li>
                    <strong>Portability:</strong> Export your data in
                    machine-readable formats
                  </li>
                  <li>
                    <strong>Restriction:</strong> Limit how we process your
                    personal information
                  </li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">
                  How to Exercise Your Rights
                </h4>
                <p className="text-sm text-muted-foreground">
                  Contact us at{" "}
                  <a
                    href="mailto:privacy@aura.com"
                    className="text-blue-600 hover:underline"
                  >
                    privacy@aura.com
                  </a>{" "}
                  or use the settings page to manage your data preferences. We
                  will respond within 30 days.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data Sharing & Third Parties</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">
                  We DO NOT sell your personal data
                </h4>
                <p className="text-sm text-muted-foreground">
                  Your personal information is never sold to third parties for
                  marketing or commercial purposes.
                </p>
              </div>

              <div>
                <h4 className="font-semibold mb-2">
                  Limited Sharing for Service Delivery
                </h4>
                <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                  <li>
                    Cloud infrastructure providers (AWS, Google Cloud) for
                    hosting
                  </li>
                  <li>
                    Analytics services for platform improvement (anonymized data
                    only)
                  </li>
                  <li>Payment processors for subscription management</li>
                  <li>Email services for notifications and communications</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">
                  Research & Aggregated Data
                </h4>
                <p className="text-sm text-muted-foreground">
                  We may share anonymized, aggregated data for climate research
                  and policy development. This data cannot be used to identify
                  individual users.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5" />
              <CardTitle>Important Information</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Data Retention</h4>
              <p className="text-sm text-muted-foreground">
                We retain your data for as long as your account is active or as
                needed to provide services. After account deletion, we may
                retain anonymized data for research purposes.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">International Transfers</h4>
              <p className="text-sm text-muted-foreground">
                Your data may be processed in countries outside India. We ensure
                adequate protection through standard contractual clauses and
                certification schemes.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Children&apos;s Privacy</h4>
              <p className="text-sm text-muted-foreground">
                Our service is not intended for children under 13. We do not
                knowingly collect personal information from children under 13.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Policy Updates</h4>
              <p className="text-sm text-muted-foreground">
                We may update this policy periodically. We will notify you of
                significant changes via email or platform notifications.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contact Us</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              If you have questions about this Privacy Policy or our data
              practices, please contact us:
            </p>
            <div className="space-y-2 text-sm">
              <p>
                <strong>Email:</strong>{" "}
                <a
                  href="mailto:privacy@aura.com"
                  className="text-blue-600 hover:underline"
                >
                  privacy@aura.com
                </a>
              </p>
              <p>
                <strong>Address:</strong> Aura Privacy Team, Koramangala,
                Bangalore, Karnataka 560034, India
              </p>
              <p>
                <strong>Data Protection Officer:</strong>{" "}
                <a
                  href="mailto:dpo@aura.com"
                  className="text-blue-600 hover:underline"
                >
                  dpo@aura.com
                </a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
