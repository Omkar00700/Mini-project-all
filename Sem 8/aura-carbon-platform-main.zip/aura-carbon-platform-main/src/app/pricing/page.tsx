import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

export default function PricingPage() {
  return (
    <div className="container mx-auto px-6 py-32 min-h-[60vh]">
      <div className="text-center mb-24 max-w-3xl mx-auto">
        <h1 className="text-5xl font-bold tracking-tight mb-6">
          Simple, transparent pricing
        </h1>
        <p className="text-xl text-muted-foreground font-light">
          Start for free. Upgrade when you need more power.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="p-10 rounded-[32px] bg-background border border-border shadow-lg">
          <div className="text-emerald-500 font-bold mb-4">INDIVIDUAL</div>
          <div className="text-5xl font-black mb-6">
            Free
            <span className="text-xl text-muted-foreground font-normal">
              /forever
            </span>
          </div>
          <p className="text-muted-foreground mb-8">
            Everything you need to track your personal footprint perfectly.
          </p>
          <ul className="space-y-4 mb-10">
            {[
              "Basic Calculation Engine",
              "Monthly Goal Tracking",
              "Standard Analytics",
              "Community Access",
            ].map((f, i) => (
              <li key={i} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-500" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
          <Button className="w-full py-6 rounded-xl bg-secondary text-foreground hover:bg-secondary/80 text-lg">
            Current Plan
          </Button>
        </div>

        <div className="p-10 rounded-[32px] bg-emerald-950/20 border border-emerald-500/30 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 px-4 py-1 bg-emerald-500 text-white text-xs font-bold rounded-bl-xl">
            POPULAR
          </div>
          <div className="text-emerald-400 font-bold mb-4">PREMIUM</div>
          <div className="text-5xl font-black mb-6">
            ₹499
            <span className="text-xl text-muted-foreground font-normal">
              /month
            </span>
          </div>
          <p className="text-muted-foreground mb-8">
            Advanced features for power users and small teams.
          </p>
          <ul className="space-y-4 mb-10">
            {[
              "API Access",
              "Custom Offset Projects",
              "Export to PDF/CSV",
              "Priority Support",
              "AI Predictive Trends",
            ].map((f, i) => (
              <li key={i} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
          <Button className="w-full py-6 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-lg">
            Upgrade Now
          </Button>
        </div>
      </div>
    </div>
  );
}
