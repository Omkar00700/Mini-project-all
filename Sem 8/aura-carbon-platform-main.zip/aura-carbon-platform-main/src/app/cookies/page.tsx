export default function CookiesPage() {
  return (
    <div className="container mx-auto px-6 py-32 min-h-[60vh] max-w-4xl">
      <h1 className="text-4xl font-bold mb-8">Cookie Policy</h1>
      <div className="prose prose-emerald dark:prose-invert">
        <p className="text-lg text-muted-foreground mb-6">
          Last Updated: February 2026
        </p>
        <p className="mb-4">
          This policy explains how Aura Platform uses cookies and similar
          technologies to recognize you when you visit our website.
        </p>
        <h2 className="text-2xl font-semibold mt-8 mb-4">What are cookies?</h2>
        <p className="mb-4">
          Cookies are small data files that are placed on your computer or
          mobile device when you visit a website. They are widely used by
          website owners in order to make their websites work, or to work more
          efficiently, as well as to provide reporting information.
        </p>
        <div className="p-6 bg-secondary/30 rounded-xl mt-8">
          <h3 className="text-xl font-semibold mb-2">Manage Preferences</h3>
          <p className="text-sm text-muted-foreground mb-4">
            You can change your cookie preferences at any time.
          </p>
          <button className="px-4 py-2 bg-foreground text-background rounded-lg text-sm font-medium">
            Cookie Settings (Demo)
          </button>
        </div>
      </div>
    </div>
  );
}
