"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/auth-context-simple";
import { motion } from "framer-motion";
import {
  Users,
  Activity,
  Leaf,
  Shield,
  TrendingDown,
  RefreshCw,
  Calendar,
  Mail,
  Crown,
  User,
  ChevronUp,
  Database,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface UserRow {
  id: string;
  name: string;
  email: string;
  role: string;
  createdAt: string;
  lastLoginAt: string | null;
  _count: {
    activityData: number;
    sessions: number;
    carbonCalculations: number;
    goals: number;
  };
}

interface AdminStats {
  totalUsers: number;
  activeToday: number;
  totalActivities: number;
  totalCalculations: number;
}

interface ActivityLog {
  id: string;
  userId: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  date: string;
  co2Impact: number | null;
}

const StatCard = ({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType;
  label: string;
  value: number | string;
  color: string;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="relative p-6 rounded-2xl border bg-background/80 backdrop-blur-xl overflow-hidden"
    style={{ borderColor: `${color}20` }}
  >
    <div
      className="absolute top-0 inset-x-0 h-[1px]"
      style={{
        background: `linear-gradient(90deg, transparent, ${color}60, transparent)`,
      }}
    />
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm text-muted-foreground mb-1">{label}</p>
        <p className="text-4xl font-black text-foreground">{value}</p>
      </div>
      <div
        className="p-3 rounded-xl"
        style={{
          backgroundColor: `${color}15`,
          border: `1px solid ${color}25`,
        }}
      >
        <Icon className="w-6 h-6" style={{ color }} />
      </div>
    </div>
  </motion.div>
);

export default function AdminPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [fetching, setFetching] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setFetching(true);
    setError(null);
    try {
      const [usersRes, logsRes] = await Promise.all([
        fetch("/api/admin/users"),
        fetch("/api/activities?limit=20"),
      ]);

      if (usersRes.status === 403) {
        setError("You don't have admin access.");
        setFetching(false);
        return;
      }

      const userData = await usersRes.json();
      const logData = await logsRes.json();

      setStats(userData.stats);
      setUsers(userData.users);
      setLogs(logData.activities || []);
    } catch {
      setError("Failed to load admin data.");
    } finally {
      setFetching(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login");
      return;
    }
    if (!authLoading && user) {
      if (user.role !== "admin") {
        router.push("/dashboard");
      } else {
        fetchData();
      }
    }
  }, [user, authLoading, router, fetchData]);

  const handlePromote = async (userId: string, currentRole: string) => {
    const newRole = currentRole === "admin" ? "user" : "admin";
    await fetch("/api/admin/users", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, role: newRole }),
    });
    fetchData();
  };

  const formatDate = (iso: string | null) => {
    if (!iso) return "Never";
    return new Date(iso).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  if (authLoading || fetching) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex items-center gap-3 text-muted-foreground">
          <RefreshCw className="w-5 h-5 animate-spin text-primary" />
          <span>Loading admin panel...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-destructive mx-auto mb-4 opacity-50" />
          <p className="text-lg font-semibold text-foreground mb-2">{error}</p>
          <Button onClick={() => router.push("/dashboard")}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-6 py-10">
        {}
        <div className="flex items-center justify-between mb-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-5 h-5 text-amber-500" />
              <span className="text-xs font-bold uppercase tracking-widest text-amber-500">
                Admin Command Center
              </span>
            </div>
            <h1 className="text-4xl font-black text-foreground tracking-tight">
              System Transparency
            </h1>
            <p className="text-muted-foreground mt-1">
              Real-time database monitoring and user governance.
            </p>
          </div>
          <div className="flex gap-4">
            <Badge
              variant="outline"
              className="px-4 py-2 border-emerald-500/50 text-emerald-500 bg-emerald-500/5"
            >
              DB: Neon / Secure
            </Badge>
            <Button
              variant="outline"
              onClick={fetchData}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </Button>
          </div>
        </div>

        {}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            <StatCard
              icon={Users}
              label="Total Users"
              value={stats.totalUsers}
              color="#10b981"
            />
            <StatCard
              icon={Activity}
              label="Active Today"
              value={stats.activeToday}
              color="#3b82f6"
            />
            <StatCard
              icon={Leaf}
              label="Total Activities"
              value={stats.totalActivities}
              color="#22c55e"
            />
            <StatCard
              icon={TrendingDown}
              label="Calculations"
              value={stats.totalCalculations}
              color="#a855f7"
            />
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8 mb-10">
          {}
          <div className="lg:col-span-2 rounded-2xl border bg-background/80 backdrop-blur-xl overflow-hidden">
            <div className="p-6 border-b border-border/50 flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">
                User Management
              </h2>
              <Users className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-muted/30">
                    {["User", "Email", "Role", "Activities", "Actions"].map(
                      (h) => (
                        <th
                          key={h}
                          className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider text-muted-foreground"
                        >
                          {h}
                        </th>
                      )
                    )}
                  </tr>
                </thead>
                <tbody>
                  {users.map((u, i) => (
                    <motion.tr
                      key={u.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="border-t border-border/30 hover:bg-muted/20 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center text-xs font-bold text-primary">
                            {u.name.slice(0, 2).toUpperCase()}
                          </div>
                          <span className="font-medium text-foreground text-sm">
                            {u.name}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs text-muted-foreground">
                          {u.email}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant={u.role === "admin" ? "default" : "secondary"}
                          className="text-[10px] h-5"
                        >
                          {u.role}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs">
                        {u._count.activityData}
                      </td>
                      <td className="px-4 py-3">
                        {u.id !== user?.id && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              handlePromote(u.id as string, u.role)
                            }
                            className="text-xs h-7 text-emerald-500 hover:text-emerald-600 hover:bg-emerald-500/10"
                          >
                            Toggle Admin
                          </Button>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {}
          <div className="rounded-2xl border bg-background/80 backdrop-blur-xl overflow-hidden">
            <div className="p-6 border-b border-border/50 flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">
                Live Data Stream
              </h2>
              <Database className="h-4 w-4 text-emerald-500" />
            </div>
            <div className="p-4 space-y-4 max-h-[600px] overflow-y-auto">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-secondary/20 border border-border/40 space-y-2"
                >
                  <div className="flex justify-between items-start">
                    <Badge
                      variant="outline"
                      className="text-[10px] uppercase tracking-tighter"
                    >
                      {log.category}
                    </Badge>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {new Date(log.date).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-medium">
                      {log.value} {log.unit}
                    </span>
                    <span className="text-xs font-bold text-emerald-500">
                      -{log.co2Impact?.toFixed(1) || 0} kg CO₂
                    </span>
                  </div>
                </div>
              ))}
              {logs.length === 0 && (
                <div className="text-center py-10 text-muted-foreground text-xs italic">
                  No recent activity data available.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
