"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles, User, RefreshCw, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/auth-context";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  source?: "openai" | "fallback";
}

const SUGGESTED_PROMPTS = [
  {
    label: "📊 My top emission sources",
    text: "What are my top emission sources and how can I reduce them?",
  },
  {
    label: "🔮 What-if scenario",
    text: "What if I take the metro instead of driving every day?",
  },
  {
    label: "📉 Compare to Indian average",
    text: "Compare my carbon footprint to the Indian average",
  },
  {
    label: "⚡ Energy savings",
    text: "How can I reduce my energy emissions at home?",
  },
  {
    label: "🥗 Food impact",
    text: "How much CO₂ can I save by eating less meat?",
  },
  {
    label: "🌞 Solar panels",
    text: "Would installing solar panels be worth it for me in India?",
  },
];

function RenderMessage({ content }: { content: string }) {
  const lines = content.split("\n");

  return (
    <div className="space-y-1.5 text-sm leading-relaxed">
      {lines
        .map((line, i) => {
          if (line.includes("|") && line.trim().startsWith("|")) {
            if (line.replace(/\|/g, "").trim().replace(/-/g, "").trim() === "")
              return null;
            const cells = line
              .split("|")
              .filter(Boolean)
              .map((c) => c.trim());
            return (
              <div key={i} className="flex gap-3 text-xs">
                {cells.map((cell, ci) => (
                  <span
                    key={ci}
                    className={cn(
                      "flex-1",
                      ci === 0
                        ? "text-slate-400 font-medium"
                        : "text-white font-semibold"
                    )}
                  >
                    {cell.replace(/\*\*(.*?)\*\*/g, (_, t) => t)}
                  </span>
                ))}
              </div>
            );
          }

          const parts = line.split(/(\*\*.*?\*\*)/g);
          const rendered = parts.map((p, pi) =>
            p.startsWith("**") && p.endsWith("**") ? (
              <strong key={pi} className="text-white font-bold">
                {p.slice(2, -2)}
              </strong>
            ) : (
              <span key={pi}>{p}</span>
            )
          );

          if (!line.trim()) return <div key={i} className="h-1" />;
          if (line.startsWith("##"))
            return (
              <p key={i} className="text-base font-bold text-white mt-2">
                {line.replace(/^#+\s/, "")}
              </p>
            );
          if (line.startsWith("#"))
            return (
              <p key={i} className="text-lg font-black text-white mt-2">
                {line.replace(/^#+\s/, "")}
              </p>
            );
          if (line.startsWith("- ") || line.startsWith("* "))
            return (
              <p key={i} className="pl-3 text-slate-200">
                {rendered}
              </p>
            );
          if (/^\d+\./.test(line))
            return (
              <p key={i} className="pl-3 text-slate-200">
                {rendered}
              </p>
            );
          return (
            <p key={i} className="text-slate-200">
              {rendered}
            </p>
          );
        })
        .filter(Boolean)}
    </div>
  );
}

export default function AIChatPage() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: `🌱 Hi${user?.name ? ` ${user.name.split(" ")[0]}` : ""}! I'm **Aura AI** — your personal carbon footprint assistant.

I have access to your real emission data and can help you:

- 📊 Understand your carbon footprint breakdown
- 🔮 Model what-if scenarios ("What if I switch to an EV?")
- 📉 Find your **biggest** reduction opportunities
- 🌍 Compare you to Indian and global averages
- 💡 Give India-specific, actionable advice

Ask me anything about your carbon footprint, or pick one of the suggestions below!`,
      timestamp: new Date(),
      source: "fallback",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || loading) return;

      const userMsg: Message = {
        role: "user",
        content: text.trim(),
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setLoading(true);

      try {
        const response = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            messages: [...messages, userMsg]
              .filter((m) => m.source !== "fallback")
              .map(({ role, content }) => ({
                role,
                content,
              })),
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || "Failed to get AI response");
        }

        const assistantMsg: Message = {
          role: "assistant",
          content: data.response,
          timestamp: new Date(),
          source: data.source,
        };

        setMessages((prev) => [...prev, assistantMsg]);
      } catch (err) {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: "⚠️ I couldn't process that request. Please try again.",
            timestamp: new Date(),
            source: "fallback",
          },
        ]);
      } finally {
        setLoading(false);
        setTimeout(() => inputRef.current?.focus(), 100);
      }
    },
    [loading, messages]
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-4xl mx-auto">
      {}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800/60 bg-[#0b1120]/80 backdrop-blur-sm shrink-0">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500/30 to-green-600/20 border border-emerald-500/30">
          <Sparkles className="h-5 w-5 text-emerald-400" />
        </div>
        <div>
          <h1 className="text-base font-bold text-white">Aura AI Assistant</h1>
          <p className="text-xs text-slate-400">
            Powered by your real carbon data
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <div className="flex items-center gap-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1">
            <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs text-emerald-400 font-medium">
              AI Active
            </span>
          </div>
          <button
            onClick={() => setMessages(messages.slice(0, 1))}
            className="text-slate-500 hover:text-slate-300 transition-colors p-1.5 rounded-lg hover:bg-slate-800/50"
            title="Clear chat"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className={cn(
                "flex gap-3",
                msg.role === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              {}
              <div
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-sm",
                  msg.role === "user"
                    ? "bg-blue-900/40 border-blue-700/40 text-blue-300"
                    : "bg-emerald-900/40 border-emerald-700/40 text-emerald-400"
                )}
              >
                {msg.role === "user" ? (
                  <User className="h-4 w-4" />
                ) : (
                  <Sparkles className="h-4 w-4" />
                )}
              </div>

              {}
              <div
                className={cn(
                  "max-w-[80%] rounded-2xl px-4 py-3 border",
                  msg.role === "user"
                    ? "bg-blue-900/30 border-blue-700/30 rounded-tr-sm"
                    : "bg-slate-900/60 border-slate-800/60 rounded-tl-sm"
                )}
              >
                {msg.role === "assistant" ? (
                  <RenderMessage content={msg.content} />
                ) : (
                  <p className="text-sm text-white">{msg.content}</p>
                )}
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-slate-600">
                    {msg.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  {msg.source === "openai" && (
                    <span className="flex items-center gap-1 text-xs text-emerald-600">
                      <Zap className="h-3 w-3" />
                      GPT-4o
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {}
        {loading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex gap-3"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-emerald-900/40 border-emerald-700/40">
              <Sparkles className="h-4 w-4 text-emerald-400 animate-pulse" />
            </div>
            <div className="flex items-center gap-1 rounded-2xl rounded-tl-sm bg-slate-900/60 border border-slate-800/60 px-4 py-3">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-bounce"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <div ref={bottomRef} />
      </div>

      {}
      {messages.length <= 1 && (
        <div className="px-4 pb-2 shrink-0">
          <p className="text-xs text-slate-600 mb-2">Suggested questions:</p>
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTED_PROMPTS.map((prompt) => (
              <button
                key={prompt.label}
                onClick={() => sendMessage(prompt.text)}
                className="rounded-xl border border-slate-800 bg-slate-900/40 px-3 py-1.5 text-xs text-slate-300 hover:border-emerald-500/40 hover:text-emerald-400 hover:bg-emerald-950/30 transition-all duration-200"
              >
                {prompt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {}
      <div className="px-4 pb-4 shrink-0">
        <div className="flex items-end gap-2 rounded-2xl border border-slate-800 bg-slate-900/60 px-4 py-3 focus-within:border-emerald-500/40 transition-colors backdrop-blur-sm">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about your carbon footprint… (Enter to send)"
            className="flex-1 resize-none bg-transparent text-sm text-white placeholder-slate-600 outline-none max-h-32 min-h-[1.5rem]"
            rows={1}
            disabled={loading}
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || loading}
            className={cn(
              "flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-all duration-200",
              input.trim() && !loading
                ? "bg-emerald-500 text-white hover:bg-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.4)]"
                : "bg-slate-800 text-slate-600 cursor-not-allowed"
            )}
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
        <p className="text-center text-xs text-slate-700 mt-1.5">
          Aura AI uses your real emission data for personalized insights
        </p>
      </div>
    </div>
  );
}
