"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Car,
  Zap,
  Leaf,
  Trash2,
  TrendingDown,
  RefreshCw,
  ArrowRight,
  Calculator,
  CheckCircle2,
  AlertCircle,
  Clock,
  ChevronRight,
} from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  category: string;
  impact: "high" | "medium" | "low";
  estimatedSaving: number;
  effort: "easy" | "medium" | "hard";
  timeframe: string;
  actionItems?: string[];
  co2Saved?: number;
}

interface RecommendationsData {
  hasData: boolean;
  totalEmissions?: number;
  breakdown?: {
    transport: number;
    energy: number;
    food: number;
    waste: number;
  };
  recommendations: Recommendation[];
  aiEnabled: boolean;
  message?: string;
}

const categoryIcon = (cat: string) => {
  const c = cat?.toLowerCase() ?? "";
  if (c.includes("transport") || c.includes("travel")) return Car;
  if (c.includes("energy") || c.includes("electric")) return Zap;
  if (c.includes("food") || c.includes("diet")) return Leaf;
  if (c.includes("waste") || c.includes("recycl")) return Trash2;
  return TrendingDown;
};

const categoryColor = (cat: string) => {
  const c = cat?.toLowerCase() ?? "";
  if (c.includes("transport"))
    return {
      bg: "bg-blue-500/10",
      border: "border-blue-500/20",
      text: "text-blue-400",
      iconBg: "bg-blue-500/15",
    };
  if (c.includes("energy"))
    return {
      bg: "bg-amber-500/10",
      border: "border-amber-500/20",
      text: "text-amber-400",
      iconBg: "bg-amber-500/15",
    };
  if (c.includes("food"))
    return {
      bg: "bg-emerald-500/10",
      border: "border-emerald-500/20",
      text: "text-emerald-400",
      iconBg: "bg-emerald-500/15",
    };
  if (c.includes("waste"))
    return {
      bg: "bg-purple-500/10",
      border: "border-purple-500/20",
      text: "text-purple-400",
      iconBg: "bg-purple-500/15",
    };
  return {
    bg: "bg-slate-500/10",
    border: "border-slate-500/20",
    text: "text-slate-400",
    iconBg: "bg-slate-500/15",
  };
};

const impactBadge = (impact: string) =>
  ({
    high: "bg-red-500/15 text-red-400 border-red-500/25",
    medium: "bg-amber-500/15 text-amber-400 border-amber-500/25",
    low: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  })[impact] ?? "bg-slate-500/15 text-slate-400 border-slate-500/25";

const effortLabel = {
  easy: "Quick win",
  medium: "Moderate",
  hard: "Long-term",
};

function SkeletonCard() {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5 space-y-3 animate-pulse">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-slate-800" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-3/4 bg-slate-800 rounded" />
          <div className="h-3 w-1/3 bg-slate-800 rounded" />
        </div>
      </div>
      <div className="h-12 bg-slate-800 rounded" />
      <div className="flex gap-2">
        <div className="h-6 w-16 bg-slate-800 rounded-full" />
        <div className="h-6 w-20 bg-slate-800 rounded-full" />
      </div>
    </div>
  );
}

function RecommendationCard({
  rec,
  index,
}: {
  rec: Recommendation;
  index: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const Icon = categoryIcon(rec.category);
  const colors = categoryColor(rec.category);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      className={cn(
        "rounded-2xl border p-5 cursor-pointer transition-all duration-300",
        colors.bg,
        colors.border,
        "hover:scale-[1.01] hover:shadow-lg active:scale-[0.99]"
      )}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-start gap-3">
        {}
        <div
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
            colors.iconBg
          )}
        >
          <Icon className={cn("h-5 w-5", colors.text)} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-semibold text-white leading-snug">
              {rec.title}
            </h3>
            <ChevronRight
              className={cn(
                "h-4 w-4 shrink-0 text-slate-500 transition-transform mt-0.5",
                expanded && "rotate-90"
              )}
            />
          </div>
          <p className="text-xs text-slate-400 mt-0.5">{rec.category}</p>
        </div>
      </div>

      <p className="text-sm text-slate-300 mt-3 leading-relaxed">
        {rec.description}
      </p>

      {}
      <div className="flex flex-wrap items-center gap-2 mt-3">
        <span
          className={cn(
            "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium",
            impactBadge(rec.impact)
          )}
        >
          {rec.impact === "high"
            ? "⬆ High impact"
            : rec.impact === "medium"
              ? "→ Medium"
              : "↓ Low impact"}
        </span>
        <span className="inline-flex items-center gap-1 rounded-full border border-slate-700 bg-slate-800/50 px-2 py-0.5 text-xs text-slate-400">
          <Clock className="h-3 w-3" />
          {effortLabel[rec.effort] ?? rec.effort}
        </span>
        {(rec.estimatedSaving > 0 || rec.co2Saved) && (
          <span className="inline-flex items-center gap-1 rounded-full border border-emerald-700/40 bg-emerald-950/40 px-2 py-0.5 text-xs text-emerald-400 font-semibold">
            ~{(rec.co2Saved ?? rec.estimatedSaving).toFixed(0)} kg CO₂/yr saved
          </span>
        )}
      </div>

      <AnimatePresence>
        {expanded && rec.actionItems && rec.actionItems.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="mt-4 border-t border-white/5 pt-3 space-y-2">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide">
                Action steps
              </p>
              {rec.actionItems.map((item, i) => (
                <div key={i} className="flex items-start gap-2">
                  <CheckCircle2
                    className={cn("h-3.5 w-3.5 shrink-0 mt-0.5", colors.text)}
                  />
                  <span className="text-xs text-slate-300">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function RecommendationsPage() {
  const [data, setData] = useState<RecommendationsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState("all");

  const fetchRecommendations = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ai/recommendations", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to load recommendations");
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const categories = data?.recommendations
    ? [
        "all",
        ...Array.from(
          new Set(
            data.recommendations
              .map((r) => r.category?.toLowerCase().split(" ")[0])
              .filter(Boolean)
          )
        ),
      ]
    : ["all"];

  const filtered = (data?.recommendations ?? []).filter(
    (r) =>
      activeFilter === "all" || r.category?.toLowerCase().includes(activeFilter)
  );

  if (!loading && data && !data.hasData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-5">
          <Sparkles className="h-8 w-8 text-emerald-400" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">No data yet</h1>
        <p className="text-slate-400 max-w-sm mb-6">
          Calculate your carbon footprint first — Aura AI will then generate
          personalized recommendations based on your real emission data.
        </p>
        <Link
          href="/calculator"
          className="inline-flex items-center gap-2 rounded-xl bg-emerald-500 px-5 py-3 text-sm font-semibold text-white hover:bg-emerald-400 transition-colors"
        >
          <Calculator className="h-4 w-4" />
          Open Carbon Calculator
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 px-4 sm:px-0 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              AI Recommendations
            </h1>
            {data?.aiEnabled && (
              <span className="flex items-center gap-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 text-xs font-bold text-emerald-400">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                AI Active
              </span>
            )}
          </div>
          <p className="text-sm text-slate-400">
            {data?.totalEmissions
              ? `Based on your ${data.totalEmissions.toFixed(1)} kg CO₂/month footprint — personalized for India`
              : "Personalized sustainability actions for you"}
          </p>
        </div>
        <button
          onClick={fetchRecommendations}
          disabled={loading}
          className="self-start sm:self-auto flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800/50 px-3 py-2 text-sm text-slate-300 hover:border-emerald-500/40 hover:text-emerald-400 transition-all disabled:opacity-50"
        >
          <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
          Refresh
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-3 rounded-xl border border-red-500/20 bg-red-950/20 px-4 py-3 text-sm text-red-400">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
          <button
            onClick={fetchRecommendations}
            className="ml-auto text-xs underline hover:text-red-300"
          >
            Retry
          </button>
        </div>
      )}

      {data?.breakdown && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
          {[
            {
              label: "Transport",
              value: data.breakdown.transport,
              icon: Car,
              color: "text-blue-400",
            },
            {
              label: "Energy",
              value: data.breakdown.energy,
              icon: Zap,
              color: "text-amber-400",
            },
            {
              label: "Food",
              value: data.breakdown.food,
              icon: Leaf,
              color: "text-emerald-400",
            },
            {
              label: "Waste",
              value: data.breakdown.waste,
              icon: Trash2,
              color: "text-purple-400",
            },
          ].map(({ label, value, icon: Icon, color }) => (
            <div
              key={label}
              className="rounded-xl border border-slate-800 bg-slate-900/40 p-3"
            >
              <div className="flex items-center gap-2 mb-0.5">
                <Icon className={cn("h-3.5 w-3.5", color)} />
                <span className="text-xs text-slate-400">{label}</span>
              </div>
              <p className="text-lg font-bold text-white">
                {value.toFixed(0)}
                <span className="text-xs font-normal text-slate-500 ml-1">
                  kg
                </span>
              </p>
            </div>
          ))}
        </div>
      )}

      {categories.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={cn(
                "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium capitalize transition-all border",
                activeFilter === cat
                  ? "bg-emerald-500 text-white border-emerald-500"
                  : "border-slate-700 text-slate-400 hover:border-emerald-500/40 hover:text-emerald-400"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
          : filtered.map((rec, i) => (
              <RecommendationCard key={rec.id || i} rec={rec} index={i} />
            ))}
      </div>

      {!loading && filtered.length === 0 && data?.hasData && (
        <div className="text-center py-12 text-slate-500">
          <p>No recommendations in this category.</p>
          <button
            onClick={() => setActiveFilter("all")}
            className="text-emerald-400 text-sm mt-1 hover:underline"
          >
            Show all
          </button>
        </div>
      )}

      {!loading && data && !data.aiEnabled && data.hasData && (
        <div className="rounded-xl border border-amber-500/20 bg-amber-950/20 p-4 text-sm text-amber-300">
          <strong className="block font-semibold mb-0.5">
            Using rule-based recommendations
          </strong>
          Add your OpenAI / OpenRouter API key to enable personalized AI
          recommendations powered by Llama 3.3 70B.
        </div>
      )}
    </div>
  );
}
