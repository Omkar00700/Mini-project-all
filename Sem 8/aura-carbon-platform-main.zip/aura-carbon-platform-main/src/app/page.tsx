"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Leaf,
  ArrowRight,
  Calculator,
  Github,
  Twitter,
  Linkedin,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import InteractiveGlobe from "@/components/home/interactive-globe";
import CarbonDataShowcase from "@/components/home/carbon-data-showcase";
import { Header } from "@/components/layout/header";

function MagneticText() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    setMousePosition({
      x: (clientX / innerWidth - 0.5) * 40,
      y: (clientY / innerHeight - 0.5) * -40,
    });
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      className="perspective-1000 relative inline-flex items-center justify-center gap-4 md:gap-8 z-20 flex-wrap"
      animate={{
        rotateX: mousePosition.y,
        rotateY: mousePosition.x,
      }}
      transition={{ type: "spring", stiffness: 150, damping: 15 }}
      style={{ transformStyle: "preserve-3d" }}
    >
      <div
        className="absolute inset-0 bg-primary/20 blur-[120px] -z-10 rounded-full"
        style={{ transform: "translateZ(-50px)" }}
      />
      <h1
        className="text-[12vw] sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter leading-none m-0 p-0"
        style={{ transform: "translateZ(50px)" }}
      >
        <span className="bg-gradient-to-r from-foreground via-foreground/90 to-muted-foreground bg-clip-text text-transparent">
          Meet
        </span>
      </h1>

      <motion.div
        className="p-3 md:p-4 lg:p-5 bg-gradient-to-br from-primary to-emerald-600 rounded-full shadow-[0_0_60px_rgba(16,185,129,0.5)] border border-primary/40 flex items-center justify-center cursor-pointer"
        style={{ transform: "translateZ(80px)" }}
        animate={{
          y: [0, -20, 0],
          rotateZ: [0, 10, -10, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        whileHover={{
          scale: 1.25,
          rotateZ: 180,
          boxShadow: "0 0 100px rgba(16,185,129,0.8)",
        }}
      >
        <Leaf
          className="w-10 h-10 md:w-16 md:h-16 lg:w-20 lg:h-20 text-white"
          strokeWidth={1.5}
        />
      </motion.div>

      <h1
        className="text-[12vw] sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter leading-none m-0 p-0"
        style={{ transform: "translateZ(50px)" }}
      >
        <span
          className="bg-gradient-to-r from-emerald-400 via-primary to-emerald-300 dark:from-emerald-400 dark:via-emerald-300 dark:to-emerald-200 bg-clip-text text-transparent inline-block"
          style={{ textShadow: "0 0 80px rgba(16, 185, 129, 0.4)" }}
        >
          Aura
        </span>
      </h1>
    </motion.div>
  );
}

function EcosystemShowcase() {
  return (
    <section className="relative py-32 overflow-hidden bg-[#010804] border-t border-emerald-900/30 text-white">
      {}
      <div className="absolute top-0 right-0 w-[40vw] h-[40vw] rounded-full bg-emerald-500/10 blur-[150px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[50vw] h-[50vw] rounded-full bg-blue-500/5 blur-[150px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-24">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl lg:text-7xl font-black tracking-tighter mb-6"
          >
            A Living Connection to{" "}
            <span className="text-emerald-400 italic">Our Planet.</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl md:text-2xl text-emerald-100/60 font-medium leading-relaxed"
          >
            Aura transcends simple tracking. We visualize your profound
            relationship with the environment, creating a breathing ecosystem of
            sustainable progress.
          </motion.p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {}
          <div className="relative h-[500px] rounded-[3rem] overflow-hidden bg-gradient-to-br from-emerald-900/20 to-[#010804] border border-emerald-500/20 p-8 flex flex-col items-center justify-center shadow-2xl">
            <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] [mask-image:linear-gradient(to_bottom,transparent,black,transparent)]" />
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border border-dashed border-emerald-500/30 flex items-center justify-center"
            >
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute w-48 h-48 md:w-56 md:h-56 rounded-full bg-emerald-500/10 blur-xl"
              />
              <Leaf className="w-20 h-20 text-emerald-400 z-10 drop-shadow-[0_0_30px_rgba(52,211,153,0.8)]" />

              {}
              <div className="absolute top-0 w-4 h-4 rounded-full bg-emerald-400 shadow-[0_0_15px_rgba(52,211,153,1)]" />
              <div className="absolute bottom-4 right-4 w-3 h-3 rounded-full bg-blue-400 shadow-[0_0_15px_rgba(96,165,250,1)]" />
              <div className="absolute top-1/2 left-0 w-2 h-2 rounded-full bg-purple-400 shadow-[0_0_10px_rgba(192,132,252,1)]" />
            </motion.div>
          </div>

          {}
          <div className="space-y-12">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="group"
            >
              <h3 className="text-3xl font-bold mb-3 flex items-center gap-4 text-emerald-50">
                <span className="flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition-transform">
                  01
                </span>
                Invisible Harmony
              </h3>
              <p className="text-lg text-emerald-100/60 leading-relaxed pl-16">
                Connect your lifestyle natively. Aura tracks your footprint
                silently in the background, transforming complex daily habits
                into elegant, understandable environmental metrics.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="group"
            >
              <h3 className="text-3xl font-bold mb-3 flex items-center gap-4 text-emerald-50">
                <span className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-500/20 text-blue-400 group-hover:scale-110 transition-transform">
                  02
                </span>
                Actionable Wisdom
              </h3>
              <p className="text-lg text-emerald-100/60 leading-relaxed pl-16">
                Our AI doesn&apos;t just judge your past; it illuminates your
                future. Test life changes instantly and see exactly how your
                microscopic choices heal the planet in real-time.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="group"
            >
              <h3 className="text-3xl font-bold mb-3 flex items-center gap-4 text-emerald-50">
                <span className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-500/20 text-purple-400 group-hover:scale-110 transition-transform">
                  03
                </span>
                Collective Impact
              </h3>
              <p className="text-lg text-emerald-100/60 leading-relaxed pl-16">
                Watch your individual efforts multiply when joined with a
                localized ecosystem. Compare, compete, and offset together to
                create massive, undeniable terrestrial change.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="min-h-screen bg-background selection:bg-primary/30 selection:text-primary">
      {}
      <Header className="fixed top-0 w-full z-50 bg-background/60 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60 border-b border-border/40" />

      {}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0 pointer-events-auto">
          {mounted && <InteractiveGlobe />}
        </div>

        <div className="relative z-10 w-full container mx-auto px-6 text-center pt-20 pointer-events-none">
          {}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="flex justify-center mb-8 pointer-events-auto mt-4 md:mt-12"
          >
            <div className="inline-flex items-center gap-2 px-6 py-2 rounded-full border border-primary/20 bg-background/30 backdrop-blur-md shadow-[0_0_30px_var(--primary-20)]">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-primary text-xs md:text-sm font-bold tracking-widest uppercase">
                Next-Generation Carbon Intelligence
              </span>
            </div>
          </motion.div>

          {}
          <div className="mb-16 select-none pointer-events-auto flex justify-center">
            <MagneticText />
          </div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-2xl md:text-3xl text-muted-foreground max-w-4xl mx-auto mb-16 font-medium leading-relaxed"
          >
            Empowering your journey to a sustainable zero-carbon future.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 pointer-events-auto"
          >
            <Link href="/dashboard">
              <Button
                size="lg"
                className="h-16 px-10 text-xl font-bold rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_40px_rgba(16,185,129,0.4)] hover:shadow-[0_0_60px_rgba(16,185,129,0.6)] border border-primary/20 group transition-all hover:scale-105 active:scale-95"
              >
                Go to Dashboard
                <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/calculator">
              <Button
                size="lg"
                variant="outline"
                className="h-16 px-10 text-xl font-bold rounded-full bg-background/50 hover:bg-background/80 backdrop-blur-md border border-border/80 group transition-all hover:border-primary/50 hover:scale-105 active:scale-95 shadow-sm"
              >
                <Calculator className="mr-3 w-6 h-6 text-primary group-hover:rotate-12 transition-transform" />
                Calculate your Carbon Footprint
              </Button>
            </Link>
          </motion.div>
        </div>

        {}
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-background to-transparent z-10 pointer-events-none" />
      </section>

      {}
      <div className="relative z-20 bg-background">
        <CarbonDataShowcase isDark={true} />
      </div>

      {}
      <EcosystemShowcase />

      {}
      <footer className="bg-background border-t border-border/50 pt-24 pb-12 overflow-hidden relative">
        <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-primary/5 blur-[150px] pointer-events-none rounded-full" />

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-16 mb-20">
            {}
            <div className="lg:col-span-2">
              <Link
                href="/"
                className="inline-flex items-center space-x-3 group perspective-1000 mb-6"
              >
                <div className="p-2.5 bg-gradient-to-br from-primary to-emerald-600 rounded-xl shadow-lg border border-primary/20">
                  <Leaf className="h-6 w-6 text-white" />
                </div>
                <span className="text-3xl font-black tracking-tighter text-foreground">
                  Aura
                </span>
              </Link>
              <p className="text-xl text-muted-foreground mb-8 max-w-sm font-medium leading-relaxed">
                Designing a harmonious balance between technology and nature.
              </p>
              <div className="flex items-center gap-4">
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-white transition-all shadow-sm"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-foreground hover:text-background transition-all shadow-sm"
                >
                  <Github className="w-5 h-5" />
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-muted-foreground hover:bg-blue-600 hover:text-white transition-all shadow-sm"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
            </div>

            {}
            <div>
              <h4 className="text-lg font-bold text-foreground mb-6">
                Features
              </h4>
              <ul className="space-y-4">
                <li>
                  <Link
                    href="/dashboard"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium"
                  >
                    Dashboard
                  </Link>
                </li>
                <li>
                  <Link
                    href="/calculator"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium"
                  >
                    Calculator
                  </Link>
                </li>
                <li>
                  <Link
                    href="/achievements"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium"
                  >
                    Achievements
                  </Link>
                </li>
                <li>
                  <Link
                    href="/ai-chat"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium"
                  >
                    ✨ AI Intelligence
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold text-foreground mb-6">
                Company
              </h4>
              <ul className="space-y-4">
                <li>
                  <Link
                    href="/about"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/contact"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="/careers"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Careers
                  </Link>
                </li>
                <li>
                  <Link
                    href="/privacy"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold text-foreground mb-6">
                Resources
              </h4>
              <ul className="space-y-4">
                <li>
                  <Link
                    href="/blog"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Blog & Insights
                  </Link>
                </li>
                <li>
                  <Link
                    href="/research"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Climate Research
                  </Link>
                </li>
                <li>
                  <Link
                    href="/community"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Community Forum
                  </Link>
                </li>
                <li>
                  <Link
                    href="/support"
                    className="text-muted-foreground hover:text-primary transition-colors font-medium cursor-pointer"
                  >
                    Help Center
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-border/40 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-muted-foreground font-medium">
              &copy; {new Date().getFullYear()} Aura Platform. All rights
              reserved.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="font-semibold tracking-wide">
                Made with{" "}
                <span className="text-red-500 animate-pulse text-[1.2rem]">
                  ❤️
                </span>{" "}
                for the Planet
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
