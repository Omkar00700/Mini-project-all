"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/auth-context";
import {
  CheckCircle,
  Save,
  AlertCircle,
  Calculator,
  Sparkles,
  Plus,
  Trash2,
  ArrowRight,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface CalculationItem {
  category: string;
  subcategory: string;
  value: number | string;
  unit?: string;
}

interface CalculationResult {
  totalEmissionsKg: number;
  breakdown: Array<{
    itemIndex: number;
    category: string;
    subcategory: string;
    value: number;
    unit: string;
    kgCO2: number;
    factor: {
      co2_per_unit: number;
      unit: string;
      source: string;
    };
  }>;
}

import { useGamificationStore } from "@/store/gamification-store";

export default function CalculatorPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [items, setItems] = useState<CalculationItem[]>([
    { category: "transport", subcategory: "car_petrol", value: "", unit: "km" },
  ]);
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [savingActivity, setSavingActivity] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addItem = () => {
    setItems([
      ...items,
      {
        category: "transport",
        subcategory: "car_petrol",
        value: "",
        unit: "km",
      },
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (index: number, field: string, value: string | number) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const { processServerReward } = useGamificationStore();

  const calculate = async () => {
    setLoading(true);
    setError(null);
    setSaved(false);

    try {
      const response = await fetch("/api/carbon/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          items: items
            .filter(
              (item) =>
                item.category &&
                item.subcategory &&
                item.value !== "" &&
                Number(item.value) > 0
            )
            .map((item) => ({ ...item, value: Number(item.value) })),
          region: "India",
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Calculation failed");
      }

      const data = await response.json();
      setResult(data);

      if (data.reward) {
        processServerReward(data.reward);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const saveCalculation = async () => {
    if (!user) {
      router.push("/auth/login");
      return;
    }

    if (!result) return;

    setSaving(true);
    setError(null);

    try {
      const response = await fetch("/api/carbon/save-calculation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          totalEmissionsKg: result.totalEmissionsKg,
          breakdown: result.breakdown.map((item) => ({
            category: item.category,
            subcategory: item.subcategory,
            value: item.value,
            unit: item.unit,
            kgCO2: item.kgCO2,
          })),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to save calculation");
      }

      setSaved(true);
      router.refresh();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to save calculation"
      );
    } finally {
      setSaving(false);
    }
  };

  const saveActivity = async (item: CalculationResult["breakdown"][0]) => {
    if (!user) {
      router.push("/auth/login");
      return;
    }

    setSavingActivity(true);
    setError(null);

    try {
      const response = await fetch("/api/activities", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          category: item.category,
          subcategory: item.subcategory,
          value: item.value,
          unit: item.unit,
          name: `${item.category} - ${item.subcategory}`,
          isRecurring: false,
          frequency: "monthly",
          notes: `Saved from calculator: ${item.value} ${item.unit}`,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to save activity");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save activity");
    } finally {
      setSavingActivity(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020804] text-foreground font-sans relative overflow-hidden pb-20">
      {}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.1)_0%,transparent_70%)] blur-[80px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-[radial-gradient(circle_at_center,rgba(20,184,166,0.1)_0%,transparent_70%)] blur-[80px]" />
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage:
              'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")',
          }}
        ></div>
      </div>

      <div className="container mx-auto pt-24 px-4 max-w-5xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center justify-center p-3 bg-emerald-500/10 rounded-2xl mb-6 border border-emerald-500/20 text-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.2)]">
            <Calculator className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 text-white">
            Precision{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
              Calculator
            </span>
          </h1>
          <p className="text-lg text-muted-foreground font-light max-w-2xl mx-auto">
            Input your consumption data to calculate your immediate
            environmental impact using hyper-local emission factors.
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-12 md:items-start">
          {}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="md:col-span-7"
          >
            <Card className="bg-black/40 backdrop-blur-xl border-white/10 shadow-2xl overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500" />
              <CardHeader className="pb-4 border-b border-white/5 space-y-1 bg-white/5">
                <CardTitle className="text-2xl text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-400" /> Activity
                  Data
                </CardTitle>
                <CardDescription className="text-white/60 text-sm">
                  Add lines for your energy, transport, or waste.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6 p-6">
                <AnimatePresence>
                  {items.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, height: 0, scale: 0.95 }}
                      animate={{ opacity: 1, height: "auto", scale: 1 }}
                      exit={{ opacity: 0, height: 0, scale: 0.95 }}
                      transition={{ duration: 0.3 }}
                      className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-4 hover:border-emerald-500/30 transition-colors group"
                    >
                      <div className="flex justify-between items-center">
                        <Label className="text-sm font-semibold text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center text-xs text-emerald-300">
                            {index + 1}
                          </span>
                          Entry
                        </Label>
                        {items.length > 1 && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-white/40 hover:text-red-400 hover:bg-red-400/10 rounded-full opacity-0 group-hover:opacity-100 transition-all"
                            onClick={() => removeItem(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label
                            htmlFor={`category-${index}`}
                            className="text-white/80"
                          >
                            Category
                          </Label>
                          <Select
                            value={item.category}
                            onValueChange={(value) =>
                              updateItem(index, "category", value as any)
                            }
                          >
                            <SelectTrigger className="bg-black/50 border-white/10 text-white focus:ring-emerald-500/50 mt-1.5 h-11">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#0f172a] border-white/10 text-white">
                              <SelectItem value="energy">Energy</SelectItem>
                              <SelectItem value="transportation">
                                Transportation
                              </SelectItem>
                              <SelectItem value="food">Food</SelectItem>
                              <SelectItem value="waste">Waste</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label
                            htmlFor={`subcategory-${index}`}
                            className="text-white/80"
                          >
                            Subcategory
                          </Label>
                          <Select
                            value={item.subcategory}
                            onValueChange={(value) =>
                              updateItem(index, "subcategory", value)
                            }
                          >
                            <SelectTrigger className="bg-black/50 border-white/10 text-white focus:ring-emerald-500/50 mt-1.5 h-11">
                              <SelectValue placeholder="Select subcategory" />
                            </SelectTrigger>
                            <SelectContent className="bg-[#0f172a] border-white/10 text-white">
                              {item.category === "energy" && (
                                <>
                                  <SelectItem value="electricity">
                                    Electricity
                                  </SelectItem>
                                  <SelectItem value="lpg">LPG</SelectItem>
                                </>
                              )}
                              {item.category === "transportation" && (
                                <>
                                  <SelectItem value="personal_vehicle_gasoline">
                                    Petrol Vehicle
                                  </SelectItem>
                                  <SelectItem value="personal_vehicle_diesel">
                                    Diesel Vehicle
                                  </SelectItem>
                                  <SelectItem value="cng">
                                    CNG Vehicle
                                  </SelectItem>
                                  <SelectItem value="bus">Bus</SelectItem>
                                  <SelectItem value="train">Train</SelectItem>
                                  <SelectItem value="auto_rickshaw">
                                    Auto Rickshaw
                                  </SelectItem>
                                  <SelectItem value="motorcycle">
                                    Motorcycle
                                  </SelectItem>
                                </>
                              )}
                              {item.category === "food" && (
                                <>
                                  <SelectItem value="chicken">
                                    Chicken
                                  </SelectItem>
                                  <SelectItem value="rice">Rice</SelectItem>
                                  <SelectItem value="wheat">Wheat</SelectItem>
                                  <SelectItem value="lentils">
                                    Lentils
                                  </SelectItem>
                                </>
                              )}
                              {item.category === "waste" && (
                                <SelectItem value="municipal_solid_waste">
                                  Municipal Solid Waste
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label
                          htmlFor={`value-${index}`}
                          className="text-white/80"
                        >
                          Amount Value
                        </Label>
                        <div className="relative mt-1.5">
                          <Input
                            id={`value-${index}`}
                            type="number"
                            className="bg-black/50 border-white/10 text-white focus:ring-emerald-500/50 h-11 text-lg font-mono font-medium"
                            value={item.value === "" ? "" : item.value}
                            onChange={(e) =>
                              updateItem(
                                index,
                                "value",
                                e.target.value === ""
                                  ? ""
                                  : parseFloat(e.target.value) || 0
                              )
                            }
                            placeholder="0.00"
                          />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>

                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button
                    onClick={addItem}
                    variant="outline"
                    className="flex-1 bg-white/5 border-white/10 text-white hover:bg-white/10 hover:text-white h-12 rounded-xl group"
                  >
                    <Plus className="w-5 h-5 mr-2 group-hover:rotate-90 transition-transform" />{" "}
                    Add Activity
                  </Button>
                  <Button
                    onClick={calculate}
                    disabled={loading}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] h-12 rounded-xl text-lg relative overflow-hidden group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <span className="relative z-10 flex items-center justify-center">
                      {loading ? "Crunching Data..." : "Calculate Emissions"}
                      {!loading && (
                        <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                      )}
                    </span>
                  </Button>
                </div>

                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3"
                  >
                    <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-red-400 text-sm font-medium">{error}</p>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="md:col-span-5"
          >
            <Card className="bg-gradient-to-b from-[#0f172a] to-black/80 backdrop-blur-xl border-white/10 shadow-2xl sticky top-32 overflow-hidden">
              <div className="absolute -top-32 -right-32 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]" />
              <CardHeader className="border-b border-white/5 bg-white/5 pb-4">
                <CardTitle className="text-xl text-white">
                  Impact Report
                </CardTitle>
                <CardDescription className="text-white/50">
                  Your calculated carbon footprint
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 relative z-10">
                {result ? (
                  <div className="space-y-6">
                    <motion.div
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-center p-8 bg-gradient-to-br from-emerald-500/10 to-teal-500/5 rounded-3xl border border-emerald-500/20 shadow-inner"
                    >
                      <p className="text-emerald-400 text-sm font-bold uppercase tracking-widest mb-2">
                        Total Estimated Footprint
                      </p>
                      <div className="text-5xl font-black text-white tracking-tighter drop-shadow-lg flex items-baseline justify-center gap-2">
                        {result.totalEmissionsKg.toFixed(2)}{" "}
                        <span className="text-xl text-emerald-500/80 font-medium">
                          kg CO₂e
                        </span>
                      </div>
                    </motion.div>

                    {}
                    <div className="space-y-4">
                      {saved ? (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex items-center gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl"
                        >
                          <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
                          <p className="text-sm font-medium text-emerald-100">
                            Saved securely to your dashboard.
                          </p>
                        </motion.div>
                      ) : (
                        <div className="flex gap-3">
                          <Button
                            onClick={saveCalculation}
                            disabled={saving || !user}
                            className="flex-1 bg-white text-black hover:bg-white/90 font-bold h-12 rounded-xl border border-white/20"
                          >
                            {saving ? (
                              <div className="flex items-center">
                                <div className="animate-spin rounded-full h-4 w-4 border-2 border-black border-t-transparent mr-2" />
                                Saving...
                              </div>
                            ) : (
                              <>
                                <Save className="h-4 w-4 mr-2" />{" "}
                                {user ? "Record to Dashboard" : "Login to Save"}
                              </>
                            )}
                          </Button>
                          {!user && (
                            <Button
                              onClick={() => router.push("/auth/login")}
                              variant="outline"
                              className="bg-white/5 border-white/10 text-white hover:bg-white/10 h-12 rounded-xl"
                            >
                              Login
                            </Button>
                          )}
                        </div>
                      )}

                      {!user && !saved && (
                        <div className="flex flex-col gap-2 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                          <div className="flex items-center gap-2 text-amber-400">
                            <AlertCircle className="h-4 w-4 shrink-0" />
                            <span className="text-sm font-bold">
                              Unsaved Progress
                            </span>
                          </div>
                          <p className="text-xs text-amber-200/80 leading-relaxed">
                            By logging in, you can securely track the reduction
                            of this footprint over time across personalized
                            dashboards.
                          </p>
                        </div>
                      )}
                    </div>

                    <Separator className="bg-white/10" />

                    <div className="space-y-4">
                      <h4 className="font-semibold text-white/80 text-sm tracking-wide uppercase">
                        Breakdown
                      </h4>
                      <div className="space-y-3">
                        {result.breakdown.map((item, index) => (
                          <motion.div
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            key={index}
                            className="p-4 bg-white/5 border border-white/10 rounded-2xl flex justify-between items-center group relative overflow-hidden"
                          >
                            <div className="absolute inset-y-0 left-0 w-1 bg-emerald-500 rounded-l-2xl opacity-50" />
                            <div className="pl-2">
                              <div className="text-xs font-bold text-emerald-400 mb-0.5 tracking-wider uppercase">
                                {item.category}
                              </div>
                              <p className="font-medium text-white tracking-tight">
                                {item.subcategory.replace(/_/g, " ")}
                              </p>
                              <p className="text-xs text-white/40 mt-1 font-mono">
                                {item.value} {item.unit} • factor:{" "}
                                {item.factor.co2_per_unit}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-lg text-white font-mono">
                                {item.kgCO2.toFixed(1)}
                              </p>
                              <p className="text-[10px] text-white/40">
                                kg CO₂
                              </p>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-20 text-white/40 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-4 text-white/20">
                      <Calculator className="w-8 h-8" />
                    </div>
                    <p className="font-medium text-white/60">
                      Awaiting Data Input
                    </p>
                    <p className="text-sm mt-2 max-w-[200px]">
                      Fill out your activities to see the detailed emissions
                      breakdown and recommendations.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
