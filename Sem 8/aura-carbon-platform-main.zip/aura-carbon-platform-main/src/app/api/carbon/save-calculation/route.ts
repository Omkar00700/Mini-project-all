import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { revalidatePath } from "next/cache";
import { achievementService } from "@/services/gamification/achievement.service";

interface SaveCalculationRequest {
  totalEmissionsKg: number;
  breakdown: Array<{
    category: string;
    subcategory: string;
    value: number;
    unit: string;
    kgCO2: number;
  }>;
  periodStart?: string;
  periodEnd?: string;
  notes?: string;
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const payload: SaveCalculationRequest = await request.json();
    const { totalEmissionsKg, breakdown, periodStart, periodEnd, notes } =
      payload;

    if (typeof totalEmissionsKg !== "number" || totalEmissionsKg < 0) {
      return NextResponse.json(
        { error: "Valid totalEmissionsKg is required" },
        { status: 400 }
      );
    }

    if (!Array.isArray(breakdown) || breakdown.length === 0) {
      return NextResponse.json(
        { error: "breakdown array is required and cannot be empty" },
        { status: 400 }
      );
    }

    const now = new Date();
    const defaultPeriodStart = periodStart
      ? new Date(periodStart)
      : new Date(now.getFullYear(), now.getMonth(), 1);
    const defaultPeriodEnd = periodEnd
      ? new Date(periodEnd)
      : new Date(now.getFullYear(), now.getMonth() + 1, 0);

    const breakdownObj: Record<string, number> = {};
    breakdown.forEach((item) => {
      const key = item.category;
      breakdownObj[key] = (breakdownObj[key] || 0) + item.kgCO2;
    });

    const calculation = await prisma.carbonCalculation.create({
      data: {
        userId: user.id,
        periodStart: defaultPeriodStart,
        periodEnd: defaultPeriodEnd,
        totalEmissions: totalEmissionsKg,
        breakdown: breakdownObj,
        confidenceScore: 0.85,
        metadata: {
          calculation_method: "manual_calculator",
          emission_factors_version: "2024.1",
          data_completeness: 0.95,
          notes: notes || null,
          saved_at: new Date().toISOString(),
        },
      },
    });

    const activityPromises = breakdown.map(async (item) => {
      return prisma.activityData.create({
        data: {
          userId: user.id,
          category: item.category,
          subcategory: item.subcategory,
          value: item.value,
          unit: item.unit,
          date: defaultPeriodStart,
          source: "manual_calculator",
          metadata: {
            kgCO2: item.kgCO2,
            calculation_id: calculation.id,
          },
        },
      });
    });

    await Promise.all(activityPromises);

    try {
      revalidatePath("/dashboard");
    } catch (cacheError) {
      console.error("Failed to revalidate dashboard path:", cacheError);
    }

    let reward = null;
    try {
      reward = await achievementService.processAction(
        user.id,
        "CARBON_CALCULATION"
      );
    } catch (rewardError) {
      console.error("Failed to process calculation reward:", rewardError);
    }

    return NextResponse.json({
      success: true,
      calculation: {
        id: calculation.id,
        totalEmissions: calculation.totalEmissions,
        periodStart: calculation.periodStart,
        periodEnd: calculation.periodEnd,
        savedAt: calculation.createdAt,
      },
      reward,
      message: "Carbon calculation saved successfully",
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to save calculation" },
      { status: 500 }
    );
  }
}
