import { NextRequest } from "next/server";
import { POST, GET } from "../route";

jest.mock("@/lib/auth/middleware", () => ({
  createAuthenticatedRoute: (handler: any) => handler,
}));

jest.mock("@/services/energy-calculator", () => ({
  energyCalculator: {
    calculateEnergyFootprint: jest.fn(),
  },
}));

jest.mock("@/services/carbon-calculators", () => ({
  carbonCalculatorsService: {
    getEnergyRecommendations: jest.fn(),
  },
}));

import { energyCalculator } from "@/services/energy-calculator";
import { carbonCalculatorsService } from "@/services/carbon-calculators";

const mockEnergyCalculator = energyCalculator as jest.Mocked<
  typeof energyCalculator
>;
const mockCarbonCalculatorsService = carbonCalculatorsService as jest.Mocked<
  typeof carbonCalculatorsService
>;

describe("/api/carbon/energy", () => {
  const mockUser = { id: "user123", email: "test@example.com" };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("POST", () => {
    it("should calculate energy emissions successfully", async () => {
      const mockResult = {
        totalEmissions: 1500,
        breakdown: {
          electricity: 1000,
          heating: 400,
          cooling: 200,
          renewableCredits: -100,
        },
        details: [],
        methodology: "Test methodology",
        recommendations: ["Test recommendation"],
      };

      const mockRecommendations = {
        recommendations: [
          {
            title: "Install Solar Panels",
            description: "Reduce grid electricity usage",
            category: "renewable",
            impactEstimate: 800,
            difficultyScore: 3,
          },
        ],
      };

      mockEnergyCalculator.calculateEnergyFootprint.mockResolvedValue(
        mockResult
      );
      mockCarbonCalculatorsService.getEnergyRecommendations.mockResolvedValue({
        recommendations: mockRecommendations.recommendations,
      });

      const requestBody = {
        electricity: {
          consumption: 1000,
          gridRegion: "US",
        },
        heating: {
          naturalGas: 500,
        },
      };

      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy",
        {
          method: "POST",
          body: JSON.stringify(requestBody),
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.totalEmissions).toBe(1500);
      expect(data.breakdown).toEqual(mockResult.breakdown);
      expect(data.userRecommendations).toEqual(
        mockRecommendations.recommendations
      );
      expect(data.message).toBe("Energy emissions calculated successfully");
    });

    it("should return validation error for invalid input", async () => {
      const invalidRequestBody = {
        electricity: {
          consumption: -100,
          gridRegion: "",
        },
      };

      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy",
        {
          method: "POST",
          body: JSON.stringify(invalidRequestBody),
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(400);
      expect(data.error).toBe("Invalid input data");
      expect(data.details).toBeDefined();
    });

    it("should handle calculation errors", async () => {
      mockEnergyCalculator.calculateEnergyFootprint.mockRejectedValue(
        new Error("Calculation failed")
      );

      const requestBody = {
        electricity: {
          consumption: 1000,
          gridRegion: "US",
        },
      };

      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy",
        {
          method: "POST",
          body: JSON.stringify(requestBody),
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const response = await POST(request);
      const data = await response.json();

      expect(response.status).toBe(500);
      expect(data.error).toBe("Failed to calculate energy emissions");
    });
  });

  describe("GET", () => {
    it("should return grid data", async () => {
      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=grid-data&region=US"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.gridData).toBeDefined();
      expect(data.gridData.emissionFactor).toBeDefined();
      expect(data.gridData.renewablePercentage).toBeDefined();
      expect(data.gridData.sourceMix).toBeDefined();
    });

    it("should return emission factors", async () => {
      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=emission-factors"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.emissionFactors).toBeDefined();
      expect(data.emissionFactors.electricity).toBeDefined();
      expect(data.emissionFactors.heating).toBeDefined();
      expect(data.emissionFactors.renewable).toBeDefined();
    });

    it("should return benchmarks", async () => {
      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=benchmarks"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.benchmarks).toBeDefined();
      expect(data.benchmarks.global).toBeDefined();
      expect(data.benchmarks.residential).toBeDefined();
      expect(data.benchmarks.recommendations).toBeDefined();
    });

    it("should return user recommendations", async () => {
      const mockRecommendations = {
        recommendations: [
          {
            title: "Upgrade HVAC System",
            description: "Install high-efficiency heat pump",
            category: "heating",
            impactEstimate: 600,
            difficultyScore: 4,
          },
        ],
      };

      mockCarbonCalculatorsService.getEnergyRecommendations.mockResolvedValue({
        recommendations: mockRecommendations.recommendations,
      });

      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=recommendations"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.recommendations).toEqual(mockRecommendations.recommendations);
      expect(data.message).toBe(
        "Energy recommendations retrieved successfully"
      );
    });

    it("should return utility programs", async () => {
      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=utility-programs"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(200);
      expect(data.programs).toBeDefined();
      expect(data.programs.federal).toBeDefined();
      expect(data.programs.state).toBeDefined();
      expect(data.programs.utility).toBeDefined();
    });

    it("should return error for invalid type", async () => {
      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=invalid"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(400);
      expect(data.error).toBe("Invalid type parameter");
    });

    it("should handle service errors", async () => {
      mockCarbonCalculatorsService.getEnergyRecommendations.mockRejectedValue(
        new Error("Service error")
      );

      const request = new NextRequest(
        "http://localhost:3000/api/carbon/energy?type=recommendations"
      );

      const response = await GET(request);
      const data = await response.json();

      expect(response.status).toBe(500);
      expect(data.error).toBe("Failed to fetch energy data");
    });
  });
});
