import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { energyCalculator } from "@/services/energy-calculator";
import { carbonCalculatorsService } from "@/services/carbon-calculators";
import { z } from "zod";

const electricityDataSchema = z.object({
  consumption: z.number().min(0),
  gridRegion: z.string(),
  renewablePercentage: z.number().min(0).max(100).optional(),
  sourceMix: z
    .object({
      coal: z.number().min(0).max(100).optional(),
      naturalGas: z.number().min(0).max(100).optional(),
      nuclear: z.number().min(0).max(100).optional(),
      hydro: z.number().min(0).max(100).optional(),
      wind: z.number().min(0).max(100).optional(),
      solar: z.number().min(0).max(100).optional(),
      other: z.number().min(0).max(100).optional(),
    })
    .optional(),
  timeOfUse: z
    .object({
      peak: z.number().min(0),
      offPeak: z.number().min(0),
    })
    .optional(),
  utilityProvider: z.string().optional(),
});

const heatingDataSchema = z.object({
  naturalGas: z.number().min(0).optional(),
  heatingOil: z.number().min(0).optional(),
  propane: z.number().min(0).optional(),
  wood: z.number().min(0).optional(),
  districtHeating: z.number().min(0).optional(),
  heatPump: z
    .object({
      electricity: z.number().min(0),
      cop: z.number().min(1).max(10),
      heatSource: z.enum(["air", "ground", "water"]),
    })
    .optional(),
  systemEfficiency: z.number().min(0).max(1).optional(),
  heatedArea: z.number().min(0).optional(),
});

const coolingDataSchema = z.object({
  electricity: z.number().min(0),
  systemType: z.enum(["central_ac", "window_ac", "heat_pump", "evaporative"]),
  seer: z.number().min(8).max(30).optional(),
  cooledArea: z.number().min(0).optional(),
  climateZone: z
    .enum([
      "hot_humid",
      "hot_dry",
      "mixed_humid",
      "mixed_dry",
      "cold",
      "very_cold",
    ])
    .optional(),
});

const renewableDataSchema = z.object({
  solarGenerated: z.number().min(0).optional(),
  windGenerated: z.number().min(0).optional(),
  hydroGenerated: z.number().min(0).optional(),
  geothermalGenerated: z.number().min(0).optional(),
  batteryStorage: z
    .object({
      capacity: z.number().min(0),
      cycleEfficiency: z.number().min(0).max(1),
    })
    .optional(),
  netMetering: z.boolean().optional(),
});

const energyCalculationSchema = z.object({
  electricity: electricityDataSchema.optional(),
  heating: heatingDataSchema.optional(),
  cooling: coolingDataSchema.optional(),
  renewable: renewableDataSchema.optional(),
});

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const body = await request.json();

      const validationResult = energyCalculationSchema.safeParse(body);
      if (!validationResult.success) {
        return NextResponse.json(
          {
            error: "Invalid input data",
            details: validationResult.error.errors,
          },
          { status: 400 }
        );
      }

      const data = validationResult.data;

      const result = await energyCalculator.calculateEnergyFootprint(data);

      const recommendations =
        await carbonCalculatorsService.getEnergyRecommendations(user.id);

      return NextResponse.json({
        ...result,
        userRecommendations: recommendations.recommendations,
        message: "Energy emissions calculated successfully",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to calculate energy emissions" },
        { status: 500 }
      );
    }
  }
);

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const { searchParams } = new URL(request.url);
      const type = searchParams.get("type");
      const region = searchParams.get("region") || "global";

      if (type === "grid-data") {
        const gridData = {
          regions: {
            US: {
              emissionFactor: 0.386,
              renewablePercentage: 22,
              sourceMix: {
                coal: 19.3,
                naturalGas: 40.3,
                nuclear: 18.2,
                hydro: 6.0,
                wind: 9.2,
                solar: 3.3,
                other: 3.7,
              },
              lastUpdated: new Date().toISOString(),
            },
            EU: {
              emissionFactor: 0.276,
              renewablePercentage: 42,
              sourceMix: {
                coal: 13.2,
                naturalGas: 19.7,
                nuclear: 25.1,
                hydro: 12.8,
                wind: 16.2,
                solar: 5.2,
                other: 7.8,
              },
              lastUpdated: new Date().toISOString(),
            },
            UK: {
              emissionFactor: 0.193,
              renewablePercentage: 48,
              sourceMix: {
                coal: 1.8,
                naturalGas: 35.7,
                nuclear: 14.5,
                hydro: 1.8,
                wind: 26.8,
                solar: 4.4,
                other: 15.0,
              },
              lastUpdated: new Date().toISOString(),
            },
            global: {
              emissionFactor: 0.475,
              renewablePercentage: 30,
              sourceMix: {
                coal: 35.1,
                naturalGas: 23.5,
                nuclear: 10.1,
                hydro: 15.6,
                wind: 7.3,
                solar: 3.7,
                other: 4.7,
              },
              lastUpdated: new Date().toISOString(),
            },
          },
        };

        return NextResponse.json({
          gridData:
            gridData.regions[region as keyof typeof gridData.regions] ||
            gridData.regions.global,
        });
      }

      if (type === "emission-factors") {
        const factors = {
          electricity: {
            US: { factor: 0.386, unit: "kg CO2/kWh" },
            EU: { factor: 0.276, unit: "kg CO2/kWh" },
            UK: { factor: 0.193, unit: "kg CO2/kWh" },
            global: { factor: 0.475, unit: "kg CO2/kWh" },
          },
          heating: {
            naturalGas: { factor: 0.185, unit: "kg CO2/kWh" },
            heatingOil: { factor: 2.52, unit: "kg CO2/liter" },
            propane: { factor: 3.0, unit: "kg CO2/kg" },
            wood: { factor: 0.1, unit: "kg CO2/kg" },
            heatPump: { factor: "varies by COP and grid", unit: "kg CO2/kWh" },
          },
          renewable: {
            solar: { factor: 0.041, unit: "kg CO2/kWh lifecycle" },
            wind: { factor: 0.011, unit: "kg CO2/kWh lifecycle" },
            hydro: { factor: 0.024, unit: "kg CO2/kWh lifecycle" },
            nuclear: { factor: 0.012, unit: "kg CO2/kWh lifecycle" },
          },
        };

        return NextResponse.json({ emissionFactors: factors });
      }

      if (type === "benchmarks") {
        const benchmarks = {
          global: {
            averageAnnualEnergyEmissions: 3200,
            breakdown: {
              electricity: 2240,
              heating: 800,
              cooling: 160,
            },
          },
          residential: {
            US: {
              average: 4800,
              electricity: 0.65,
              heating: 0.3,
              cooling: 0.05,
            },
            EU: {
              average: 2800,
              electricity: 0.55,
              heating: 0.4,
              cooling: 0.05,
            },
            global: {
              average: 3200,
              electricity: 0.7,
              heating: 0.25,
              cooling: 0.05,
            },
          },
          recommendations: {
            target: 1600,
            actions: [
              "Switch to renewable energy plan",
              "Install solar panels (8+ kW system)",
              "Upgrade to heat pump heating",
              "Improve home insulation (R-30+ attic)",
              "Use ENERGY STAR appliances",
              "Install smart thermostat",
            ],
          },
          efficiency: {
            heatPumpCOP: {
              air: { min: 2.5, good: 3.5, excellent: 4.5 },
              ground: { min: 3.0, good: 4.0, excellent: 5.0 },
              water: { min: 3.5, good: 4.5, excellent: 5.5 },
            },
            seerRatings: {
              minimum: 14,
              good: 16,
              excellent: 20,
              best: 25,
            },
            solarROI: {
              paybackYears: { min: 6, average: 8, max: 12 },
              annualSavings: { min: 800, average: 1200, max: 2000 },
            },
          },
        };

        return NextResponse.json({ benchmarks });
      }

      if (type === "recommendations") {
        const recommendations =
          await carbonCalculatorsService.getEnergyRecommendations(user.id);

        return NextResponse.json({
          recommendations: recommendations.recommendations,
          message: "Energy recommendations retrieved successfully",
        });
      }

      if (type === "utility-programs") {
        const programs = {
          federal: [
            {
              name: "Federal Solar Tax Credit",
              description: "30% tax credit for solar installations",
              type: "tax_credit",
              value: 0.3,
              expires: "2032-12-31",
              eligibility: "Residential and commercial solar installations",
            },
            {
              name: "Heat Pump Tax Credit",
              description:
                "Up to $2,000 tax credit for heat pump installations",
              type: "tax_credit",
              value: 2000,
              expires: "2032-12-31",
              eligibility: "ENERGY STAR certified heat pumps",
            },
          ],
          state: [
            {
              name: "Net Metering",
              description: "Sell excess solar power back to the grid",
              type: "net_metering",
              availability: "Most states",
              value: "Varies by utility",
            },
            {
              name: "Time-of-Use Rates",
              description: "Lower electricity rates during off-peak hours",
              type: "rate_structure",
              availability: "Many utilities",
              savings: "10-30%",
            },
          ],
          utility: [
            {
              name: "Energy Efficiency Rebates",
              description: "Rebates for efficient appliances and upgrades",
              type: "rebate",
              value: "Varies",
              contact: "Local utility provider",
            },
            {
              name: "Smart Thermostat Programs",
              description: "Free or discounted smart thermostats",
              type: "equipment",
              value: "Up to $200",
              contact: "Local utility provider",
            },
          ],
        };

        return NextResponse.json({ programs });
      }

      return NextResponse.json(
        { error: "Invalid type parameter" },
        { status: 400 }
      );
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch energy data" },
        { status: 500 }
      );
    }
  }
);
