import { NextRequest, NextResponse } from "next/server";
import { getFactor } from "@/services/emission-factors";
import { getUserFromRequest } from "@/lib/auth";
import { achievementService } from "@/services/gamification/achievement.service";

export interface CalculationItem {
  category: string;
  subcategory: string;
  value: number;
  unit?: string;
}

export interface CalculationRequest {
  items: CalculationItem[];
  region?: string;
}

export interface CalculationBreakdownItem {
  itemIndex: number;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  kgCO2: number;
  factor: {
    co2_per_unit: number;
    unit: string;
    source: string;
  };
}

export interface CalculationResponse {
  totalEmissionsKg: number;
  breakdown: CalculationBreakdownItem[];
  reward?: any;
}

export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    const payload: CalculationRequest = await req.json();
    const { items = [], region = "India" } = payload;

    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: "items array required" },
        { status: 400 }
      );
    }

    let totalKg = 0;
    const breakdown: CalculationBreakdownItem[] = [];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];

      if (
        !item.category ||
        !item.subcategory ||
        typeof item.value !== "number"
      ) {
        return NextResponse.json(
          { error: `Invalid item at index ${i}` },
          { status: 400 }
        );
      }

      const factor = await getFactor(item.category, item.subcategory, region);

      if (!factor) {
        return NextResponse.json(
          {
            error: `Missing emission factor for ${item.category}/${item.subcategory}`,
          },
          { status: 400 }
        );
      }

      const kgCO2 = Number(item.value) * Number(factor.value);
      totalKg += kgCO2;

      breakdown.push({
        itemIndex: i,
        category: item.category,
        subcategory: item.subcategory,
        value: item.value,
        unit: item.unit || factor.unit,
        kgCO2: Number(kgCO2.toFixed(3)),
        factor: {
          co2_per_unit: factor.value,
          unit: factor.unit,
          source: factor.source,
        },
      });
    }

    let reward = null;
    if (user) {
      reward = await achievementService.processAction(
        user.id,
        "CARBON_CALCULATION"
      );
    }

    return NextResponse.json({
      totalEmissionsKg: Number(totalKg.toFixed(3)),
      breakdown,
      reward,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const { getAvailableCategories } = await import(
      "@/services/emission-factors"
    );
    const categories = await getAvailableCategories();

    return NextResponse.json({
      categories,
      supportedRegions: ["India", "global"],
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
