import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { emissionFactorsService } from "@/services/emission-factors";

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const { searchParams } = new URL(request.url);
      const category = searchParams.get("category");
      const region = searchParams.get("region");
      const search = searchParams.get("search");

      let factors;

      if (search) {
        factors = await emissionFactorsService.searchEmissionFactors({
          query: search,
          category: category || undefined,
          region: region || undefined,
        });
      } else if (category) {
        factors =
          await emissionFactorsService.getEmissionFactorsByCategory(category);
      } else {
        const stats = await emissionFactorsService.getEmissionFactorsStats();
        return NextResponse.json({ stats });
      }

      return NextResponse.json({
        factors,
        total: factors.length,
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch emission factors" },
        { status: 500 }
      );
    }
  }
);

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      await emissionFactorsService.initializeEmissionFactors();

      return NextResponse.json({
        message: "Emission factors database initialized successfully",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to initialize emission factors" },
        { status: 500 }
      );
    }
  }
);
