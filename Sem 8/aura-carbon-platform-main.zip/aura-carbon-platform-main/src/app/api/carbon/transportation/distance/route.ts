import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { distanceCalculator } from "@/services/distance-calculator";
import {
  distanceCalculationSchema,
  multipleWaypointsSchema,
  distanceMatrixSchema,
  geocodeSchema,
  reverseGeocodeSchema,
} from "@/services/distance-calculator";

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const body = await request.json();
      const { type } = body;

      switch (type) {
        case "route": {
          const validationResult = distanceCalculationSchema.safeParse(body);
          if (!validationResult.success) {
            return NextResponse.json(
              {
                error: "Invalid input data",
                details: validationResult.error.errors,
              },
              { status: 400 }
            );
          }

          const { origin, destination, options } = validationResult.data;
          const result = await distanceCalculator.calculateRouteDistance(
            origin,
            destination,
            options
          );

          return NextResponse.json({
            ...result,
            message: "Route calculated successfully",
          });
        }

        case "optimize": {
          const validationResult = multipleWaypointsSchema.safeParse(body);
          if (!validationResult.success) {
            return NextResponse.json(
              {
                error: "Invalid input data",
                details: validationResult.error.errors,
              },
              { status: 400 }
            );
          }

          const { origin, destination, waypoints, options } =
            validationResult.data;
          const result = await distanceCalculator.optimizeMultipleWaypoints(
            origin,
            destination,
            waypoints,
            options
          );

          return NextResponse.json({
            ...result,
            message: "Route optimized successfully",
          });
        }

        case "matrix": {
          const validationResult = distanceMatrixSchema.safeParse(body);
          if (!validationResult.success) {
            return NextResponse.json(
              {
                error: "Invalid input data",
                details: validationResult.error.errors,
              },
              { status: 400 }
            );
          }

          const { origins, destinations, mode } = validationResult.data;
          const result = await distanceCalculator.calculateDistanceMatrix(
            origins,
            destinations,
            mode
          );

          return NextResponse.json({
            ...result,
            message: "Distance matrix calculated successfully",
          });
        }

        case "geocode": {
          const validationResult = geocodeSchema.safeParse(body);
          if (!validationResult.success) {
            return NextResponse.json(
              {
                error: "Invalid input data",
                details: validationResult.error.errors,
              },
              { status: 400 }
            );
          }

          const { address } = validationResult.data;
          const result = await distanceCalculator.geocodeAddress(address);

          if (!result) {
            return NextResponse.json(
              { error: "Address not found" },
              { status: 404 }
            );
          }

          return NextResponse.json({
            location: result,
            message: "Address geocoded successfully",
          });
        }

        case "reverse-geocode": {
          const validationResult = reverseGeocodeSchema.safeParse(body);
          if (!validationResult.success) {
            return NextResponse.json(
              {
                error: "Invalid input data",
                details: validationResult.error.errors,
              },
              { status: 400 }
            );
          }

          const { location } = validationResult.data;
          const result = await distanceCalculator.reverseGeocode(location);

          return NextResponse.json({
            address: result,
            message: "Location reverse geocoded successfully",
          });
        }

        default:
          return NextResponse.json(
            { error: "Invalid calculation type" },
            { status: 400 }
          );
      }
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to calculate distance" },
        { status: 500 }
      );
    }
  }
);

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const { searchParams } = new URL(request.url);
      const type = searchParams.get("type");

      if (type === "supported-modes") {
        return NextResponse.json({
          modes: [
            {
              id: "driving",
              name: "Driving",
              description: "Calculate route for personal vehicle",
              icon: "car",
            },
            {
              id: "walking",
              name: "Walking",
              description: "Calculate walking route",
              icon: "walk",
            },
            {
              id: "bicycling",
              name: "Bicycling",
              description: "Calculate cycling route",
              icon: "bike",
            },
            {
              id: "transit",
              name: "Public Transit",
              description: "Calculate public transport route",
              icon: "bus",
            },
          ],
        });
      }

      if (type === "route-options") {
        return NextResponse.json({
          options: [
            {
              id: "avoidTolls",
              name: "Avoid Tolls",
              description: "Route around toll roads",
              type: "boolean",
            },
            {
              id: "avoidHighways",
              name: "Avoid Highways",
              description: "Use local roads instead of highways",
              type: "boolean",
            },
            {
              id: "avoidFerries",
              name: "Avoid Ferries",
              description: "Route around ferry crossings",
              type: "boolean",
            },
            {
              id: "optimize",
              name: "Optimize Route",
              description: "Optimize waypoint order for shortest route",
              type: "boolean",
            },
          ],
        });
      }

      if (type === "efficiency-factors") {
        return NextResponse.json({
          factors: {
            highway: {
              factor: 0.85,
              description: "15% better fuel efficiency on highways",
            },
            city: {
              factor: 1.0,
              description: "Baseline efficiency for city driving",
            },
            traffic: {
              light: {
                factor: 0.9,
                description: "10% better in light traffic",
              },
              moderate: {
                factor: 1.0,
                description: "Baseline for moderate traffic",
              },
              heavy: { factor: 1.3, description: "30% worse in heavy traffic" },
            },
            route_optimization: {
              factor: 0.95,
              description: "5% average savings from route optimization",
            },
          },
        });
      }

      return NextResponse.json(
        { error: "Invalid type parameter" },
        { status: 400 }
      );
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch distance calculation data" },
        { status: 500 }
      );
    }
  }
);
