import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { transportationCalculator } from "@/services/transportation-calculator";
import { z } from "zod";

const vehicleSpecsSchema = z.object({
  make: z.string(),
  model: z.string(),
  year: z
    .number()
    .min(1990)
    .max(new Date().getFullYear() + 1),
  fuelType: z.enum(["gasoline", "diesel", "electric", "hybrid"]),
  engineSize: z.number().optional(),
  fuelEfficiency: z.number().min(0.1),
  vehicleType: z.enum([
    "compact",
    "midsize",
    "large",
    "suv",
    "truck",
    "motorcycle",
  ]),
});

const locationSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().optional(),
});

const routeOptionsSchema = z.object({
  mode: z.enum(["driving", "walking", "bicycling", "transit"]),
  avoidTolls: z.boolean().optional(),
  avoidHighways: z.boolean().optional(),
  avoidFerries: z.boolean().optional(),
  optimize: z.boolean().optional(),
});

const tripDataSchema = z.object({
  distance: z.number().min(0).optional(),
  origin: locationSchema.optional(),
  destination: locationSchema.optional(),
  waypoints: z.array(locationSchema).optional(),
  routeOptions: routeOptionsSchema.optional(),
  passengers: z.number().min(1).optional(),
  cargoWeight: z.number().min(0).optional(),
  trafficCondition: z.enum(["light", "moderate", "heavy"]).optional(),
  drivingStyle: z.enum(["eco", "normal", "aggressive"]).optional(),
});

const flightDataSchema = z.object({
  origin: z.union([z.string(), locationSchema]),
  destination: z.union([z.string(), locationSchema]),
  distance: z.number().min(0).optional(),
  class: z.enum(["economy", "premium_economy", "business", "first"]),
  aircraftType: z.string().optional(),
  loadFactor: z.number().min(0).max(1).optional(),
  roundTrip: z.boolean(),
});

const publicTransportSchema = z.object({
  mode: z.enum(["bus", "train", "metro", "tram", "ferry"]),
  distance: z.number().min(0),
  fuelType: z.enum(["diesel", "electric", "cng", "biodiesel"]).optional(),
  occupancyRate: z.number().min(0).max(1).optional(),
  region: z.string(),
});

const ridesharingSchema = z.object({
  service: z.enum(["uber", "lyft", "taxi", "other"]),
  vehicleType: z.enum(["standard", "premium", "electric", "pool"]),
  distance: z.number().min(0),
  waitTime: z.number().min(0).optional(),
  detourFactor: z.number().min(1).optional(),
});

const transportationCalculationSchema = z.object({
  personalVehicle: z
    .object({
      vehicle: vehicleSpecsSchema,
      trips: z.array(tripDataSchema),
    })
    .optional(),
  flights: z.array(flightDataSchema).optional(),
  publicTransport: z.array(publicTransportSchema).optional(),
  ridesharing: z.array(ridesharingSchema).optional(),
});

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const body = await request.json();

      const validationResult = transportationCalculationSchema.safeParse(body);
      if (!validationResult.success) {
        return NextResponse.json(
          {
            error: "Invalid input data",
            details: validationResult.error.errors,
          },
          { status: 400 }
        );
      }

      const data = validationResult.data;

      const result =
        await transportationCalculator.calculateTransportationFootprint(data);

      let recommendations = null;
      if (data.personalVehicle) {
        const annualDistance =
          data.personalVehicle.trips.reduce(
            (sum, trip) => sum + (trip.distance ?? 0),
            0
          ) * 52;
        recommendations =
          await transportationCalculator.getVehicleRecommendations(
            data.personalVehicle.vehicle,
            annualDistance
          );
      }

      return NextResponse.json({
        ...result,
        recommendations,
        message: "Transportation emissions calculated successfully",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to calculate transportation emissions" },
        { status: 500 }
      );
    }
  }
);

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const { searchParams } = new URL(request.url);
      const type = searchParams.get("type");

      if (type === "vehicle-database") {
        const vehicleDatabase = [
          {
            make: "Toyota",
            model: "Prius",
            year: 2023,
            fuelType: "hybrid",
            efficiency: 23,
            vehicleType: "compact",
          },
          {
            make: "Tesla",
            model: "Model 3",
            year: 2023,
            fuelType: "electric",
            efficiency: 6.1,
            vehicleType: "midsize",
          },
          {
            make: "Honda",
            model: "Civic",
            year: 2023,
            fuelType: "gasoline",
            efficiency: 15,
            vehicleType: "compact",
          },
          {
            make: "Ford",
            model: "F-150",
            year: 2023,
            fuelType: "gasoline",
            efficiency: 8.5,
            vehicleType: "truck",
          },
          {
            make: "BMW",
            model: "X5",
            year: 2023,
            fuelType: "gasoline",
            efficiency: 10,
            vehicleType: "suv",
          },
          {
            make: "Nissan",
            model: "Leaf",
            year: 2023,
            fuelType: "electric",
            efficiency: 5.8,
            vehicleType: "compact",
          },
          {
            make: "Chevrolet",
            model: "Bolt",
            year: 2023,
            fuelType: "electric",
            efficiency: 5.9,
            vehicleType: "compact",
          },
          {
            make: "Audi",
            model: "A4",
            year: 2023,
            fuelType: "gasoline",
            efficiency: 12,
            vehicleType: "midsize",
          },
        ];

        return NextResponse.json({ vehicles: vehicleDatabase });
      }

      if (type === "emission-factors") {
        const factors = {
          personalVehicle: {
            gasoline: { factor: 2.31, unit: "kg CO2/liter" },
            diesel: { factor: 2.68, unit: "kg CO2/liter" },
            electric: { factor: 0.05, unit: "kg CO2/kWh" },
            hybrid: { factor: 1.85, unit: "kg CO2/liter equivalent" },
          },
          aviation: {
            economy: { factor: 0.255, unit: "kg CO2/km" },
            business: { factor: 0.429, unit: "kg CO2/km" },
            first: { factor: 0.599, unit: "kg CO2/km" },
          },
          publicTransport: {
            bus: { factor: 0.089, unit: "kg CO2/km" },
            train: { factor: 0.041, unit: "kg CO2/km" },
            metro: { factor: 0.028, unit: "kg CO2/km" },
          },
        };

        return NextResponse.json({ emissionFactors: factors });
      }

      if (type === "benchmarks") {
        const benchmarks = {
          global: {
            averageAnnualTransportEmissions: 2400,
            breakdown: {
              personalVehicle: 1680,
              aviation: 480,
              publicTransport: 240,
            },
          },
          regional: {
            US: { average: 3200, personalVehicle: 0.75 },
            EU: { average: 2100, personalVehicle: 0.55 },
            Asia: { average: 1800, personalVehicle: 0.45 },
          },
          recommendations: {
            target: 1500,
            actions: [
              "Switch to electric vehicle",
              "Use public transport 3+ times per week",
              "Limit flights to 1 round-trip per year",
              "Walk/bike for trips under 5km",
            ],
          },
        };

        return NextResponse.json({ benchmarks });
      }

      return NextResponse.json(
        { error: "Invalid type parameter" },
        { status: 400 }
      );
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch transportation data" },
        { status: 500 }
      );
    }
  }
);
