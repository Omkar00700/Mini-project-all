import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

interface CSVActivity {
  name: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  isRecurring?: boolean;
  frequency?: string;
  notes?: string;
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (!file.name.endsWith(".csv") && !file.type.includes("csv")) {
      return NextResponse.json(
        { error: "File must be a CSV file" },
        { status: 400 }
      );
    }

    const text = await file.text();
    const lines = text.split("\n").filter((line) => line.trim());

    if (lines.length < 2) {
      return NextResponse.json(
        { error: "CSV file must have at least a header row and one data row" },
        { status: 400 }
      );
    }

    const headers = lines[0].split(",").map((h) => h.replace(/"/g, "").trim());
    const expectedHeaders = [
      "name",
      "category",
      "subcategory",
      "value",
      "unit",
    ];

    const hasRequiredHeaders = expectedHeaders.every((header) =>
      headers.some((h) => h.toLowerCase() === header.toLowerCase())
    );

    if (!hasRequiredHeaders) {
      return NextResponse.json(
        {
          error:
            "CSV must contain columns: name, category, subcategory, value, unit",
          providedHeaders: headers,
        },
        { status: 400 }
      );
    }

    const activities: CSVActivity[] = [];
    const errors: string[] = [];

    for (let i = 1; i < lines.length; i++) {
      try {
        const values = parseCSVLine(lines[i]);
        if (values.length !== headers.length) {
          errors.push(
            `Row ${i + 1}: Expected ${headers.length} columns, got ${values.length}`
          );
          continue;
        }

        const activity: any = {};
        headers.forEach((header, index) => {
          const key = header.toLowerCase();
          const value = values[index]?.trim() || "";

          if (key === "value") {
            const numValue = parseFloat(value);
            if (isNaN(numValue)) {
              errors.push(`Row ${i + 1}: Invalid number for value: ${value}`);
              return;
            }
            activity[key] = numValue;
          } else if (key === "isrecurring") {
            activity.isRecurring =
              value.toLowerCase() === "true" || value === "1";
          } else if (key === "name") {
            activity[key] = value;
          } else {
            activity[key] = value;
          }
        });

        if (
          !activity.name ||
          !activity.category ||
          !activity.subcategory ||
          typeof activity.value !== "number" ||
          !activity.unit
        ) {
          errors.push(`Row ${i + 1}: Missing required fields`);
          continue;
        }

        activities.push(activity);
      } catch (err) {
        errors.push(
          `Row ${i + 1}: Failed to parse - ${err instanceof Error ? err.message : "Unknown error"}`
        );
      }
    }

    if (activities.length === 0) {
      return NextResponse.json(
        { error: "No valid activities found in CSV", parseErrors: errors },
        { status: 400 }
      );
    }

    const savedActivities = [];
    const saveErrors = [];

    for (const activity of activities) {
      try {
        const saved = await prisma.activityData.create({
          data: {
            userId: user.id,
            category: activity.category,
            subcategory: activity.subcategory,
            value: activity.value,
            unit: activity.unit,
            date: new Date(),
            source: "csv_import",
            metadata: {
              saved: true,
              name: activity.name,
              isRecurring: activity.isRecurring || false,
              frequency: activity.isRecurring
                ? activity.frequency || "monthly"
                : null,
              notes:
                activity.notes ||
                `Imported from CSV on ${new Date().toLocaleDateString()}`,
              imported_at: new Date().toISOString(),
            },
          },
        });
        savedActivities.push(saved);
      } catch (err) {
        saveErrors.push(
          `${activity.name}: ${err instanceof Error ? err.message : "Save failed"}`
        );
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully imported ${savedActivities.length} activities`,
      imported: savedActivities.length,
      totalParsed: activities.length,
      errors: [...errors, ...saveErrors],
      activities: savedActivities.map((a) => ({
        id: a.id,
        name: (a.metadata as Record<string, unknown>)?.name as
          | string
          | undefined,
        category: a.category,
        subcategory: a.subcategory,
        value: a.value,
        unit: a.unit,
      })),
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to import CSV file" },
      { status: 500 }
    );
  }
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  result.push(current);

  return result;
}
