import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { getFactor } from "@/services/emission-factors";
import { achievementService } from "@/services/gamification/achievement.service";
import { z } from "zod";

const logActivitySchema = z.object({
  category: z.string().min(1, "Category is required"),
  subcategory: z.string().min(1, "Subcategory is required"),
  value: z.number({ required_error: "Value is required" }),
  unit: z.string().min(1, "Unit is required"),
  date: z.string().datetime().optional(),
  name: z.string().optional(),
  notes: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user)
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    let body;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid JSON payload" },
        { status: 400 }
      );
    }

    const validation = logActivitySchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.errors[0].message },
        { status: 400 }
      );
    }

    const { category, subcategory, value, unit, name, notes } = validation.data;
    const date = validation.data.date
      ? new Date(validation.data.date)
      : new Date();

    const factor = await getFactor(category, subcategory, "India");
    let co2Impact = 0;
    if (factor) {
      co2Impact = value * factor.value;
    }

    const activity = await prisma.activityData.create({
      data: {
        userId: user.id,
        category,
        subcategory,
        value,
        unit,
        date,
        source: "user_logged",
        metadata: {
          name: name || `${category} - ${subcategory}`,
          co2Impact,
          notes: notes || null,
        },
      },
    });

    const rewardResult = await achievementService.processAction(
      user.id,
      "LOG_ACTIVITY"
    );

    return NextResponse.json({
      success: true,
      activity: {
        id: activity.id,
        category: activity.category,
        subcategory: activity.subcategory,
        value: activity.value,
        unit: activity.unit,
        date: activity.date,
        co2Impact,
        name: name || `${category} - ${subcategory}`,
        notes,
        createdAt: activity.createdAt,
      },
      message: "Activity logged successfully",
      reward: rewardResult,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to log activity" },
      { status: 500 }
    );
  }
}
