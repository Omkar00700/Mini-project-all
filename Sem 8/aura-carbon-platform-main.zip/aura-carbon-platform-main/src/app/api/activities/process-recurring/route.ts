import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { getFactor } from "@/services/emission-factors";

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const allActivities = await prisma.activityData.findMany({
      where: {
        userId: user.id,
      },
    });

    const recurringActivities = allActivities.filter(
      (a) => (a.metadata as Record<string, unknown>)?.isRecurring === true
    );

    if (recurringActivities.length === 0) {
      return NextResponse.json({
        message: "No recurring activities found",
        processed: 0,
      });
    }

    const now = new Date();
    const currentMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const allCalculations = await prisma.carbonCalculation.findMany({
      where: {
        userId: user.id,
        periodStart: currentMonth,
      },
    });

    const existingCalculation = allCalculations.find(
      (c) =>
        (c.metadata as Record<string, unknown>)?.calculation_type ===
        "recurring_auto"
    );

    if (existingCalculation) {
      return NextResponse.json({
        message: "Recurring calculation already exists for this month",
        calculationId: existingCalculation.id,
      });
    }

    let totalEmissions = 0;
    const breakdown: Record<string, number> = {};
    const processedActivities = [];

    for (const activity of recurringActivities) {
      const frequency = (activity.metadata as any)?.frequency || "monthly";
      let multiplier = 1;

      switch (frequency) {
        case "daily":
          multiplier = 30;
          break;
        case "weekly":
          multiplier = 4.3;
          break;
        case "monthly":
          multiplier = 1;
          break;
        case "yearly":
          multiplier = 1 / 12;
          break;
        default:
          multiplier = 1;
      }

      const adjustedValue = activity.value * multiplier;

      const factor = await getFactor(
        activity.category,
        activity.subcategory,
        "India"
      );
      if (factor) {
        const emissions = adjustedValue * factor.value;
        totalEmissions += emissions;
        breakdown[activity.category] =
          (breakdown[activity.category] || 0) + emissions;

        processedActivities.push({
          activityId: activity.id,
          category: activity.category,
          subcategory: activity.subcategory,
          originalValue: activity.value,
          adjustedValue,
          unit: activity.unit,
          emissions,
          frequency,
          multiplier,
        });
      }
    }

    if (totalEmissions === 0) {
      return NextResponse.json({
        message: "No emissions calculated from recurring activities",
        processed: processedActivities.length,
      });
    }

    const calculation = await prisma.carbonCalculation.create({
      data: {
        userId: user.id,
        periodStart: currentMonth,
        periodEnd: nextMonth,
        totalEmissions,
        breakdown,
        confidenceScore: 0.75,
        metadata: {
          calculation_type: "recurring_auto",
          processed_activities: processedActivities.length,
          generated_at: new Date().toISOString(),
          activities: processedActivities,
        },
      },
    });

    return NextResponse.json({
      success: true,
      message: "Recurring activities processed successfully",
      calculation: {
        id: calculation.id,
        totalEmissions,
        periodStart: currentMonth,
        periodEnd: nextMonth,
      },
      processedActivities,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to process recurring activities" },
      { status: 500 }
    );
  }
}
