import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { revalidateTag } from "next/cache";
import { achievementService } from "@/services/gamification/achievement.service";

import { z } from "zod";

const activitySchemaBase = z.object({
  category: z.string().min(1, "Category is required"),
  subcategory: z.string().min(1, "Subcategory is required"),
  value: z.number({
    required_error: "Value is required",
    invalid_type_error: "Value must be a number",
  }),
  unit: z.string().min(1, "Unit is required"),
  name: z.string().optional(),
  isRecurring: z.boolean().default(false),
  frequency: z
    .enum(["daily", "weekly", "monthly", "yearly"])
    .optional()
    .nullable(),
  notes: z.string().optional().nullable(),
});

const createActivitySchema = activitySchemaBase;
const updateActivitySchema = activitySchemaBase.extend({
  id: z.string().min(1, "Activity ID is required"),
});

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const activities = await prisma.activityData.findMany({
      where: {
        userId: user.id,
        source: "user_saved",
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return NextResponse.json({ activities }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch activities" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid JSON payload" },
        { status: 400 }
      );
    }

    const validation = createActivitySchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.errors[0].message },
        { status: 400 }
      );
    }

    const {
      category,
      subcategory,
      value,
      unit,
      name,
      isRecurring,
      frequency,
      notes,
    } = validation.data;

    const activity = await prisma.activityData.create({
      data: {
        userId: user.id,
        category,
        subcategory,
        value,
        unit,
        date: new Date(),
        source: "user_saved",
        metadata: {
          saved: true,
          name: name || `${category} - ${subcategory}`,
          isRecurring,
          frequency: isRecurring ? frequency : null,
          notes: notes || null,
          saved_at: new Date().toISOString(),
        },
      },
    });

    // Sync: Invalidate dashboard cache
    try {
      revalidateTag("dashboard-calculations");
    } catch (e) {}

    await achievementService.calculateStreak(user.id);

    const reward = await achievementService.processAction(
      user.id,
      "ACTIVITY_LOGGED"
    );

    return NextResponse.json(
      {
        success: true,
        activity,
        reward,
        message: "Activity logged successfully",
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to log activity" },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid JSON payload" },
        { status: 400 }
      );
    }

    const validation = updateActivitySchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.errors[0].message },
        { status: 400 }
      );
    }

    const {
      id,
      category,
      subcategory,
      value,
      unit,
      name,
      isRecurring,
      frequency,
      notes,
    } = validation.data;

    const activity = await prisma.activityData.updateMany({
      where: {
        id,
        userId: user.id,
      },
      data: {
        category,
        subcategory,
        value,
        unit,
        metadata: JSON.parse(
          JSON.stringify({
            saved: true,
            name: name || `${category} - ${subcategory}`,
            isRecurring,
            frequency: isRecurring ? frequency : null,
            notes: notes || null,
            updated_at: new Date().toISOString(),
          })
        ),
      },
    });

    if (activity.count === 0) {
      return NextResponse.json(
        { error: "Activity not found or not owned by user" },
        { status: 404 }
      );
    }

    // Sync: Invalidate dashboard cache
    try {
      revalidateTag("dashboard-calculations");
    } catch (e) {}

    return NextResponse.json(
      {
        success: true,
        message: "Activity updated successfully",
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to update activity" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "Activity ID is required" },
        { status: 400 }
      );
    }

    const activity = await prisma.activityData.deleteMany({
      where: {
        id,
        userId: user.id,
      },
    });

    if (activity.count === 0) {
      return NextResponse.json(
        { error: "Activity not found or not owned by user" },
        { status: 404 }
      );
    }

    // Sync: Invalidate dashboard cache
    try {
      revalidateTag("dashboard-calculations");
    } catch (e) {}

    return NextResponse.json(
      {
        success: true,
        message: "Activity deleted successfully",
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to delete activity" },
      { status: 500 }
    );
  }
}
