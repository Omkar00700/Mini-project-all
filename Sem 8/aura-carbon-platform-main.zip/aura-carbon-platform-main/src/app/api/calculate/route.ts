import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { achievementService } from "@/services/gamification/achievement.service";

interface CalculationItem {
  category: string;
  subcategory: string;
  quantity: number;
  unit: string;
}

interface CalculationRequest {
  items: CalculationItem[];
  date: string;
}

async function calculateEmissions(
  userId: string,
  items: CalculationItem[],
  date: string
) {
  const factors = await prisma.emissionFactor.findMany({
    where: {
      OR: items.map((item) => ({
        category: item.category,
        subcategory: item.subcategory,
        region: "India",
      })),
    },
  });

  const factorMap = new Map(
    factors.map((f) => [`${f.category}__${f.subcategory}`, f.value])
  );

  let total = 0;
  const breakdown: Record<string, number> = {};
  const itemDetails: any[] = [];

  for (const item of items) {
    const key = `${item.category}__${item.subcategory}`;
    let factor = factorMap.get(key);
    let source = "database";

    if (!factor) {
      factor = getFallbackFactor(item);
      source = "estimated";
    }

    const emission = item.quantity * factor;
    breakdown[item.category] = (breakdown[item.category] || 0) + emission;
    total += emission;

    itemDetails.push({
      ...item,
      emissionFactor: factor,
      emission,
      source,
    });
  }

  const calculation = await prisma.carbonCalculation.create({
    data: {
      userId,
      periodStart: new Date(date),
      periodEnd: new Date(date),
      totalEmissions: total,
      breakdown,
      confidenceScore: 0.85,
      metadata: {
        calculation_method: "direct_factors",
        items: itemDetails,
        calculated_at: new Date().toISOString(),
      },
    },
  });

  return { total, breakdown, calculation, itemDetails };
}

function getFallbackFactor(item: CalculationItem): number {
  const fallbacks: Record<string, number> = {
    transport__petrol: 2.31,
    transport__diesel: 2.68,
    transport__cng: 2.75,
    energy__grid: 0.82,
    cooking__lpg: 1.5,
    food__rice: 2.7,
    food__wheat: 0.7,
    food__chicken: 6.9,
    food__mutton: 39.2,
    waste__municipal_solid_waste: 0.46,
  };

  const key = `${item.category}__${item.subcategory}`;
  return fallbacks[key] || 1.0;
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { items, date }: CalculationRequest = await request.json();

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: "Items array is required" },
        { status: 400 }
      );
    }

    if (!date) {
      return NextResponse.json({ error: "Date is required" }, { status: 400 });
    }

    const result = await calculateEmissions(user.id, items, date);

    const rewardResult = await achievementService.processAction(
      user.id,
      "CARBON_CALCULATION"
    );

    return NextResponse.json(
      {
        success: true,
        totalKgCO2e: result.total,
        breakdown: result.breakdown,
        calculationId: result.calculation.id,
        itemDetails: result.itemDetails,
        reward: rewardResult,
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
