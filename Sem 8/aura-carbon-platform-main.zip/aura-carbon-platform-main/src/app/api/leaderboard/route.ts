import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { authService } from "@/services/auth/simple-auth.service";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const token = req.cookies.get("auth-token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const currentUser = await authService.verifyTokenAndGetUser(token);
    if (!currentUser) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const timeframe = searchParams.get("timeframe") || "all-time";
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = 50;
    const skip = (page - 1) * limit;

    if (timeframe === "weekly") {
      const now = new Date();
      const dayOfWeek = now.getUTCDay();
      const daysFromMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
      const weekStart = new Date(now);
      weekStart.setUTCDate(now.getUTCDate() - daysFromMonday);
      weekStart.setUTCHours(0, 0, 0, 0);

      const [weeklyUsers, totalActiveUsers] = await Promise.all([
        prisma.user.findMany({
          where: {
            activityData: {
              some: {
                date: { gte: weekStart },
              },
            },
          },
          orderBy: { totalXp: "desc" },
          skip,
          take: limit,
          select: {
            id: true,
            name: true,
            image: true,
            totalXp: true,
            currentLevel: true,
          },
        }),
        prisma.user.count({
          where: {
            activityData: {
              some: {
                date: { gte: weekStart },
              },
            },
          },
        }),
      ]);

      const safeLeaderboard = weeklyUsers.map((user, index) => ({
        rank: skip + index + 1,
        name: user.name,
        totalXp: user.totalXp,
        currentLevel: user.currentLevel,
        image: user.image,
        isCurrentUser: user.id === currentUser.id,
      }));

      return NextResponse.json(
        {
          leaderboard: safeLeaderboard,
          pagination: {
            page,
            limit,
            totalUsers: totalActiveUsers,
            totalPages: Math.ceil(totalActiveUsers / limit),
          },
          timeframe: "weekly",
          weekStart: weekStart.toISOString(),
        },
        { status: 200 }
      );
    }

    const [topUsers, totalUsers] = await Promise.all([
      prisma.user.findMany({
        orderBy: { totalXp: "desc" },
        skip,
        take: limit,
        select: {
          id: true,
          name: true,
          image: true,
          totalXp: true,
          currentLevel: true,
        },
      }),
      prisma.user.count(),
    ]);

    const safeLeaderboard = topUsers.map((user, index) => ({
      rank: skip + index + 1,
      name: user.name,
      totalXp: user.totalXp,
      currentLevel: user.currentLevel,
      image: user.image,
      isCurrentUser: user.id === currentUser.id,
    }));

    return NextResponse.json(
      {
        leaderboard: safeLeaderboard,
        pagination: {
          page,
          limit,
          totalUsers,
          totalPages: Math.ceil(totalUsers / limit),
        },
        timeframe: "all-time",
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch leaderboard" },
      { status: 500 }
    );
  }
}
