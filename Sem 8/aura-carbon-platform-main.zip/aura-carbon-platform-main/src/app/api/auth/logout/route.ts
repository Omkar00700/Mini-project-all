import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value;

    if (token) {
      await authService.logout(token);
    }

    const response = NextResponse.json(
      {
        success: true,
        message: "Logout successful",
      },
      { status: 200 }
    );

    response.cookies.delete("auth-token");

    return response;
  } catch (error: any) {
    return NextResponse.json({ error: "Logout failed" }, { status: 500 });
  }
}
