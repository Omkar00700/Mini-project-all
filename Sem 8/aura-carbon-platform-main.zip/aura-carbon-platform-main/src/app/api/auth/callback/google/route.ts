import { google } from "googleapis";
import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";
import { prisma } from "@/lib/prisma";

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const NEXT_PUBLIC_APP_URL = process.env.NEXT_PUBLIC_APP_URL;

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const code = searchParams.get("code");

  if (
    !code ||
    !GOOGLE_CLIENT_ID ||
    !GOOGLE_CLIENT_SECRET ||
    !NEXT_PUBLIC_APP_URL
  ) {
    if (!NEXT_PUBLIC_APP_URL) {
      return NextResponse.json(
        { error: "Google authentication failed" },
        { status: 500 }
      );
    }
    return NextResponse.redirect(
      `${NEXT_PUBLIC_APP_URL}/auth/login?error=Google%20authentication%20failed`
    );
  }

  try {
    const oauth2Client = new google.auth.OAuth2(
      GOOGLE_CLIENT_ID,
      GOOGLE_CLIENT_SECRET,
      `${NEXT_PUBLIC_APP_URL}/api/auth/callback/google`
    );

    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    const oauth2 = google.oauth2({
      auth: oauth2Client,
      version: "v2",
    });

    const { data } = await oauth2.userinfo.get();

    if (!data.email || !data.id) {
      return NextResponse.redirect(
        `${NEXT_PUBLIC_APP_URL}/auth/login?error=Failed%20to%20get%20user%20data%20from%20Google`
      );
    }

    let user = await prisma.user.findUnique({
      where: { email: data.email },
    });

    if (!user) {
      const { defaultDashboardConfig } = await import(
        "@/config/default-dashboard"
      );
      user = await prisma.user.create({
        data: {
          email: data.email,
          name: data.name || data.email.split("@")[0],
          passwordHash: "",
          location: { country: "India", region: "", city: "" },
          household: { size: 1, type: "individual" },
          preferences: {
            units: "metric",
            privacy_level: "private",
            notifications: true,
            language: "en",
            timezone: "Asia/Kolkata",
            currency: "INR",
          },
          subscription: {
            tier: "free",
            features: ["basic_tracking", "monthly_reports"],
          },
          dashboardConfig: defaultDashboardConfig as any,
        },
      });
    }

    const token = authService.generateToken(user.id);
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await authService.createSession(user.id, token, expiresAt);

    const response = NextResponse.redirect(`${NEXT_PUBLIC_APP_URL}/dashboard`);

    response.cookies.set({
      name: "auth-token",
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
      path: "/",
    });

    return response;
  } catch {
    if (!NEXT_PUBLIC_APP_URL) {
      return NextResponse.json(
        { error: "Google authentication failed" },
        { status: 500 }
      );
    }
    return NextResponse.redirect(
      `${NEXT_PUBLIC_APP_URL}/auth/login?error=Google%20authentication%20failed`
    );
  }
}
