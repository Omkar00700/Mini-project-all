import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";

const NEXT_PUBLIC_APP_URL = process.env.NEXT_PUBLIC_APP_URL;

export async function POST(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value;

  if (token) {
    await authService.logout(token).catch(() => {});
  }

  if (!NEXT_PUBLIC_APP_URL) {
    const response = NextResponse.json(
      { success: true, message: "Signed out" },
      { status: 200 }
    );
    response.cookies.set("auth-token", "", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 0,
      path: "/",
    });
    return response;
  }

  const response = NextResponse.redirect(new URL("/", NEXT_PUBLIC_APP_URL), {
    status: 302,
  });

  response.cookies.set("auth-token", "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 0,
    path: "/",
  });

  return response;
}
