import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { TOTP } from "otpauth";
import { z } from "zod";

const setupTwoFactorSchema = z.object({
  secret: z.string(),
  code: z.string().length(6),
});

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const body = await request.json();
      const { secret, code } = setupTwoFactorSchema.parse(body);

      const totp = new TOTP({
        issuer: "Aura Platform",
        label: user.email,
        algorithm: "SHA1",
        digits: 6,
        period: 30,
        secret: secret,
      });

      const isValid = totp.validate({ token: code, window: 1 });

      if (isValid === null) {
        return NextResponse.json(
          { error: "Invalid verification code" },
          { status: 400 }
        );
      }

      const backupCodes = Array.from({ length: 8 }, () =>
        Math.random().toString(36).substring(2, 10).toUpperCase()
      );

      return NextResponse.json({
        success: true,
        backupCodes,
        message: "Two-factor authentication has been enabled successfully",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to set up two-factor authentication" },
        { status: 500 }
      );
    }
  }
);

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const totp = new TOTP({
        issuer: "Aura Platform",
        label: user.email,
        algorithm: "SHA1",
        digits: 6,
        period: 30,
      });

      const secret = totp.secret.base32;
      const qrCodeUrl = totp.toString();

      return NextResponse.json({
        secret,
        qrCodeUrl,
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to generate 2FA setup" },
        { status: 500 }
      );
    }
  }
);
