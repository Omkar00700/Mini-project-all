import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";

export const GET = createAuthenticatedRoute(
  async (_request: NextRequest, _user: { id: string; email: string }) => {
    try {
      const backupCodes = Array.from({ length: 8 }, () =>
        Math.random().toString(36).substring(2, 10).toUpperCase()
      );

      return NextResponse.json({
        backupCodes,
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch backup codes" },
        { status: 500 }
      );
    }
  }
);

export const POST = createAuthenticatedRoute(
  async (_request: NextRequest, _user: { id: string; email: string }) => {
    try {
      const backupCodes = Array.from({ length: 8 }, () =>
        Math.random().toString(36).substring(2, 10).toUpperCase()
      );

      return NextResponse.json({
        backupCodes,
        message: "New backup codes have been generated",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to regenerate backup codes" },
        { status: 500 }
      );
    }
  }
);
