import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { z } from "zod";

const disableTwoFactorSchema = z.object({
  password: z.string().min(1, "Password is required"),
});

export const POST = createAuthenticatedRoute(
  async (request: NextRequest, _user: { id: string; email: string }) => {
    try {
      const body = await request.json();
      const { password } = disableTwoFactorSchema.parse(body);

      if (password) {
      }

      await new Promise((resolve) => setTimeout(resolve, 1000));

      return NextResponse.json({
        success: true,
        message: "Two-factor authentication has been disabled",
      });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to disable two-factor authentication" },
        { status: 500 }
      );
    }
  }
);
