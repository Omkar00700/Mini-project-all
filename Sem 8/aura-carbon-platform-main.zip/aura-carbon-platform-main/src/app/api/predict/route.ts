import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function linearPredict(months: number[], values: number[], steps = 3) {
  const n = months.length;
  if (n < 2) {
    const avg =
      values.length > 0
        ? values.reduce((a, b) => a + b, 0) / values.length
        : 100;
    return {
      predictions: Array(steps)
        .fill(0)
        .map((_, i) => ({
          month: months[months.length - 1] + i + 1,
          value: avg,
          confidence: 0.3,
        })),
      rmse: 0,
      trend: "insufficient_data",
    };
  }

  const meanX = months.reduce((a, b) => a + b, 0) / n;
  const meanY = values.reduce((a, b) => a + b, 0) / n;

  let numerator = 0;
  let denominator = 0;

  for (let i = 0; i < n; i++) {
    numerator += (months[i] - meanX) * (values[i] - meanY);
    denominator += (months[i] - meanX) * (months[i] - meanX);
  }

  const slope = denominator === 0 ? 0 : numerator / denominator;
  const intercept = meanY - slope * meanX;

  const residuals = months.map((m, i) => values[i] - (intercept + slope * m));
  const rmse = Math.sqrt(residuals.reduce((a, b) => a + b * b, 0) / n);

  const predictions = [];
  const lastMonth = months[months.length - 1];

  for (let s = 1; s <= steps; s++) {
    const x = lastMonth + s;
    const predictedValue = Math.max(0, intercept + slope * x);
    const confidence = Math.max(0.1, Math.min(0.9, 1 - rmse / meanY));

    predictions.push({
      month: x,
      value: predictedValue,
      confidence,
      lowerBound: Math.max(0, predictedValue - 1.5 * rmse),
      upperBound: predictedValue + 1.5 * rmse,
    });
  }

  const trend = slope > 5 ? "increasing" : slope < -5 ? "decreasing" : "stable";

  return { predictions, rmse, trend, slope, intercept };
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const calculations = await prisma.carbonCalculation.findMany({
      where: { userId: user.id },
      orderBy: { periodStart: "asc" },
    });

    if (calculations.length < 1) {
      return NextResponse.json({
        predictions: [],
        message:
          "Insufficient data for predictions. Please add some carbon calculations first.",
        dataPoints: 0,
      });
    }

    const monthlyData: Record<string, number> = {};

    calculations.forEach((calc) => {
      const monthKey = calc.periodStart.toISOString().slice(0, 7);
      monthlyData[monthKey] =
        (monthlyData[monthKey] || 0) + calc.totalEmissions;
    });

    const sortedMonths = Object.keys(monthlyData).sort();
    const months = sortedMonths.map((_, index) => index + 1);
    const values = sortedMonths.map((month) => monthlyData[month]);

    const result = linearPredict(months, values, 3);

    const baseDate = new Date(sortedMonths[0] + "-01");
    const predictions = result.predictions.map((pred) => {
      const predDate = new Date(baseDate);
      predDate.setMonth(predDate.getMonth() + pred.month - 1);

      return {
        month: predDate.toISOString().slice(0, 7),
        predictedEmissions: Math.round(pred.value * 100) / 100,
        confidence: Math.round(pred.confidence * 100) / 100,
        lowerBound:
          "lowerBound" in pred
            ? Math.round(pred.lowerBound * 100) / 100
            : undefined,
        upperBound:
          "upperBound" in pred
            ? Math.round(pred.upperBound * 100) / 100
            : undefined,
      };
    });

    await prisma.prediction.create({
      data: {
        userId: user.id,
        modelId: "linear_regression_v1",
        predictionType: "monthly_emissions",
        inputData: {
          historical_months: sortedMonths,
          historical_values: values,
          data_points: calculations.length,
        },
        outputData: {
          predictions,
          trend: result.trend,
          rmse: result.rmse,
          model_params: {
            slope: result.slope,
            intercept: result.intercept,
          },
        },
        confidenceScore:
          predictions.length > 0 ? predictions[0].confidence : 0.5,
      },
    });

    return NextResponse.json({
      predictions,
      metadata: {
        dataPoints: calculations.length,
        trend: result.trend,
        rmse: Math.round(result.rmse * 100) / 100,
        historicalAverage:
          Math.round(
            (values.reduce((a, b) => a + b, 0) / values.length) * 100
          ) / 100,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
