import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";
import { exportService, ExportOptions } from "@/services/export/export.service";

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value;

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const user = await authService.verifyTokenAndGetUser(token);

    if (!user) {
      return NextResponse.json(
        { error: "Invalid or expired session" },
        { status: 401 }
      );
    }

    const searchParams = request.nextUrl.searchParams;
    const format = (searchParams.get("format") || "csv") as
      | "csv"
      | "json"
      | "html";
    const includeActivities = searchParams.get("activities") !== "false";
    const includeCalculations = searchParams.get("calculations") !== "false";
    const includePredictions = searchParams.get("predictions") === "true";
    const includeRecommendations =
      searchParams.get("recommendations") === "true";

    let dateRange: { start: Date; end: Date } | undefined;
    const startDateStr = searchParams.get("startDate");
    const endDateStr = searchParams.get("endDate");

    if (startDateStr && endDateStr) {
      dateRange = {
        start: new Date(startDateStr),
        end: new Date(endDateStr),
      };
    }

    const options: ExportOptions = {
      userId: user.id,
      format,
      dateRange,
      includeActivities,
      includeCalculations,
      includePredictions,
      includeRecommendations,
    };

    const data = await exportService.generateExportData(options);

    let output: string;
    let contentType: string;
    let filename: string;
    const dateStr = new Date().toISOString().split("T")[0];

    switch (format) {
      case "json":
        output = exportService.generateJSON(data);
        contentType = "application/json";
        filename = `aura-carbon-report-${dateStr}.json`;
        break;
      case "html":
        output = exportService.generateHTMLReport(data);
        contentType = "text/html";
        filename = `aura-carbon-report-${dateStr}.html`;
        break;
      case "csv":
      default:
        output = exportService.generateCSV(data);
        contentType = "text/csv";
        filename = `aura-carbon-report-${dateStr}.csv`;
    }

    return new NextResponse(output, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error: unknown) {
    return NextResponse.json(
      {
        error: "Something went wrong. Please try again.",
      },
      { status: 500 }
    );
  }
}
