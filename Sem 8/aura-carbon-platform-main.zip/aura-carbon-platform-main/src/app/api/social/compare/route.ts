import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const compareWith = searchParams.get("userId");

    if (!compareWith) {
      return NextResponse.json(
        { error: "User ID to compare with is required" },
        { status: 400 }
      );
    }

    const now = new Date();
    const periodStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const [userCalculations, otherCalculations] = await Promise.all([
      prisma.carbonCalculation.findMany({
        where: {
          userId: user.id,
          periodStart: { gte: periodStart },
        },
      }),
      prisma.carbonCalculation.findMany({
        where: {
          userId: compareWith,
          periodStart: { gte: periodStart },
        },
      }),
    ]);

    const otherUser = await prisma.user.findUnique({
      where: { id: compareWith },
      select: { id: true, name: true },
    });

    if (!otherUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const userTotal = userCalculations.reduce(
      (sum, c) => sum + c.totalEmissions,
      0
    );
    const otherTotal = otherCalculations.reduce(
      (sum, c) => sum + c.totalEmissions,
      0
    );

    const userAchievements = await prisma.achievement.count({
      where: { userId: user.id },
    });
    const otherAchievements = await prisma.achievement.count({
      where: { userId: compareWith },
    });

    const categories = ["transportation", "energy", "food", "consumption"];
    const categoryBreakdown = categories.map((cat) => {
      const userCatTotal = userCalculations.reduce((sum, c) => {
        const breakdown = c.breakdown as Record<string, number> | null;
        return sum + (breakdown?.[cat] || 0);
      }, 0);

      const otherCatTotal = otherCalculations.reduce((sum, c) => {
        const breakdown = c.breakdown as Record<string, number> | null;
        return sum + (breakdown?.[cat] || 0);
      }, 0);

      return {
        category: cat,
        user: Math.round(userCatTotal * 100) / 100,
        other: Math.round(otherCatTotal * 100) / 100,
        difference: Math.round((userCatTotal - otherCatTotal) * 100) / 100,
      };
    });

    return NextResponse.json({
      user: {
        id: user.id,
        name: "You",
        totalEmissions: Math.round(userTotal * 100) / 100,
        achievements: userAchievements,
      },
      other: {
        id: otherUser.id,
        name: otherUser.name,
        totalEmissions: Math.round(otherTotal * 100) / 100,
        achievements: otherAchievements,
      },
      comparison: {
        emissionsDifference: Math.round((userTotal - otherTotal) * 100) / 100,
        percentDifference:
          otherTotal > 0
            ? Math.round(((userTotal - otherTotal) / otherTotal) * 100)
            : 0,
        winner: userTotal < otherTotal ? "user" : "other",
      },
      categoryBreakdown,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to compare users" },
      { status: 500 }
    );
  }
}
