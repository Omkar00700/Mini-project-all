import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "month";
    const limit = parseInt(searchParams.get("limit") || "50");

    const now = new Date();
    let periodStart: Date;

    switch (period) {
      case "week":
        periodStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case "month":
        periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case "year":
        periodStart = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        periodStart = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    const calculations = await prisma.carbonCalculation.findMany({
      where: {
        periodStart: { gte: periodStart },
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            image: true,
            preferences: true,
          },
        },
      },
      orderBy: {
        totalEmissions: "asc",
      },
    });

    const userTotals = new Map<
      string,
      {
        user: { id: string; name: string; image: string | null };
        totalEmissions: number;
      }
    >();

    for (const calc of calculations) {
      const userId = calc.userId;
      if (!userId) continue;

      const userPrefs = calc.user?.preferences as Record<
        string,
        unknown
      > | null;
      if (userPrefs?.privacy_level === "private") continue;

      const existing = userTotals.get(userId);
      if (existing) {
        existing.totalEmissions += calc.totalEmissions;
      } else {
        userTotals.set(userId, {
          user: {
            id: calc.user?.id || userId,
            name: calc.user?.name || "Anonymous",
            image: calc.user?.image || null,
          },
          totalEmissions: calc.totalEmissions,
        });
      }
    }

    const leaderboard = Array.from(userTotals.values())
      .sort((a, b) => a.totalEmissions - b.totalEmissions)
      .slice(0, limit)
      .map((entry, index) => ({
        rank: index + 1,
        ...entry,
        totalEmissions: Math.round(entry.totalEmissions * 100) / 100,
      }));

    const userRank = leaderboard.findIndex((e) => e.user.id === user.id);

    return NextResponse.json({
      period,
      leaderboard,
      userRank: userRank >= 0 ? userRank + 1 : null,
      userEmissions:
        userRank >= 0 ? leaderboard[userRank].totalEmissions : null,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch leaderboard" },
      { status: 500 }
    );
  }
}
