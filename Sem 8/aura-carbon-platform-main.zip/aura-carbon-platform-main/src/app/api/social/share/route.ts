import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await request.json();
    const { shareType, data } = body;

    if (!shareType || !data) {
      return NextResponse.json(
        { error: "Share type and data are required" },
        { status: 400 }
      );
    }

    const shareId = `${user.id}-${shareType}-${Date.now()}`;

    const APP_URL = process.env.NEXT_PUBLIC_APP_URL;
    if (!APP_URL) {
      throw new Error("NEXT_PUBLIC_APP_URL environment variable is not set.");
    }

    return NextResponse.json(
      {
        shareId,
        shareUrl: `${APP_URL}/shared/${shareId}`,
        message: "Share link generated successfully",
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to create share" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const shareId = searchParams.get("id");

    if (!shareId) {
      return NextResponse.json(
        { error: "Share ID is required" },
        { status: 400 }
      );
    }

    const [userId, shareType] = shareId.split("-");

    const userData = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        preferences: true,
      },
    });

    if (!userData) {
      return NextResponse.json({ error: "Share not found" }, { status: 404 });
    }

    const preferences = userData.preferences as Record<string, unknown> | null;
    if (preferences?.privacy_level === "private") {
      return NextResponse.json({ error: "Share not found" }, { status: 404 });
    }

    switch (shareType) {
      case "profile": {
        const calculations = await prisma.carbonCalculation.findMany({
          where: { userId },
          orderBy: { createdAt: "desc" },
          take: 1,
        });

        const achievements = await prisma.achievement.findMany({
          where: { userId },
          take: 10,
        });

        return NextResponse.json(
          {
            type: "profile",
            user: {
              name: userData.name,
            },
            stats: {
              totalCalculations: await prisma.carbonCalculation.count({
                where: { userId },
              }),
              totalAchievements: achievements.length,
              latestEmissions: calculations[0]?.totalEmissions || 0,
            },
            achievements: achievements.map((a) => ({
              title: a.title,
              icon: a.icon,
            })),
          },
          { status: 200 }
        );
      }

      case "achievement": {
        const achievementId = searchParams.get("achievementId");
        if (!achievementId) {
          return NextResponse.json(
            { error: "Achievement ID required" },
            { status: 400 }
          );
        }

        const achievement = await prisma.achievement.findFirst({
          where: { id: achievementId, userId },
        });

        if (!achievement) {
          return NextResponse.json(
            { error: "Achievement not found" },
            { status: 404 }
          );
        }

        return NextResponse.json(
          {
            type: "achievement",
            user: { name: userData.name },
            achievement: {
              title: achievement.title,
              description: achievement.description,
              icon: achievement.icon,
              unlockedAt: achievement.unlockedAt,
            },
          },
          { status: 200 }
        );
      }

      case "comparison": {
        const calculations = await prisma.carbonCalculation.findMany({
          where: { userId },
          orderBy: { periodStart: "desc" },
          take: 12,
        });

        if (calculations.length === 0) {
          return NextResponse.json(
            { error: "No data to share" },
            { status: 404 }
          );
        }

        const totalEmissions = calculations.reduce(
          (sum, c) => sum + c.totalEmissions,
          0
        );
        const avgEmissions = totalEmissions / calculations.length;

        return NextResponse.json(
          {
            type: "comparison",
            user: { name: userData.name },
            stats: {
              totalEmissions: Math.round(totalEmissions * 100) / 100,
              avgMonthlyEmissions: Math.round(avgEmissions * 100) / 100,
              monthsTracked: calculations.length,
            },
          },
          { status: 200 }
        );
      }

      default:
        return NextResponse.json(
          { error: "Invalid share type" },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch share" },
      { status: 500 }
    );
  }
}
