import { NextRequest, NextResponse } from "next/server";
import {
  createScenario,
  getUserScenarios,
  saveScenario,
  deleteScenario,
  calculateBaseline,
} from "@/services/analytics/scenario.service";
import type { ScenarioModification } from "@/services/analytics/scenario.service";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const [scenarios, baseline] = await Promise.all([
      getUserScenarios(userId),
      calculateBaseline(userId),
    ]);

    return NextResponse.json(
      {
        success: true,
        count: scenarios.length,
        scenarios,
        baseline,
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch scenarios" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const body = await request.json();
    const { name, description, modifications } = body;

    if (!name) {
      return NextResponse.json({ error: "name is required" }, { status: 400 });
    }

    if (
      !modifications ||
      !Array.isArray(modifications) ||
      modifications.length === 0
    ) {
      return NextResponse.json(
        { error: "At least one modification is required" },
        { status: 400 }
      );
    }

    const result = await createScenario(
      userId,
      name,
      modifications as ScenarioModification[],
      description
    );

    const saved = await saveScenario(userId, result);

    return NextResponse.json(
      {
        success: true,
        scenario: saved,
        details: {
          breakdownBefore: result.breakdownBefore,
          breakdownAfter: result.breakdownAfter,
          savingsAbsolute: result.savingsAbsolute,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to create scenario" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "id is required" }, { status: 400 });
    }

    const deleted = await deleteScenario(id);

    if (!deleted) {
      return NextResponse.json(
        { error: "Scenario not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to delete scenario" },
      { status: 500 }
    );
  }
}
