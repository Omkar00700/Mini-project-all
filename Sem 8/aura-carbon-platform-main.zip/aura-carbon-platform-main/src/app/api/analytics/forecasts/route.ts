import { NextRequest, NextResponse } from "next/server";
import {
  generateForecast,
  getLatestForecasts,
  saveForecastsBatch,
  getHistoricalMonthlyEmissions,
} from "@/services/analytics/forecasting.service";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    let targetUserId = searchParams.get("userId") || "current";
    const months = parseInt(searchParams.get("months") || "6", 10);
    const model = searchParams.get("model") || "prophet";
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    if (targetUserId === "current") {
      targetUserId = user.id;
    }

    const stored = await getLatestForecasts(targetUserId, months);

    const historical = await getHistoricalMonthlyEmissions(targetUserId);

    if (stored.length > 0) {
      return NextResponse.json({
        success: true,
        source: "stored",
        historical: historical.map((h) => ({
          month: h.date.toISOString().slice(0, 7),
          emissions: h.value,
        })),
        forecasts: stored.map((f) => ({
          month: f.forecastDate.toISOString().slice(0, 7),
          predictedEmissions: f.predictedValue,
          confidence: f.confidenceLevel,
          lowerBound: f.lowerBound,
          upperBound: f.upperBound,
          model: f.model,
        })),
      });
    }

    const result = await generateForecast(targetUserId, months, model);

    if (!result) {
      return NextResponse.json({
        success: true,
        message: "Insufficient data for forecasting (need at least 3 months)",
        historical: historical.map((h) => ({
          month: h.date.toISOString().slice(0, 7),
          emissions: h.value,
        })),
        forecasts: [],
        categoryForecasts: [],
      });
    }

    await saveForecastsBatch(targetUserId, result.forecasts);

    return NextResponse.json({
      success: true,
      source: "generated",
      historical: historical.map((h) => ({
        month: h.date.toISOString().slice(0, 7),
        emissions: h.value,
      })),
      forecasts: result.forecasts.map((f) => ({
        month: f.forecastDate.toISOString().slice(0, 7),
        predictedEmissions: f.predictedValue,
        confidence: f.confidenceLevel,
        lowerBound: f.lowerBound,
        upperBound: f.upperBound,
        model: f.model,
      })),
      categoryForecasts:
        result.categoryForecasts?.map((cf) => ({
          category: cf.category,
          forecasts: cf.forecasts.map((f) => ({
            month: f.forecastDate.toISOString().slice(0, 7),
            predictedEmissions: f.predictedValue,
            lowerBound: f.lowerBound,
            upperBound: f.upperBound,
          })),
        })) || [],
      metadata: {
        trend: result.trend,
        historicalAverage: result.historicalAverage,
        model: result.model,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch forecasts" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    let { userId = "current", months = 6, model = "linear-regression" } = body;

    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    if (userId === "current") {
      userId = user.id;
    }

    const result = await generateForecast(userId, months, model);

    if (!result) {
      return NextResponse.json({
        success: true,
        message: "Insufficient historical data for forecasting",
        forecasts: [],
      });
    }

    const savedCount = await saveForecastsBatch(userId, result.forecasts);

    return NextResponse.json({
      success: true,
      savedCount,
      forecasts: result.forecasts.map((f) => ({
        month: f.forecastDate.toISOString().slice(0, 7),
        predictedEmissions: f.predictedValue,
        confidence: f.confidenceLevel,
        lowerBound: f.lowerBound,
        upperBound: f.upperBound,
        model: f.model,
      })),
      categoryForecasts:
        result.categoryForecasts?.map((cf) => ({
          category: cf.category,
          forecasts: cf.forecasts.map((f) => ({
            month: f.forecastDate.toISOString().slice(0, 7),
            predictedEmissions: f.predictedValue,
            lowerBound: f.lowerBound,
            upperBound: f.upperBound,
          })),
        })) || [],
      metadata: {
        trend: result.trend,
        historicalAverage: result.historicalAverage,
        model: result.model,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to generate forecasts" },
      { status: 500 }
    );
  }
}
