import { NextRequest, NextResponse } from "next/server";
import {
  runAnomalyDetectionForUser,
  detectAnomaliesForUser,
} from "@/services/analytics/anomaly-detection.service";
import { getUserFromRequest } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const body = await request.json();
    const { categories } = body;

    const result = await runAnomalyDetectionForUser(userId, categories);

    return NextResponse.json({
      success: true,
      detected: result.detected,
      saved: result.saved,
      message: `Detected ${result.detected} anomalies, saved ${result.saved} new ones`,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to run anomaly detection" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category") || "energy";
    const method = (searchParams.get("method") || "zscore") as "zscore" | "iqr";

    const anomalies = await detectAnomaliesForUser(userId, category, method);

    return NextResponse.json({
      success: true,
      category,
      method,
      count: anomalies.length,
      anomalies,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to detect anomalies" },
      { status: 500 }
    );
  }
}
