import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "../../../../../generated/prisma";

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const acknowledgedParam = searchParams.get("acknowledged");
    const category = searchParams.get("category");

    if (!userId) {
      return NextResponse.json(
        { error: "userId is required" },
        { status: 400 }
      );
    }

    const anomalies = await prisma.anomaly.findMany({
      where: {
        userId,
        ...(acknowledgedParam !== null
          ? { acknowledged: acknowledgedParam === "true" }
          : {}),
        ...(category ? { category } : {}),
      },
      orderBy: {
        date: "desc",
      },
    });

    return NextResponse.json({
      success: true,
      count: anomalies.length,
      anomalies,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch anomalies" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { anomalyId, acknowledged } = body;

    if (!anomalyId) {
      return NextResponse.json(
        { error: "anomalyId is required" },
        { status: 400 }
      );
    }

    const updatedAnomaly = await prisma.anomaly.update({
      where: { id: anomalyId },
      data: { acknowledged: acknowledged ?? true },
    });

    return NextResponse.json({
      success: true,
      anomaly: updatedAnomaly,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to update anomaly" },
      { status: 500 }
    );
  }
}
