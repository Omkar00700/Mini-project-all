import { NextRequest, NextResponse } from "next/server";
import {
  calculateBenchmarkForUser,
  getUserBenchmarks,
  getLatestBenchmark,
  saveBenchmark,
} from "@/services/analytics/benchmarking.service";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const { searchParams } = new URL(request.url);
    const latest = searchParams.get("latest");
    const limit = searchParams.get("limit");

    if (latest === "true") {
      const benchmark = await getLatestBenchmark(userId);

      return NextResponse.json({
        success: true,
        benchmark,
      });
    }

    const benchmarks = await getUserBenchmarks(userId, {
      limit: limit ? parseInt(limit, 10) : 12,
    });

    return NextResponse.json({
      success: true,
      count: benchmarks.length,
      benchmarks,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch benchmarks" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const body = await request.json();
    const { period } = body;

    const targetPeriod = period ? new Date(period) : new Date();

    const result = await calculateBenchmarkForUser(userId, targetPeriod);

    if (!result) {
      return NextResponse.json({
        success: true,
        message:
          "No benchmark data available (insufficient activity data or no cohort members)",
        benchmark: null,
      });
    }

    await saveBenchmark(result);

    return NextResponse.json({
      success: true,
      benchmark: result,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to calculate benchmark" },
      { status: 500 }
    );
  }
}
