import { NextRequest, NextResponse } from "next/server";
import {
  checkAndUnlockAchievements,
  getUserAchievements,
} from "@/services/analytics/gamification.service";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const achievements = await getUserAchievements(userId);
    const unlocked = achievements.filter((a) => a.unlocked);

    return NextResponse.json({
      success: true,
      total: achievements.length,
      unlocked: unlocked.length,
      achievements,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch achievements" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    const userId = user.id;

    const achievements = await checkAndUnlockAchievements(userId);
    const unlocked = achievements.filter((a) => a.unlocked);
    const newlyUnlocked = achievements.filter(
      (a) =>
        a.unlocked &&
        a.unlockedAt &&
        Date.now() - new Date(a.unlockedAt).getTime() < 5000
    );

    return NextResponse.json({
      success: true,
      total: achievements.length,
      unlocked: unlocked.length,
      newlyUnlocked: newlyUnlocked.length,
      achievements,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to check achievements" },
      { status: 500 }
    );
  }
}
