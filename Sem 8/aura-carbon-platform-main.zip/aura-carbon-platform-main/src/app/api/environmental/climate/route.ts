import { NextResponse } from "next/server";

export const revalidate = 86400;

interface ClimateData {
  year: number;
  annualMeanAnomaly: number;
  fiveYearMean: number | null;
  absoluteTemp: number;
  source: string;
  lastUpdated: string;
}

export async function GET() {
  try {
    const response = await fetch(
      "https://data.giss.nasa.gov/gistemp/graphs/graph_data/Global_Mean_Estimates_based_on_Land_and_Ocean_Data/graph.txt",
      {
        next: { revalidate: 86400 },
        headers: {
          "User-Agent": "Aura Platform / Climate Data (educational)",
        },
      }
    );

    if (!response.ok) {
      throw new Error(`NASA GISS fetch failed: ${response.status}`);
    }

    const text = await response.text();
    const lines = text.split("\n");

    const dataLines = lines.filter((line) => /^\d{4}/.test(line.trim()));

    if (dataLines.length === 0) {
      throw new Error("No data lines found in NASA GISS file");
    }

    const latestLine = dataLines[dataLines.length - 1].trim();
    const parts = latestLine.split(/\s+/);

    const year = parseInt(parts[0]);
    const annualMean = parseFloat(parts[1]);
    const fiveYearMean = parts[2] ? parseFloat(parts[2]) : null;

    if (isNaN(annualMean) || annualMean < -1 || annualMean > 3) {
      throw new Error(`Invalid anomaly value: ${annualMean}`);
    }

    const absoluteTemp = Math.round((14.0 + annualMean) * 10) / 10;

    const data: ClimateData = {
      year,
      annualMeanAnomaly: Math.round(annualMean * 100) / 100,
      fiveYearMean:
        fiveYearMean !== null ? Math.round(fiveYearMean * 100) / 100 : null,
      absoluteTemp,
      source:
        "NASA GISS Surface Temperature Analysis (GISTEMP v4) — vs 1951-1980 baseline",
      lastUpdated: `${year}`,
    };

    return NextResponse.json(
      { success: true, data },
      {
        headers: {
          "Cache-Control":
            "public, s-maxage=86400, stale-while-revalidate=3600",
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        fallback: true,
        data: {
          year: 2024,
          annualMeanAnomaly: 1.29,
          fiveYearMean: 1.17,
          absoluteTemp: 15.29,
          source: "NASA GISS (cached fallback — 2024 preliminary data)",
          lastUpdated: "2024",
        },
        error: "Something went wrong. Please try again.",
      },
      { status: 200 }
    );
  }
}
