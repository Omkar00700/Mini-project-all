import { NextResponse } from "next/server";

export const revalidate = 21600;

interface Co2Data {
  ppm: number;
  year: number;
  month: number;
  day: number;
  weeksSince1800: number;
  ppmYearAgo: number;
  ppmDecadeAgo: number;
  increaseFromLastYear: number;
  source: string;
  lastUpdated: string;
}

export async function GET() {
  try {
    const response = await fetch(
      "https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_weekly_mlo.csv",
      {
        next: { revalidate: 21600 },
        headers: {
          "User-Agent": "Aura Platform / Climate Data (educational)",
        },
      }
    );

    if (!response.ok) {
      throw new Error(`NOAA fetch failed: ${response.status}`);
    }

    const csv = await response.text();
    const lines = csv.split("\n");

    const dataLines = lines.filter(
      (line) => line.trim() && !line.startsWith("#")
    );

    if (dataLines.length < 2) {
      throw new Error("No data lines found in NOAA CSV");
    }

    const latestLine = dataLines[dataLines.length - 1].trim();
    dataLines.find((line) => {
      const parts = line
        .trim()
        .split(",")
        .map((p) => p.trim());

      return parts.length > 4;
    });

    const parts = latestLine.split(",").map((p) => p.trim());

    if (parts.length < 5) {
      throw new Error("Unexpected CSV format");
    }

    const ppm = parseFloat(parts[4]);
    const year = parseInt(parts[0]);
    const month = parseInt(parts[1]);
    const day = parseInt(parts[2]);
    const ppmYearAgo = parseFloat(parts[6]) || 0;
    const ppmDecadeAgo = parseFloat(parts[7]) || 0;

    if (isNaN(ppm) || ppm < 350 || ppm > 500) {
      throw new Error(`Invalid ppm value: ${ppm}`);
    }

    const data: Co2Data = {
      ppm: Math.round(ppm * 10) / 10,
      year,
      month,
      day,
      weeksSince1800: parseInt(parts[8]) || 0,
      ppmYearAgo: Math.round(ppmYearAgo * 10) / 10,
      ppmDecadeAgo: Math.round(ppmDecadeAgo * 10) / 10,
      increaseFromLastYear: Math.round((ppm - ppmYearAgo) * 10) / 10,
      source:
        "NOAA Global Monitoring Laboratory (Mauna Loa Observatory, Hawaii)",
      lastUpdated: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
    };

    return NextResponse.json(
      { success: true, data },
      {
        headers: {
          "Cache-Control":
            "public, s-maxage=21600, stale-while-revalidate=3600",
        },
      }
    );
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        fallback: true,
        data: {
          ppm: 424.6,
          year: 2025,
          month: 2,
          day: 17,
          weeksSince1800: 11258,
          ppmYearAgo: 422.0,
          ppmDecadeAgo: 399.1,
          increaseFromLastYear: 2.6,
          source: "NOAA GML (cached fallback)",
          lastUpdated: "2025-02-17",
        },
        error: "Something went wrong. Please try again.",
      },
      { status: 200 }
    );
  }
}
