import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";

export async function GET(req: NextRequest) {
  const token = req.cookies.get("auth-token")?.value;
  if (!token) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const user = await authService.verifyTokenAndGetUser(token);
  if (!user || user.role !== "admin") {
    return NextResponse.json(
      { error: "Admin access required" },
      { status: 403 }
    );
  }

  return NextResponse.json(
    {
      message: "API test endpoint",
      timestamp: new Date().toISOString(),
    },
    { status: 200 }
  );
}
