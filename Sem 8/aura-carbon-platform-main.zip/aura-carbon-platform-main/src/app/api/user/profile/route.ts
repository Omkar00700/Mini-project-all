import { NextRequest, NextResponse } from "next/server";
import { createAuthenticatedRoute } from "@/lib/auth/middleware";
import { userService } from "@/services/user";
import { updateUserProfileSchema } from "@/lib/validations/user";

export const GET = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const profile = await userService.getUserProfile(user.id);

      if (!profile) {
        return NextResponse.json(
          { error: "Profile not found" },
          { status: 404 }
        );
      }

      return NextResponse.json({ profile });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to fetch profile" },
        { status: 500 }
      );
    }
  }
);

const updateProfile = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      const body = await request.json();

      const validationResult = updateUserProfileSchema.safeParse(body);

      if (!validationResult.success) {
        return NextResponse.json(
          {
            error: "Invalid data",
            details: validationResult.error.errors,
          },
          { status: 400 }
        );
      }

      const updatedProfile = await userService.updateUserProfile(
        user.id,
        validationResult.data
      );

      return NextResponse.json({ profile: updatedProfile });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to update profile" },
        { status: 500 }
      );
    }
  }
);

export const PUT = updateProfile;
export const PATCH = updateProfile;

export const DELETE = createAuthenticatedRoute(
  async (request: NextRequest, user: { id: string; email: string }) => {
    try {
      await userService.deleteUserProfile(user.id);
      return NextResponse.json({ success: true });
    } catch (error) {
      return NextResponse.json(
        { error: "Failed to delete profile" },
        { status: 500 }
      );
    }
  }
);
