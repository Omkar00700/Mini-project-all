import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const userId = user.id;

    const now = new Date();
    const currentYear = now.getUTCFullYear();
    const currentMonth = now.getUTCMonth();

    let sixMonthsAgoYear = currentYear;
    let sixMonthsAgoMonth = currentMonth - 6;
    while (sixMonthsAgoMonth < 0) {
      sixMonthsAgoMonth += 12;
      sixMonthsAgoYear -= 1;
    }
    const sixMonthsAgo = new Date(
      Date.UTC(sixMonthsAgoYear, sixMonthsAgoMonth, 1, 0, 0, 0)
    );

    let lastMonthYear = currentYear;
    let lastMonthNum = currentMonth - 1;
    if (lastMonthNum < 0) {
      lastMonthNum = 11;
      lastMonthYear -= 1;
    }
    const lastMonth = new Date(
      Date.UTC(lastMonthYear, lastMonthNum, 1, 0, 0, 0)
    );

    const currentMonthStart = new Date(
      Date.UTC(currentYear, currentMonth, 1, 0, 0, 0)
    );

    const calculations = await prisma.carbonCalculation.findMany({
      where: {
        userId: userId,
        createdAt: { gte: sixMonthsAgo },
      },
      orderBy: { createdAt: "desc" },
    });

    const lastMonthCalculations = calculations.filter(
      (calc) =>
        calc.createdAt >= lastMonth && calc.createdAt < currentMonthStart
    );
    const lastMonthTotal = lastMonthCalculations.reduce(
      (sum, calc) => sum + calc.totalEmissions,
      0
    );

    const currentMonthCalculations = calculations.filter(
      (calc) => calc.createdAt >= currentMonthStart
    );
    const currentMonthTotal = currentMonthCalculations.reduce(
      (sum, calc) => sum + calc.totalEmissions,
      0
    );

    const monthlySeries = [];

    for (let i = 5; i >= 0; i--) {
      let targetYear = currentYear;
      let targetMonth = currentMonth - i;
      while (targetMonth < 0) {
        targetMonth += 12;
        targetYear -= 1;
      }

      const monthStart = new Date(
        Date.UTC(targetYear, targetMonth, 1, 0, 0, 0)
      );
      const monthEnd = new Date(
        Date.UTC(targetYear, targetMonth + 1, 0, 23, 59, 59)
      );

      const monthCalculations = calculations.filter(
        (calc) => calc.createdAt >= monthStart && calc.createdAt <= monthEnd
      );

      const monthTotal = monthCalculations.reduce(
        (sum, calc) => sum + calc.totalEmissions,
        0
      );

      const monthLabel = `${targetYear}-${String(targetMonth + 1).padStart(2, "0")}`;

      const monthCategoryTotals: Record<string, number> = {};
      monthCalculations.forEach((calc) => {
        if (calc.breakdown && typeof calc.breakdown === "object") {
          Object.entries(calc.breakdown as Record<string, number>).forEach(
            ([category, amount]) => {
              monthCategoryTotals[category] = (monthCategoryTotals[category] || 0) + amount;
            }
          );
        }
      });

      monthlySeries.push({
        month: monthLabel,
        total: monthTotal,
        count: monthCalculations.length,
        breakdown: monthCategoryTotals,
      });
    }

    const categoryTotals: Record<string, number> = {};
    calculations.forEach((calc) => {
      if (calc.breakdown && typeof calc.breakdown === "object") {
        Object.entries(calc.breakdown as Record<string, number>).forEach(
          ([category, amount]) => {
            categoryTotals[category] = (categoryTotals[category] || 0) + amount;
          }
        );
      }
    });

    const topContributors = Object.entries(categoryTotals)
      .map(([category, total]) => ({ category, total }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    const recentCalculations = calculations.slice(0, 5).map((calc) => {
      return {
        id: calc.id,
        date: calc.createdAt,
        total: calc.totalEmissions,
        breakdown: calc.breakdown,
      };
    });

    const goals = await prisma.goal.findMany({
      where: {
        userId: userId,
        startDate: { lte: now },
        OR: [{ endDate: null }, { endDate: { gte: now } }],
      },
      orderBy: { createdAt: "desc" },
    });

    const goalProgress = goals.map((goal) => {
      const progress = lastMonthTotal / goal.targetKgPerMonth;
      return {
        id: goal.id,
        targetName: goal.targetName,
        targetKgPerMonth: goal.targetKgPerMonth,
        currentMonthEmissions: lastMonthTotal,
        progress: Math.min(progress, 1),
        isOnTrack: progress <= 1,
      };
    });

    const userData = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        currentStreak: true,
        streakLastMaintained: true,
      },
    });

    const streakTrend =
      userData && userData.streakLastMaintained
        ? Math.max(0, userData.currentStreak - 5) // Simplified trend calculation
        : 0;

    return NextResponse.json(
      {
        summary: {
          lastMonthTotal,
          currentMonthTotal,
          totalCalculations: calculations.length,
          averageMonthly:
            monthlySeries.reduce((sum, month) => sum + month.total, 0) / 6,
        },
        monthlySeries,
        topContributors,
        recentCalculations,
        goalProgress,
        streak: userData?.currentStreak || 0,
        streakTrend,
        monthSavings: Math.max(0, lastMonthTotal - currentMonthTotal),
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      {
        error: "Something went wrong. Please try again.",
      },
      { status: 500 }
    );
  }
}
