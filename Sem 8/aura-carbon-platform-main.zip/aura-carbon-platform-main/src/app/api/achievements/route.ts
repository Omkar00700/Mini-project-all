import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { calculateLevel } from "@/config/gamification";

const ACHIEVEMENTS = [
  {
    id: "first_step",
    name: "First Step",
    description: "Log your first activity",
    category: "tracking",
    tier: "bronze",
    icon: "👣",
    points: 10,
    requirement: { type: "activities_logged", target: 1 },
  },
  {
    id: "active_tracker",
    name: "Active Tracker",
    description: "Log 25 activities",
    category: "tracking",
    tier: "silver",
    icon: "📊",
    points: 50,
    requirement: { type: "activities_logged", target: 25 },
  },
  {
    id: "data_master",
    name: "Data Master",
    description: "Log 100 activities",
    category: "tracking",
    tier: "gold",
    icon: "🎯",
    points: 150,
    requirement: { type: "activities_logged", target: 100 },
  },
  {
    id: "carbon_pioneer",
    name: "Carbon Pioneer",
    description: "Log 500 activities",
    category: "tracking",
    tier: "platinum",
    icon: "🌟",
    points: 500,
    requirement: { type: "activities_logged", target: 500 },
  },
  {
    id: "small_saver",
    name: "Small Saver",
    description: "Save 10 kg of CO2",
    category: "reduction",
    tier: "bronze",
    icon: "🌱",
    points: 20,
    requirement: { type: "co2_saved", target: 10 },
  },
  {
    id: "eco_warrior",
    name: "Eco Warrior",
    description: "Save 100 kg of CO2",
    category: "reduction",
    tier: "silver",
    icon: "🦸",
    points: 100,
    requirement: { type: "co2_saved", target: 100 },
  },
  {
    id: "planet_guardian",
    name: "Planet Guardian",
    description: "Save 500 kg of CO2",
    category: "reduction",
    tier: "gold",
    icon: "🌍",
    points: 250,
    requirement: { type: "co2_saved", target: 500 },
  },
  {
    id: "climate_hero",
    name: "Climate Hero",
    description: "Save 2 tons of CO2",
    category: "reduction",
    tier: "platinum",
    icon: "🏆",
    points: 1000,
    requirement: { type: "co2_saved", target: 2000 },
  },
  {
    id: "week_warrior",
    name: "Week Warrior",
    description: "Maintain a 7-day logging streak",
    category: "streaks",
    tier: "bronze",
    icon: "🔥",
    points: 50,
    requirement: { type: "days_streak", target: 7 },
  },
  {
    id: "monthly_master",
    name: "Monthly Master",
    description: "Maintain a 30-day logging streak",
    category: "streaks",
    tier: "silver",
    icon: "📅",
    points: 200,
    requirement: { type: "days_streak", target: 30 },
  },
  {
    id: "consistency_king",
    name: "Consistency King",
    description: "Maintain a 100-day logging streak",
    category: "streaks",
    tier: "gold",
    icon: "👑",
    points: 500,
    requirement: { type: "days_streak", target: 100 },
  },
  {
    id: "eternal_flame",
    name: "Eternal Flame",
    description: "Maintain a 365-day logging streak",
    category: "streaks",
    tier: "platinum",
    icon: "💎",
    points: 2000,
    requirement: { type: "days_streak", target: 365 },
  },
  {
    id: "goal_starter",
    name: "Goal Starter",
    description: "Create your first goal",
    category: "goals",
    tier: "bronze",
    icon: "🎯",
    points: 25,
    requirement: { type: "goals_completed", target: 1 },
  },
  {
    id: "achiever",
    name: "Achiever",
    description: "Complete 10 goals",
    category: "goals",
    tier: "silver",
    icon: "🏅",
    points: 150,
    requirement: { type: "goals_completed", target: 10 },
  },
  {
    id: "champion",
    name: "Champion",
    description: "Complete 50 goals",
    category: "goals",
    tier: "gold",
    icon: "🎖️",
    points: 500,
    requirement: { type: "goals_completed", target: 50 },
  },
  {
    id: "visionary",
    name: "Visionary",
    description: "Complete 100 goals",
    category: "goals",
    tier: "platinum",
    icon: "✨",
    points: 1200,
    requirement: { type: "goals_completed", target: 100 },
  },
];

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const unlockedAchievements = await prisma.achievement.findMany({
      where: { userId: user.id },
    });

    const unlockedMap = new Map(unlockedAchievements.map((a) => [a.key, a]));

    const activitiesCount = await prisma.activityData.count({
      where: { userId: user.id },
    });

    const userRecord = await prisma.user.findUnique({
      where: { id: user.id },
      select: { currentStreak: true, streakFreezes: true },
    });

    const goalsCompleted = await prisma.goal.count({
      where: {
        userId: user.id,
        endDate: { lt: new Date() },
      },
    });

    const allCalcs = await prisma.carbonCalculation.findMany({
      where: { userId: user.id },
      select: { totalEmissions: true, createdAt: true },
      orderBy: { createdAt: "asc" },
    });

    let co2Saved = 0;
    if (allCalcs.length > 1) {
      const baseline = allCalcs[0].totalEmissions;
      for (const calc of allCalcs.slice(1)) {
        if (calc.totalEmissions < baseline) {
          co2Saved += baseline - calc.totalEmissions;
        }
      }
    }

    const badgesEarned = unlockedAchievements.length;

    const achievements = ACHIEVEMENTS.map((def) => {
      const unlocked = unlockedMap.get(def.id);
      let progress = 0;

      switch (def.requirement.type) {
        case "activities_logged":
          progress = Math.min(
            100,
            (activitiesCount / def.requirement.target) * 100
          );
          break;
        case "co2_saved":
          progress = Math.min(
            100,
            (co2Saved / def.requirement.target) * 100
          );
          break;
        case "days_streak":
          progress = Math.min(
            100,
            ((userRecord?.currentStreak || 0) / def.requirement.target) * 100
          );
          break;
        case "goals_completed":
          progress = Math.min(
            100,
            (goalsCompleted / def.requirement.target) * 100
          );
          break;
        case "badges_earned":
          progress = Math.min(
            100,
            (badgesEarned / def.requirement.target) * 100
          );
          break;
        default:
          progress = 0;
      }

      return {
        ...def,
        unlockedAt: unlocked?.unlockedAt,
        progress: Math.round(progress),
        isUnlocked: !!unlocked,
      };
    });

    const userXpRecord = await prisma.user.findUnique({
      where: { id: user.id },
      select: { totalXp: true },
    });
    const totalXp = userXpRecord?.totalXp ?? 0;
    const levelData = calculateLevel(totalXp);

    return NextResponse.json(
      {
        achievements,
        streak: userRecord?.currentStreak || 0,
        streakFreezes: userRecord?.streakFreezes || 0,
        stats: {
          totalPoints: totalXp,
          level: levelData.level,
          levelTitle: levelData.title,
          unlockedCount: achievements.filter((a) => a.isUnlocked).length,
          totalCount: achievements.length,
        },
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch achievements" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { achievementId } = await request.json();

    if (!achievementId) {
      return NextResponse.json(
        { error: "Achievement ID is required" },
        { status: 400 }
      );
    }

    const achievementDef = ACHIEVEMENTS.find((a) => a.id === achievementId);
    if (!achievementDef) {
      return NextResponse.json(
        { error: "Invalid achievement ID" },
        { status: 400 }
      );
    }

    const existing = await prisma.achievement.findFirst({
      where: { userId: user.id, key: achievementId },
    });

    if (existing) {
      return NextResponse.json(
        {
          message: "Achievement already unlocked",
          achievement: existing,
        },
        { status: 200 }
      );
    }

    const achievement = await prisma.achievement.create({
      data: {
        userId: user.id,
        key: achievementId,
        title: achievementDef.name,
        description: achievementDef.description,
        icon: achievementDef.icon,
      },
    });

    return NextResponse.json(
      {
        message: "Achievement unlocked!",
        achievement: {
          id: achievement.id,
          key: achievement.key,
          title: achievement.title,
          description: achievement.description,
          icon: achievement.icon,
          unlockedAt: achievement.unlockedAt,
          points: achievementDef.points,
          tier: achievementDef.tier,
          category: achievementDef.category,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to unlock achievement" },
      { status: 500 }
    );
  }
}
