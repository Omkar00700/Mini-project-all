import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";

export async function GET(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value;
  if (!token) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const currentUser = await authService.verifyTokenAndGetUser(token);
  if (!currentUser || currentUser.role !== "admin") {
    return NextResponse.json(
      { error: "Admin access required" },
      { status: 403 }
    );
  }

  return NextResponse.json(
    {
      DATABASE_URL_SET: !!process.env.DATABASE_URL,
      DIRECT_URL_SET: !!process.env.DIRECT_URL,
      JWT_SECRET_SET: !!process.env.JWT_SECRET,
      NEXTAUTH_SECRET_SET: !!process.env.NEXTAUTH_SECRET,
      OPENAI_API_KEY_SET: !!process.env.OPENAI_API_KEY,
      NODE_ENV: process.env.NODE_ENV,
    },
    { status: 200 }
  );
}
