import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const currentUser = await authService.verifyTokenAndGetUser(token);
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    const users = await prisma.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        createdAt: true,
        lastLoginAt: true,
        _count: {
          select: {
            activityData: true,
            sessions: true,
            carbonCalculations: true,
            goals: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    const totalUsers = users.length;
    const activeToday = users.filter((u) => {
      if (!u.lastLoginAt) return false;
      const today = new Date();
      const loginDate = new Date(u.lastLoginAt);
      return loginDate.toDateString() === today.toDateString();
    }).length;
    const totalActivities = users.reduce(
      (sum, u) => sum + u._count.activityData,
      0
    );
    const totalCalculations = users.reduce(
      (sum, u) => sum + u._count.carbonCalculations,
      0
    );

    return NextResponse.json({
      success: true,
      stats: { totalUsers, activeToday, totalActivities, totalCalculations },
      users,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const token = request.cookies.get("auth-token")?.value;
    if (!token)
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const currentUser = await authService.verifyTokenAndGetUser(token);
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    const { userId, role } = await request.json();
    if (!userId || !["admin", "user"].includes(role)) {
      return NextResponse.json({ error: "Invalid request" }, { status: 400 });
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { role },
      select: { id: true, name: true, email: true, role: true },
    });

    return NextResponse.json({ success: true, user: updated });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to update user role" },
      { status: 500 }
    );
  }
}
