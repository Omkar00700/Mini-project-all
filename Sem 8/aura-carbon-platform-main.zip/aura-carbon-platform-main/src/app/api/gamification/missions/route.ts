import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [todayActivities, goals] = await Promise.all([
      prisma.activityData.findMany({
        where: {
          userId: user.id,
          createdAt: { gte: today },
        },
      }),
      prisma.goal.findMany({
        where: { userId: user.id },
      }),
    ]);

    const hasGoal = goals.length > 0;
    const totalActivitiesToday = todayActivities.length;
    const transportActivitiesToday = todayActivities.filter(
      (a) =>
        a.category.toLowerCase().includes("transport") ||
        a.category.toLowerCase().includes("vehicle")
    ).length;

    const energyActivitiesToday = todayActivities.filter(
      (a) =>
        a.category.toLowerCase().includes("energy") ||
        a.category.toLowerCase().includes("electricity")
    ).length;

    const missions = [
      {
        id: "daily_log",
        title: "Daily Tracker",
        description: "Log any carbon activity today",
        rewardXp: 15,
        progress: Math.min(totalActivitiesToday, 1),
        target: 1,
        completed: totalActivitiesToday >= 1,
        icon: "📅",
      },
      {
        id: "daily_transit",
        title: "Transit Check",
        description: "Log a transportation activity today",
        rewardXp: 25,
        progress: Math.min(transportActivitiesToday, 1),
        target: 1,
        completed: transportActivitiesToday >= 1,
        icon: "🚗",
      },
      {
        id: "daily_energy",
        title: "Energy Audit",
        description: "Log your energy usage today",
        rewardXp: 20,
        progress: Math.min(energyActivitiesToday, 1),
        target: 1,
        completed: energyActivitiesToday >= 1,
        icon: "⚡",
      },
      {
        id: "goal_setter",
        title: "Visionary",
        description: "Set an active reduction goal (One-time)",
        rewardXp: 50,
        progress: hasGoal ? 1 : 0,
        target: 1,
        completed: hasGoal,
        icon: "🎯",
      },
    ];

    return NextResponse.json({ missions });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to load missions" },
      { status: 500 }
    );
  }
}
