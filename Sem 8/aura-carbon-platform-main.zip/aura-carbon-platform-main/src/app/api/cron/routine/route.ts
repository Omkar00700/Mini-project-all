import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization");
    const cronSecret = process.env.CRON_SECRET;

    if (
      process.env.NODE_ENV === "production" &&
      authHeader !== `Bearer ${cronSecret}`
    ) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const now = new Date();
    const dailyThreshold = new Date(now.getTime() - 20 * 60 * 60 * 1000);

    const weeklyThreshold = new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000);

    const routinesDue = await db.routine.findMany({
      where: {
        isActive: true,
        OR: [
          {
            frequency: "daily",
            lastTriggered: { lt: dailyThreshold },
          },
          {
            frequency: "weekly",
            lastTriggered: { lt: weeklyThreshold },
          },
        ],
      },
      include: {
        user: true,
      },
    });

    if (routinesDue.length === 0) {
      return NextResponse.json({
        message: "No routines due for processing",
        count: 0,
      });
    }

    let processedCount = 0;

    for (const routine of routinesDue) {
      try {
        await db.activityData.create({
          data: {
            userId: routine.userId,
            category: routine.category,
            subcategory: routine.subcategory,
            value: routine.value,
            unit: routine.unit,
            date: now,
            source: "routine_generated",
            metadata: { routineId: routine.id, frequency: routine.frequency },
          },
        });

        await db.routine.update({
          where: { id: routine.id },
          data: {
            lastTriggered: now,
          },
        });

        const currentStreak = routine.user.currentStreak;
        let newStreak = currentStreak;

        const streakMaintained = routine.user.streakLastMaintained;
        if (
          !streakMaintained ||
          now.getTime() - streakMaintained.getTime() > 48 * 60 * 60 * 1000
        ) {
          newStreak = 1;
        } else {
          if (
            now.getTime() - streakMaintained.getTime() >
            12 * 60 * 60 * 1000
          ) {
            newStreak += 1;
          }
        }

        Math.max(newStreak, routine.user.longestStreak);

        const currentExp = routine.user.totalXp;
        const newExp = currentExp + 25;
        const newLevel = Math.floor(Math.sqrt(newExp / 100)) + 1;

        await db.user.update({
          where: { id: routine.userId },
          data: {
            currentStreak: routine.user.currentStreak + 1,
            longestStreak: Math.max(
              routine.user.longestStreak,
              routine.user.currentStreak + 1
            ),
            streakLastMaintained: new Date(),
            totalXp: newExp,
            currentLevel: newLevel,
          },
        });

        processedCount++;
      } catch (err) {}
    }

    return NextResponse.json({
      success: true,
      message: `Successfully processed ${processedCount} routines`,
      count: processedCount,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error during routine processing" },
      { status: 500 }
    );
  }
}
