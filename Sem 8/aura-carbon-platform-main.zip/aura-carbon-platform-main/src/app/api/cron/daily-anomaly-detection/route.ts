import { NextRequest, NextResponse } from "next/server";
import { runDailyAnomalyDetection } from "@/jobs/daily-anomaly-detection";

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization");
    const cronSecret =
      process.env.CRON_SECRET || "dev-secret-change-in-production";

    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const result = await runDailyAnomalyDetection();

    return NextResponse.json({
      message: "Daily anomaly detection completed",
      ...result,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Something went wrong. Please try again.",
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json(
      { error: "GET not allowed in production" },
      { status: 405 }
    );
  }

  return POST(request);
}
