import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { predictionService } from "@/services/ai/prediction.service";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);

    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const monthsAhead = parseInt(searchParams.get("months") || "6");

    const predictions = await predictionService.generatePredictions(
      user.id,
      monthsAhead
    );

    const historical = await predictionService.getHistoricalEmissions(user.id);

    return NextResponse.json(
      {
        success: true,
        historical,
        predictions,
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
