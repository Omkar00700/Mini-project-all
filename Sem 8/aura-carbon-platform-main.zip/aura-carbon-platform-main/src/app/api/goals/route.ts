import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import { achievementService } from "@/services/gamification/achievement.service";
import { z } from "zod";

const createGoalSchema = z.object({
  targetName: z.string().min(1, "Target name is required"),
  targetKgPerMonth: z
    .any()
    .transform(Number)
    .refine((n) => !isNaN(n) && n > 0, "Valid target amount required"),
  baselineKgPerMonth: z
    .any()
    .optional()
    .transform((v) => (v ? Number(v) : null))
    .refine((n) => n === null || !isNaN(n), "Invalid baseline"),
  startDate: z.string().datetime().optional().or(z.date().optional()),
  endDate: z.string().datetime().optional().or(z.date().optional()).nullable(),
});

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const goals = await prisma.goal.findMany({
      where: {
        userId: user.id,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return NextResponse.json({ goals }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid JSON payload" },
        { status: 400 }
      );
    }

    const validation = createGoalSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { error: validation.error.errors[0].message },
        { status: 400 }
      );
    }

    const {
      targetName,
      targetKgPerMonth,
      baselineKgPerMonth,
      startDate,
      endDate,
    } = validation.data;

    const goal = await prisma.goal.create({
      data: {
        userId: user.id,
        targetName,
        targetKgPerMonth,
        baselineKgPerMonth,
        startDate: startDate ? new Date(startDate) : new Date(),
        endDate: endDate ? new Date(endDate) : null,
      },
    });

    const reward = await achievementService.processAction(
      user.id,
      "GOAL_CREATED"
    );

    return NextResponse.json(
      { goal, xpEarned: reward.xpEarned, reward },
      { status: 201 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
