import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { aiRecommendationsService } from "@/services/ai/openai-recommendations.service";

export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const latestCalc = await prisma.carbonCalculation.findFirst({
      where: { userId: user.id },
      orderBy: { periodStart: "desc" },
      select: { totalEmissions: true, breakdown: true, periodStart: true },
    });

    if (!latestCalc) {
      return NextResponse.json(
        {
          success: true,
          hasData: false,
          recommendations: [],
          aiEnabled: aiRecommendationsService.isConfigured(),
          message: "No carbon data yet. Use the calculator to get started.",
        },
        { status: 200 }
      );
    }

    const bd = (latestCalc.breakdown ?? {}) as Record<string, number>;
    const breakdown = {
      transport: bd.transportation ?? bd.transport ?? bd.Transport ?? bd.Transportation ?? bd.transport_emissions ?? 0,
      energy: bd.energy ?? bd.Energy ?? bd.energy_emissions ?? 0,
      food: bd.food ?? bd.Food ?? bd.food_emissions ?? 0,
      waste: bd.waste ?? bd.Waste ?? bd.waste_emissions ?? 0,
    };

    const [userData, activityCount, recentCalcs] = await Promise.all([
      prisma.user.findUnique({
        where: { id: user.id },
        select: {
          location: true,
          household: true,
          currentLevel: true,
          totalXp: true,
        },
      }),
      prisma.activityData.count({ where: { userId: user.id } }),
      prisma.carbonCalculation.findMany({
        where: { userId: user.id },
        orderBy: { periodStart: "desc" },
        take: 5,
        select: { totalEmissions: true, periodStart: true },
      }),
    ]);

    const recentHistory = recentCalcs.map((c) => ({
      month: c.periodStart.toISOString().slice(0, 7),
      emissions: c.totalEmissions,
    }));

    const recommendations =
      await aiRecommendationsService.generateRecommendations(
        {
          totalEmissions: latestCalc.totalEmissions,
          breakdown,
          location:
            (userData?.location as any)?.country || userData?.location || "India",
          householdSize: (userData?.household as any)?.size || 1,
          userLevel: userData?.currentLevel ?? 1,
          activityCount,
          recentHistory,
        },
        6
      );

    return NextResponse.json(
      {
        success: true,
        hasData: true,
        totalEmissions: latestCalc.totalEmissions,
        breakdown,
        periodStart: latestCalc.periodStart,
        recommendations,
        aiEnabled: aiRecommendationsService.isConfigured(),
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Recommendations API Error:", error);
    return NextResponse.json(
      { error: error.message || "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await request.json();
    const { totalEmissions, breakdown, location, householdSize, limit } = body;

    if (!totalEmissions || !breakdown) {
      return NextResponse.json(
        { error: "Missing required fields: totalEmissions, breakdown" },
        { status: 400 }
      );
    }

    const recommendations =
      await aiRecommendationsService.generateRecommendations(
        { totalEmissions, breakdown, location, householdSize },
        limit || 5
      );

    return NextResponse.json(
      {
        success: true,
        recommendations,
        aiEnabled: aiRecommendationsService.isConfigured(),
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
