import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const SYSTEM_PROMPT = `You are Aura AI — an expert carbon footprint analyst and sustainability advisor for Indian households and professionals.

You have access to the user's actual carbon footprint data which will be provided in the context. Use this data to give highly personalized, specific advice.

Your capabilities:
- Analyze their real emission breakdowns (transport, energy, food, waste)
- Calculate exact CO₂ savings for specific lifestyle changes
- Compare to Indian averages and global benchmarks
- Suggest practical, affordable actions specific to India (public transport options, local foods, government subsidies, etc.)
- Model "what-if" scenarios (e.g., "What if I switch from bike to metro daily?")
- Explain carbon concepts in simple terms
- Track progress and celebrate reductions

Guidelines:
- Always be specific and data-driven — use their actual numbers
- Consider Indian context: climate, culture, infrastructure, cost of living
- Be encouraging and actionable, not preachy
- Give concrete numbers (e.g., "switching to metro will save ~45 kg CO₂/month based on your 15km daily commute")
- Keep responses concise but complete (3-6 lines unless detail is needed)
- Use emojis sparingly for key metrics (🌱 ✅ ⚠️ 📊)

You are NOT a general chatbot. Redirect non-sustainability questions back to the user's carbon footprint.`;


export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { messages }: { messages: Message[] } = await request.json();
    if (!messages?.length) {
      return NextResponse.json({ error: "Messages required" }, { status: 400 });
    }

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const [latestCalc, activitiesCount, historicalCalcs, _userData] = await Promise.all([
      prisma.carbonCalculation.findFirst({
        where: { userId: user.id },
        orderBy: { periodStart: "desc" },
        select: { totalEmissions: true, breakdown: true },
      }),
      prisma.activityData.count({ where: { userId: user.id } }),
      prisma.carbonCalculation.findMany({
        where: {
          userId: user.id,
          periodStart: { gte: sixMonthsAgo },
        },
        orderBy: { periodStart: "asc" },
        select: { totalEmissions: true, periodStart: true },
      }),
      prisma.user.findUnique({
        where: { id: user.id },
        select: { currentLevel: true, totalXp: true, currentStreak: true, longestStreak: true },
      })
    ]);

    const userData = _userData;

    const hasData = latestCalc !== null;
    const bd = (latestCalc?.breakdown ?? {}) as Record<string, number>;
    const userStats = {
      hasData,
      totalEmissions: latestCalc?.totalEmissions ?? 0,
      transport:
        bd.transport ?? bd.Transportation ?? bd.transport_emissions ?? 0,
      energy: bd.energy ?? bd.Energy ?? bd.energy_emissions ?? 0,
      food: bd.food ?? bd.Food ?? bd.food_emissions ?? 0,
      waste: bd.waste ?? bd.Waste ?? bd.waste_emissions ?? 0,
      activitiesLogged: activitiesCount,
      userName: user.name,
      history: historicalCalcs.map((c) => ({
        month: c.periodStart.toISOString().slice(0, 7),
        emissions: c.totalEmissions.toFixed(1),
      })),
      currentLevel: userData?.currentLevel ?? 1,
      totalXp: userData?.totalXp ?? 0,
      currentStreak: userData?.currentStreak ?? 0,
      longestStreak: userData?.longestStreak ?? 0,
    };

    if (
      !process.env.OPENAI_API_KEY ||
      !process.env.OPENAI_BASE_URL ||
      !process.env.OPENAI_MODEL
    ) {
      throw new Error(
        "AI service is not properly configured. Missing required environment variables."
      );
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    const BASE_URL = process.env.OPENAI_BASE_URL.replace(/\/$/, "");
    const PRIMARY_MODEL = process.env.OPENAI_MODEL;

    const isOpenRouter = BASE_URL.includes("openrouter.ai");
    const lastUserMessage = messages[messages.length - 1]?.content ?? "";

    const contextualSystem = userStats.hasData
      ? `${SYSTEM_PROMPT}

USER'S REAL CARBON DATA (verified from database — use these exact numbers):
- Name: ${userStats.userName}
- Monthly total emissions: ${userStats.totalEmissions.toFixed(1)} kg CO₂
- Transport: ${userStats.transport.toFixed(1)} kg CO₂
- Energy: ${userStats.energy.toFixed(1)} kg CO₂
- Food: ${userStats.food.toFixed(1)} kg CO₂
- Waste: ${userStats.waste.toFixed(1)} kg CO₂
- Activities logged: ${userStats.activitiesLogged}
- Emission History (last 6 months): ${JSON.stringify(userStats.history)}
- Indian average: 150 kg CO₂/month
- Global average: 400 kg CO₂/month

GAMIFICATION STATS:
- Current Level: ${userStats.currentLevel}
- Total XP: ${userStats.totalXp}
- Current Streak: ${userStats.currentStreak} days
- Longest Streak: ${userStats.longestStreak} days`
      : `${SYSTEM_PROMPT}

IMPORTANT: This user (${userStats.userName}) is new and has NOT yet calculated their carbon footprint.
They have logged ${userStats.activitiesLogged} activities and have no emission data yet.

GAMIFICATION STATS:
- Current Level: ${userStats.currentLevel}
- Total XP: ${userStats.totalXp}
- Current Streak: ${userStats.currentStreak} days

DO NOT make up or assume any emission numbers. Instead:
1. Warmly welcome them as a new user
2. Explain what Aura AI can help them with once they have data
3. Guide them to use the Carbon Calculator first (/calculator page)
4. You can answer general questions about carbon footprints, Indian averages, sustainability tips
5. Once they calculate their footprint, you will have their real data to give personalized advice`;

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    };
    if (isOpenRouter) {
      headers["HTTP-Referer"] = process.env.NEXT_PUBLIC_APP_URL ?? "";
      headers["X-Title"] = "Aura";
    }

    const callLLM = async (model: string) => {
      return fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: contextualSystem },
            ...messages.slice(-10),
          ],
          max_tokens: 600,
          temperature: 0.7,
        }),
      });
    };

    const FALLBACK_MODEL = process.env.OPENAI_FALLBACK_MODEL || null;

    let response = await callLLM(PRIMARY_MODEL);

    if (!response.ok && FALLBACK_MODEL && FALLBACK_MODEL !== PRIMARY_MODEL) {
      response = await callLLM(FALLBACK_MODEL);
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("OpenRouter Response Error:", errorData);
      throw new Error(
        `AI service request failed: ${errorData.error?.message || response.statusText || response.status}`
      );
    }

    const data = await response.json();
    const aiResponse = data.choices?.[0]?.message?.content ?? "";
    const modelUsed = data.model || PRIMARY_MODEL;

    if (!aiResponse) {
      throw new Error("Empty response from AI service");
    }

    return NextResponse.json(
      {
        response: aiResponse,
        source: "openrouter",
        model: modelUsed,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Chat API Error:", error);
    return NextResponse.json(
      { error: error.message || "AI service temporarily unavailable. Please try again." },
      { status: 500 }
    );
  }
}
