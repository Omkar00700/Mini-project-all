import { NextRequest, NextResponse } from "next/server";
import { aiRecommendationsService } from "@/services/ai/openai-recommendations.service";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { historicalData } = body;

    if (!historicalData || !Array.isArray(historicalData)) {
      return NextResponse.json(
        { error: "Missing or invalid historicalData array" },
        { status: 400 }
      );
    }

    const predictions =
      await aiRecommendationsService.predictEmissions(historicalData);

    return NextResponse.json(
      {
        success: true,
        predictions,
        aiEnabled: aiRecommendationsService.isConfigured(),
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
