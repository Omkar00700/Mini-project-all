import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { chartType, data } = await req.json();

    if (!chartType || !data) {
      return NextResponse.json(
        { error: "Missing chartType or data" },
        { status: 400 }
      );
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    const rawBaseUrl = process.env.OPENAI_BASE_URL;
    const rawModel = process.env.OPENAI_MODEL;
    const rawFallbackModel = process.env.OPENAI_FALLBACK_MODEL;

    if (!OPENAI_API_KEY || !rawBaseUrl || !rawModel) {
      return NextResponse.json(
        { error: "AI service configuration missing" },
        { status: 500 }
      );
    }

    const BASE_URL = rawBaseUrl.replace(/\/$/, "");
    const MODEL = rawModel;
    const FALLBACK_MODEL = rawFallbackModel || null;

    const isOpenRouter = BASE_URL.includes("openrouter.ai");

    const systemPrompt = `You are Aura, an expert sustainability and carbon data analyst.
Your goal is to explain carbon footprint chart data to a user in plain, encouraging, and highly readable English.
Keep your explanation concise (2 short paragraphs max).
Focus on:
1. Identifying the most significant trend, category, or anomaly.
2. Explaining WHAT it means for their footprint.
3. Suggesting ONE practical, actionable tip based on this specific data.
Output clean text. Do NOT use fake numbers; use only the numbers provided in the data.`;

    let userPrompt = `Here is the data for my ${chartType} chart:\n\n${JSON.stringify(data, null, 2)}\n\nPlease explain this to me.`;

    if (chartType === "Monthly Emissions Trend") {
      userPrompt = `Here is my monthly emissions trend data over the last 6 months:\n\n${JSON.stringify(data, null, 2)}\n\nWhat is the overall trend? Am I doing better or worse, and what was my best/worst month?`;
    } else if (chartType === "Emission Breakdown") {
      userPrompt = `Here is the breakdown of my carbon emissions by category for this period:\n\n${JSON.stringify(data, null, 2)}\n\nWhich category is dominating my footprint, and what's a quick win to reduce it?`;
    } else if (chartType === "AI Predictions") {
      userPrompt = `Here is my historical and AI predicted carbon footprint for the next 6 months:\n\n${JSON.stringify(data, null, 2)}\n\nWhat is the forecast telling me? Am I on track to reduce emissions, and what should I watch out for?`;
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    };
    if (isOpenRouter) {
      headers["HTTP-Referer"] = process.env.NEXT_PUBLIC_APP_URL ?? "";
      headers["X-Title"] = "Aura";
    }

    const callLLM = async (modelName: string) => {
      return fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: modelName,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt },
          ],
          temperature: 0.3,
          max_tokens: 300,
        }),
      });
    };

    let response = await callLLM(MODEL);

    if ((response.status === 429 || response.status >= 500) && FALLBACK_MODEL) {
      response = await callLLM(FALLBACK_MODEL);
    }

    if (!response.ok) {
      throw new Error(`AI service request failed with status ${response.status}`);
    }

    const result = await response.json();
    const explanation = result.choices?.[0]?.message?.content;

    if (!explanation) {
      throw new Error("No explanation generated.");
    }

    return NextResponse.json({ success: true, explanation });
  } catch (error: any) {
    console.error("Explain Chart API Error:", error);
    return NextResponse.json(
      { error: error.message || "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}

