import { NextRequest, NextResponse } from "next/server";
import { getUserFromRequest } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const EMISSION_FACTORS = {
  transport: {
    car_petrol_per_km: 0.21,
    car_diesel_per_km: 0.17,
    bike_petrol_per_km: 0.047,
    auto_rickshaw_per_km: 0.054,
    metro_per_km: 0.009,
    bus_per_km: 0.019,
    train_per_km: 0.012,
    flight_domestic_per_km: 0.255,
    wfh_car_saving_per_day: 0.21 * 15,
    ev_car_per_km: 0.02,
    cycle_per_km: 0.0,
  },
  food: {
    meat_heavy_per_day: 7.2,
    mixed_diet_per_day: 3.5,
    vegetarian_per_day: 2.5,
    vegan_per_day: 1.8,
    meat_day_saving: 7.2 - 3.5,
    local_food_saving_pct: 0.1,
  },
  energy: {
    ac_per_hour: 1.5,
    ac_setpoint_saving_per_degree: 0.06,
    led_vs_cfl_per_bulb_per_year: 4.5,
    solar_per_kw_per_year: 1400,
    geyser_per_shower: 0.35,
    solar_shower_saving: 0.35 * 0.8,
  },
  waste: {
    composting_saving_per_month: 4.5,
    recycling_saving_per_month: 2.2,
    plastic_reduction_per_month: 1.1,
  },
};

interface ScenarioResult {
  co2SavedMonthly: number;
  co2SavedAnnually: number;
  percentReduction: number;
  calculationBreakdown: string;
  confidence: "high" | "medium" | "low";
}

function calculateScenario(
  scenario: string,
  currentEmissions: number
): ScenarioResult | null {
  const s = scenario.toLowerCase();
  let monthly = 0;
  let breakdown = "";
  let confidence: "high" | "medium" | "low" = "medium";

  if (
    s.includes("metro") ||
    s.includes("bus") ||
    s.includes("public transport")
  ) {
    const kmMatch = s.match(/(\d+)\s*km/);
    const daysMatch = s.match(/(\d+)\s*day/);
    const km = kmMatch ? parseInt(kmMatch[1]) : 15;
    const days = daysMatch ? parseInt(daysMatch[1]) : 20;
    const saving =
      (EMISSION_FACTORS.transport.car_petrol_per_km -
        EMISSION_FACTORS.transport.metro_per_km) *
      km *
      days;
    monthly = saving;
    breakdown = `${km}km × ${days} days × (${EMISSION_FACTORS.transport.car_petrol_per_km} - ${EMISSION_FACTORS.transport.metro_per_km}) kg CO₂/km = ${monthly.toFixed(1)} kg/month`;
    confidence = "high";
  } else if (
    s.includes("ev") ||
    s.includes("electric vehicle") ||
    s.includes("electric car")
  ) {
    const kmMatch = s.match(/(\d+)\s*km/);
    const km = kmMatch ? parseInt(kmMatch[1]) : 15;
    const saving =
      (EMISSION_FACTORS.transport.car_petrol_per_km -
        EMISSION_FACTORS.transport.ev_car_per_km) *
      km *
      20;
    monthly = saving;
    breakdown = `${km}km × 20 days × (${EMISSION_FACTORS.transport.car_petrol_per_km} - ${EMISSION_FACTORS.transport.ev_car_per_km}) kg CO₂/km = ${monthly.toFixed(1)} kg/month`;
    confidence = "high";
  } else if (
    s.includes("cycle") ||
    s.includes("bicycle") ||
    s.includes("bike") ||
    s.includes("walk")
  ) {
    const kmMatch = s.match(/(\d+)\s*km/);
    const km = kmMatch ? parseInt(kmMatch[1]) : 10;
    const saving = EMISSION_FACTORS.transport.car_petrol_per_km * km * 20;
    monthly = saving;
    breakdown = `${km}km × 20 days × ${EMISSION_FACTORS.transport.car_petrol_per_km} kg CO₂/km = ${monthly.toFixed(1)} kg/month`;
    confidence = "high";
  } else if (
    s.includes("wfh") ||
    s.includes("work from home") ||
    s.includes("remote work") ||
    s.includes("don't commute")
  ) {
    const daysMatch = s.match(/(\d+)\s*day/);
    const days = daysMatch ? parseInt(daysMatch[1]) : 5;
    const saving = EMISSION_FACTORS.transport.wfh_car_saving_per_day * days;
    monthly = saving;
    breakdown = `${days} WFH days × ${EMISSION_FACTORS.transport.wfh_car_saving_per_day.toFixed(2)} kg CO₂/day (15km commute saved) = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (
    s.includes("flight") ||
    s.includes("fly") ||
    s.includes("air travel")
  ) {
    const flightsMatch = s.match(/(\d+)\s*flight/);
    const flights = flightsMatch ? parseInt(flightsMatch[1]) : 1;
    const saving =
      EMISSION_FACTORS.transport.flight_domestic_per_km * 1200 * flights;
    monthly = saving / 12;
    breakdown = `${flights} domestic flight(s) × 1200km × ${EMISSION_FACTORS.transport.flight_domestic_per_km} kg CO₂/km ÷ 12 = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (
    s.includes("veg") ||
    s.includes("plant") ||
    s.includes("meatless") ||
    s.includes("meat free") ||
    s.includes("stop eating meat")
  ) {
    const daysMatch = s.match(/(\d+)\s*day/);
    const days = daysMatch ? parseInt(daysMatch[1]) : 30;
    const saving = EMISSION_FACTORS.food.meat_day_saving * days;
    monthly = saving;
    breakdown = `${days} meatless days × ${EMISSION_FACTORS.food.meat_day_saving.toFixed(1)} kg CO₂/day (mixed→veg) = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (s.includes("vegan")) {
    const saving =
      (EMISSION_FACTORS.food.mixed_diet_per_day -
        EMISSION_FACTORS.food.vegan_per_day) *
      30;
    monthly = saving;
    breakdown = `30 days × ${(EMISSION_FACTORS.food.mixed_diet_per_day - EMISSION_FACTORS.food.vegan_per_day).toFixed(1)} kg CO₂/day (mixed→vegan) = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (s.includes("solar")) {
    const kwMatch = s.match(/(\d+)\s*kw/);
    const kw = kwMatch ? parseInt(kwMatch[1]) : 3;
    const annualSaving =
      kw * EMISSION_FACTORS.energy.solar_per_kw_per_year * 1.25;
    monthly = annualSaving / 12;
    breakdown = `${kw}kW system × 1400 kWh/yr × 1.25 kg CO₂/kWh ÷ 12 = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (s.includes("ac") || s.includes("air condition")) {
    const hoursMatch = s.match(/(\d+)\s*hour/);
    const hours = hoursMatch ? parseInt(hoursMatch[1]) : 4;
    const saving = EMISSION_FACTORS.energy.ac_per_hour * hours * 30 * 0.5;
    monthly = saving;
    breakdown = `${hours}hr/day × 30 days × ${EMISSION_FACTORS.energy.ac_per_hour} kg CO₂/hr × 50% less use = ${monthly.toFixed(1)} kg/month`;
    confidence = "medium";
  } else if (s.includes("led") || s.includes("bulb") || s.includes("light")) {
    const bulbsMatch = s.match(/(\d+)\s*bulb/);
    const bulbs = bulbsMatch ? parseInt(bulbsMatch[1]) : 5;
    monthly =
      (bulbs * EMISSION_FACTORS.energy.led_vs_cfl_per_bulb_per_year) / 12;
    breakdown = `${bulbs} bulbs × ${EMISSION_FACTORS.energy.led_vs_cfl_per_bulb_per_year} kg CO₂/yr ÷ 12 = ${monthly.toFixed(1)} kg/month`;
    confidence = "high";
  } else if (s.includes("compost")) {
    monthly = EMISSION_FACTORS.waste.composting_saving_per_month;
    breakdown = `Composting kitchen waste saves ~${monthly} kg CO₂/month (avoided landfill methane)`;
    confidence = "medium";
  } else if (s.includes("recycl")) {
    monthly = EMISSION_FACTORS.waste.recycling_saving_per_month;
    breakdown = `Regular recycling saves ~${monthly} kg CO₂/month`;
    confidence = "medium";
  }

  if (monthly === 0) return null;

  const annually = monthly * 12;
  const pct =
    currentEmissions > 0 ? Math.min(99, (monthly / currentEmissions) * 100) : 0;

  return {
    co2SavedMonthly: Math.round(monthly * 10) / 10,
    co2SavedAnnually: Math.round(annually),
    percentReduction: Math.round(pct),
    calculationBreakdown: breakdown,
    confidence,
  };
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { scenario } = await request.json();
    if (!scenario?.trim()) {
      return NextResponse.json(
        { error: "Scenario is required" },
        { status: 400 }
      );
    }

    const latestCalc = await prisma.carbonCalculation.findFirst({
      where: { userId: user.id },
      orderBy: { periodStart: "desc" },
      select: { totalEmissions: true, breakdown: true },
    });

    const hasData = latestCalc !== null;
    const currentEmissions = latestCalc?.totalEmissions ?? 0;
    const bd = (latestCalc?.breakdown ?? {}) as Record<string, number>;
    const breakdown = {
      transport: bd.transportation ?? bd.transport ?? bd.Transportation ?? 0,
      energy: bd.energy ?? bd.Energy ?? 0,
      food: bd.food ?? bd.Food ?? 0,
      waste: bd.waste ?? bd.Waste ?? 0,
    };

    const mathResult = calculateScenario(scenario, currentEmissions);

    if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_BASE_URL || !process.env.OPENAI_MODEL) {
      throw new Error('AI service is not properly configured. Missing required environment variables.');
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    const rawBaseUrl = process.env.OPENAI_BASE_URL;
    const MODEL = process.env.OPENAI_MODEL as string;
    const BASE_URL = rawBaseUrl ? rawBaseUrl.replace(/\/$/, "") : "";

    const isOpenRouter = BASE_URL.includes("openrouter.ai");

    const systemPrompt = `You are Aura AI, a carbon footprint expert for India. The user asks a "What if" scenario about reducing their carbon footprint.

You will be given:
1. The user's scenario
2. Our calculated emission savings (already computed using India-specific emission factors)
3. The user's current emission data

Your job:
- Confirm and explain the calculated savings in plain language
- Add practical India-specific context (cost savings in ₹, government schemes, local tips)
- Give 2-3 actionable next steps to implement this change
- Be encouraging and specific
- Keep response to 4-6 sentences + 2-3 action items max

If no calculation was provided, estimate reasonably and explain your estimate.
Do NOT question the math provided — just explain it well.`;

    const userContent = `Scenario: "${scenario}"

User's current footprint: ${currentEmissions.toFixed(1)} kg CO₂/month
- Transport: ${breakdown.transport.toFixed(1)} kg, Energy: ${breakdown.energy.toFixed(1)} kg, Food: ${breakdown.food.toFixed(1)} kg, Waste: ${breakdown.waste.toFixed(1)} kg
${hasData ? "✓ Using user's real emission data" : "⚠ User has no data yet — using India average (150 kg/month)"}

${
  mathResult
    ? `Our calculated savings: ${mathResult.co2SavedMonthly} kg CO₂/month (${mathResult.percentReduction}% reduction)
Annual: ${mathResult.co2SavedAnnually} kg CO₂/year
How we calculated it: ${mathResult.calculationBreakdown}
Confidence: ${mathResult.confidence}`
    : "Could not auto-calculate this specific scenario. Please estimate based on your expertise."
}`;

    let aiExplanation = "";
    let modelUsed = MODEL;

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    };
    if (isOpenRouter) {
      headers["HTTP-Referer"] = process.env.NEXT_PUBLIC_APP_URL ?? "";
      headers["X-Title"] = "Aura";
    }

    const callLLM = async (modelName: string) => {
      return fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: modelName,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userContent },
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      });
    };

    const FALLBACK_MODEL = process.env.OPENAI_FALLBACK_MODEL || null;

    let res = await callLLM(MODEL);

    if (!res.ok && FALLBACK_MODEL && FALLBACK_MODEL !== MODEL) {
      res = await callLLM(FALLBACK_MODEL);
    }

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      console.error("OpenRouter Response Error:", errorData);
      throw new Error(`AI service request failed: ${errorData.error?.message || res.statusText || res.status}`);
    }

    const data = await res.json();
    aiExplanation = data.choices?.[0]?.message?.content ?? "";
    if (data.model) modelUsed = data.model;

    if (!aiExplanation) {
      throw new Error('Failed to generate AI explanation for what-if scenario');
    }

    return NextResponse.json({
      success: true,
      scenario,
      hasData,
      currentEmissions,
      math: mathResult,
      explanation: aiExplanation,
      source: "openrouter",
      model: modelUsed,
    });
  } catch (error: any) {
    console.error("WhatIf API Error:", error);
    return NextResponse.json(
      { error: error.message || "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
