import { NextRequest, NextResponse } from "next/server";
import { aiRecommendationsService } from "@/services/ai/openai-recommendations.service";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      totalEmissions,
      breakdown,
      location,
      householdSize,
      historicalData,
    } = body;

    if (!totalEmissions || !breakdown) {
      return NextResponse.json(
        { error: "Missing required fields: totalEmissions, breakdown" },
        { status: 400 }
      );
    }

    const insights = await aiRecommendationsService.generateInsights(
      {
        totalEmissions,
        breakdown,
        location,
        householdSize,
      },
      historicalData
    );

    return NextResponse.json(
      {
        success: true,
        insights,
        aiEnabled: aiRecommendationsService.isConfigured(),
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
