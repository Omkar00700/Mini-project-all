"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Trophy,
  Star,
  Flame,
  Zap,
  Target,
  Leaf,
  BarChart3,
  CheckCircle2,
  Lock,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useGamificationStore } from "@/store/gamification-store";
import {
  LEVEL_CONFIG,
  calculateLevel,
  getLevelProgress,
} from "@/config/gamification";

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: string;
  tier: "bronze" | "silver" | "gold" | "platinum";
  icon: string;
  points: number;
  progress: number;
  isUnlocked: boolean;
  unlockedAt?: string;
  requirement: { type: string; target: number };
}

interface Stats {
  totalPoints: number;
  level: number;
  unlockedCount: number;
  totalCount: number;
}

const TIER_COLORS = {
  bronze: {
    bg: "from-amber-900/30 to-orange-900/20",
    border: "border-amber-700/40",
    text: "text-amber-400",
    badge: "bg-amber-900/40 text-amber-300 border border-amber-700/40",
  },
  silver: {
    bg: "from-slate-700/30 to-slate-800/20",
    border: "border-slate-500/40",
    text: "text-slate-300",
    badge: "bg-slate-700/40 text-slate-200 border border-slate-500/40",
  },
  gold: {
    bg: "from-yellow-900/30 to-amber-900/20",
    border: "border-yellow-600/40",
    text: "text-yellow-400",
    badge: "bg-yellow-900/40 text-yellow-300 border border-yellow-600/40",
  },
  platinum: {
    bg: "from-purple-900/30 to-violet-900/20",
    border: "border-purple-500/40",
    text: "text-purple-400",
    badge: "bg-purple-900/40 text-purple-300 border border-purple-500/40",
  },
};

const CATEGORY_META: Record<
  string,
  { label: string; icon: React.FC<{ className?: string }> }
> = {
  tracking: { label: "Tracking", icon: BarChart3 },
  reduction: { label: "Reduction", icon: Leaf },
  streaks: { label: "Streaks", icon: Flame },
  goals: { label: "Goals", icon: Target },
  special: { label: "Special", icon: Star },
  milestones: { label: "Milestones", icon: Trophy },
};

function LevelCard({ totalXp }: { totalXp: number }) {
  const currentLevel = calculateLevel(totalXp);
  const progress = getLevelProgress(totalXp);
  const title = currentLevel.title;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative overflow-hidden rounded-[2.5rem] border border-emerald-500/20 bg-gradient-to-br from-[#0d1622] via-[#0d1622] to-emerald-950/40 p-8 pt-10 shadow-2xl backdrop-blur-md"
    >
      <div className="absolute top-0 right-0 w-full h-full overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute -top-20 -right-20 w-80 h-80 bg-emerald-500 rounded-full blur-[100px]"
        />
      </div>

      <div className="relative flex flex-col md:flex-row items-center justify-between gap-10">
        <div className="flex items-center gap-8">
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-[-15px] border-2 border-dashed border-emerald-500/20 rounded-full"
            />
            <div className="relative flex h-28 w-28 items-center justify-center rounded-[2rem] bg-gradient-to-br from-emerald-500 to-teal-400 text-5xl shadow-[0_0_50px_rgba(16,185,129,0.3)]">
              <span className="drop-shadow-lg">{currentLevel.icon}</span>
              <div className="absolute -bottom-3 -right-3 flex h-10 w-10 items-center justify-center rounded-2xl bg-[#0d1622] border-2 border-emerald-500 text-sm font-black text-emerald-400 shadow-xl">
                {currentLevel.level}
              </div>
            </div>
          </div>
          <div>
            <p className="text-xs font-black uppercase tracking-[0.4em] text-emerald-400">
              Current Rank
            </p>
            <h2 className="text-5xl font-black text-white leading-tight tracking-tight mt-1">
              {title}
            </h2>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-sm font-bold text-slate-400">
                {totalXp.toLocaleString()} Total XP
              </span>
              <span className="h-1 w-1 rounded-full bg-slate-700" />
              <span className="text-sm font-bold text-emerald-500/80">
                Season 1
              </span>
            </div>
          </div>
        </div>

        <div className="flex gap-4 md:gap-8">
          {[
            {
              label: "Badges",
              value: "Locked",
              icon: "🏅",
              color: "text-amber-400",
            },
            {
              label: "Points",
              value: totalXp,
              icon: "⚡",
              color: "text-blue-400",
            },
          ].map((s) => (
            <div
              key={s.label}
              className="flex flex-col items-center min-w-[80px] p-4 rounded-2xl bg-white/5 border border-white/10"
            >
              <span className="text-2xl mb-1">{s.icon}</span>
              <span className="text-2xl font-black text-white">
                {typeof s.value === "number"
                  ? s.value.toLocaleString()
                  : s.value}
              </span>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="relative mt-10">
        <div className="mb-3 flex justify-between items-end">
          <div className="space-y-1">
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
              Next Milestone
            </p>
            <p className="text-sm font-bold text-emerald-400">
              {progress.isMaxLevel
                ? "Max Level Reached"
                : `${progress.xpNeededTotal?.toLocaleString() ?? 0} XP remaining`}
            </p>
          </div>
          <span className="text-2xl font-black text-white">
            {Math.round(progress.percent)}%
          </span>
        </div>
        <div className="h-4 w-full overflow-hidden rounded-2xl bg-slate-900/80 border border-white/5 p-1">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress.percent}%` }}
            transition={{ duration: 1.5, ease: "circOut" }}
            className="h-full rounded-xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-300 shadow-[0_0_20px_rgba(16,185,129,0.3)] relative overflow-hidden"
          >
            <motion.div
              animate={{ x: ["-100%", "200%"] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent w-20 skew-x-12"
            />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

function AchievementCard({
  achievement,
  index,
}: {
  achievement: Achievement;
  index: number;
}) {
  const tier = TIER_COLORS[achievement.tier];
  const remaining = achievement.requirement?.target
    ? Math.max(
        0,
        Math.ceil(
          achievement.requirement.target * (1 - achievement.progress / 100)
        )
      )
    : null;

  const requirementLabel: Record<string, string> = {
    activities_logged: "activities",
    streak_days: "streak days",
    goals_created: "goals",
    calculations: "calculations",
    reductions: "kg reduced",
  };

  const unitLabel = achievement.requirement?.type
    ? requirementLabel[achievement.requirement.type] || "steps"
    : "steps";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.35 }}
      className={cn(
        "relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 transition-all duration-300",
        "hover:scale-[1.02] hover:shadow-xl cursor-default",
        achievement.isUnlocked
          ? cn(tier.bg, tier.border)
          : "from-slate-900/60 to-slate-900/30 border-slate-800/50"
      )}
    >
      {!achievement.isUnlocked && (
        <div className="absolute top-3 right-3 z-10">
          <Lock className="h-4 w-4 text-slate-700" />
        </div>
      )}

      {achievement.isUnlocked && (
        <div
          className={cn(
            "absolute -right-8 -top-8 h-24 w-24 rounded-full blur-2xl opacity-30",
            tier.text,
            "bg-current"
          )}
        />
      )}

      <div className="relative z-20">
        <div className="flex items-start justify-between mb-3">
          <div
            className={cn(
              "flex h-12 w-12 items-center justify-center rounded-xl text-2xl border",
              achievement.isUnlocked
                ? tier.border
                : "border-slate-700/50 bg-slate-800/40"
            )}
          >
            <span
              className={
                !achievement.isUnlocked ? "opacity-30 grayscale blur-[1px]" : ""
              }
            >
              {achievement.icon}
            </span>
          </div>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-xs font-bold capitalize",
              achievement.isUnlocked
                ? tier.badge
                : "bg-slate-800 text-slate-600 border border-slate-700"
            )}
          >
            {achievement.tier}
          </span>
        </div>

        <h3
          className={cn(
            "font-bold text-sm mb-0.5",
            achievement.isUnlocked ? "text-white" : "text-slate-500"
          )}
        >
          {achievement.name}
        </h3>
        <p
          className={cn(
            "text-xs mb-3 line-clamp-2",
            achievement.isUnlocked ? "text-slate-400" : "text-slate-700"
          )}
        >
          {achievement.description}
        </p>

        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span
              className={
                achievement.isUnlocked ? tier.text : "text-emerald-600/70"
              }
            >
              {achievement.isUnlocked
                ? "✓ Unlocked"
                : remaining !== null && remaining > 0
                  ? `${remaining} more ${unitLabel}`
                  : `${Math.round(achievement.progress)}%`}
            </span>
            <span
              className={
                achievement.isUnlocked ? "text-slate-400" : "text-slate-700"
              }
            >
              +{achievement.points} XP
            </span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800/60">
            {achievement.isUnlocked ? (
              <div
                className={cn(
                  "h-full w-full rounded-full bg-gradient-to-r",
                  achievement.tier === "bronze"
                    ? "from-amber-600 to-orange-500"
                    : achievement.tier === "silver"
                      ? "from-slate-400 to-slate-300"
                      : achievement.tier === "gold"
                        ? "from-yellow-500 to-amber-400"
                        : "from-purple-500 to-violet-400"
                )}
              />
            ) : (
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${achievement.progress}%` }}
                transition={{
                  duration: 1,
                  ease: "easeOut",
                  delay: index * 0.04 + 0.3,
                }}
                className="h-full rounded-full bg-emerald-700/60"
              />
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function CategoryTabs({
  active,
  onChange,
  counts,
}: {
  active: string;
  onChange: (c: string) => void;
  counts: Record<string, number>;
}) {
  const categories = ["all", ...Object.keys(CATEGORY_META)];
  return (
    <div className="flex flex-wrap gap-2">
      {categories.map((cat) => {
        const meta = CATEGORY_META[cat];
        const Icon = meta?.icon;
        const count =
          cat === "all"
            ? Object.values(counts).reduce((a, b) => a + b, 0)
            : counts[cat] || 0;
        return (
          <button
            key={cat}
            onClick={() => onChange(cat)}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm font-medium transition-all duration-200",
              active === cat
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "text-slate-400 border border-slate-800 hover:border-slate-700 hover:text-slate-300"
            )}
          >
            {Icon && <Icon className="h-3.5 w-3.5" />}
            <span className="capitalize">{cat}</span>
            <span
              className={cn(
                "text-xs rounded-full px-1.5",
                active === cat
                  ? "bg-emerald-500/30 text-emerald-300"
                  : "bg-slate-800 text-slate-500"
              )}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function StreakCard({
  streak,
  streakFreezes,
}: {
  streak: number;
  streakFreezes: number;
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <motion.div
        whileHover={{ scale: 1.02 }}
        className="relative overflow-hidden rounded-[2rem] border border-orange-500/20 bg-gradient-to-br from-orange-950/20 to-[#1a1c24] p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/20 rounded-xl">
              <Flame className="h-6 w-6 text-orange-500" />
            </div>
            <span className="text-sm font-black text-orange-400 uppercase tracking-widest">
              Active Streak
            </span>
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-6xl font-black text-white drop-shadow-[0_0_20px_rgba(249,115,22,0.3)]">
            {streak}
          </span>
          <span className="text-xl font-bold text-orange-500/60 uppercase">
            Days
          </span>
        </div>
        <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-1">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className={cn(
                    "w-6 h-6 rounded-full border-2 border-[#1a1c24] flex items-center justify-center text-[10px]",
                    i < streakFreezes
                      ? "bg-cyan-500 text-white"
                      : "bg-slate-800 text-slate-600"
                  )}
                >
                  ❄️
                </div>
              ))}
            </div>
            <span className="text-xs font-bold text-slate-500">
              {streakFreezes} Streak Freezes
            </span>
          </div>
        </div>
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.02 }}
        className="relative overflow-hidden rounded-[2rem] border border-blue-500/20 bg-gradient-to-br from-blue-950/20 to-[#1a1c24] p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/20 rounded-xl">
              <Zap className="h-6 w-6 text-blue-500" />
            </div>
            <span className="text-sm font-black text-blue-400 uppercase tracking-widest">
              Power Level
            </span>
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-6xl font-black text-white drop-shadow-[0_0_20px_rgba(59,130,246,0.3)]">
            Top 5%
          </span>
        </div>
        <p className="text-sm text-slate-500 mt-4 font-medium">
          You are outperforming 95% of users in your region this week.
        </p>
      </motion.div>
    </div>
  );
}

export default function AchievementsPage() {
  const { xp, level, streak, streakFreezes, syncWithServer } =
    useGamificationStore();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("all");
  const [unlockedCount, setUnlockedCount] = useState(0);

  const fetchAchievements = useCallback(async () => {
    try {
      const achRes = await fetch("/api/achievements");
      if (achRes.ok) {
        const data = await achRes.json();
        setAchievements(data.achievements || []);
        setUnlockedCount(data.stats?.unlockedCount || 0);

        syncWithServer({
          xp: data.stats?.totalPoints ?? xp,
          level: data.stats?.level ?? level,
          streak: data.stats?.currentStreak ?? streak,
          streakFreezes: data.stats?.streakFreezes ?? streakFreezes,
        });
      }
    } catch (e) {
    } finally {
      setLoading(false);
    }
  }, [xp, level, streak, streakFreezes, syncWithServer]);

  useEffect(() => {
    fetchAchievements();
  }, [fetchAchievements]);

  const filtered =
    activeCategory === "all"
      ? achievements
      : achievements.filter((a) => a.category === activeCategory);

  const categoryCounts = achievements.reduce<Record<string, number>>(
    (acc, a) => {
      acc[a.category] = (acc[a.category] || 0) + 1;
      return acc;
    },
    {}
  );

  const unlockedFiltered = filtered.filter((a) => a.isUnlocked);
  const lockedFiltered = filtered.filter((a) => !a.isUnlocked);

  if (loading) {
    return (
      <div className="flex h-full min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 rounded-full border-2 border-emerald-500/30 border-t-emerald-500 animate-spin" />
          <p className="text-sm text-slate-500">Loading achievements…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-10 p-6 md:p-8 pb-32">
      {}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-4xl font-black text-white flex items-center gap-3 tracking-tight">
            <Trophy className="h-10 w-10 text-emerald-400" />
            Achievements
          </h1>
          <p className="text-slate-400 mt-2 text-base font-medium">
            Level up your climate impact and collect planetary badges.
          </p>
        </div>
        <div className="hidden md:flex items-center gap-3 rounded-2xl border border-emerald-500/20 bg-emerald-950/30 px-5 py-3 shadow-xl">
          <CheckCircle2 className="h-5 w-5 text-emerald-400" />
          <span className="text-base text-emerald-300 font-bold">
            {unlockedCount}/{achievements.length} Unlocked
          </span>
        </div>
      </motion.div>

      {}
      <LevelCard totalXp={xp} />

      {}
      <StreakCard streak={streak} streakFreezes={streakFreezes} />

      {}
      <div className="space-y-6">
        <CategoryTabs
          active={activeCategory}
          onChange={setActiveCategory}
          counts={categoryCounts}
        />

        {}
        <AnimatePresence mode="popLayout">
          {unlockedFiltered.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <h2 className="text-sm font-black text-emerald-400 uppercase tracking-[0.2em]">
                  Mastered ({unlockedFiltered.length})
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {unlockedFiltered.map((a, i) => (
                  <AchievementCard key={a.id} achievement={a} index={i} />
                ))}
              </div>
            </motion.div>
          )}

          {}
          {lockedFiltered.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4 pt-4"
            >
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-slate-500" />
                <h2 className="text-sm font-black text-slate-500 uppercase tracking-[0.2em]">
                  In Progress ({lockedFiltered.length})
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {lockedFiltered.map((a, i) => (
                  <AchievementCard key={a.id} achievement={a} index={i} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-slate-600 bg-white/5 rounded-3xl border border-dashed border-white/10">
            <Trophy className="h-16 w-16 mb-4 opacity-10" />
            <p className="text-lg font-bold opacity-30">
              No achievements found in this category
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
