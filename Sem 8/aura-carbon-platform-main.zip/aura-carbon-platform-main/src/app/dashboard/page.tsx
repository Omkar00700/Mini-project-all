"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  EmissionMetricsCard,
  MetricsCard,
  SavingsMetricsCard,
} from "@/components/dashboard/metrics-card";
import { EmissionBreakdownChart } from "@/components/dashboard/charts/emission-breakdown-chart";
import { PredictionChart } from "@/components/dashboard/PredictionChart";
import { AIInsightsCard } from "@/components/dashboard/AIInsightsCard";
import { BenchmarkCard } from "@/components/analytics/BenchmarkCard";
import { ScenarioBuilder } from "@/components/analytics/ScenarioBuilder";
import { AchievementBadges } from "@/components/analytics/AchievementBadges";
import { ExplainChartButton } from "@/components/dashboard/charts/explain-chart-button";

import { StreakCard } from "@/components/dashboard/streak-card";
import { SeedlingTracker } from "@/components/dashboard/seedling-tracker";

import { QuickAddActivity } from "@/components/dashboard/QuickAddActivity";
import { MissionBoard } from "@/components/dashboard/MissionBoard";
import {
  RefreshCw,
  AlertCircle,
  CalendarDays,
  Activity,
  TrendingDown,
  Trophy,
} from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface DashboardSummary {
  lastMonthTotal: number;
  totalCalculations: number;
  averageMonthly: number;
}

interface MonthlySeriesItem {
  month: string;
  total: number;
  count: number;
}

interface TopContributor {
  category: string;
  total: number;
}

interface RecentCalculation {
  id: string;
  date: string;
  total: number;
  breakdown?: Record<string, number>;
}

interface GoalProgress {
  id: string;
  targetName: string;
  targetKgPerMonth: number;
  currentMonthEmissions: number;
  progress: number;
  isOnTrack: boolean;
}

interface DashboardResponse {
  summary: DashboardSummary;
  monthlySeries: MonthlySeriesItem[];
  topContributors: TopContributor[];
  recentCalculations: RecentCalculation[];
  goalProgress: GoalProgress[];
}

interface MonthlyChartPoint {
  label: string;
  value: number;
}

const CATEGORY_COLORS: Record<string, string> = {
  transportation: "#ef4444",
  transport: "#ef4444",
  travel: "#ef4444",
  energy: "#f59e0b",
  electricity: "#f59e0b",
  food: "#10b981",
  diet: "#10b981",
  consumption: "#3b82f6",
  purchases: "#3b82f6",
  waste: "#8b5cf6",
  recycling: "#8b5cf6",
  other: "#6b7280",
};

const formatKg = (value: number) => {
  if (!value) return "0 kg";
  if (Math.abs(value) >= 1000) return `${(value / 1000).toFixed(1)} t`;
  return `${value.toFixed(1)} kg`;
};

const formatMonthLabel = (value: string) => {
  const parts = value.split("-");
  if (parts.length !== 2) return value;
  const [year, month] = parts;
  return new Date(Number(year), Number(month) - 1, 1).toLocaleDateString(
    "en-IN",
    { month: "short", year: "numeric" }
  );
};

const normalizeCategory = (label: string) => {
  const key = label.toLowerCase();
  if (key.includes("transport")) return "transportation";
  if (key.includes("travel")) return "transportation";
  if (key.includes("vehicle")) return "transportation";
  if (key.includes("energy")) return "energy";
  if (key.includes("electric")) return "energy";
  if (key.includes("power")) return "energy";
  if (key.includes("food")) return "food";
  if (key.includes("diet")) return "food";
  if (key.includes("waste")) return "waste";
  if (key.includes("recycl")) return "waste";
  if (key.includes("consumption")) return "consumption";
  if (key.includes("purchase")) return "consumption";
  return "other";
};

const MonthlyEmissionsChart = ({
  data,
  isLoading,
}: {
  data: MonthlyChartPoint[];
  isLoading: boolean;
}) => {
  return (
    <Card className="w-full relative overflow-hidden bg-background/50 backdrop-blur-xl border-border/50">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent opacity-50" />
      <CardHeader className="flex flex-col space-y-2 relative z-10">
        <div className="flex items-start sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Monthly Emissions Trend</CardTitle>
            <CardDescription>
              Performance across the last six reporting periods
            </CardDescription>
          </div>
          {data.length > 0 && (
            <div className="shrink-0">
              <ExplainChartButton
                chartType="Monthly Emissions Trend"
                data={data}
                variant="outline"
              />
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : data.length === 0 ? (
          <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
            No emissions recorded yet. Add your first calculation to see trends.
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ left: 4, right: 16 }}>
                <CartesianGrid strokeDasharray="4 4" stroke="#e5e7eb" />
                <XAxis
                  dataKey="label"
                  stroke="#9ca3af"
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  stroke="#9ca3af"
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(value: number) => formatKg(value)}
                />
                <Tooltip
                  cursor={{ stroke: "#a855f7", strokeDasharray: "3 3" }}
                  formatter={(value: number) => formatKg(value)}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#a855f7"
                  strokeWidth={3}
                  dot={{ r: 4, strokeWidth: 2, stroke: "#fff" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const DashboardPage = () => {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [dashboardData, setDashboardData] = useState<DashboardResponse | null>(
    null
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/dashboard", {
        credentials: "include",
        headers: {
          "Cache-Control": "no-cache",
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(
          `Unable to load dashboard data: ${response.status} ${errorText}`
        );
      }

      const data: DashboardResponse = await response.json();
      setDashboardData(data);
      setLastUpdated(new Date());
    } catch (error: unknown) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to load dashboard data";
      setError(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      router.replace("/auth/login");
    }
  }, [authLoading, user, router]);

  useEffect(() => {
    if (!authLoading && user) {
      fetchDashboard();
    }
  }, [authLoading, user, fetchDashboard]);

  const monthlyChartData = useMemo(() => {
    if (!dashboardData?.monthlySeries?.length) return [];
    return dashboardData.monthlySeries.map((item) => ({
      label: formatMonthLabel(item.month),
      value: Number(item.total?.toFixed(2) || 0),
    }));
  }, [dashboardData]);

  const latestMonth = monthlyChartData.at(-1)?.value ?? 0;
  const previousMonth = monthlyChartData.at(-2)?.value ?? 0;
  const prePreviousMonth = monthlyChartData.at(-3)?.value ?? previousMonth;
  const previousSavings = Math.max(prePreviousMonth - previousMonth, 0);

  const breakdownTotals = useMemo(() => {
    if (!dashboardData) {
      return null;
    }

    const totals: Record<string, number> = {
      transportation: 0,
      energy: 0,
      food: 0,
      waste: 0,
      consumption: 0,
      other: 0,
    };

    dashboardData.topContributors.forEach((item) => {
      const key = normalizeCategory(item.category);
      totals[key] = (totals[key] || 0) + item.total;
    });

    dashboardData.recentCalculations.forEach((calc) => {
      if (calc.breakdown) {
        Object.entries(calc.breakdown).forEach(([key, value]) => {
          const normalized = normalizeCategory(key);
          totals[normalized] = (totals[normalized] || 0) + value;
        });
      }
    });

    return totals;
  }, [dashboardData]);

  const breakdownChartData = useMemo(() => {
    if (!breakdownTotals) return [];
    const totalValue = Object.values(breakdownTotals).reduce(
      (sum, value) => sum + value,
      0
    );
    if (!totalValue) return [];

    return Object.entries(breakdownTotals)
      .filter(([key, value]) => key !== "other" && value > 0)
      .map(([key, value]) => ({
        category: key,
        value,
        percentage: (value / totalValue) * 100,
        color: CATEGORY_COLORS[key] || CATEGORY_COLORS.other,
      }));
  }, [breakdownTotals]);

  const carbonProfile = useMemo(() => {
    if (!dashboardData || !breakdownTotals) return null;
    const total =
      dashboardData.summary?.lastMonthTotal ||
      dashboardData.summary?.averageMonthly ||
      0;
    if (!total) return null;

    return {
      totalEmissions: Number(total.toFixed(2)),
      breakdown: {
        transport: breakdownTotals.transportation || 0,
        energy: breakdownTotals.energy || 0,
        food: breakdownTotals.food || 0,
        waste:
          (breakdownTotals.waste || 0) + (breakdownTotals.consumption || 0),
      },
    };
  }, [dashboardData, breakdownTotals]);

  const handleRefresh = async () => {
    await fetchDashboard();
  };

  const goalCards = dashboardData?.goalProgress ?? [];
  const averageMonthly = dashboardData?.summary?.averageMonthly ?? 0;
  const monthlyTarget = goalCards.at(0)?.targetKgPerMonth;
  const emissionSavings = Math.max(previousMonth - latestMonth, 0);

  if (!user && authLoading) {
    return (
      <div className="flex-1 space-y-6 p-6">
        <div className="text-sm text-muted-foreground mb-4">
          Loading authentication status...
        </div>
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!user && !authLoading) {
    return (
      <div className="flex-1 p-6">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Sign in to access your personalized carbon intelligence dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Demo credentials: demo@aura.com / demo123
            </div>
            <Button onClick={() => router.push("/auth/login")}>Sign In</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6 md:p-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-1">
          <h2 className="text-3xl font-semibold tracking-tight">
            Welcome back{user?.name ? `, ${user.name}` : ""}
          </h2>
          <p className="text-sm text-muted-foreground">
            Real-time insights, AI predictions, and actionable recommendations
            for your sustainability journey.
          </p>
          {lastUpdated && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <CalendarDays className="h-4 w-4" />
              Last updated {lastUpdated.toLocaleString("en-IN")}
            </div>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <QuickAddActivity
            userId={user?.id || ""}
            onActivityAdded={handleRefresh}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw
              className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`}
            />
            Refresh
          </Button>
        </div>
      </div>

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="flex items-center justify-between gap-4 py-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-red-500" />
              <div>
                <p className="font-medium text-red-600">{error}</p>
                <p className="text-xs text-red-500">
                  Please try refreshing the dashboard. If the issue persists,
                  verify your connection and authentication status.
                </p>
                {error.includes("Not authenticated") && (
                  <p className="text-xs text-red-500 mt-1">
                    Try signing out and signing back in with your credentials.
                  </p>
                )}
              </div>
            </div>
            <Button size="sm" variant="outline" onClick={handleRefresh}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {}
      <div className="flex flex-col gap-6 mb-8">
        {}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <StreakCard
            currentStreak={user?.currentStreak || 0}
            longestStreak={user?.longestStreak || 0}
            lastMaintained={
              user?.streakLastMaintained
                ? new Date(user.streakLastMaintained)
                : null
            }
          />
          <SeedlingTracker
            level={user?.currentLevel || 1}
            experience={user?.totalXp || 0}
          />
        </div>

        {}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          <EmissionMetricsCard
            period="Month"
            emissions={
              latestMonth || dashboardData?.summary?.lastMonthTotal || 0
            }
            target={monthlyTarget}
            previousPeriod={previousMonth}
          />
          <SavingsMetricsCard
            period="Month"
            savings={emissionSavings}
            previousPeriod={previousSavings || undefined}
          />
          <MetricsCard
            title="Average Monthly Footprint"
            value={averageMonthly}
            unit="kg CO₂e"
            trend={
              previousMonth
                ? {
                    value:
                      previousMonth === 0
                        ? 0
                        : ((latestMonth - previousMonth) / previousMonth) * 100,
                    period: "last month",
                  }
                : undefined
            }
            icon={TrendingDown}
            status={latestMonth <= averageMonthly ? "good" : "warning"}
            description="Six-month rolling average emissions"
          />
          <BenchmarkCard userId={user?.id || ""} />
        </div>
      </div>

      {}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {}
        <div className="xl:col-span-2 flex flex-col gap-6">
          <MonthlyEmissionsChart
            data={monthlyChartData}
            isLoading={loading && !dashboardData}
          />
          <PredictionChart />
          <AIInsightsCard carbonData={carbonProfile || undefined} />
        </div>

        {}
        <div className="flex flex-col gap-6">
          <Card className="w-full relative overflow-hidden bg-background/50 backdrop-blur-xl border-border/50">
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/5 via-transparent to-transparent opacity-50" />
            <CardContent className="p-0 relative z-10">
              {loading && !breakdownChartData.length ? (
                <div className="p-6">
                  <Skeleton className="h-64 w-full" />
                </div>
              ) : breakdownChartData.length === 0 ? (
                <div className="flex h-64 items-center justify-center text-sm text-muted-foreground p-6">
                  No category data available yet.
                </div>
              ) : (
                <EmissionBreakdownChart
                  data={breakdownChartData}
                  totalEmissions={
                    dashboardData?.summary?.lastMonthTotal || latestMonth
                  }
                  period="month"
                  className="rounded-xl border-0 shadow-none bg-transparent"
                />
              )}
            </CardContent>
          </Card>

          <Card className="w-full bg-background/50 backdrop-blur-xl border-border/50">
            <CardHeader className="pb-3 border-b border-border/50 dark:border-white/5 mb-3">
              <CardTitle className="text-lg">Recent Calculations</CardTitle>
              <CardDescription className="text-xs">
                Latest log history
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              {loading && !dashboardData ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, index) => (
                    <Skeleton key={index} className="h-16 w-full" />
                  ))}
                </div>
              ) : dashboardData?.recentCalculations?.length ? (
                dashboardData.recentCalculations.map((calc) => {
                  const dateLabel = new Date(calc.date).toLocaleDateString(
                    "en-IN",
                    {
                      day: "2-digit",
                      month: "short",
                      year: "numeric",
                    }
                  );
                  const sortedBreakdown = calc.breakdown
                    ? Object.entries(calc.breakdown).sort((a, b) => b[1] - a[1])
                    : [];
                  const dominantCategory = sortedBreakdown[0]?.[0] ?? null;
                  const dominantLabel = dominantCategory
                    ? dominantCategory.charAt(0).toUpperCase() +
                      dominantCategory.slice(1)
                    : "";
                  const normalized = dominantCategory
                    ? normalizeCategory(dominantCategory)
                    : "other";
                  return (
                    <div
                      key={calc.id}
                      className="flex items-center justify-between rounded-xl bg-secondary/20 hover:bg-secondary/40 transition-colors border border-border/50 p-3"
                    >
                      <div>
                        <p className="text-sm font-semibold text-foreground/90">
                          {dateLabel}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {formatKg(calc.total)} recorded
                        </p>
                      </div>
                      {dominantCategory && (
                        <Badge
                          variant="outline"
                          className="capitalize px-2 py-0.5 text-[10px]"
                          style={{
                            borderColor:
                              CATEGORY_COLORS[normalized] ||
                              CATEGORY_COLORS.other,
                            color:
                              CATEGORY_COLORS[normalized] ||
                              CATEGORY_COLORS.other,
                            backgroundColor: `${CATEGORY_COLORS[normalized] || CATEGORY_COLORS.other}10`,
                          }}
                        >
                          {dominantLabel}
                        </Badge>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="text-sm text-muted-foreground p-4 text-center bg-secondary/20 rounded-xl">
                  No calculations recorded yet.
                </div>
              )}
            </CardContent>
          </Card>

          <MissionBoard />

          <Card className="w-full bg-background/50 backdrop-blur-xl border-border/50">
            <CardHeader className="pb-3 border-b border-border/50 dark:border-white/5 mb-3">
              <CardTitle className="text-lg">Goal Progress</CardTitle>
              <CardDescription className="text-xs">
                Tracking to your targets
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pt-0">
              {loading && !dashboardData ? (
                <div className="space-y-3">
                  {[...Array(2)].map((_, index) => (
                    <Skeleton key={index} className="h-20 w-full" />
                  ))}
                </div>
              ) : goalCards.length ? (
                goalCards.map((goal) => (
                  <div
                    key={goal.id}
                    className="space-y-2 rounded-xl bg-secondary/20 border border-border/50 p-4"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold text-foreground/90">
                          {goal.targetName}
                        </p>
                      </div>
                      <Badge
                        className="text-[10px] h-5"
                        variant={goal.isOnTrack ? "default" : "destructive"}
                      >
                        {goal.isOnTrack ? "On track" : "Off track"}
                      </Badge>
                    </div>
                    <div className="h-2 w-full rounded-full bg-background/50 overflow-hidden shadow-inner">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${goal.isOnTrack ? "bg-emerald-500" : "bg-red-500"}`}
                        style={{
                          width: `${Math.min(goal.progress * 100, 100)}%`,
                        }}
                      />
                    </div>
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>
                        {formatKg(goal.currentMonthEmissions)} current
                      </span>
                      <span className="font-mono">
                        {formatKg(goal.targetKgPerMonth)} target
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-sm text-muted-foreground p-4 text-center bg-secondary/20 rounded-xl">
                  No sustainability goals set yet.
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {}
      <div className="mt-12 mb-4 pt-8 border-t border-border/50 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-[1px] bg-gradient-to-r from-transparent via-emerald-500/50 to-transparent" />
        <h3 className="text-xl font-bold tracking-tight mb-8 text-foreground/90 flex items-center justify-center gap-2">
          <Trophy className="w-5 h-5 text-emerald-500" /> Explore Tools &
          Community
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link href="/leaderboard" className="block">
            <Card className="bg-background/40 backdrop-blur-xl border-border/40 hover:bg-background/60 transition-colors h-full cursor-pointer group">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base group-hover:text-emerald-500 transition-colors">
                  <Trophy className="h-4 w-4" />
                  Global Leaderboard
                </CardTitle>
                <CardDescription className="text-xs">
                  See where you rank globally
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mt-2">
                  <div className="text-sm font-medium">Your Rank: </div>
                  <Badge
                    variant="secondary"
                    className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                  >
                    {user?.currentLevel
                      ? `Level ${user.currentLevel}`
                      : "Compute"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Card
            data-section="scenarios"
            className="bg-background/40 backdrop-blur-xl border-border/40 hover:bg-background/60 transition-colors"
          >
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Activity className="h-4 w-4 text-teal-500" />
                What-If Scenarios
              </CardTitle>
              <CardDescription className="text-xs">
                Model reduction changes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScenarioBuilder userId={user?.id || ""} />
            </CardContent>
          </Card>

          <Card className="bg-background/40 backdrop-blur-xl border-border/40 hover:bg-background/60 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Trophy className="h-4 w-4 text-amber-500" />
                Achievements
              </CardTitle>
              <CardDescription className="text-xs">
                Milestones earned
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AchievementBadges userId={user?.id || ""} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
