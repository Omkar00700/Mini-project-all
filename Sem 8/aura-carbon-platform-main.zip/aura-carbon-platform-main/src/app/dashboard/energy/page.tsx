import { EnergyCalculatorForm } from "@/components/energy/energy-calculator-form";

export default function EnergyCalculatorPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Energy Calculator</h1>
        <p className="text-muted-foreground mt-2">
          Calculate your carbon footprint from electricity, heating, cooling,
          and renewable energy sources. Get personalized recommendations to
          reduce your energy emissions.
        </p>
      </div>

      <EnergyCalculatorForm />
    </div>
  );
}
