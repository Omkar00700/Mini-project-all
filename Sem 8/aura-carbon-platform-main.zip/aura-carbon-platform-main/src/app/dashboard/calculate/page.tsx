"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Calculator, ArrowLeft, Plus, Trash2, CheckCircle } from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";

interface CalculationItem {
  category: string;
  subcategory: string;
  quantity: number;
  unit: string;
}

export default function CalculatePage() {
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<CalculationItem[]>([
    {
      category: "transport",
      subcategory: "petrol",
      quantity: 0,
      unit: "liter",
    },
  ]);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const addItem = () => {
    setItems([
      ...items,
      {
        category: "transport",
        subcategory: "petrol",
        quantity: 0,
        unit: "liter",
      },
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (
    index: number,
    field: keyof CalculationItem,
    value: any
  ) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };

    if (field === "subcategory") {
      const unitMap: Record<string, string> = {
        petrol: "liter",
        diesel: "liter",
        cng: "kg",
        grid: "kWh",
        lpg: "kg",
        rice: "kg",
        wheat: "kg",
        chicken: "kg",
        mutton: "kg",
        municipal_solid_waste: "kg",
      };
      newItems[index].unit = unitMap[value] || "kg";
    }

    setItems(newItems);
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.filter((item) => item.quantity > 0),
          date: new Date().toISOString().split("T")[0],
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Calculation failed");
      }

      setResult(data);

      if (data.xpEarned) {
        toast.success(`Calculation Logged! +${data.xpEarned} XP`, {
          icon: "🌱",
        });
      }

      if (data.newlyUnlocked && data.newlyUnlocked.length > 0) {
        toast("Achievement Unlocked!", {
          icon: "🏆",
          description: "Check your achievements page for details.",
        });
      }
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Calculate Carbon Footprint
              </h1>
              <p className="text-gray-600 mt-1">
                Enter your consumption data for accurate emissions calculation
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {result && (
          <Card className="mb-6 border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-800">
                <CheckCircle className="h-5 w-5" />
                <span>Calculation Complete!</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-2xl font-bold text-green-800">
                    {result.totalKgCO2e.toFixed(2)} kg CO₂e
                  </p>
                  <p className="text-green-600">Total Carbon Footprint</p>
                </div>
                <div>
                  <h4 className="font-medium text-green-800 mb-2">
                    Breakdown by Category:
                  </h4>
                  {Object.entries(result.breakdown).map(
                    ([category, amount]: [string, any]) => (
                      <div
                        key={category}
                        className="flex justify-between text-sm"
                      >
                        <span className="capitalize">{category}:</span>
                        <span>{amount.toFixed(2)} kg CO₂e</span>
                      </div>
                    )
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={onSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Carbon Footprint Items</CardTitle>
                  <CardDescription>
                    Add items from different categories to calculate your carbon
                    footprint
                  </CardDescription>
                </div>
                <Button
                  type="button"
                  onClick={addItem}
                  variant="outline"
                  size="sm"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Item
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item, index) => (
                <div key={index} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Item {index + 1}</h4>
                    {items.length > 1 && (
                      <Button
                        type="button"
                        onClick={() => removeItem(index)}
                        variant="outline"
                        size="sm"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select
                        value={item.category}
                        onValueChange={(value) =>
                          updateItem(index, "category", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="transport">Transport</SelectItem>
                          <SelectItem value="energy">Energy</SelectItem>
                          <SelectItem value="cooking">Cooking</SelectItem>
                          <SelectItem value="food">Food</SelectItem>
                          <SelectItem value="waste">Waste</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select
                        value={item.subcategory}
                        onValueChange={(value) =>
                          updateItem(index, "subcategory", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {item.category === "transport" && (
                            <>
                              <SelectItem value="petrol">Petrol</SelectItem>
                              <SelectItem value="diesel">Diesel</SelectItem>
                              <SelectItem value="cng">CNG</SelectItem>
                            </>
                          )}
                          {item.category === "energy" && (
                            <SelectItem value="grid">
                              Grid Electricity
                            </SelectItem>
                          )}
                          {item.category === "cooking" && (
                            <SelectItem value="lpg">LPG</SelectItem>
                          )}
                          {item.category === "food" && (
                            <>
                              <SelectItem value="rice">Rice</SelectItem>
                              <SelectItem value="wheat">Wheat</SelectItem>
                              <SelectItem value="chicken">Chicken</SelectItem>
                              <SelectItem value="mutton">Mutton</SelectItem>
                            </>
                          )}
                          {item.category === "waste" && (
                            <SelectItem value="municipal_solid_waste">
                              Municipal Solid Waste
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.1"
                        value={item.quantity}
                        onChange={(e) =>
                          updateItem(
                            index,
                            "quantity",
                            parseFloat(e.target.value) || 0
                          )
                        }
                        placeholder="0"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Unit</Label>
                      <Input
                        value={item.unit}
                        readOnly
                        className="bg-gray-50"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            <Link href="/dashboard">
              <Button variant="outline">Cancel</Button>
            </Link>
            <Button
              type="submit"
              disabled={loading}
              className="bg-green-600 hover:bg-green-700"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Emissions
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
