import { TransportationCalculatorForm } from "@/components/transportation/transportation-calculator-form";

export default function TransportationPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Transportation Carbon Calculator</h1>
        <p className="text-muted-foreground mt-2">
          Calculate your carbon footprint from personal vehicles, flights, and
          public transport. Use route optimization to get more accurate distance
          calculations.
        </p>
      </div>

      <TransportationCalculatorForm />
    </div>
  );
}
