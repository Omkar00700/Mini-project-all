"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Trash2,
  Target,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Calendar,
  BarChart3,
  Info,
  Plus,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";

interface Goal {
  id: string;
  targetName: string;
  targetKgPerMonth: number;
  baselineKgPerMonth: number;
  startDate: string;
  endDate?: string | null;
  createdAt: string;
}

interface DashboardSummary {
  lastMonthTotal: number;
  averageMonthly: number;
  totalCalculations: number;
}

interface CategoryBreakdown {
  category: string;
  total: number;
}

export default function GoalsPage() {
  const { user } = useAuth();
  const [goalName, setGoalName] = useState("Reduce my carbon footprint");
  const [targetReduction, setTargetReduction] = useState(20);
  const [targetDeadline, setTargetDeadline] = useState("");
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(true);
  const [deletingGoalId, setDeletingGoalId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dashboardData, setDashboardData] = useState<DashboardSummary | null>(
    null
  );
  const [topContributors, setTopContributors] = useState<CategoryBreakdown[]>(
    []
  );
  const [currentEmissions, setCurrentEmissions] = useState<number>(0);

  useEffect(() => {
    if (user) {
      loadAll();
    }
  }, [user]);

  useEffect(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 6);
    setTargetDeadline(d.toISOString().slice(0, 7));

    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const nameParam = params.get("name");
      const redParam = params.get("reduction");
      if (nameParam) setGoalName(nameParam);
      if (redParam) setTargetReduction(parseInt(redParam) || 20);
    }
  }, []);

  const loadAll = async () => {
    setLoadingData(true);
    try {
      const [goalsRes, dashRes] = await Promise.all([
        fetch("/api/goals"),
        fetch("/api/dashboard"),
      ]);

      if (goalsRes.ok) {
        const data = await goalsRes.json();
        setGoals(data.goals || []);
      }

      if (dashRes.ok) {
        const dash = await dashRes.json();
        const summary: DashboardSummary = dash.summary;
        setDashboardData(summary);
        setTopContributors(dash.topContributors || []);

        const real =
          summary.lastMonthTotal > 0
            ? summary.lastMonthTotal
            : summary.averageMonthly;
        setCurrentEmissions(Math.round(real * 10) / 10);
      }
    } catch (error) {
    } finally {
      setLoadingData(false);
    }
  };

  const calculateTarget = () => currentEmissions * (1 - targetReduction / 100);

  const getGoalProgress = (goal: Goal) => {
    if (!dashboardData) return null;
    const current =
      dashboardData.lastMonthTotal > 0
        ? dashboardData.lastMonthTotal
        : dashboardData.averageMonthly;
    if (current === 0 || !goal.baselineKgPerMonth) return null;

    const reduction = goal.baselineKgPerMonth - current;
    const needed = goal.baselineKgPerMonth - goal.targetKgPerMonth;
    return needed <= 0
      ? 100
      : Math.min(100, Math.max(0, (reduction / needed) * 100));
  };

  const getGoalStatus = (goal: Goal) => {
    const current = dashboardData?.lastMonthTotal ?? 0;
    if (current === 0) return "no-data";
    if (current <= goal.targetKgPerMonth) return "achieved";
    if (current <= goal.baselineKgPerMonth) return "on-track";
    return "above-baseline";
  };

  const createGoal = async () => {
    if (!user) {
      setError("Please log in to create goals");
      return;
    }
    if (currentEmissions === 0) {
      setError(
        "Calculate your carbon footprint first — we need your real baseline."
      );
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const targetKgPerMonth = calculateTarget();
      const endDate = targetDeadline
        ? new Date(`${targetDeadline}-01`).toISOString()
        : null;

      const response = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetName: goalName,
          targetKgPerMonth,
          baselineKgPerMonth: currentEmissions,
          startDate: new Date().toISOString(),
          endDate,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Goal creation failed");
      }

      const data = await response.json();
      setGoals([data.goal, ...goals]);
      setGoalName("Reduce my carbon footprint");
      setTargetReduction(20);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const deleteGoal = async (goalId: string) => {
    if (!user) return;
    setDeletingGoalId(goalId);
    setError(null);
    try {
      const response = await fetch(`/api/goals/${goalId}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Goal deletion failed");
      }
      setGoals(goals.filter((goal) => goal.id !== goalId));
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setDeletingGoalId(null);
    }
  };

  const hasRealData = dashboardData && dashboardData.totalCalculations > 0;

  const categoryLabel: Record<string, string> = {
    energy: "Energy",
    transportation: "Transport",
    food: "Food",
    waste: "Waste",
  };

  const categoryColor: Record<string, string> = {
    energy: "bg-yellow-500",
    transportation: "bg-blue-500",
    food: "bg-green-500",
    waste: "bg-orange-500",
  };

  return (
    <div className="min-h-screen bg-background dark:bg-[#020804] text-foreground font-sans relative overflow-hidden pb-20">
      {}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.08)_0%,transparent_70%)] blur-[80px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.08)_0%,transparent_70%)] blur-[80px]" />
      </div>

      <div className="container mx-auto pt-24 px-4 max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <div className="inline-flex items-center justify-center p-3 bg-purple-500/10 rounded-2xl mb-6 border border-purple-500/20 text-purple-500 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
            <Target className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 text-foreground dark:text-white">
            Reduction{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              Goals
            </span>
          </h1>
          <p className="text-lg text-muted-foreground font-light max-w-2xl">
            Set targets based on your real emissions and track progress
            automatically — no guessing.
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-12 md:items-start">
          {}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="md:col-span-6"
          >
            <Card className="bg-background/40 dark:bg-black/40 backdrop-blur-xl border-border/50 dark:border-white/10 shadow-2xl overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500" />
              <CardHeader className="pb-4 border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5 space-y-1">
                <CardTitle className="text-2xl text-foreground dark:text-white flex items-center gap-2">
                  <Plus className="w-5 h-5 text-purple-600 dark:text-purple-400" />{" "}
                  New Goal
                </CardTitle>
                <CardDescription className="text-muted-foreground dark:text-white/60 text-sm">
                  Set a reduction target based on your real carbon footprint.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6 p-6 relative z-10">
                {}
                {loadingData ? (
                  <div className="p-4 bg-muted/30 dark:bg-white/5 rounded-2xl border border-border/50 dark:border-white/10 animate-pulse">
                    <div className="h-4 w-32 bg-muted dark:bg-white/10 rounded mb-2" />
                    <div className="h-8 w-24 bg-muted dark:bg-white/10 rounded" />
                  </div>
                ) : hasRealData ? (
                  <div className="p-4 bg-gradient-to-br from-purple-500/5 to-transparent dark:from-purple-500/10 border border-purple-500/20 rounded-2xl space-y-3">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-purple-500" />
                      <h4 className="text-sm font-semibold text-purple-600 dark:text-purple-400 uppercase tracking-wider">
                        Your Real Baseline
                      </h4>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black text-foreground dark:text-white">
                        {currentEmissions}
                      </span>
                      <span className="text-sm text-muted-foreground dark:text-white/60">
                        kg CO₂ / month
                      </span>
                    </div>
                    {topContributors.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        <p className="text-xs text-muted-foreground dark:text-white/50 uppercase tracking-wider">
                          Breakdown
                        </p>
                        {topContributors.slice(0, 4).map((c) => (
                          <div
                            key={c.category}
                            className="flex items-center gap-2 text-xs"
                          >
                            <div
                              className={`w-2 h-2 rounded-full ${categoryColor[c.category] || "bg-gray-500"}`}
                            />
                            <span className="text-foreground/70 dark:text-white/60 w-20">
                              {categoryLabel[c.category] || c.category}
                            </span>
                            <div className="flex-1 h-1.5 bg-muted dark:bg-white/10 rounded-full overflow-hidden">
                              <div
                                className={`h-full ${categoryColor[c.category] || "bg-gray-500"} rounded-full opacity-70`}
                                style={{
                                  width: `${Math.min(100, (c.total / currentEmissions) * 100)}%`,
                                }}
                              />
                            </div>
                            <span className="text-foreground/50 dark:text-white/40 font-mono w-12 text-right">
                              {Math.round(c.total)} kg
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="text-[10px] text-muted-foreground dark:text-white/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-green-500" /> From
                      your {dashboardData!.totalCalculations} carbon calculation
                      {dashboardData!.totalCalculations !== 1 ? "s" : ""}
                    </p>
                  </div>
                ) : (
                  <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-2xl space-y-3">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
                      <div>
                        <p className="font-medium text-foreground dark:text-white text-sm">
                          No baseline yet
                        </p>
                        <p className="text-xs text-muted-foreground dark:text-white/50 mt-1">
                          You need to calculate your carbon footprint at least
                          once before setting a goal. That way your target is
                          based on reality, not a guess.
                        </p>
                      </div>
                    </div>
                    <Link href="/calculator">
                      <Button
                        size="sm"
                        className="w-full bg-amber-500 hover:bg-amber-600 text-white"
                      >
                        Calculate My Footprint →
                      </Button>
                    </Link>
                  </div>
                )}

                <div>
                  <Label
                    htmlFor="goalName"
                    className="text-foreground/80 dark:text-white/80"
                  >
                    Goal Name
                  </Label>
                  <Input
                    id="goalName"
                    className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-purple-500/50 mt-1.5 h-11"
                    value={goalName}
                    onChange={(e) => setGoalName(e.target.value)}
                    placeholder="e.g., Reduce commuting emissions"
                  />
                </div>

                <div>
                  <Label
                    htmlFor="targetReduction"
                    className="text-foreground/80 dark:text-white/80"
                  >
                    Target Reduction (%)
                  </Label>
                  <Input
                    id="targetReduction"
                    type="range"
                    min="5"
                    max="80"
                    step="5"
                    className="mt-2 w-full accent-purple-500 cursor-pointer"
                    value={targetReduction}
                    onChange={(e) =>
                      setTargetReduction(parseFloat(e.target.value) || 0)
                    }
                  />
                  <div className="flex justify-between text-xs text-muted-foreground dark:text-white/40 mt-1">
                    <span>5%</span>
                    <span className="font-bold text-purple-500 text-sm">
                      {targetReduction}%
                    </span>
                    <span>80%</span>
                  </div>
                </div>

                <div>
                  <Label
                    htmlFor="deadline"
                    className="text-foreground/80 dark:text-white/80 flex items-center gap-2"
                  >
                    <Calendar className="w-4 h-4" /> Target Deadline
                  </Label>
                  <Input
                    id="deadline"
                    type="month"
                    className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-purple-500/50 mt-1.5 h-11"
                    value={targetDeadline}
                    onChange={(e) => setTargetDeadline(e.target.value)}
                  />
                </div>

                {}
                {hasRealData && currentEmissions > 0 && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-5 bg-gradient-to-br from-purple-500/5 to-transparent dark:from-purple-500/10 dark:to-transparent border border-purple-500/20 rounded-2xl relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-[40px] pointer-events-none" />
                    <h4 className="font-semibold text-purple-600 dark:text-purple-400 mb-3 text-sm tracking-widest uppercase">
                      Preview
                    </h4>
                    <div className="flex items-baseline gap-2 mb-2">
                      <span className="text-3xl font-black text-foreground dark:text-white">
                        {calculateTarget().toFixed(1)}
                      </span>
                      <span className="text-purple-600/80 dark:text-purple-300/80 text-sm">
                        kg CO₂ / mo
                      </span>
                    </div>
                    <p className="text-muted-foreground dark:text-purple-200/60 text-sm leading-relaxed">
                      Down from{" "}
                      <strong className="text-foreground dark:text-white">
                        {currentEmissions} kg
                      </strong>{" "}
                      — a saving of{" "}
                      <strong className="text-emerald-500">
                        {(currentEmissions - calculateTarget()).toFixed(1)} kg
                      </strong>{" "}
                      per month.
                    </p>
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-muted-foreground dark:text-white/40 mb-1">
                        <span>Current: {currentEmissions} kg</span>
                        <span>Target: {calculateTarget().toFixed(1)} kg</span>
                      </div>
                      <div className="h-2 bg-muted dark:bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-red-400 via-amber-400 to-emerald-400 rounded-full"
                          style={{ width: `${100 - targetReduction}%` }}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}

                <Button
                  onClick={createGoal}
                  disabled={loading || loadingData || !hasRealData}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white shadow-[0_0_20px_rgba(168,85,247,0.3)] h-12 rounded-xl text-lg font-medium"
                >
                  {loading ? "Creating Goal…" : "Commit to This Goal"}
                </Button>

                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3"
                  >
                    <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    <p className="text-red-400 text-sm font-medium">{error}</p>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="md:col-span-6"
          >
            <Card className="bg-background/40 dark:bg-black/40 backdrop-blur-xl border-border/50 dark:border-white/10 shadow-2xl sticky top-32 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500" />
              <CardHeader className="border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5 pb-4">
                <CardTitle className="text-xl text-foreground dark:text-white">
                  Active Goals
                </CardTitle>
                <CardDescription className="text-muted-foreground dark:text-white/50">
                  Real progress against your real emissions
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {goals.length > 0 ? (
                  <div className="space-y-5">
                    <AnimatePresence>
                      {goals.map((goal, index) => {
                        const progress = getGoalProgress(goal);
                        const status = getGoalStatus(goal);
                        const current = dashboardData?.lastMonthTotal || 0;

                        return (
                          <motion.div
                            key={goal.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ delay: index * 0.08 }}
                            className="p-5 bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 rounded-2xl relative overflow-hidden group hover:border-purple-500/30 transition-colors"
                          >
                            {}
                            <div
                              className={`absolute inset-y-0 left-0 w-1 rounded-l-2xl ${status === "achieved" ? "bg-emerald-500" : status === "on-track" ? "bg-blue-500" : "bg-amber-500"} opacity-70`}
                            />

                            <div className="flex justify-between items-start mb-3 pl-2">
                              <div className="flex-1">
                                <h4 className="font-semibold text-foreground dark:text-white tracking-tight text-lg mb-1">
                                  {goal.targetName}
                                </h4>
                                <p className="text-[10px] text-muted-foreground dark:text-white/40 tracking-wider uppercase font-mono">
                                  Started{" "}
                                  {new Date(
                                    goal.createdAt
                                  ).toLocaleDateString()}
                                  {goal.endDate &&
                                    ` · Due ${new Date(goal.endDate).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}`}
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                {status === "achieved" && (
                                  <Badge
                                    variant="secondary"
                                    className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-0"
                                  >
                                    <CheckCircle2 className="w-3 h-3 mr-1" />{" "}
                                    Achieved!
                                  </Badge>
                                )}
                                {status === "on-track" && (
                                  <Badge
                                    variant="secondary"
                                    className="bg-blue-500/10 text-blue-600 dark:text-blue-400 border-0"
                                  >
                                    <TrendingDown className="w-3 h-3 mr-1" /> On
                                    Track
                                  </Badge>
                                )}
                                {status === "above-baseline" && (
                                  <Badge
                                    variant="secondary"
                                    className="bg-amber-500/10 text-amber-600 dark:text-amber-400 border-0"
                                  >
                                    <TrendingUp className="w-3 h-3 mr-1" /> In
                                    Progress
                                  </Badge>
                                )}
                                {status === "no-data" && (
                                  <Badge
                                    variant="secondary"
                                    className="bg-muted text-muted-foreground border-0"
                                  >
                                    <Info className="w-3 h-3 mr-1" /> No Data
                                  </Badge>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => deleteGoal(goal.id)}
                                  disabled={deletingGoalId === goal.id}
                                  className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 text-muted-foreground dark:text-white/30 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-500/10 rounded-full transition-all"
                                >
                                  {deletingGoalId === goal.id ? (
                                    <div className="animate-spin rounded-full h-3 w-3 border-b border-red-500" />
                                  ) : (
                                    <Trash2 className="h-4 w-4" />
                                  )}
                                </Button>
                              </div>
                            </div>

                            {}
                            <div className="grid grid-cols-3 gap-2 mb-4 pl-2 text-center">
                              <div className="bg-background/50 dark:bg-black/30 p-2 rounded-xl border border-border/30 dark:border-white/5">
                                <p className="text-[10px] text-muted-foreground dark:text-white/40 uppercase mb-0.5">
                                  Baseline
                                </p>
                                <p className="font-mono text-foreground dark:text-white font-bold">
                                  {goal.baselineKgPerMonth?.toFixed(0)}
                                </p>
                                <p className="text-[9px] text-muted-foreground dark:text-white/30">
                                  kg/mo
                                </p>
                              </div>
                              <div className="bg-background/50 dark:bg-black/30 p-2 rounded-xl border border-border/30 dark:border-white/5">
                                <p className="text-[10px] text-muted-foreground dark:text-white/40 uppercase mb-0.5">
                                  Now
                                </p>
                                <p
                                  className={`font-mono font-bold ${current === 0 ? "text-muted-foreground" : current <= goal.targetKgPerMonth ? "text-emerald-500" : "text-foreground dark:text-white"}`}
                                >
                                  {current > 0 ? current.toFixed(0) : "—"}
                                </p>
                                <p className="text-[9px] text-muted-foreground dark:text-white/30">
                                  kg/mo
                                </p>
                              </div>
                              <div className="bg-purple-500/10 p-2 rounded-xl border border-purple-500/20">
                                <p className="text-[10px] text-purple-500 dark:text-purple-300 uppercase mb-0.5">
                                  Target
                                </p>
                                <p className="font-mono text-foreground dark:text-white font-bold">
                                  {goal.targetKgPerMonth.toFixed(0)}
                                </p>
                                <p className="text-[9px] text-muted-foreground dark:text-white/30">
                                  kg/mo
                                </p>
                              </div>
                            </div>

                            {}
                            {progress !== null ? (
                              <div className="pl-2">
                                <div className="flex justify-between text-xs mb-1">
                                  <span className="text-muted-foreground dark:text-white/50">
                                    Progress toward goal
                                  </span>
                                  <span
                                    className={`font-semibold ${progress >= 100 ? "text-emerald-500" : "text-purple-500"}`}
                                  >
                                    {Math.round(progress)}%
                                  </span>
                                </div>
                                <div className="h-2 bg-muted dark:bg-white/10 rounded-full overflow-hidden">
                                  <motion.div
                                    initial={{ width: 0 }}
                                    animate={{ width: `${progress}%` }}
                                    transition={{
                                      duration: 1,
                                      ease: "easeOut",
                                      delay: 0.3,
                                    }}
                                    className={`h-full rounded-full ${progress >= 100 ? "bg-gradient-to-r from-emerald-500 to-green-400" : "bg-gradient-to-r from-purple-500 to-pink-500"}`}
                                  />
                                </div>
                                {current > 0 && (
                                  <p className="text-xs text-muted-foreground dark:text-white/40 mt-1.5">
                                    {current <= goal.targetKgPerMonth
                                      ? `🎉 You're already meeting this goal! Currently at ${current.toFixed(0)} kg/mo`
                                      : `${(current - goal.targetKgPerMonth).toFixed(0)} kg/mo above your target`}
                                  </p>
                                )}
                              </div>
                            ) : (
                              <p className="text-xs text-muted-foreground dark:text-white/30 pl-2 mt-1 flex items-center gap-1">
                                <Info className="w-3 h-3" /> Run a calculation
                                to see live progress
                              </p>
                            )}
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  </div>
                ) : (
                  <div className="text-center py-20 text-muted-foreground dark:text-white/40 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-full bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 flex items-center justify-center mb-4 text-muted-foreground/50 dark:text-white/20">
                      <Target className="w-8 h-8" />
                    </div>
                    <p className="font-medium text-foreground/60 dark:text-white/60">
                      No goals yet
                    </p>
                    <p className="text-sm mt-2 max-w-[220px] leading-relaxed">
                      {hasRealData
                        ? "Create your first goal using your real baseline on the left."
                        : "Calculate your footprint first, then come back here to set a meaningful target."}
                    </p>
                    {!hasRealData && (
                      <Link href="/calculator" className="mt-4">
                        <Button size="sm" variant="outline">
                          Go to Calculator →
                        </Button>
                      </Link>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
