import Link from "next/link";
import { ArrowLeft, Leaf } from "lucide-react";
import { Header } from "@/components/layout/header";

export default function GenericPage({ params }: { params: { slug: string } }) {
  const title = params.slug
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");

  return (
    <div className="min-h-screen bg-background selection:bg-primary/30 selection:text-primary flex flex-col">
      <Header className="sticky top-0 w-full z-50 bg-background/80 backdrop-blur-xl border-b border-border/40" />

      <main className="relative flex-1 flex flex-col items-center justify-center text-center px-6 py-24 overflow-hidden">
        {}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] rounded-full bg-primary/5 blur-[120px] pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-8 border border-primary/20 shadow-[0_0_60px_rgba(16,185,129,0.2)]">
            <Leaf className="w-12 h-12 text-primary drop-shadow-[0_0_15px_rgba(16,185,129,0.5)]" />
          </div>

          <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter text-foreground">
            {title}
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-12 font-medium leading-relaxed">
            We are meticulously crafting this experience. The{" "}
            <span className="text-primary">{title}</span> page will be available
            in the upcoming monumental Aura Platform release.
            <br />
            <br />
            Our mission to build a sustainable future is an ongoing journey.
          </p>

          <Link href="/">
            <button className="h-14 px-10 rounded-full bg-foreground hover:bg-primary text-background hover:text-white font-bold text-lg flex items-center transition-all hover:scale-105 shadow-xl">
              <ArrowLeft className="w-6 h-6 mr-3" />
              Return to Aura Home
            </button>
          </Link>
        </div>
      </main>
    </div>
  );
}
