"use client";

import { useState } from "react";
import { SecuritySettings } from "@/components/auth/security-settings";
import { useAuth } from "@/contexts/auth-context";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function SecuritySettingsPage() {
  const { user } = useAuth();
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  const handleTwoFactorToggle = (enabled: boolean) => {
    setTwoFactorEnabled(enabled);
  };

  if (!user) {
    return (
      <div className="container mx-auto py-8">
        <Alert>
          <AlertDescription>
            Please sign in to access security settings.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <SecuritySettings
        twoFactorEnabled={twoFactorEnabled}
        onTwoFactorToggle={handleTwoFactorToggle}
      />
    </div>
  );
}
