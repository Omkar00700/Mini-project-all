"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  HelpCircle,
  Search,
  MessageCircle,
  Book,
  Video,
  Mail,
} from "lucide-react";

export default function HelpPage() {
  const faqs = [
    {
      question: "How accurate are the carbon footprint calculations?",
      answer:
        "Our calculations use India-specific emission factors from authoritative sources like the Central Electricity Authority and WRI India. We achieve 85-90% accuracy for most categories, with detailed source attribution for transparency.",
    },
    {
      question: "What emission factors do you use for India?",
      answer:
        "We use region-specific factors including: 0.82 kg CO2/kWh for electricity (CEA), 2.27 kg CO2/L for petrol (WRI India), and locally sourced factors for food items like rice (4.0 kg CO2/kg) and transportation modes like auto-rickshaws.",
    },
    {
      question: "How do I set up carbon reduction goals?",
      answer:
        "Go to the Goals page, enter your target monthly emissions, and we'll automatically calculate your baseline from recent activities. You can track progress and get personalized recommendations to meet your targets.",
    },
    {
      question: "Can I export my carbon footprint data?",
      answer:
        "Yes! You can export your data in PDF, Excel, or CSV formats from the Dashboard. This includes detailed breakdowns, emission factors used, and progress tracking over time.",
    },
    {
      question: "How often should I calculate my carbon footprint?",
      answer:
        "We recommend monthly calculations for the most accurate tracking. You can input daily activities and we'll aggregate them, or do bulk entries for the entire month.",
    },
    {
      question: "What transportation modes are supported?",
      answer:
        "We support all major Indian transportation: personal vehicles (petrol/diesel/CNG), public transport (bus, train), two-wheelers, auto-rickshaws, and flights. Each uses India-specific emission factors.",
    },
    {
      question: "How do you calculate food emissions?",
      answer:
        "Food emissions are calculated using lifecycle assessments that include production, processing, and transportation. We have India-specific factors for staples like rice, wheat, and lentils, plus global factors for other items.",
    },
    {
      question: "Is my data secure and private?",
      answer:
        "Yes, we use industry-standard encryption and follow GDPR/data protection guidelines. Your personal data is never shared without consent, and you can export or delete your data anytime.",
    },
  ];

  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <HelpCircle className="h-8 w-8 text-green-600" />
          <h1 className="text-3xl font-bold">Help Center</h1>
        </div>
        <p className="text-muted-foreground">
          Find answers to common questions and get support for using Aura
        </p>
      </div>

      {}
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search for help articles..."
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3 mb-8">
        {}
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Book className="h-5 w-5 text-blue-600" />
              <CardTitle>Getting Started</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Quick Start Guide
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  First Calculation
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Setting Up Goals
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Understanding Results
                </a>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Video className="h-5 w-5 text-purple-600" />
              <CardTitle>Video Tutorials</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Platform Overview (5 min)
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Calculator Walkthrough
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Dashboard Features
                </a>
              </li>
              <li>
                <a href="#" className="text-blue-600 hover:underline">
                  Advanced Tips
                </a>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-green-600" />
              <CardTitle>Contact Support</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start"
            >
              <Mail className="h-4 w-4 mr-2" />
              Email Support
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start"
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Live Chat
            </Button>
            <div className="text-xs text-muted-foreground">
              Response time: 2-4 hours
            </div>
          </CardContent>
        </Card>
      </div>

      {}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
          <CardDescription>
            Common questions about carbon footprint calculation and the Aura
            platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      {}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Still Need Help?</CardTitle>
          <CardDescription>
            Our support team is here to help you succeed with your
            sustainability goals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h4 className="font-semibold">Email Support</h4>
              <p className="text-sm text-muted-foreground">support@aura.com</p>
              <p className="text-xs text-muted-foreground">
                Response within 2-4 hours
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Documentation</h4>
              <p className="text-sm text-muted-foreground">
                Comprehensive guides and API docs
              </p>
              <a href="#" className="text-xs text-blue-600 hover:underline">
                View Documentation →
              </a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
