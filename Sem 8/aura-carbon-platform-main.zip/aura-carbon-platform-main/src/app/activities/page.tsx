"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/auth-context";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  X,
  Calendar,
  Activity as ActivityIcon,
  Upload,
  Download,
  Sparkles,
  Check,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ActivityLogTab } from "@/components/dashboard/activity-log-tab";
import { useGamificationStore } from "@/store/gamification-store";

interface SavedActivity {
  id: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  name?: string;
  isRecurring?: boolean;
  frequency?: string;
  notes?: string;
  createdAt: string;
}

interface ActivityFormData {
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  name: string;
  isRecurring: boolean;
  frequency: "daily" | "weekly" | "monthly" | "yearly";
  notes: string;
}

export default function ActivitiesPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [activities, setActivities] = useState<SavedActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [processingRecurring, setProcessingRecurring] = useState(false);
  const [importingCSV, setImportingCSV] = useState(false);
  const [showImport, setShowImport] = useState(false);

  const [formData, setFormData] = useState<ActivityFormData>({
    category: "energy",
    subcategory: "electricity",
    value: 0,
    unit: "kWh",
    name: "",
    isRecurring: false,
    frequency: "monthly",
    notes: "",
  });

  const fetchActivities = async () => {
    try {
      const response = await fetch("/api/activities", {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setActivities(data.activities || []);
      }
    } catch (err) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchActivities();
    }
  }, [user]);

  const resetForm = () => {
    setFormData({
      category: "energy",
      subcategory: "electricity",
      value: 0,
      unit: "kWh",
      name: "",
      isRecurring: false,
      frequency: "monthly",
      notes: "",
    });
    setEditingId(null);
    setShowForm(false);
  };

  const { processServerReward } = useGamificationStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      const url = editingId ? "/api/activities" : "/api/activities";
      const method = editingId ? "PUT" : "POST";
      const body = editingId ? { ...formData, id: editingId } : formData;

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to save activity");
      }

      const data = await response.json();

      if (data.reward) {
        processServerReward(data.reward);
      }

      await fetchActivities();
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save activity");
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (activity: SavedActivity) => {
    setFormData({
      category: activity.category,
      subcategory: activity.subcategory,
      value: activity.value,
      unit: activity.unit,
      name: activity.name || "",
      isRecurring: activity.isRecurring || false,
      frequency: (activity.frequency as any) || "monthly",
      notes: activity.notes || "",
    });
    setEditingId(activity.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (confirmDeleteId !== id) {
      setConfirmDeleteId(id);
      return;
    }
    setConfirmDeleteId(null);
    try {
      const response = await fetch(`/api/activities?id=${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to delete activity");
      await fetchActivities();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to delete activity"
      );
    }
  };

  const processRecurringActivities = async () => {
    setProcessingRecurring(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch("/api/activities/process-recurring", {
        method: "POST",
        credentials: "include",
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to process recurring activities");
      }

      setSuccessMessage(
        data.message || "Recurring activities processed successfully!"
      );
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Failed to process recurring activities"
      );
    } finally {
      setProcessingRecurring(false);
    }
  };

  const importCSV = async (file: File) => {
    setImportingCSV(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/activities/import-csv", {
        method: "POST",
        credentials: "include",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to import CSV");
      }

      setSuccessMessage(
        `Successfully imported ${data.imported} activities from CSV!`
      );
      await fetchActivities();
      setShowImport(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to import CSV");
    } finally {
      setImportingCSV(false);
    }
  };

  const downloadCSVTemplate = () => {
    const csvContent =
      "name,category,subcategory,value,unit,isRecurring,frequency,notes\n" +
      "Monthly Electricity,energy,electricity,250,kWh,true,monthly,Home electricity usage\n" +
      "Daily Commute,transportation,personal_vehicle_gasoline,20,km,true,daily,Office commute";

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "activities_template.csv";
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getSubcategories = (category: string) => {
    const subcategories = {
      energy: ["electricity", "lpg"],
      transportation: [
        "personal_vehicle_gasoline",
        "personal_vehicle_diesel",
        "cng",
        "bus",
        "train",
        "auto_rickshaw",
        "motorcycle",
      ],
      food: ["chicken", "rice", "wheat", "lentils"],
      waste: ["municipal_solid_waste"],
    };
    return subcategories[category as keyof typeof subcategories] || [];
  };

  const getUnitForSubcategory = (category: string, subcategory: string) => {
    const unitMap: Record<string, Record<string, string>> = {
      energy: {
        electricity: "kWh",
        lpg: "kg",
      },
      transportation: {
        personal_vehicle_gasoline: "km",
        personal_vehicle_diesel: "km",
        cng: "km",
        bus: "km",
        train: "km",
        auto_rickshaw: "km",
        motorcycle: "km",
      },
      food: {
        chicken: "kg",
        rice: "kg",
        wheat: "kg",
        lentils: "kg",
      },
      waste: {
        municipal_solid_waste: "kg",
      },
    };
    return unitMap[category]?.[subcategory] || "";
  };

  if (!user) {
    return (
      <div className="flex-1 p-6">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Sign in to manage your saved activities.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => router.push("/auth/login")}>Sign In</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background dark:bg-[#020804] text-foreground font-sans relative overflow-hidden pb-20">
      {}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 right-1/4 w-[600px] h-[600px] bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.1)_0%,transparent_70%)] blur-[80px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.1)_0%,transparent_70%)] blur-[80px]" />
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage:
              'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")',
          }}
        ></div>
      </div>

      <div className="container mx-auto pt-24 px-4 max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <div className="inline-flex items-center justify-center p-3 bg-blue-500/10 rounded-2xl mb-6 border border-blue-500/20 text-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.2)]">
            <ActivityIcon className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 text-foreground dark:text-white">
            Activity{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
              Ledger
            </span>
          </h1>
          <p className="text-lg text-muted-foreground font-light max-w-2xl">
            Save and manage your recurring carbon activities for easy tracking
            and accurate baselines.
          </p>
        </motion.div>

        <Tabs defaultValue="log" className="w-full space-y-8">
          <div className="flex justify-center sm:justify-start">
            <TabsList className="bg-muted/50 dark:bg-black/40 border border-border/50 dark:border-white/10 p-1 rounded-xl shadow-lg">
              <TabsTrigger
                value="log"
                className="rounded-lg data-[state=active]:bg-emerald-500 data-[state=active]:text-white dark:data-[state=active]:bg-emerald-600 px-6 font-medium"
              >
                Activity Log
              </TabsTrigger>
              <TabsTrigger
                value="templates"
                className="rounded-lg data-[state=active]:bg-blue-500 data-[state=active]:text-white dark:data-[state=active]:bg-blue-600 px-6 font-medium"
              >
                Saved Templates
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="log" className="mt-0 outline-none">
            <ActivityLogTab />
          </TabsContent>

          <TabsContent value="templates" className="mt-0 outline-none">
            <div className="grid gap-8 lg:grid-cols-3">
              {}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-2"
              >
                <Card className="bg-background/40 dark:bg-black/40 backdrop-blur-xl border-border/50 dark:border-white/10 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-500" />
                  <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5 pb-4 gap-4">
                    <div>
                      <CardTitle className="text-xl text-foreground dark:text-white flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-blue-600 dark:text-blue-400" />{" "}
                        Saved Activities
                      </CardTitle>
                      <CardDescription className="text-muted-foreground dark:text-white/60">
                        Your carbon activity templates
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={processRecurringActivities}
                        disabled={processingRecurring}
                        className="bg-muted/50 dark:bg-white/5 border-border/50 dark:border-white/10 text-foreground dark:text-white hover:bg-muted dark:hover:bg-white/10 shadow-none border"
                      >
                        {processingRecurring ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-foreground dark:border-white mr-2"></div>
                            Processing...
                          </>
                        ) : (
                          <>
                            <Calendar className="h-4 w-4 mr-2 text-blue-600 dark:text-blue-400" />
                            Process Recurring
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => setShowImport(true)}
                        disabled={showImport}
                        className="bg-muted/50 dark:bg-white/5 border-border/50 dark:border-white/10 text-foreground dark:text-white hover:bg-muted dark:hover:bg-white/10 shadow-none border"
                      >
                        <Upload className="h-4 w-4 mr-2 text-cyan-400" />
                        Import CSV
                      </Button>
                      <Button
                        onClick={() => setShowForm(true)}
                        disabled={showForm}
                        className="bg-blue-500 hover:bg-blue-600 text-white border-0 shadow-[0_0_20px_rgba(59,130,246,0.3)]"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Activity
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {successMessage && (
                      <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-md">
                        <p className="text-green-700 text-sm">
                          {successMessage}
                        </p>
                      </div>
                    )}

                    {loading ? (
                      <div className="space-y-3">
                        {[...Array(3)].map((_, i) => (
                          <div
                            key={i}
                            className="h-20 bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 rounded-2xl animate-pulse"
                          />
                        ))}
                      </div>
                    ) : activities.length === 0 ? (
                      <div className="text-center py-20 text-muted-foreground dark:text-white/40 flex flex-col items-center">
                        <div className="w-16 h-16 rounded-full bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 flex items-center justify-center mb-4 text-muted-foreground/50 dark:text-white/20">
                          <ActivityIcon className="w-8 h-8" />
                        </div>
                        <p className="font-medium text-foreground/60 dark:text-white/60 mb-4">
                          No saved activities yet
                        </p>
                        <Button
                          onClick={() => setShowForm(true)}
                          className="bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 text-foreground dark:text-white hover:bg-muted dark:hover:bg-white/10"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Your First Template
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <AnimatePresence>
                          {activities.map((activity, index) => (
                            <motion.div
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.95 }}
                              transition={{ delay: index * 0.05 }}
                              key={activity.id}
                              className="p-5 bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 rounded-2xl hover:border-blue-500/30 transition-colors group relative overflow-hidden"
                            >
                              <div className="absolute inset-y-0 left-0 w-1 bg-blue-500 rounded-l-2xl opacity-50" />
                              <div className="flex justify-between items-start mb-3 pl-2">
                                <div>
                                  <div className="text-xs font-bold text-blue-600 dark:text-blue-400 mb-1 tracking-wider uppercase">
                                    {activity.category}
                                  </div>
                                  <h4 className="font-semibold text-foreground dark:text-white text-lg tracking-tight leading-none mb-1">
                                    {activity.name ||
                                      `${activity.category} - ${activity.subcategory}`}
                                  </h4>
                                  <p className="text-sm text-muted-foreground dark:text-white/60 font-mono">
                                    {activity.value} {activity.unit}
                                  </p>
                                </div>
                                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-8 w-8 p-0 text-muted-foreground dark:text-white/50 hover:text-foreground dark:hover:text-white hover:bg-muted dark:hover:bg-white/10 rounded-full"
                                    onClick={() => handleEdit(activity)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  {confirmDeleteId === activity.id ? (
                                    <div className="flex bg-red-500/10 dark:bg-red-500/20 rounded-full items-center p-0.5 ml-1">
                                      <span className="text-[10px] text-red-600 dark:text-red-400 font-bold px-2 uppercase tracking-wide">
                                        Delete?
                                      </span>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-7 w-7 p-0 text-red-600 hover:text-white hover:bg-red-500 rounded-full"
                                        onClick={() =>
                                          handleDelete(activity.id)
                                        }
                                      >
                                        <Check className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-7 w-7 p-0 text-slate-500 hover:text-white hover:bg-slate-500 rounded-full ml-0.5"
                                        onClick={() => setConfirmDeleteId(null)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  ) : (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0 text-muted-foreground dark:text-white/50 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-500/10 dark:hover:bg-red-400/20 rounded-full"
                                      onClick={() => handleDelete(activity.id)}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-2 mb-3 pl-2">
                                <Badge
                                  variant="secondary"
                                  className="bg-muted dark:bg-white/10 text-foreground/80 dark:text-white/80 border-0 hover:bg-muted/80 dark:hover:bg-white/20"
                                >
                                  {activity.category}
                                </Badge>
                                {activity.isRecurring && (
                                  <Badge
                                    variant="outline"
                                    className="border-cyan-500/30 text-cyan-600 dark:text-cyan-400"
                                  >
                                    {activity.frequency}
                                  </Badge>
                                )}
                              </div>
                              {activity.notes && (
                                <p className="text-sm text-muted-foreground dark:text-white/40 pl-2">
                                  {activity.notes}
                                </p>
                              )}
                              <p className="text-[10px] text-muted-foreground dark:text-white/30 tracking-wider uppercase pl-2 mt-4">
                                Added{" "}
                                {new Date(
                                  activity.createdAt
                                ).toLocaleDateString()}
                              </p>
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              {}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="lg:col-span-1 border-white/10"
              >
                {showImport && (
                  <Card className="mb-4">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle>Import Activities from CSV</CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowImport(false)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-4">
                          Upload a CSV file with your activities. Download the
                          template to see the required format.
                        </p>
                        <Button
                          onClick={downloadCSVTemplate}
                          variant="outline"
                          className="w-full mb-4"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download CSV Template
                        </Button>
                      </div>

                      <div>
                        <Label htmlFor="csv-file">Select CSV File</Label>
                        <Input
                          id="csv-file"
                          type="file"
                          accept=".csv"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              importCSV(file);
                            }
                          }}
                          disabled={importingCSV}
                          className="mt-1"
                        />
                        {importingCSV && (
                          <p className="text-sm text-muted-foreground mt-2">
                            Importing activities...
                          </p>
                        )}
                      </div>

                      <div className="text-xs text-muted-foreground">
                        <p>
                          <strong>CSV Format:</strong>
                        </p>
                        <ul className="list-disc list-inside mt-1 space-y-1">
                          <li>name: Activity name</li>
                          <li>category: energy, transportation, food, waste</li>
                          <li>
                            subcategory: Specific type (e.g., electricity,
                            personal_vehicle_gasoline)
                          </li>
                          <li>value: Numeric amount</li>
                          <li>unit: Unit of measurement (kWh, km, kg, etc.)</li>
                          <li>isRecurring: true/false (optional)</li>
                          <li>
                            frequency: daily/weekly/monthly/yearly (optional)
                          </li>
                          <li>notes: Additional notes (optional)</li>
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {}
                <AnimatePresence>
                  {showForm && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                    >
                      <Card className="bg-background/40 dark:bg-transparent bg-gradient-to-br from-transparent dark:from-[#0f172a] to-transparent dark:to-black/80 backdrop-blur-xl border-border/50 dark:border-white/10 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-[40px]" />
                        <CardHeader className="flex flex-row items-center justify-between border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5">
                          <CardTitle className="text-foreground dark:text-white text-lg">
                            {editingId ? "Edit Activity" : "New Activity"}
                          </CardTitle>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={resetForm}
                            className="h-8 w-8 p-0 text-muted-foreground dark:text-white/50 hover:text-foreground dark:hover:text-white hover:bg-muted dark:hover:bg-white/10 rounded-full"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </CardHeader>
                        <CardContent className="pt-6 relative z-10">
                          <form onSubmit={handleSubmit} className="space-y-5">
                            <div>
                              <Label
                                htmlFor="name"
                                className="text-foreground/80 dark:text-white/80"
                              >
                                Activity Name
                              </Label>
                              <Input
                                id="name"
                                className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1"
                                value={formData.name}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    name: e.target.value,
                                  })
                                }
                                placeholder="e.g., Monthly Electricity"
                              />
                            </div>

                            <div>
                              <Label
                                htmlFor="category"
                                className="text-foreground/80 dark:text-white/80"
                              >
                                Category
                              </Label>
                              <Select
                                value={formData.category}
                                onValueChange={(value) => {
                                  setFormData({
                                    ...formData,
                                    category: value,
                                    subcategory: "",
                                    unit: "",
                                  });
                                }}
                              >
                                <SelectTrigger className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1">
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                                <SelectContent className="bg-background dark:bg-[#0f172a] border-border dark:border-white/10 text-foreground dark:text-white">
                                  <SelectItem value="energy">Energy</SelectItem>
                                  <SelectItem value="transportation">
                                    Transportation
                                  </SelectItem>
                                  <SelectItem value="food">Food</SelectItem>
                                  <SelectItem value="waste">Waste</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <Label
                                htmlFor="subcategory"
                                className="text-foreground/80 dark:text-white/80"
                              >
                                Subcategory
                              </Label>
                              <Select
                                value={formData.subcategory}
                                onValueChange={(value) => {
                                  const unit = getUnitForSubcategory(
                                    formData.category,
                                    value
                                  );
                                  setFormData({
                                    ...formData,
                                    subcategory: value,
                                    unit,
                                  });
                                }}
                                disabled={!formData.category}
                              >
                                <SelectTrigger className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1">
                                  <SelectValue placeholder="Select subcategory" />
                                </SelectTrigger>
                                <SelectContent className="bg-background dark:bg-[#0f172a] border-border dark:border-white/10 text-foreground dark:text-white">
                                  {getSubcategories(formData.category).map(
                                    (sub) => (
                                      <SelectItem key={sub} value={sub}>
                                        {sub
                                          .replace(/_/g, " ")
                                          .replace(/\b\w/g, (l) =>
                                            l.toUpperCase()
                                          )}
                                      </SelectItem>
                                    )
                                  )}
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <Label
                                htmlFor="value"
                                className="text-foreground/80 dark:text-white/80"
                              >
                                Amount Value
                              </Label>
                              <Input
                                id="value"
                                type="number"
                                className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1 font-mono"
                                value={formData.value || ""}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    value: parseFloat(e.target.value) || 0,
                                  })
                                }
                                placeholder="0.00"
                              />
                              {formData.unit && (
                                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1.5 font-medium ml-1">
                                  Unit Required: {formData.unit}
                                </p>
                              )}
                            </div>

                            <div className="flex items-center space-x-3 p-3 bg-muted/50 dark:bg-white/5 rounded-xl border border-border/50 dark:border-white/10">
                              <input
                                type="checkbox"
                                id="recurring"
                                checked={formData.isRecurring}
                                className="w-4 h-4 rounded border-input dark:border-white/20 bg-background dark:bg-black/50 text-blue-500 focus:ring-blue-500/50"
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    isRecurring: e.target.checked,
                                  })
                                }
                              />
                              <Label
                                htmlFor="recurring"
                                className="text-foreground dark:text-white"
                              >
                                Make this a Recurring Activity
                              </Label>
                            </div>

                            {formData.isRecurring && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                              >
                                <Label
                                  htmlFor="frequency"
                                  className="text-foreground/80 dark:text-white/80"
                                >
                                  Frequency
                                </Label>
                                <Select
                                  value={formData.frequency}
                                  onValueChange={(value: any) =>
                                    setFormData({
                                      ...formData,
                                      frequency: value,
                                    })
                                  }
                                >
                                  <SelectTrigger className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent className="bg-background dark:bg-[#0f172a] border-border dark:border-white/10 text-foreground dark:text-white">
                                    <SelectItem value="daily">Daily</SelectItem>
                                    <SelectItem value="weekly">
                                      Weekly
                                    </SelectItem>
                                    <SelectItem value="monthly">
                                      Monthly
                                    </SelectItem>
                                    <SelectItem value="yearly">
                                      Yearly
                                    </SelectItem>
                                  </SelectContent>
                                </Select>
                              </motion.div>
                            )}

                            <div>
                              <Label
                                htmlFor="notes"
                                className="text-foreground/80 dark:text-white/80"
                              >
                                Notes (Optional)
                              </Label>
                              <Input
                                id="notes"
                                className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 text-foreground dark:text-white focus:ring-blue-500/50 h-10 mt-1 text-sm"
                                value={formData.notes}
                                onChange={(e) =>
                                  setFormData({
                                    ...formData,
                                    notes: e.target.value,
                                  })
                                }
                                placeholder="Additional context"
                              />
                            </div>

                            {error && (
                              <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                                <p className="text-red-700 text-sm">{error}</p>
                              </div>
                            )}

                            <div className="flex gap-3 pt-2">
                              <Button
                                type="submit"
                                disabled={saving}
                                className="flex-1 bg-blue-500 hover:bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]"
                              >
                                {saving ? (
                                  <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Saving...
                                  </>
                                ) : (
                                  <>
                                    <Save className="h-4 w-4 mr-2" />
                                    {editingId
                                      ? "Update Activity"
                                      : "Save Activity"}
                                  </>
                                )}
                              </Button>
                              <Button
                                type="button"
                                variant="outline"
                                onClick={resetForm}
                                className="bg-muted/50 dark:bg-white/5 border-border/50 dark:border-white/10 text-foreground dark:text-white hover:bg-muted dark:hover:bg-white/10"
                              >
                                Cancel
                              </Button>
                            </div>
                          </form>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
