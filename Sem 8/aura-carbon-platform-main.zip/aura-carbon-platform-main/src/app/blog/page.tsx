"use client";

import { motion } from "framer-motion";
import {
  Calendar,
  User,
  ArrowRight,
  BookOpen,
  Zap,
  Leaf,
  Flame,
} from "lucide-react";
import Link from "next/link";

export const articles = [
  {
    slug: "india-grid-emission-factor",
    title:
      "Why India's Grid Emission Factor is 0.82 kg CO₂/kWh — And Why It Varies By State",
    excerpt:
      "When you use 1 kWh of electricity in India, you're emitting roughly 0.82 kg of CO₂ into the atmosphere. But that number hides enormous variation across states — and understanding it changes how you think about rooftop solar.",
    date: "March 5, 2026",
    author: "Dr. Nandita Rao",
    category: "Energy",
    readTime: "7 min read",
    icon: Zap,
    color: "text-yellow-500",
    bg: "bg-yellow-500/10",
    border: "border-yellow-500/20",
    featured: true,
    content: `India's electricity grid doesn't run on one type of fuel. It runs on a mix — coal (about 55%), hydropower (12%), solar and wind (18%), natural gas (7%), and nuclear (3%). That mix changes the carbon intensity of every unit of electricity produced.

The Central Electricity Authority (CEA) calculates a national average emission factor annually. For 2023–24, it came in at **0.82 kg CO₂ per kWh** — more than double the European average of 0.31, and about four times the French figure (which is nuclear-heavy at 0.08).

**Why it varies by state**

This 0.82 figure is a national average, but your actual impact depends heavily on which grid you're connected to. Consider:

- **Uttar Pradesh:** Relies heavily on coal. Effective emission factor closer to 1.1–1.2 kg CO₂/kWh.
- **Karnataka:** Significant hydro and solar. Emission factor around 0.5–0.6 kg CO₂/kWh.
- **Tamil Nadu:** Strong wind capacity. One of India's cleaner grids at 0.55–0.65 kg CO₂/kWh.
- **Chhattisgarh:** Coal-dominant. Emission factor exceeds 1.3 kg CO₂/kWh.

This means a factory in Karnataka running on grid electricity can have half the operational emissions of an identical factory in Chhattisgarh.

**What this means for rooftop solar**

For a household in Delhi consuming 300 kWh/month, that's roughly **246 kg CO₂/month** from electricity alone (at 0.82). A 3 kW rooftop solar system — which generates about 350–400 kWh/month in North India — could eliminate that footprint entirely. The payback period on emissions is under 3 years for most Indian rooftop installations.

In Karnataka, the same math is somewhat less dramatic numerically because the grid is already cleaner — but solar still wins.

**The direction of travel**

India's grid emission factor has been declining steadily. In 2018, it was 0.92 kg CO₂/kWh. By 2030, with India's 500 GW renewable target, it could fall to under 0.6. This is why building solar capacity today — even when grid electricity costs less — is forward-looking: the grid will get cleaner, but your solar system continues to offset regardless.

For Aura users: your electricity calculations use India's national factor of 0.82. We're tracking CEA's annual updates and will adjust the coefficient when new data is published.`,
  },
  {
    slug: "two-wheeler-problem",
    title:
      "The Two-Wheeler Problem: 280 Million Petrol Bikes and India's Quiet Climate Challenge",
    excerpt:
      "India has more registered two-wheelers than any country on Earth. They're affordable, practical, and a major hidden source of urban carbon emissions. Here's the actual math — and why EV two-wheelers are probably India's highest-leverage climate opportunity.",
    date: "February 28, 2026",
    author: "Arjun Mehta",
    category: "Transportation",
    readTime: "8 min read",
    icon: Flame,
    color: "text-orange-500",
    bg: "bg-orange-500/10",
    border: "border-orange-500/20",
    featured: false,
    content: `India has roughly 280 million registered two-wheelers — motorcycles and scooters. That's more than the entire population of Brazil. Most of them run on petrol.

**The per-vehicle math**

A typical 100cc petrol motorcycle in India returns 50–60 km/litre under urban conditions. Petrol has an emission factor of approximately 2.31 kg CO₂ per litre (source: MoEFCC, IPCC 2006 Guidelines).

So for a daily commuter riding 15 km each way (30 km/day, ~23 working days/month = 690 km/month):
- Fuel consumed: ~690 / 55 ≈ **12.5 litres/month**  
- Emissions: 12.5 × 2.31 = **~29 kg CO₂/month**
- Annual: **~348 kg CO₂/year** — just from commuting

That's significant for a single individual. Now multiply by 280 million vehicles.

**Why this is often underestimated**

When we talk about transport emissions in India, the conversation usually focuses on four-wheelers or aviation. But the sheer volume of two-wheelers means they contribute roughly **30% of road transport CO₂** despite being individually low-emission.

Factor in that many two-wheelers also emit disproportionate levels of particulate matter — older carbureted engines produce NOx, HC, and PM2.5 at much higher rates per km than modern fuel-injected cars — and the public health case against petrol two-wheelers is as strong as the climate case.

**The EV opportunity**

An EV two-wheeler consuming 2–2.5 kWh per 100 km on India's grid (at 0.82 kg CO₂/kWh) produces roughly **1.6–2.0 kg CO₂ per 100 km**, compared to ~4.2 kg CO₂ per 100 km for a typical 100cc petrol bike.

That's a **50–60% reduction in CO₂** at current grid intensity — and the advantage grows as the grid gets cleaner.

The economics are already compelling for high-usage commuters: charging costs approximately ₹1–1.50 per km (at ₹8/kWh electricity) versus ₹2.20–2.50 per km on petrol at ₹100/litre.

**The range limitation problem is real but shrinking**

The main objection is range anxiety. Most affordable EVs in the ₹80,000–1.2 lakh segment offer 80–120 km real-world range, which covers the vast majority of Indian daily commutes (national average: under 25 km/day). The 2% of trips exceeding this range can often be handled with ICE alternatives or public transport.

For Aura users: switching from a 100cc petrol bike to an EV for a 30 km/day commute would save approximately **21 kg CO₂/month**, or about **250 kg/year**. Use our What-If analyzer to model your specific commute.`,
  },
  {
    slug: "rice-vs-wheat-carbon",
    title:
      "Rice vs. Wheat: The Surprising Carbon Difference in India's Staple Foods",
    excerpt:
      "A kilogram of rice generates roughly 4x the greenhouse gas emissions of a kilogram of wheat. The reason has nothing to do with farming methods — it comes from a surprising source: flooded paddy fields and methane.",
    date: "February 20, 2026",
    author: "Dr. Nandita Rao",
    category: "Food",
    readTime: "6 min read",
    icon: Leaf,
    color: "text-green-500",
    bg: "bg-green-500/10",
    border: "border-green-500/20",
    featured: false,
    content: `If you eat rice daily — as most people in South and East India do — your food's carbon footprint is being shaped by an unexpected culprit: methane-producing bacteria living in flooded paddy fields.

**The methane connection**

Paddy rice is grown in flooded fields. Submerged soil creates anaerobic (oxygen-free) conditions that are perfect for methane-producing microorganisms called methanogens. They consume organic matter and release methane (CH₄), which bubbles up through the water and into the atmosphere.

Methane is not CO₂. It's a much more potent greenhouse gas — over 100 years, its global warming potential (GWP) is about **28x that of CO₂**. When we convert rice paddy methane into "CO₂-equivalent" terms, the numbers shift dramatically.

**The actual numbers**

Emission factors from the IPCC AR6 Working Group III (Chapter 12, food systems) for Indian growing conditions:

- **Rice (paddy to milled):** ~3.5–4.5 kg CO₂e per kg of rice consumed
- **Wheat flour:** ~0.8–1.1 kg CO₂e per kg
- **Lentils (dal):** ~0.9–1.4 kg CO₂e per kg  
- **Chicken:** ~6–9 kg CO₂e per kg (feed + transport)
- **Eggs:** ~2.7–4.0 kg CO₂e per kg

A household consuming 8 kg of rice per person per month is generating roughly **32–36 kg CO₂e/month from rice alone**.

**Important context: rice also provides extraordinary nutrition density**

This data shouldn't be used to shame rice consumption — rice feeds 3.5 billion people. The global food system needs to change structurally, not through individual guilt. But for people actively trying to reduce their food footprint, these numbers are useful.

**What can actually reduce rice's footprint?**

Three interventions show real evidence:

1. **Alternate wetting and drying (AWD):** Farmers periodically drain fields, disrupting methane production. Studies suggest 20–40% methane reduction with no yield loss. Already adopted by some cooperatives in Punjab and Andhra Pradesh.

2. **Direct-seeded rice (DSR):** Skips the flooded nursery phase. Reduces water use by 25–30% and methane by 15–25%.

3. **Consumer-side:** Replacing some rice with lentils — which fix atmospheric nitrogen and require no flooding — reduces both carbon footprint and increases protein intake.

For Aura users: your food emissions are calculated using IPCC-based factors. 1 kg of rice in our model contributes approximately 3.5 kg CO₂e.`,
  },
  {
    slug: "scope-1-2-3-guide",
    title: "Understanding Scope 1, 2, and 3 Emissions: A Practical Guide",
    excerpt:
      "The foundation of carbon accounting lies in understanding what you're responsible for. The GHG Protocol's three-scope framework is the global standard — here's what it actually means in practice.",
    date: "February 15, 2026",
    author: "Dr. Nandita Rao",
    category: "Carbon Accounting",
    readTime: "6 min read",
    icon: BookOpen,
    color: "text-blue-500",
    bg: "bg-blue-500/10",
    border: "border-blue-500/20",
    featured: false,
    content: `When organizations begin their net-zero journey, the GHG Protocol is the starting point. It's the global standard for how we measure, categorize, and report greenhouse gas emissions. At its core is a three-scope framework — and understanding it changes how you think about corporate responsibility.

**Scope 1: What you burn**

Direct emissions from owned or controlled sources. If you own a boiler, a company vehicle, or a factory furnace, those are Scope 1. They're the emissions you have the most direct control over and the most responsibility for.

Examples:
- Natural gas combusted in office heating systems
- Petrol/diesel used by company-owned vehicles
- Process emissions from industrial operations

For most Indian small businesses and individuals, Scope 1 is LPG cooking, direct fuel consumption, and any owned diesel generators.

**Scope 2: What your electricity produces**

Indirect emissions from purchased electricity, steam, heat, or cooling. When you pay your electricity bill, you're not directly burning coal — but someone is, on your behalf.

India's Scope 2 calculation is straightforward: multiply your kWh consumption by the national grid emission factor (0.82 kg CO₂/kWh as of 2024). Businesses with renewable energy certificates or Power Purchase Agreements for solar/wind can claim lower Scope 2 figures.

**Scope 3: Everything else (and it's usually most of it)**

All other indirect emissions across your value chain — upstream and downstream. For most companies, this is where 70–90% of their total footprint lives:

- **Upstream:** Purchased goods and services, capital goods, business travel, employee commuting, waste generated in operations
- **Downstream:** Use of sold products, end-of-life treatment, transportation and distribution

For a software company, Scope 3 includes: server energy (if using cloud), employee commuting, business travel, and even the emissions embedded in the laptops their employees use.

For an individual, Scope 3 roughly maps to everything outside your direct home energy use: the food you buy, the clothes you wear, the flights you take.

**Why Scope 3 reporting is hard**

Scope 3 requires data from your suppliers, your employees, and sometimes your customers. You can't measure it directly — you have to model it using spend-based or activity-based emission factors. This is where high-quality carbon accounting platforms (and emission factor databases) matter most.

Aura's calculator addresses individual Scope 1 and Scope 2 directly, and captures the most significant Scope 3 categories: food, transportation choices, and waste.`,
  },
  {
    slug: "lpg-cooking-footprint",
    title: "How Much CO₂ Does Your Kitchen Cylinder Actually Emit?",
    excerpt:
      "Most Indians think of LPG as 'clean cooking fuel' compared to firewood. That's true for air quality. But for climate? Each 14.2 kg cylinder emits about 43 kg of CO₂. Here's the full picture.",
    date: "March 8, 2026",
    author: "Priya Sharma",
    category: "Energy",
    readTime: "5 min read",
    icon: Zap,
    color: "text-amber-500",
    bg: "bg-amber-500/10",
    border: "border-amber-500/20",
    featured: false,
    content: `LPG — liquefied petroleum gas — is the cooking fuel for more than 300 million Indian households. It replaced firewood and biomass as part of the Pradhan Mantri Ujjwala Yojana programme, and that's genuinely good news for indoor air quality and women's health. But it's worth understanding what it means for carbon.

**The basic chemistry**

LPG is primarily propane (C₃H₈) and butane (C₄H₁₀). When burned completely, these hydrocarbons produce CO₂ and water.

The IPCC emission factor for LPG combustion: **approximately 2.98–3.00 kg CO₂ per kg of LPG burned**.

**Per cylinder math**

A standard Indian domestic cylinder contains **14.2 kg of LPG**.

14.2 kg × 2.99 kg CO₂/kg = **~42.5 kg CO₂ per cylinder**

The average urban Indian household uses roughly 1 to 1.5 cylinders per month — meaning cooking alone contributes **43–64 kg CO₂/month**.

For a family of four over a year, LPG cooking represents **510–765 kg CO₂** — often more than their entire electricity footprint.

**Comparison with alternatives**

| Fuel | CO₂ per cooking unit | Practical notes |
|------|---------------------|-----------------|
| LPG (domestic) | ~2.99 kg/kg | Clean combustion, grid-independent |
| PNG (piped gas) | ~2.04 kg/m³ | Slightly lower emission factor, convenience |
| Electric induction (grid) | ~0.82 kg/kWh × efficiency | Higher if grid is coal-heavy |
| Electric induction (solar) | Near zero | Depends on solar availability |

Electric induction cooking on India's current grid can actually be *higher* in emissions than LPG if you're in a coal-heavy state like UP or Jharkhand. But for households with solar, induction cooking becomes one of the lowest-emission cooking methods available.

**The key insight**

LPG is "clean" relative to biomass burning — for health. But it is still a fossil fuel, and its climate impact is real and significant. The path to zero-emission cooking runs through electric induction + renewable electricity, not just through switching from wood to gas.

Aura uses the value of **2.98 kg CO₂ per kg of LPG** in all calculations, based on MoEFCC and IPCC 2006 guidelines.`,
  },
];

export default function BlogPage() {
  const featured = articles[0];
  const rest = articles.slice(1);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-emerald-500/6 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 left-1/4 w-[600px] h-[600px] bg-teal-500/6 rounded-full blur-[120px]" />
      </div>

      <div className="container mx-auto px-4 py-28 relative z-10 max-w-5xl">
        {}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-5">
            Aura{" "}
            <span className="text-emerald-500 font-serif italic">Insights</span>
          </h1>
          <p className="text-xl text-muted-foreground font-light max-w-2xl mx-auto">
            Deep reads on carbon science, India-specific emission data, and how
            to actually reduce your footprint. Written by people who spend too
            much time reading IPCC tables.
          </p>
        </motion.div>

        {}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="mb-12"
        >
          <Link href={`/blog/${featured.slug}`}>
            <div className="group p-8 md:p-10 rounded-3xl border border-border/50 bg-secondary/10 hover:bg-secondary/30 hover:border-emerald-500/30 transition-all duration-300 cursor-pointer">
              <div className="flex items-center gap-3 mb-5">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${featured.bg} ${featured.color}`}
                >
                  {featured.category}
                </span>
                <span className="text-muted-foreground text-sm flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> {featured.date}
                </span>
                <span className="text-muted-foreground text-sm">
                  {featured.readTime}
                </span>
              </div>

              <h2 className="text-3xl md:text-4xl font-bold mb-4 group-hover:text-emerald-500 transition-colors tracking-tight leading-tight">
                {featured.title}
              </h2>

              <p className="text-muted-foreground text-lg mb-6 leading-relaxed max-w-3xl">
                {featured.excerpt}
              </p>

              <div className="flex items-center justify-between pt-5 border-t border-border/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-500 text-lg">
                    🔬
                  </div>
                  <span className="font-medium text-sm">{featured.author}</span>
                </div>
                <span className="flex items-center gap-1.5 text-emerald-500 font-medium text-sm group-hover:gap-3 transition-all">
                  Read full article <ArrowRight className="w-4 h-4" />
                </span>
              </div>
            </div>
          </Link>
        </motion.div>

        {}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {rest.map((article, i) => (
            <motion.div
              key={article.slug}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 + i * 0.08 }}
            >
              <Link href={`/blog/${article.slug}`}>
                <div className="group h-full p-6 rounded-2xl border border-border/50 bg-secondary/10 hover:bg-secondary/30 hover:border-border transition-all duration-200 cursor-pointer flex flex-col">
                  <div className="flex items-center gap-2 mb-3">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${article.bg} ${article.color}`}
                    >
                      {article.category}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {article.readTime}
                    </span>
                  </div>

                  <h3 className="font-bold text-lg mb-2 group-hover:text-emerald-500 transition-colors leading-snug flex-1">
                    {article.title}
                  </h3>

                  <p className="text-muted-foreground text-sm leading-relaxed mb-4 line-clamp-2">
                    {article.excerpt}
                  </p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground mt-auto pt-4 border-t border-border/30">
                    <span className="flex items-center gap-1.5">
                      <User className="w-3 h-3" /> {article.author}
                    </span>
                    <span>{article.date}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}

          {}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.55 }}
            className="p-6 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex flex-col justify-center"
          >
            <div className="text-3xl mb-3">📬</div>
            <h3 className="text-xl font-bold mb-2">New articles every week.</h3>
            <p className="text-emerald-50/90 text-sm mb-5 leading-relaxed">
              We write about India-specific climate data, emission factors, and
              practical ways to understand (and shrink) your footprint.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 rounded-xl px-3 py-2 text-sm text-foreground bg-white/95 outline-none focus:ring-2 focus:ring-white/50"
              />
              <button className="px-4 py-2 bg-white text-emerald-600 font-semibold rounded-xl text-sm hover:bg-emerald-50 transition-colors">
                Subscribe
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
