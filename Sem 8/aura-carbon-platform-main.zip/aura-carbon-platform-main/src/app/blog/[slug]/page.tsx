"use client";

import { motion } from "framer-motion";
import { Calendar, ArrowLeft, Clock, ExternalLink } from "lucide-react";
import Link from "next/link";
import { articles } from "@/app/blog/page";

interface PageProps {
  params: { slug: string };
}

export default function BlogPostPage({ params }: PageProps) {
  const { slug } = params;
  const article = articles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">📄</div>
          <h1 className="text-2xl font-bold mb-2">Article not found</h1>
          <Link href="/blog" className="text-emerald-500 hover:underline">
            ← Back to Blog
          </Link>
        </div>
      </div>
    );
  }

  const authorEmojis: Record<string, string> = {
    "Dr. Nandita Rao": "🔬",
    "Arjun Mehta": "🌱",
    "Priya Sharma": "⚡",
  };

  const paragraphs = article.content.split("\n\n").map((block, i) => {
    const isHeading =
      block.startsWith("**") &&
      block.endsWith("**") &&
      !block.slice(2, -2).includes("**");
    const isTable = block.includes("| --- |") || block.startsWith("| ");

    if (isHeading) {
      return (
        <h2 key={i} className="text-xl font-bold text-foreground mt-8 mb-3">
          {block.replace(/\*\*/g, "")}
        </h2>
      );
    }

    if (isTable) {
      const rows = block
        .split("\n")
        .filter((r) => r.trim() && !r.match(/^[\s|:-]+$/));
      return (
        <div
          key={i}
          className="overflow-x-auto my-6 rounded-xl border border-border/50"
        >
          <table className="w-full text-sm">
            <tbody>
              {rows.map((row, ri) => (
                <tr
                  key={ri}
                  className={
                    ri === 0
                      ? "bg-muted/50 font-semibold"
                      : "border-t border-border/30"
                  }
                >
                  {row
                    .split("|")
                    .filter((c, ci, arr) => ci > 0 && ci < arr.length - 1)
                    .map((cell, ci) => (
                      <td
                        key={ci}
                        className="px-4 py-2.5 text-muted-foreground"
                      >
                        {cell.trim()}
                      </td>
                    ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    if (block.startsWith("- ")) {
      const items = block.split("\n").map((line) => line.replace(/^- /, ""));
      return (
        <ul key={i} className="list-none space-y-2 my-4">
          {items.map((item, ii) => (
            <li
              key={ii}
              className="flex items-start gap-2 text-muted-foreground leading-relaxed"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
              <span
                dangerouslySetInnerHTML={{
                  __html: item.replace(
                    /\*\*(.*?)\*\*/g,
                    "<strong class='text-foreground'>$1</strong>"
                  ),
                }}
              />
            </li>
          ))}
        </ul>
      );
    }

    return (
      <p
        key={i}
        className="text-muted-foreground leading-relaxed my-4"
        dangerouslySetInnerHTML={{
          __html: block.replace(
            /\*\*(.*?)\*\*/g,
            "<strong class='text-foreground font-semibold'>$1</strong>"
          ),
        }}
      />
    );
  });

  const related = articles
    .filter((a) => a.slug !== slug && a.category === article.category)
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[100px]" />
      </div>

      <div className="container mx-auto px-4 py-28 relative z-10 max-w-3xl">
        {}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-10"
        >
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Aura Insights
          </Link>
        </motion.div>

        {}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-10"
        >
          <div className="flex items-center gap-3 mb-5">
            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold ${article.bg} ${article.color}`}
            >
              {article.category}
            </span>
            <span className="text-muted-foreground text-sm flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" /> {article.date}
            </span>
            <span className="text-muted-foreground text-sm flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" /> {article.readTime}
            </span>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold tracking-tight leading-tight mb-5">
            {article.title}
          </h1>

          <p className="text-lg text-muted-foreground leading-relaxed mb-6 border-l-4 border-emerald-500/40 pl-5">
            {article.excerpt}
          </p>

          <div className="flex items-center gap-3 pb-8 border-b border-border/50">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-lg">
              {authorEmojis[article.author] || "✍️"}
            </div>
            <div>
              <p className="font-semibold text-sm">{article.author}</p>
              <p className="text-xs text-muted-foreground">Aura Climate Team</p>
            </div>
          </div>
        </motion.div>

        {}
        <motion.article
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="prose-neutral max-w-none"
        >
          {paragraphs}
        </motion.article>

        {}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-10 p-5 rounded-2xl border border-border/50 bg-secondary/20 text-sm"
        >
          <p className="font-semibold mb-2 text-foreground">
            Data sources & methodology
          </p>
          <p className="text-muted-foreground text-xs leading-relaxed">
            Emission factors used in Aura are sourced from: IPCC 2006 Guidelines
            for National Greenhouse Gas Inventories, India&apos;s MoEFCC
            national communications, CEA (Central Electricity Authority) grid
            emission data, and BEE (Bureau of Energy Efficiency) appliance
            standards. Numbers cited in this article reflect the same values
            used in Aura&apos;s carbon calculator.
          </p>
        </motion.div>

        {}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8 p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between flex-wrap gap-4"
        >
          <div>
            <p className="font-semibold text-foreground">
              See your own numbers
            </p>
            <p className="text-muted-foreground text-sm">
              Calculate your actual carbon footprint using the same data.
            </p>
          </div>
          <Link
            href="/calculator"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold rounded-xl text-sm transition-colors"
          >
            Carbon Calculator <ExternalLink className="w-4 h-4" />
          </Link>
        </motion.div>

        {}
        {related.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-14"
          >
            <h2 className="text-xl font-bold mb-6">Related articles</h2>
            <div className="grid gap-4">
              {related.map((rel) => (
                <Link key={rel.slug} href={`/blog/${rel.slug}`}>
                  <div className="group p-5 rounded-2xl border border-border/50 hover:border-emerald-500/30 hover:bg-secondary/30 transition-all">
                    <span
                      className={`text-xs font-semibold ${rel.color} mb-2 block`}
                    >
                      {rel.category}
                    </span>
                    <h3 className="font-bold group-hover:text-emerald-500 transition-colors mb-1">
                      {rel.title}
                    </h3>
                    <p className="text-muted-foreground text-sm line-clamp-1">
                      {rel.excerpt}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
