"use client";

import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/contexts/auth-context-simple";
import { motion, AnimatePresence } from "framer-motion";
import {
  Medal,
  Flame,
  Trophy as TrophyIcon,
  Users,
  RefreshCcw,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { LEVEL_CONFIG } from "@/config/gamification";

interface LeaderboardUser {
  rank: number;
  name: string;
  totalXp: number;
  currentLevel: number;
  image: string | null;
}

export default function LeaderboardPage() {
  const { user } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeframe, setTimeframe] = useState("all-time");
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchLeaderboard = useCallback(
    async () => {
      setLoading(true);

      try {
        const response = await fetch(`/api/leaderboard?timeframe=${timeframe}`);
        if (response.ok) {
          const data = await response.json();
          setLeaderboard(data.leaderboard || []);
        }
      } catch {
      } finally {
        setLoading(false);
      }
    },
    [timeframe]
  );

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Medal className="w-6 h-6 text-amber-400" fill="currentColor" />;
      case 2:
        return <Medal className="w-6 h-6 text-slate-300" fill="currentColor" />;
      case 3:
        return <Medal className="w-6 h-6 text-amber-700" fill="currentColor" />;
      default:
        return (
          <span className="font-bold text-muted-foreground w-6 text-center">
            {rank}
          </span>
        );
    }
  };

  const getLevelInfo = (level: number) => {
    const config =
      LEVEL_CONFIG.find((c) => c.level === level) || LEVEL_CONFIG[0];
    return { name: config.title, icon: config.icon };
  };

  return (
    <div className="flex-1 space-y-8 p-4 pt-6 md:p-8 max-w-5xl mx-auto w-full">
      <div className="flex flex-col items-center justify-center text-center space-y-4 mb-8">
        <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mb-2">
          <TrophyIcon className="w-8 h-8" />
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-emerald-600 to-teal-400 bg-clip-text text-transparent">
          Global Leaderboard
        </h1>
        <p className="text-muted-foreground max-w-lg">
          See how your sustainability journey compares against the entire Aura
          community. Log activities and crush goals to climb the ranks!
        </p>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
        <Tabs
          value={timeframe}
          onValueChange={setTimeframe}
          className="w-full md:w-auto"
        >
          <TabsList className="grid grid-cols-2 w-full md:w-80">
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
            <TabsTrigger value="all-time">All-Time</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
        </div>
      </div>

      <Card className="border-border/50 bg-background/50 backdrop-blur-xl shadow-xl overflow-hidden">
        <CardHeader className="bg-secondary/30 border-b border-border/50">
          <CardTitle className="text-lg flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-500" /> Top Carbon Reducers
          </CardTitle>
          <CardDescription>
            Rankings are updated in real-time based on your Experience Points
            (XP).
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-16 w-full rounded-xl" />
              ))}
            </div>
          ) : leaderboard.length <= 1 ? (
            <div className="p-16 text-center space-y-4">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto">
                <Users className="w-8 h-8 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold">No other users yet</h3>
                <p className="text-muted-foreground">
                  Invite friends to compete and see who can reduce the most
                  carbon!
                </p>
              </div>
              <Button variant="outline">Invite Friends</Button>
            </div>
          ) : (
            <div className="divide-y divide-border/50">
              <AnimatePresence mode="popLayout">
                {leaderboard.map((player, index) => {
                  const isCurrentUser =
                    (player as any).isCurrentUser || user?.name === player.name;
                  const stage = getLevelInfo(player.currentLevel);

                  return (
                    <motion.div
                      layout
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ delay: index * 0.05 }}
                      key={player.name}
                      className={`flex items-center gap-4 p-4 transition-colors hover:bg-secondary/40 ${
                        isCurrentUser
                          ? "bg-emerald-500/5 hover:bg-emerald-500/10"
                          : ""
                      }`}
                    >
                      <div className="flex items-center justify-center w-10 shrink-0">
                        {getRankIcon(player.rank)}
                      </div>

                      <Avatar
                        className={`h-12 w-12 border-2 ${isCurrentUser ? "border-emerald-500" : "border-border"}`}
                      >
                        <AvatarImage src={player.image || ""} />
                        <AvatarFallback className="text-lg bg-secondary">
                          {stage.icon}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p
                            className={`font-bold truncate ${isCurrentUser ? "text-emerald-600 dark:text-emerald-400" : "text-foreground"}`}
                          >
                            {player.name} {isCurrentUser && "(You)"}
                          </p>
                          {player.rank === 1 && (
                            <Badge
                              variant="secondary"
                              className="bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] px-1.5 py-0 h-5 border-amber-500/20"
                            >
                              Champion
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                          <span className="flex items-center gap-1 font-medium bg-secondary px-2 py-0.5 rounded-full">
                            Level {player.currentLevel}
                          </span>
                          <span>{stage.name}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-sm md:text-base font-extrabold text-foreground tracking-tight flex items-center gap-1.5 justify-end">
                          {player.totalXp.toLocaleString()}{" "}
                          <span className="text-xs font-bold text-emerald-500 uppercase">
                            XP
                          </span>
                        </div>
                        <div className="w-24 mt-2 hidden sm:block">
                          <Progress
                            value={player.totalXp % 100}
                            className="h-1.5 shadow-sm"
                          />
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
