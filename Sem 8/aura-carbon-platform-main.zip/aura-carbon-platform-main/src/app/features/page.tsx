import { Leaf, Calculator, BarChart3, Globe } from "lucide-react";

export default function FeaturesPage() {
  return (
    <div className="container mx-auto px-6 py-32 min-h-[60vh]">
      <div className="text-center mb-24 max-w-3xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
          Intelligence applied to{" "}
          <span className="text-emerald-500 font-serif italic">
            sustainability.
          </span>
        </h1>
        <p className="text-xl text-muted-foreground font-light">
          Every pixel has been engineered to provide you with visceral,
          immediate insight into your carbon impact.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          {
            icon: Calculator,
            title: "Precision Engine",
            desc: "Powered by meticulously verified Indian emission databases.",
          },
          {
            icon: Globe,
            title: "Beautiful Scale",
            desc: "Visualize your planetary impact through cinematic interfaces.",
          },
          {
            icon: BarChart3,
            title: "Real-time Metrics",
            desc: "Sub-second updates to your carbon offset goals and tracking.",
          },
          {
            icon: Leaf,
            title: "Community Driven",
            desc: "Compare and compete with friends to reduce footprints locally.",
          },
        ].map((f, i) => (
          <div
            key={i}
            className="p-8 rounded-3xl bg-secondary/30 border border-border hover:bg-secondary/50 transition-all duration-300"
          >
            <div className="w-14 h-14 rounded-2xl bg-background border border-border flex items-center justify-center mb-6 shadow-sm">
              <f.icon className="w-6 h-6 text-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-3">{f.title}</h3>
            <p className="text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
