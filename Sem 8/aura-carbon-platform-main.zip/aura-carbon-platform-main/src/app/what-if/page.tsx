"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Lightbulb,
  Sparkles,
  RefreshCw,
  ArrowRight,
  Trees,
  ChevronRight,
  AlertCircle,
  Target,
} from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";

const PRESETS = [
  {
    emoji: "🚇",
    label: "Metro instead of car",
    query: "What if I take the metro instead of driving my car 15km every day?",
    category: "transport",
  },
  {
    emoji: "🏠",
    label: "Work from home 3 days",
    query: "What if I work from home 3 days a week instead of commuting?",
    category: "transport",
  },
  {
    emoji: "⚡",
    label: "Switch to EV",
    query:
      "What if I switch from my petrol car to an electric vehicle for 20km daily commute?",
    category: "transport",
  },
  {
    emoji: "🥗",
    label: "Meatless 3 days/week",
    query:
      "What if I eat vegetarian 3 days a week instead of my current mixed diet?",
    category: "food",
  },
  {
    emoji: "☀️",
    label: "Install solar panels",
    query: "What if I install a 3kW rooftop solar panel system in my home?",
    category: "energy",
  },
  {
    emoji: "💡",
    label: "Switch to LED bulbs",
    query:
      "What if I replace all 10 incandescent bulbs in my home with LED bulbs?",
    category: "energy",
  },
  {
    emoji: "🌿",
    label: "Start composting",
    query: "What if I start composting all my kitchen and garden waste?",
    category: "waste",
  },
  {
    emoji: "🚲",
    label: "Cycle for short trips",
    query:
      "What if I cycle for all trips under 5km instead of using a petrol bike?",
    category: "transport",
  },
];

interface MathResult {
  co2SavedMonthly: number;
  co2SavedAnnually: number;
  percentReduction: number;
  calculationBreakdown: string;
  confidence: "high" | "medium" | "low";
}

interface WhatIfResult {
  scenario: string;
  hasData: boolean;
  currentEmissions: number;
  math: MathResult | null;
  explanation: string;
  source: "llama" | "fallback";
}

const confidenceColor = {
  high: "text-emerald-400",
  medium: "text-amber-400",
  low: "text-slate-400",
};

function ResultCard({ result }: { result: WhatIfResult }) {
  const treesEquivalent = result.math
    ? Math.round(result.math.co2SavedAnnually / 20)
    : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-950/40 to-slate-900/60 p-5 space-y-4"
    >
      <div className="flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/15 border border-emerald-500/25">
          <Sparkles className="h-4 w-4 text-emerald-400" />
        </div>
        <div>
          <p className="text-xs text-slate-400 mb-0.5">
            Analyzing:{" "}
            <span className="text-emerald-300 font-medium">
              &quot;{result.scenario}&quot;
            </span>
          </p>
          {!result.hasData && (
            <p className="text-xs text-amber-400/80">
              ⚠ Using India average (150 kg/month) — calculate your footprint
              for personalized results
            </p>
          )}
        </div>
      </div>

      {result.math && (
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-xl bg-slate-800/60 border border-slate-700/50 p-3 text-center">
            <p className="text-xl font-black text-white">
              {result.math.co2SavedMonthly}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">kg CO₂/month</p>
            <p className="text-xs text-emerald-400 font-medium">saved</p>
          </div>
          <div className="rounded-xl bg-slate-800/60 border border-slate-700/50 p-3 text-center">
            <p className="text-xl font-black text-white">
              {result.math.percentReduction}%
            </p>
            <p className="text-xs text-slate-400 mt-0.5">of your footprint</p>
            <p className="text-xs text-emerald-400 font-medium">reduction</p>
          </div>
          <div className="rounded-xl bg-slate-800/60 border border-slate-700/50 p-3 text-center">
            <p className="text-xl font-black text-white">
              {result.math.co2SavedAnnually}
            </p>
            <p className="text-xs text-slate-400 mt-0.5">kg CO₂/year</p>
            <p className="text-xs text-emerald-400 font-medium">annually</p>
          </div>
        </div>
      )}

      {treesEquivalent > 0 && (
        <div className="flex items-center gap-2 rounded-xl bg-emerald-950/50 border border-emerald-800/30 px-3 py-2">
          <Trees className="h-4 w-4 text-emerald-500 shrink-0" />
          <p className="text-sm text-emerald-300">
            That&apos;s equivalent to planting{" "}
            <span className="font-bold text-emerald-400">
              {treesEquivalent} trees
            </span>{" "}
            per year 🌳
          </p>
        </div>
      )}

      {result.math && (
        <div className="rounded-xl bg-slate-900/60 border border-slate-800 px-3 py-2.5">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">
              How we calculated it
            </span>
            <span
              className={cn(
                "text-xs ml-auto",
                confidenceColor[result.math.confidence]
              )}
            >
              {result.math.confidence === "high"
                ? "✓ High"
                : result.math.confidence === "medium"
                  ? "≈ Estimated"
                  : "~ Approximate"}{" "}
              confidence
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono leading-relaxed">
            {result.math.calculationBreakdown}
          </p>
        </div>
      )}

      {result.explanation && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
            <span className="text-xs font-semibold text-emerald-400">
              {result.source === "llama"
                ? "Llama 3.3 70B Analysis"
                : "AI Analysis"}
            </span>
          </div>
          <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
            {result.explanation}
          </div>
        </div>
      )}

      {result.hasData && result.math && (
        <Link
          href={`/goals?name=${encodeURIComponent(result.scenario)}&reduction=${result.math.percentReduction}`}
          className="flex items-center justify-between rounded-xl border border-purple-500/25 bg-purple-950/30 px-4 py-3 text-sm text-purple-400 hover:border-purple-500/50 hover:bg-purple-900/30 transition-all group mt-2"
        >
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            <span className="font-medium">Set this as a reduction goal</span>
          </div>
          <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      )}

      {!result.hasData && (
        <Link
          href="/calculator"
          className="flex items-center justify-between rounded-xl border border-emerald-500/25 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-400 hover:border-emerald-500/50 transition-colors group"
        >
          <span>Get personalized results → Calculate your footprint</span>
          <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      )}
    </motion.div>
  );
}

export default function WhatIfPage() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WhatIfResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>("all");

  const analyze = async (scenario: string) => {
    if (!scenario.trim() || loading) return;
    setQuery(scenario);
    setLoading(true);
    setResult(null);
    setError(null);

    try {
      const res = await fetch("/api/ai/whatif", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ scenario }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Analysis failed");
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const categories = ["all", "transport", "food", "energy", "waste"];
  const filtered =
    activeCategory === "all"
      ? PRESETS
      : PRESETS.filter((p) => p.category === activeCategory);

  return (
    <div className="max-w-3xl mx-auto space-y-6 px-4 sm:px-0 pb-10">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Lightbulb className="h-6 w-6 text-amber-400" />
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            What-If Analyzer
          </h1>
        </div>
        <p className="text-slate-400 text-sm">
          Model any lifestyle change and see the exact CO₂ impact — powered by
          India-specific data + Llama AI
        </p>
      </div>

      <div className="rounded-2xl border border-slate-700 bg-slate-900/60 p-4 focus-within:border-emerald-500/50 transition-colors">
        <p className="text-xs text-slate-500 mb-2 font-medium">
          Describe your scenario:
        </p>
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !loading) {
              e.preventDefault();
              analyze(query);
            }
          }}
          placeholder="e.g. What if I take the metro instead of driving 20km every day?"
          rows={2}
          className="w-full bg-transparent text-sm text-white placeholder-slate-600 outline-none resize-none"
          disabled={loading}
        />
        <div className="flex items-center justify-between mt-3">
          <p className="text-xs text-slate-600">Press Enter or click Analyze</p>
          <button
            onClick={() => analyze(query)}
            disabled={!query.trim() || loading}
            className={cn(
              "flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-all",
              query.trim() && !loading
                ? "bg-emerald-500 text-white hover:bg-emerald-400 shadow-[0_0_16px_rgba(16,185,129,0.3)]"
                : "bg-slate-800 text-slate-500 cursor-not-allowed"
            )}
          >
            {loading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" /> Analyzing…
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" /> Analyze
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-xl border border-red-500/20 bg-red-950/20 px-4 py-3 text-sm text-red-400">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      {loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center gap-3 py-8"
        >
          <div className="flex gap-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
          <p className="text-sm text-slate-400">
            Calculating with India-specific emission data + AI…
          </p>
          <p className="text-xs text-slate-600">
            Analysis typically takes 10–30 seconds — complex scenarios may take
            longer
          </p>
        </motion.div>
      )}

      <AnimatePresence>
        {result && !loading && <ResultCard result={result} />}
      </AnimatePresence>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-300">
            Try a preset scenario
          </h2>
          <div className="flex gap-1.5 overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  "shrink-0 px-2.5 py-1 rounded-full text-xs capitalize transition-all border",
                  activeCategory === cat
                    ? "bg-emerald-500 text-white border-emerald-500"
                    : "border-slate-700 text-slate-500 hover:border-slate-500 hover:text-slate-300"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-2 sm:grid-cols-2">
          {filtered.map((preset) => (
            <button
              key={preset.query}
              onClick={() => analyze(preset.query)}
              disabled={loading}
              className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/40 px-4 py-3 text-left hover:border-emerald-500/30 hover:bg-emerald-950/20 transition-all disabled:opacity-50 group"
            >
              <span className="text-2xl">{preset.emoji}</span>
              <span className="text-sm text-slate-300 group-hover:text-white transition-colors">
                {preset.label}
              </span>
              <ChevronRight className="h-4 w-4 text-slate-600 group-hover:text-emerald-400 ml-auto transition-colors" />
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900/30 px-4 py-3 text-xs text-slate-500 space-y-1">
        <p className="font-semibold text-slate-400">How it works</p>
        <p>
          • Emission calculations use verified India-specific factors (IPCC +
          MoEFCC data)
        </p>
        <p>• AI explanation powered by Llama 3.3 70B via OpenRouter</p>
        <p>
          • Results are more accurate when you&apos;ve calculated your carbon
          footprint
        </p>
      </div>
    </div>
  );
}
