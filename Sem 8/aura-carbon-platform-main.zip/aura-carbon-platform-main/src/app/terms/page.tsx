"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  FileText,
  Scale,
  AlertCircle,
  Shield,
  Users,
  Gavel,
} from "lucide-react";

export default function TermsPage() {
  return (
    <div className="container mx-auto py-8 px-4 max-w-4xl">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <FileText className="h-8 w-8 text-green-600" />
          <h1 className="text-3xl font-bold">Terms of Service</h1>
        </div>
        <p className="text-muted-foreground">Last updated: January 1, 2025</p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Agreement to Terms</CardTitle>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none">
            <p>
              By accessing and using Aura&apos;s carbon footprint tracking
              platform (&quot;Service&quot;), you agree to be bound by these
              Terms of Service (&quot;Terms&quot;). If you disagree with any
              part of these terms, you may not access the Service.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <CardTitle>Use of Service</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Permitted Use</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>
                  Calculate and track your personal or organizational carbon
                  footprint
                </li>
                <li>Set and monitor carbon reduction goals</li>
                <li>
                  Access educational content and sustainability recommendations
                </li>
                <li>Export your data for personal or business use</li>
                <li>
                  Share anonymized data for climate research (with your consent)
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Prohibited Use</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Violate any applicable laws or regulations</li>
                <li>Transmit malicious code or attempt to breach security</li>
                <li>Reverse engineer or attempt to extract source code</li>
                <li>
                  Use the service for commercial purposes without authorization
                </li>
                <li>Share false or misleading information</li>
                <li>Interfere with other users&apos; access to the service</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5" />
              <CardTitle>User Accounts</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Account Responsibility</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>
                  You are responsible for maintaining the confidentiality of
                  your account
                </li>
                <li>You must provide accurate and complete information</li>
                <li>
                  You must promptly update any changes to your information
                </li>
                <li>
                  You are responsible for all activities under your account
                </li>
                <li>
                  You must notify us immediately of any unauthorized access
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Account Termination</h4>
              <p className="text-sm text-muted-foreground">
                We may terminate or suspend your account at any time for
                violations of these Terms. You may delete your account at any
                time through the settings page.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Scale className="h-5 w-5" />
              <CardTitle>Data Accuracy & Calculations</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Emission Factor Sources</h4>
              <p className="text-sm text-muted-foreground mb-2">
                Our calculations use emission factors from authoritative sources
                including:
              </p>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>
                  Central Electricity Authority (CEA) for India grid emissions
                </li>
                <li>
                  World Resources Institute (WRI) for transportation factors
                </li>
                <li>GHG Protocol guidelines for methodology</li>
                <li>
                  Peer-reviewed lifecycle assessment studies for food items
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Accuracy Disclaimer</h4>
              <p className="text-sm text-muted-foreground">
                While we strive for accuracy, carbon footprint calculations are
                estimates based on available data and methodologies. Results may
                vary based on data quality, regional factors, and calculation
                methods. We provide source attribution for transparency but
                cannot guarantee 100% accuracy.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">User Data Responsibility</h4>
              <p className="text-sm text-muted-foreground">
                The accuracy of your carbon footprint depends on the accuracy of
                the data you provide. You are responsible for entering correct
                information about your activities and consumption.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Gavel className="h-5 w-5" />
              <CardTitle>Intellectual Property</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Our Rights</h4>
              <p className="text-sm text-muted-foreground">
                The Service, including its design, algorithms, content, and
                features, is owned by Aura and protected by copyright,
                trademark, and other intellectual property laws.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Your Rights</h4>
              <p className="text-sm text-muted-foreground">
                You retain ownership of the data you input into the Service. You
                grant us a license to use this data to provide the Service and
                improve our algorithms (in accordance with our Privacy Policy).
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Open Source Components</h4>
              <p className="text-sm text-muted-foreground">
                Some components of our Service use open source software. These
                components are governed by their respective licenses, which are
                available upon request.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Subscription & Billing</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Free Tier</h4>
              <p className="text-sm text-muted-foreground">
                Basic carbon footprint calculation and tracking features are
                available free of charge.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Premium Features</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Advanced analytics and detailed reporting</li>
                <li>AI-powered predictions and recommendations</li>
                <li>API access for integrations</li>
                <li>Priority customer support</li>
                <li>Enterprise features for organizations</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Billing Terms</h4>
              <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
                <li>Subscriptions are billed monthly or annually in advance</li>
                <li>Prices are subject to change with 30 days notice</li>
                <li>Refunds are available within 14 days of purchase</li>
                <li>You can cancel your subscription at any time</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5" />
              <CardTitle>Disclaimers & Limitations</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Service Availability</h4>
              <p className="text-sm text-muted-foreground">
                We strive for 99.9% uptime but cannot guarantee uninterrupted
                service. We may perform maintenance that temporarily affects
                availability.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Limitation of Liability</h4>
              <p className="text-sm text-muted-foreground">
                To the maximum extent permitted by law, Aura shall not be liable
                for any indirect, incidental, special, or consequential damages
                arising from your use of the Service.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Indemnification</h4>
              <p className="text-sm text-muted-foreground">
                You agree to indemnify and hold Aura harmless from any claims
                arising from your use of the Service or violation of these
                Terms.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Governing Law & Disputes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Jurisdiction</h4>
              <p className="text-sm text-muted-foreground">
                These Terms are governed by the laws of India. Any disputes will
                be resolved in the courts of Bangalore, Karnataka.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Dispute Resolution</h4>
              <p className="text-sm text-muted-foreground">
                We encourage resolving disputes through direct communication.
                For formal disputes, we prefer arbitration under the Arbitration
                and Conciliation Act, 2015.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Changes to Terms</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              We may update these Terms periodically. We will notify users of
              significant changes via email or platform notifications. Continued
              use of the Service after changes constitutes acceptance of the new
              Terms.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              If you have questions about these Terms of Service, please contact
              us:
            </p>
            <div className="space-y-2 text-sm">
              <p>
                <strong>Email:</strong>{" "}
                <a
                  href="mailto:legal@aura.com"
                  className="text-blue-600 hover:underline"
                >
                  legal@aura.com
                </a>
              </p>
              <p>
                <strong>Address:</strong> Aura Legal Team, Koramangala,
                Bangalore, Karnataka 560034, India
              </p>
              <p>
                <strong>Support:</strong>{" "}
                <a
                  href="mailto:support@aura.com"
                  className="text-blue-600 hover:underline"
                >
                  support@aura.com
                </a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
