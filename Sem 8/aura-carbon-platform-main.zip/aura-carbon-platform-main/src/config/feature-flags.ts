export const featureFlags = {
  enable3D: true,
  enableParticles: true,
  enableGlobe: true,
  enableAnimations: true,
  enableGlassmorphism: true,
};

export type FeatureFlag = keyof typeof featureFlags;

export function isFeatureEnabled(flag: FeatureFlag): boolean {
  if (typeof window === "undefined") return false;

  const storedPrefs = localStorage.getItem("aura_feature_flags");
  if (storedPrefs) {
    try {
      const prefs = JSON.parse(storedPrefs);
      if (typeof prefs[flag] === "boolean") {
        return prefs[flag];
      }
    } catch {}
  }

  return featureFlags[flag] ?? false;
}

export function setFeatureFlag(flag: FeatureFlag, enabled: boolean): void {
  if (typeof window === "undefined") return;

  const storedPrefs = localStorage.getItem("aura_feature_flags");
  let prefs: Record<string, boolean> = {};

  if (storedPrefs) {
    try {
      prefs = JSON.parse(storedPrefs);
    } catch {
      prefs = {};
    }
  }

  prefs[flag] = enabled;
  localStorage.setItem("aura_feature_flags", JSON.stringify(prefs));
}

export function getAllFeatureFlags(): Record<string, boolean> {
  return { ...featureFlags };
}
