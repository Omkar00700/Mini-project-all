export const XP_REWARDS = {
  LOG_ACTIVITY: 10,
  ACTIVITY_LOGGED: 10,
  COMPLETE_GOAL: 50,
  GOAL_CREATED: 50,
  DAILY_STREAK: 5,
  CARBON_CALCULATION: 25,
  STREAK_MAINTAINED: 10,
  ACHIEVEMENT_PLATINUM: 500,
  ACHIEVEMENT_GOLD: 250,
  ACHIEVEMENT_SILVER: 100,
  ACHIEVEMENT_BRONZE: 50,
};

export const LEVEL_CONFIG = [
  { level: 1, minXp: 0, title: "Seedling", icon: "🌱" },
  { level: 2, minXp: 100, title: "Sapling", icon: "🌿" },
  { level: 3, minXp: 300, title: "Sprout", icon: "☘️" },
  { level: 4, minXp: 750, title: "Forest Guardian", icon: "🌲" },
  { level: 5, minXp: 1500, title: "Nature Protector", icon: "🛡️" },
  { level: 6, minXp: 3000, title: "Carbon Warrior", icon: "⚔️" },
  { level: 7, minXp: 6000, title: "Climate Champion", icon: "🏆" },
];

export const calculateLevel = (totalXp: number) => {
  for (let i = LEVEL_CONFIG.length - 1; i >= 0; i--) {
    if (totalXp >= LEVEL_CONFIG[i].minXp) {
      return LEVEL_CONFIG[i];
    }
  }
  return LEVEL_CONFIG[0];
};

export const getLevelProgress = (totalXp: number) => {
  const current = calculateLevel(totalXp);
  const nextIndex = current.level;
  const next = LEVEL_CONFIG[nextIndex] || null;

  if (!next) {
    return {
      percent: 100,
      xpInCurrent: totalXp - current.minXp,
      xpNeededForNext: 0,
      isMaxLevel: true,
    };
  }

  const xpInCurrent = totalXp - current.minXp;
  const xpNeededInThisLevel = next.minXp - current.minXp;
  const percent = Math.min(100, (xpInCurrent / xpNeededInThisLevel) * 100);

  return {
    percent,
    xpInCurrent,
    xpNeededInThisLevel,
    xpNeededTotal: next.minXp - totalXp,
    isMaxLevel: false,
  };
};
