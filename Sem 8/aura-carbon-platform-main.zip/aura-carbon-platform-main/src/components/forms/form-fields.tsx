"use client";

import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, Plus, Minus, AlertCircle, Info, X } from "lucide-react";
import { format } from "date-fns";

interface BaseFieldProps {
  name: string;
  label: string;
  description?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  error?: string;
}

interface TextFieldProps extends BaseFieldProps {
  type?: "text" | "email" | "password" | "url" | "tel";
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
}

export function TextField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  type = "text",
  placeholder,
  value,
  onChange,
}: TextFieldProps) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={name} className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      <Input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        disabled={disabled}
        className={cn(error && "border-red-500")}
      />
      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}

interface NumberFieldProps extends BaseFieldProps {
  value?: number;
  onChange?: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  showSlider?: boolean;
}

export function NumberField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  value,
  onChange,
  min,
  max,
  step = 1,
  unit,
  showSlider = false,
}: NumberFieldProps) {
  const [inputValue, setInputValue] = useState(value?.toString() || "");

  useEffect(() => {
    setInputValue(value?.toString() || "");
  }, [value]);

  const handleInputChange = (newValue: string) => {
    setInputValue(newValue);
    const numValue = parseFloat(newValue);
    if (!isNaN(numValue)) {
      onChange?.(numValue);
    }
  };

  const handleSliderChange = (values: number[]) => {
    const newValue = values[0];
    setInputValue(newValue.toString());
    onChange?.(newValue);
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={name} className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
        {unit && (
          <Badge variant="outline" className="text-xs">
            {unit}
          </Badge>
        )}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Input
            id={name}
            name={name}
            type="number"
            value={inputValue}
            onChange={(e) => handleInputChange(e.target.value)}
            disabled={disabled}
            min={min}
            max={max}
            step={step}
            className={cn("flex-1", error && "border-red-500")}
          />
          {unit && (
            <span className="text-sm text-muted-foreground">{unit}</span>
          )}
        </div>

        {showSlider && min !== undefined && max !== undefined && (
          <Slider
            value={[value || min]}
            onValueChange={handleSliderChange}
            min={min}
            max={max}
            step={step}
            disabled={disabled}
            className="w-full"
          />
        )}
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}

interface SelectFieldProps extends BaseFieldProps {
  options: { value: string; label: string; description?: string }[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
}

export function SelectField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  options,
  value,
  onChange,
  placeholder = "Select an option...",
}: SelectFieldProps) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={name} className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}
      <Select value={value} onValueChange={onChange} disabled={disabled}>
        <SelectTrigger className={cn(error && "border-red-500")}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              <div>
                <div>{option.label}</div>
                {option.description && (
                  <div className="text-xs text-muted-foreground">
                    {option.description}
                  </div>
                )}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}

interface MultiSelectFieldProps extends BaseFieldProps {
  options: { value: string; label: string }[];
  value?: string[];
  onChange?: (value: string[]) => void;
  max?: number;
}

export function MultiSelectField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  options,
  value = [],
  onChange,
  max,
}: MultiSelectFieldProps) {
  const handleToggle = (optionValue: string) => {
    if (disabled) return;

    const newValue = value.includes(optionValue)
      ? value.filter((v) => v !== optionValue)
      : max && value.length >= max
        ? value
        : [...value, optionValue];

    onChange?.(newValue);
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
        {max && (
          <Badge variant="outline" className="text-xs">
            {value.length}/{max}
          </Badge>
        )}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}

      <div className="space-y-2">
        {options.map((option) => (
          <div key={option.value} className="flex items-center space-x-2">
            <Checkbox
              id={`${name}-${option.value}`}
              checked={value.includes(option.value)}
              onCheckedChange={() => handleToggle(option.value)}
              disabled={
                disabled ||
                Boolean(
                  max && value.length >= max && !value.includes(option.value)
                )
              }
            />
            <Label
              htmlFor={`${name}-${option.value}`}
              className="text-sm font-normal cursor-pointer"
            >
              {option.label}
            </Label>
          </div>
        ))}
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}

interface DateFieldProps extends BaseFieldProps {
  value?: Date;
  onChange?: (value: Date | undefined) => void;
  placeholder?: string;
}

export function DateField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  value,
  onChange,
  placeholder = "Pick a date",
}: DateFieldProps) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}

      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal",
              !value && "text-muted-foreground",
              error && "border-red-500"
            )}
            disabled={disabled}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {value ? format(value, "PPP") : placeholder}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0">
          <Calendar
            mode="single"
            selected={value}
            onSelect={onChange}
            initialFocus
          />
        </PopoverContent>
      </Popover>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}

interface DynamicListFieldProps extends BaseFieldProps {
  value?: string[];
  onChange?: (value: string[]) => void;
  placeholder?: string;
  addButtonText?: string;
  max?: number;
}

export function DynamicListField({
  name,
  label,
  description,
  required,
  disabled,
  className,
  error,
  value = [],
  onChange,
  placeholder = "Enter item...",
  addButtonText = "Add Item",
  max,
}: DynamicListFieldProps) {
  const [inputValue, setInputValue] = useState("");

  const addItem = () => {
    if (inputValue.trim() && (!max || value.length < max)) {
      onChange?.([...value, inputValue.trim()]);
      setInputValue("");
    }
  };

  const removeItem = (index: number) => {
    onChange?.(value.filter((_, i) => i !== index));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addItem();
    }
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label className="flex items-center gap-2">
        {label}
        {required && <span className="text-red-500">*</span>}
        {max && (
          <Badge variant="outline" className="text-xs">
            {value.length}/{max}
          </Badge>
        )}
      </Label>
      {description && (
        <p className="text-sm text-muted-foreground">{description}</p>
      )}

      <div className="space-y-2">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={placeholder}
            disabled={disabled || Boolean(max && value.length >= max)}
            className="flex-1"
          />
          <Button
            type="button"
            onClick={addItem}
            disabled={
              !inputValue.trim() ||
              disabled ||
              Boolean(max && value.length >= max)
            }
            size="sm"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {value.length > 0 && (
          <div className="space-y-1">
            {value.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-2 bg-muted rounded-md"
              >
                <span className="text-sm">{item}</span>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeItem(index)}
                  disabled={disabled}
                  className="h-6 w-6 p-0"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-500">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}
