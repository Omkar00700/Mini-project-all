"use client";

import { FormWizard, WizardStep } from "../form-wizard";
import {
  TransportationStep,
  transportationSchema,
} from "./transportation-step";
import { EnergyStep, energySchema } from "./energy-step";
import {
  Car,
  Zap,
  UtensilsCrossed,
  ShoppingBag,
  Trash2,
  User,
} from "lucide-react";
import { z } from "zod";
import { useCarbonStore } from "@/store";

function BasicInfoStep({ data, updateData }: any) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Let&apos;s get started!</h3>
        <p className="text-muted-foreground">
          We&apos;ll help you calculate your carbon footprint across different
          categories. This should take about 10-15 minutes to complete.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-2">What we&apos;ll cover:</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Car className="w-4 h-4" />
              Transportation
            </li>
            <li className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Energy Usage
            </li>
            <li className="flex items-center gap-2">
              <UtensilsCrossed className="w-4 h-4" />
              Food & Diet
            </li>
            <li className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              Consumption
            </li>
            <li className="flex items-center gap-2">
              <Trash2 className="w-4 h-4" />
              Waste
            </li>
          </ul>
        </div>

        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-2">Tips for accuracy:</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>• Have your utility bills handy</li>
            <li>• Think about your typical week/month</li>
            <li>• Don&apos;t worry about being perfect</li>
            <li>• You can always update later</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

function FoodStep({ data, updateData }: any) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Food & Diet</h3>
        <p className="text-muted-foreground">
          This step will be implemented in the next phase.
        </p>
      </div>
    </div>
  );
}

function ConsumptionStep({ data, updateData }: any) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Consumption & Shopping</h3>
        <p className="text-muted-foreground">
          This step will be implemented in the next phase.
        </p>
      </div>
    </div>
  );
}

function WasteStep({ data, updateData }: any) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Waste & Recycling</h3>
        <p className="text-muted-foreground">
          This step will be implemented in the next phase.
        </p>
      </div>
    </div>
  );
}

const carbonFootprintSchema = z.object({
  transportation: transportationSchema.optional(),
  energy: energySchema.optional(),
});

interface CarbonFootprintWizardProps {
  initialData?: any;
  onComplete?: (data: any) => void;
  onSave?: (data: any) => void;
}

export function CarbonFootprintWizard({
  initialData,
  onComplete,
  onSave,
}: CarbonFootprintWizardProps) {
  const { addPendingActivity, setCalculating } = useCarbonStore();

  const steps: WizardStep[] = [
    {
      id: "basic-info",
      title: "Getting Started",
      description: "Introduction to the carbon footprint calculator",
      icon: User,
      component: BasicInfoStep,
      optional: false,
    },
    {
      id: "transportation",
      title: "Transportation",
      description: "Vehicles, public transport, flights, and commuting",
      icon: Car,
      component: TransportationStep,
      validation: async (data) => {
        try {
          if (data.transportation) {
            transportationSchema.parse(data.transportation);
          }
          return true;
        } catch {
          return false;
        }
      },
      optional: false,
    },
    {
      id: "energy",
      title: "Energy Usage",
      description: "Electricity, heating, cooling, and renewable energy",
      icon: Zap,
      component: EnergyStep,
      validation: async (data) => {
        try {
          if (data.energy) {
            energySchema.parse(data.energy);
          }
          return true;
        } catch {
          return false;
        }
      },
      optional: false,
    },
    {
      id: "food",
      title: "Food & Diet",
      description: "Dietary preferences and food consumption",
      icon: UtensilsCrossed,
      component: FoodStep,
      optional: true,
    },
    {
      id: "consumption",
      title: "Consumption",
      description: "Shopping, purchases, and lifestyle consumption",
      icon: ShoppingBag,
      component: ConsumptionStep,
      optional: true,
    },
    {
      id: "waste",
      title: "Waste & Recycling",
      description: "Waste generation and recycling habits",
      icon: Trash2,
      component: WasteStep,
      optional: true,
    },
  ];

  const handleComplete = async (data: any) => {
    try {
      setCalculating(true);

      carbonFootprintSchema.parse(data);

      onComplete?.(data);
    } catch (error) {
      throw error;
    } finally {
      setCalculating(false);
    }
  };

  const handleSave = async (data: any) => {
    try {
      onSave?.(data);
    } catch (error) {
      throw error;
    }
  };

  return (
    <FormWizard
      steps={steps}
      initialData={initialData}
      onComplete={handleComplete}
      onSave={handleSave}
      autoSave={true}
      autoSaveInterval={30000}
      title="Carbon Footprint Calculator"
      description="Calculate your environmental impact across all major categories"
      className="max-w-6xl"
    />
  );
}
