"use client";

import { z } from "zod";
import { WizardStepProps } from "../form-wizard";
import {
  TextField,
  NumberField,
  SelectField,
  MultiSelectField,
} from "../form-fields";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Car, Plane, Train, Bus, Bike, MapPin } from "lucide-react";

export const transportationSchema = z.object({
  personalVehicles: z
    .array(
      z.object({
        type: z.string().min(1, "Vehicle type is required"),
        fuelType: z.string().min(1, "Fuel type is required"),
        efficiency: z.number().min(0.1, "Efficiency must be greater than 0"),
        annualMileage: z.number().min(0, "Mileage cannot be negative"),
      })
    )
    .optional(),
  publicTransport: z
    .object({
      bus: z.number().min(0).optional(),
      train: z.number().min(0).optional(),
      subway: z.number().min(0).optional(),
      tram: z.number().min(0).optional(),
    })
    .optional(),
  flights: z
    .array(
      z.object({
        type: z.enum(["domestic", "international"]),
        distance: z.number().min(0),
        frequency: z.number().min(0),
      })
    )
    .optional(),
  ridesharing: z
    .object({
      weeklyTrips: z.number().min(0).optional(),
      averageDistance: z.number().min(0).optional(),
    })
    .optional(),
  cycling: z
    .object({
      weeklyDistance: z.number().min(0).optional(),
    })
    .optional(),
  walking: z
    .object({
      weeklyDistance: z.number().min(0).optional(),
    })
    .optional(),
});

const vehicleTypes = [
  { value: "sedan", label: "Sedan" },
  { value: "suv", label: "SUV" },
  { value: "truck", label: "Truck" },
  { value: "hatchback", label: "Hatchback" },
  { value: "coupe", label: "Coupe" },
  { value: "wagon", label: "Wagon" },
  { value: "van", label: "Van" },
  { value: "motorcycle", label: "Motorcycle" },
];

const fuelTypes = [
  { value: "gasoline", label: "Gasoline" },
  { value: "diesel", label: "Diesel" },
  { value: "hybrid", label: "Hybrid" },
  { value: "electric", label: "Electric" },
  { value: "plugin-hybrid", label: "Plug-in Hybrid" },
  { value: "hydrogen", label: "Hydrogen" },
  { value: "cng", label: "Compressed Natural Gas" },
];

export function TransportationStep({
  data,
  updateData,
  errors,
}: WizardStepProps) {
  const transportationData = data.transportation || {};

  const updateTransportationData = (updates: any) => {
    updateData({
      transportation: {
        ...transportationData,
        ...updates,
      },
    });
  };

  const addVehicle = () => {
    const vehicles = transportationData.personalVehicles || [];
    updateTransportationData({
      personalVehicles: [
        ...vehicles,
        {
          type: "",
          fuelType: "",
          efficiency: 0,
          annualMileage: 0,
        },
      ],
    });
  };

  const updateVehicle = (index: number, updates: any) => {
    const vehicles = [...(transportationData.personalVehicles || [])];
    vehicles[index] = { ...vehicles[index], ...updates };
    updateTransportationData({ personalVehicles: vehicles });
  };

  const removeVehicle = (index: number) => {
    const vehicles = transportationData.personalVehicles || [];
    updateTransportationData({
      personalVehicles: vehicles.filter(
        (_v: unknown, i: number) => i !== index
      ),
    });
  };

  const addFlight = () => {
    const flights = transportationData.flights || [];
    updateTransportationData({
      flights: [
        ...flights,
        {
          type: "domestic",
          distance: 0,
          frequency: 0,
        },
      ],
    });
  };

  const updateFlight = (index: number, updates: any) => {
    const flights = [...(transportationData.flights || [])];
    flights[index] = { ...flights[index], ...updates };
    updateTransportationData({ flights });
  };

  const removeFlight = (index: number) => {
    const flights = transportationData.flights || [];
    updateTransportationData({
      flights: flights.filter((_f: unknown, i: number) => i !== index),
    });
  };

  return (
    <div className="space-y-6">
      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="w-5 h-5" />
            Personal Vehicles
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {(transportationData.personalVehicles || []).map(
            (vehicle: any, index: number) => (
              <div key={index} className="p-4 border rounded-lg space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Vehicle {index + 1}</h4>
                  <button
                    onClick={() => removeVehicle(index)}
                    className="text-red-500 hover:text-red-700 text-sm"
                  >
                    Remove
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <SelectField
                    name={`vehicle-type-${index}`}
                    label="Vehicle Type"
                    options={vehicleTypes}
                    value={vehicle.type}
                    onChange={(value) => updateVehicle(index, { type: value })}
                    required
                  />

                  <SelectField
                    name={`fuel-type-${index}`}
                    label="Fuel Type"
                    options={fuelTypes}
                    value={vehicle.fuelType}
                    onChange={(value) =>
                      updateVehicle(index, { fuelType: value })
                    }
                    required
                  />

                  <NumberField
                    name={`efficiency-${index}`}
                    label="Fuel Efficiency"
                    unit="MPG"
                    value={vehicle.efficiency}
                    onChange={(value) =>
                      updateVehicle(index, { efficiency: value })
                    }
                    min={0.1}
                    step={0.1}
                    required
                  />

                  <NumberField
                    name={`mileage-${index}`}
                    label="Annual Mileage"
                    unit="miles"
                    value={vehicle.annualMileage}
                    onChange={(value) =>
                      updateVehicle(index, { annualMileage: value })
                    }
                    min={0}
                    required
                  />
                </div>
              </div>
            )
          )}

          <button
            onClick={addVehicle}
            className="w-full p-4 border-2 border-dashed border-muted-foreground/25 rounded-lg hover:border-muted-foreground/50 transition-colors"
          >
            + Add Vehicle
          </button>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bus className="w-5 h-5" />
            Public Transportation
            <Badge variant="secondary">Weekly Usage</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <NumberField
              name="bus-usage"
              label="Bus"
              unit="hours/week"
              value={transportationData.publicTransport?.bus || 0}
              onChange={(value) =>
                updateTransportationData({
                  publicTransport: {
                    ...transportationData.publicTransport,
                    bus: value,
                  },
                })
              }
              min={0}
              step={0.5}
            />

            <NumberField
              name="train-usage"
              label="Train"
              unit="hours/week"
              value={transportationData.publicTransport?.train || 0}
              onChange={(value) =>
                updateTransportationData({
                  publicTransport: {
                    ...transportationData.publicTransport,
                    train: value,
                  },
                })
              }
              min={0}
              step={0.5}
            />

            <NumberField
              name="subway-usage"
              label="Subway/Metro"
              unit="hours/week"
              value={transportationData.publicTransport?.subway || 0}
              onChange={(value) =>
                updateTransportationData({
                  publicTransport: {
                    ...transportationData.publicTransport,
                    subway: value,
                  },
                })
              }
              min={0}
              step={0.5}
            />

            <NumberField
              name="tram-usage"
              label="Tram/Light Rail"
              unit="hours/week"
              value={transportationData.publicTransport?.tram || 0}
              onChange={(value) =>
                updateTransportationData({
                  publicTransport: {
                    ...transportationData.publicTransport,
                    tram: value,
                  },
                })
              }
              min={0}
              step={0.5}
            />
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plane className="w-5 h-5" />
            Air Travel
            <Badge variant="secondary">Annual</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {(transportationData.flights || []).map(
            (flight: any, index: number) => (
              <div key={index} className="p-4 border rounded-lg space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Flight Route {index + 1}</h4>
                  <button
                    onClick={() => removeFlight(index)}
                    className="text-red-500 hover:text-red-700 text-sm"
                  >
                    Remove
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <SelectField
                    name={`flight-type-${index}`}
                    label="Flight Type"
                    options={[
                      { value: "domestic", label: "Domestic" },
                      { value: "international", label: "International" },
                    ]}
                    value={flight.type}
                    onChange={(value) => updateFlight(index, { type: value })}
                    required
                  />

                  <NumberField
                    name={`flight-distance-${index}`}
                    label="Distance"
                    unit="miles"
                    value={flight.distance}
                    onChange={(value) =>
                      updateFlight(index, { distance: value })
                    }
                    min={0}
                    required
                  />

                  <NumberField
                    name={`flight-frequency-${index}`}
                    label="Trips per Year"
                    value={flight.frequency}
                    onChange={(value) =>
                      updateFlight(index, { frequency: value })
                    }
                    min={0}
                    required
                  />
                </div>
              </div>
            )
          )}

          <button
            onClick={addFlight}
            className="w-full p-4 border-2 border-dashed border-muted-foreground/25 rounded-lg hover:border-muted-foreground/50 transition-colors"
          >
            + Add Flight Route
          </button>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bike className="w-5 h-5" />
            Other Transportation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium">Ridesharing</h4>
              <NumberField
                name="rideshare-trips"
                label="Weekly Trips"
                value={transportationData.ridesharing?.weeklyTrips || 0}
                onChange={(value) =>
                  updateTransportationData({
                    ridesharing: {
                      ...transportationData.ridesharing,
                      weeklyTrips: value,
                    },
                  })
                }
                min={0}
              />
              <NumberField
                name="rideshare-distance"
                label="Average Trip Distance"
                unit="miles"
                value={transportationData.ridesharing?.averageDistance || 0}
                onChange={(value) =>
                  updateTransportationData({
                    ridesharing: {
                      ...transportationData.ridesharing,
                      averageDistance: value,
                    },
                  })
                }
                min={0}
              />
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Active Transportation</h4>
              <NumberField
                name="cycling-distance"
                label="Weekly Cycling"
                unit="miles"
                value={transportationData.cycling?.weeklyDistance || 0}
                onChange={(value) =>
                  updateTransportationData({
                    cycling: { weeklyDistance: value },
                  })
                }
                min={0}
              />
              <NumberField
                name="walking-distance"
                label="Weekly Walking"
                unit="miles"
                value={transportationData.walking?.weeklyDistance || 0}
                onChange={(value) =>
                  updateTransportationData({
                    walking: { weeklyDistance: value },
                  })
                }
                min={0}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
