"use client";

import { z } from "zod";
import { WizardStepProps } from "../form-wizard";
import { NumberField, SelectField, MultiSelectField } from "../form-fields";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Zap, Home, Sun, Wind, Droplets, Flame } from "lucide-react";

export const energySchema = z.object({
  electricity: z.object({
    monthlyUsage: z.number().min(0, "Usage cannot be negative"),
    provider: z.string().optional(),
    renewablePercentage: z.number().min(0).max(100).optional(),
    hasSmartMeter: z.boolean().optional(),
  }),
  heating: z.object({
    type: z.enum([
      "gas",
      "oil",
      "electric",
      "heat-pump",
      "wood",
      "solar",
      "geothermal",
    ]),
    monthlyUsage: z.number().min(0),
    efficiency: z.number().min(0).max(100).optional(),
  }),
  cooling: z
    .object({
      type: z.enum([
        "central-ac",
        "window-ac",
        "heat-pump",
        "evaporative",
        "none",
      ]),
      monthlyUsage: z.number().min(0).optional(),
      efficiency: z.number().min(0).max(100).optional(),
    })
    .optional(),
  waterHeating: z
    .object({
      type: z.enum([
        "gas",
        "electric",
        "solar",
        "heat-pump",
        "tankless-gas",
        "tankless-electric",
      ]),
      monthlyUsage: z.number().min(0).optional(),
    })
    .optional(),
  renewableEnergy: z
    .object({
      hasSolar: z.boolean().optional(),
      solarCapacity: z.number().min(0).optional(),
      hasWind: z.boolean().optional(),
      windCapacity: z.number().min(0).optional(),
      hasGeothermal: z.boolean().optional(),
      batteryStorage: z.number().min(0).optional(),
    })
    .optional(),
});

const heatingTypes = [
  { value: "gas", label: "Natural Gas" },
  { value: "oil", label: "Heating Oil" },
  { value: "electric", label: "Electric" },
  { value: "heat-pump", label: "Heat Pump" },
  { value: "wood", label: "Wood/Biomass" },
  { value: "solar", label: "Solar Heating" },
  { value: "geothermal", label: "Geothermal" },
];

const coolingTypes = [
  { value: "central-ac", label: "Central Air Conditioning" },
  { value: "window-ac", label: "Window/Wall Units" },
  { value: "heat-pump", label: "Heat Pump" },
  { value: "evaporative", label: "Evaporative Cooler" },
  { value: "none", label: "No Cooling System" },
];

const waterHeatingTypes = [
  { value: "gas", label: "Gas Water Heater" },
  { value: "electric", label: "Electric Water Heater" },
  { value: "solar", label: "Solar Water Heater" },
  { value: "heat-pump", label: "Heat Pump Water Heater" },
  { value: "tankless-gas", label: "Tankless Gas" },
  { value: "tankless-electric", label: "Tankless Electric" },
];

export function EnergyStep({ data, updateData, errors }: WizardStepProps) {
  const energyData = data.energy || {};

  const updateEnergyData = (updates: any) => {
    updateData({
      energy: {
        ...energyData,
        ...updates,
      },
    });
  };

  const updateElectricity = (updates: any) => {
    updateEnergyData({
      electricity: {
        ...energyData.electricity,
        ...updates,
      },
    });
  };

  const updateHeating = (updates: any) => {
    updateEnergyData({
      heating: {
        ...energyData.heating,
        ...updates,
      },
    });
  };

  const updateCooling = (updates: any) => {
    updateEnergyData({
      cooling: {
        ...energyData.cooling,
        ...updates,
      },
    });
  };

  const updateWaterHeating = (updates: any) => {
    updateEnergyData({
      waterHeating: {
        ...energyData.waterHeating,
        ...updates,
      },
    });
  };

  const updateRenewable = (updates: any) => {
    updateEnergyData({
      renewableEnergy: {
        ...energyData.renewableEnergy,
        ...updates,
      },
    });
  };

  return (
    <div className="space-y-6">
      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Electricity Usage
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <NumberField
              name="electricity-usage"
              label="Monthly Usage"
              unit="kWh"
              value={energyData.electricity?.monthlyUsage || 0}
              onChange={(value) => updateElectricity({ monthlyUsage: value })}
              min={0}
              required
              description="Check your electricity bill for kWh usage"
            />

            <NumberField
              name="renewable-percentage"
              label="Renewable Energy %"
              unit="%"
              value={energyData.electricity?.renewablePercentage || 0}
              onChange={(value) =>
                updateElectricity({ renewablePercentage: value })
              }
              min={0}
              max={100}
              showSlider
              description="Percentage of renewable energy from your utility"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="smart-meter"
              checked={energyData.electricity?.hasSmartMeter || false}
              onCheckedChange={(checked) =>
                updateElectricity({ hasSmartMeter: checked })
              }
            />
            <Label htmlFor="smart-meter">I have a smart meter</Label>
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Flame className="w-5 h-5" />
            Heating System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <SelectField
              name="heating-type"
              label="Heating Type"
              options={heatingTypes}
              value={energyData.heating?.type || ""}
              onChange={(value) => updateHeating({ type: value })}
              required
            />

            <NumberField
              name="heating-usage"
              label="Monthly Usage"
              unit={energyData.heating?.type === "gas" ? "therms" : "kWh"}
              value={energyData.heating?.monthlyUsage || 0}
              onChange={(value) => updateHeating({ monthlyUsage: value })}
              min={0}
              required
            />

            <NumberField
              name="heating-efficiency"
              label="System Efficiency"
              unit="%"
              value={energyData.heating?.efficiency || 80}
              onChange={(value) => updateHeating({ efficiency: value })}
              min={0}
              max={100}
              showSlider
              description="Estimated efficiency of your heating system"
            />
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Home className="w-5 h-5" />
            Cooling System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <SelectField
              name="cooling-type"
              label="Cooling Type"
              options={coolingTypes}
              value={energyData.cooling?.type || "none"}
              onChange={(value) => updateCooling({ type: value })}
            />

            {energyData.cooling?.type && energyData.cooling.type !== "none" && (
              <>
                <NumberField
                  name="cooling-usage"
                  label="Monthly Usage (Summer)"
                  unit="kWh"
                  value={energyData.cooling?.monthlyUsage || 0}
                  onChange={(value) => updateCooling({ monthlyUsage: value })}
                  min={0}
                />

                <NumberField
                  name="cooling-efficiency"
                  label="System Efficiency"
                  unit="%"
                  value={energyData.cooling?.efficiency || 75}
                  onChange={(value) => updateCooling({ efficiency: value })}
                  min={0}
                  max={100}
                  showSlider
                />
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="w-5 h-5" />
            Water Heating
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <SelectField
              name="water-heating-type"
              label="Water Heater Type"
              options={waterHeatingTypes}
              value={energyData.waterHeating?.type || ""}
              onChange={(value) => updateWaterHeating({ type: value })}
            />

            <NumberField
              name="water-heating-usage"
              label="Monthly Usage"
              unit={
                energyData.waterHeating?.type?.includes("gas")
                  ? "therms"
                  : "kWh"
              }
              value={energyData.waterHeating?.monthlyUsage || 0}
              onChange={(value) => updateWaterHeating({ monthlyUsage: value })}
              min={0}
              description="Estimated portion of bill for water heating"
            />
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sun className="w-5 h-5" />
            Renewable Energy Systems
            <Badge variant="secondary">Optional</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="has-solar"
                checked={energyData.renewableEnergy?.hasSolar || false}
                onCheckedChange={(checked) =>
                  updateRenewable({ hasSolar: checked })
                }
              />
              <Label htmlFor="has-solar" className="flex items-center gap-2">
                <Sun className="w-4 h-4" />
                Solar Panels
              </Label>
            </div>

            {energyData.renewableEnergy?.hasSolar && (
              <NumberField
                name="solar-capacity"
                label="Solar System Capacity"
                unit="kW"
                value={energyData.renewableEnergy?.solarCapacity || 0}
                onChange={(value) => updateRenewable({ solarCapacity: value })}
                min={0}
                step={0.1}
              />
            )}
          </div>

          {}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="has-wind"
                checked={energyData.renewableEnergy?.hasWind || false}
                onCheckedChange={(checked) =>
                  updateRenewable({ hasWind: checked })
                }
              />
              <Label htmlFor="has-wind" className="flex items-center gap-2">
                <Wind className="w-4 h-4" />
                Wind Turbine
              </Label>
            </div>

            {energyData.renewableEnergy?.hasWind && (
              <NumberField
                name="wind-capacity"
                label="Wind System Capacity"
                unit="kW"
                value={energyData.renewableEnergy?.windCapacity || 0}
                onChange={(value) => updateRenewable({ windCapacity: value })}
                min={0}
                step={0.1}
              />
            )}
          </div>

          {}
          <div className="flex items-center space-x-2">
            <Switch
              id="has-geothermal"
              checked={energyData.renewableEnergy?.hasGeothermal || false}
              onCheckedChange={(checked) =>
                updateRenewable({ hasGeothermal: checked })
              }
            />
            <Label htmlFor="has-geothermal">Geothermal System</Label>
          </div>

          {}
          {(energyData.renewableEnergy?.hasSolar ||
            energyData.renewableEnergy?.hasWind) && (
            <NumberField
              name="battery-storage"
              label="Battery Storage Capacity"
              unit="kWh"
              value={energyData.renewableEnergy?.batteryStorage || 0}
              onChange={(value) => updateRenewable({ batteryStorage: value })}
              min={0}
              step={0.1}
              description="Total capacity of home battery storage"
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
