"use client";

import { useState, useCallback, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ChevronLeft,
  ChevronRight,
  Check,
  AlertCircle,
  Save,
  Clock,
} from "lucide-react";
import { useUIStore } from "@/store";

export interface WizardStep {
  id: string;
  title: string;
  description?: string;
  icon?: React.ComponentType<{ className?: string }>;
  component: React.ComponentType<WizardStepProps>;
  validation?: (data: any) => Promise<boolean> | boolean;
  optional?: boolean;
}

export interface WizardStepProps {
  data: any;
  updateData: (updates: any) => void;
  errors: Record<string, string>;
  isValid: boolean;
  onNext: () => void;
  onPrevious: () => void;
  isFirstStep: boolean;
  isLastStep: boolean;
}

interface FormWizardProps {
  steps: WizardStep[];
  initialData?: any;
  onComplete: (data: any) => Promise<void>;
  onSave?: (data: any) => Promise<void>;
  autoSave?: boolean;
  autoSaveInterval?: number;
  className?: string;
  title?: string;
  description?: string;
}

export function FormWizard({
  steps,
  initialData = {},
  onComplete,
  onSave,
  autoSave = true,
  autoSaveInterval = 30000,
  className,
  title,
  description,
}: FormWizardProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [data, setData] = useState(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [stepValidation, setStepValidation] = useState<Record<string, boolean>>(
    {}
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const addToast = useUIStore((state) => state.addToast);

  const currentStep = steps[currentStepIndex];
  const isFirstStep = currentStepIndex === 0;
  const isLastStep = currentStepIndex === steps.length - 1;

  useEffect(() => {
    if (!autoSave || !onSave || !hasUnsavedChanges) return;

    const interval = setInterval(async () => {
      try {
        await onSave(data);
        setLastSaved(new Date());
        setHasUnsavedChanges(false);
        addToast({
          title: "Progress saved",
          description: "Your progress has been automatically saved",
          type: "info",
        });
      } catch (error) {}
    }, autoSaveInterval);

    return () => clearInterval(interval);
  }, [autoSave, onSave, hasUnsavedChanges, data, autoSaveInterval, addToast]);

  const updateData = useCallback((updates: Record<string, unknown>) => {
    setData((prev: Record<string, unknown>) => ({ ...prev, ...updates }));
    setHasUnsavedChanges(true);

    const updatedFields = Object.keys(updates);
    setErrors((prev) => {
      const newErrors = { ...prev };
      updatedFields.forEach((field) => {
        delete newErrors[field];
      });
      return newErrors;
    });
  }, []);

  const validateCurrentStep = useCallback(async () => {
    if (!currentStep.validation) {
      setStepValidation((prev) => ({ ...prev, [currentStep.id]: true }));
      return true;
    }

    try {
      const isValid = await currentStep.validation(data);
      setStepValidation((prev) => ({ ...prev, [currentStep.id]: isValid }));
      return isValid;
    } catch (error) {
      setStepValidation((prev) => ({ ...prev, [currentStep.id]: false }));
      return false;
    }
  }, [currentStep, data]);

  const goToNext = useCallback(async () => {
    const isValid = await validateCurrentStep();

    if (!isValid && !currentStep.optional) {
      addToast({
        title: "Validation Error",
        description: "Please fix the errors before continuing",
        type: "error",
      });
      return;
    }

    if (isLastStep) {
      await handleComplete();
    } else {
      setCurrentStepIndex((prev) => prev + 1);
    }
  }, [validateCurrentStep, currentStep.optional, isLastStep, addToast]);

  const goToPrevious = useCallback(() => {
    if (!isFirstStep) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  }, [isFirstStep]);

  const goToStep = useCallback(
    (stepIndex: number) => {
      if (stepIndex >= 0 && stepIndex < steps.length) {
        setCurrentStepIndex(stepIndex);
      }
    },
    [steps.length]
  );

  const handleComplete = useCallback(async () => {
    setIsSubmitting(true);

    try {
      await onComplete(data);
      setHasUnsavedChanges(false);
      addToast({
        title: "Success",
        description: "Form completed successfully",
        type: "success",
      });
    } catch (error) {
      addToast({
        title: "Submission Failed",
        description:
          error instanceof Error ? error.message : "Please try again",
        type: "error",
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [data, onComplete, addToast]);

  const handleManualSave = useCallback(async () => {
    if (!onSave) return;

    try {
      await onSave(data);
      setLastSaved(new Date());
      setHasUnsavedChanges(false);
      addToast({
        title: "Saved",
        description: "Your progress has been saved",
        type: "success",
      });
    } catch (error) {
      addToast({
        title: "Save Failed",
        description: "Failed to save progress",
        type: "error",
      });
    }
  }, [onSave, data, addToast]);

  const progress = ((currentStepIndex + 1) / steps.length) * 100;
  const isCurrentStepValid = stepValidation[currentStep.id] ?? false;

  return (
    <div className={cn("max-w-4xl mx-auto", className)}>
      {}
      {(title || description) && (
        <div className="mb-8">
          {title && <h1 className="text-3xl font-bold mb-2">{title}</h1>}
          {description && (
            <p className="text-muted-foreground text-lg">{description}</p>
          )}
        </div>
      )}

      {}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">
            Step {currentStepIndex + 1} of {steps.length}
          </span>
          <div className="flex items-center gap-4">
            {hasUnsavedChanges && (
              <Badge variant="outline" className="text-amber-600">
                <AlertCircle className="w-3 h-3 mr-1" />
                Unsaved changes
              </Badge>
            )}
            {lastSaved && (
              <Badge variant="secondary" className="text-green-600">
                <Clock className="w-3 h-3 mr-1" />
                Saved {lastSaved.toLocaleTimeString()}
              </Badge>
            )}
            {onSave && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualSave}
                disabled={!hasUnsavedChanges}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Progress
              </Button>
            )}
          </div>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center gap-2">
          {steps.map((step, index) => {
            const isCompleted = index < currentStepIndex;
            const isCurrent = index === currentStepIndex;
            const isValid = stepValidation[step.id] ?? false;

            return (
              <div key={step.id} className="flex items-center">
                <button
                  onClick={() => goToStep(index)}
                  className={cn(
                    "flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium transition-colors",
                    isCompleted && "bg-green-500 text-white",
                    isCurrent &&
                      !isCompleted &&
                      "bg-primary text-primary-foreground",
                    !isCurrent &&
                      !isCompleted &&
                      "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                  disabled={index > currentStepIndex}
                >
                  {isCompleted ? <Check className="w-4 h-4" /> : index + 1}
                </button>
                {index < steps.length - 1 && (
                  <div className="w-8 h-0.5 bg-muted mx-2" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-3">
            {currentStep.icon && (
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <currentStep.icon className="w-5 h-5 text-primary" />
              </div>
            )}
            <div>
              <CardTitle>{currentStep.title}</CardTitle>
              {currentStep.description && (
                <p className="text-sm text-muted-foreground mt-1">
                  {currentStep.description}
                </p>
              )}
            </div>
            {currentStep.optional && (
              <Badge variant="secondary">Optional</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <currentStep.component
            data={data}
            updateData={updateData}
            errors={errors}
            isValid={isCurrentStepValid}
            onNext={goToNext}
            onPrevious={goToPrevious}
            isFirstStep={isFirstStep}
            isLastStep={isLastStep}
          />
        </CardContent>
      </Card>

      {}
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={goToPrevious} disabled={isFirstStep}>
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <Button
          onClick={goToNext}
          disabled={
            isSubmitting || (!isCurrentStepValid && !currentStep.optional)
          }
        >
          {isLastStep ? (
            <>
              {isSubmitting ? "Submitting..." : "Complete"}
              <Check className="w-4 h-4 ml-2" />
            </>
          ) : (
            <>
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
