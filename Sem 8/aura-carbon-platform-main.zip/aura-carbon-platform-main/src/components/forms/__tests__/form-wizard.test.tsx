import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { FormWizard, WizardStep, WizardStepProps } from "../form-wizard";
import { useUIStore } from "@/store";

jest.mock("@/store");
const mockUseUIStore = useUIStore as jest.MockedFunction<typeof useUIStore>;

const MockStep1: React.FC<WizardStepProps> = ({
  data,
  updateData,
  onNext,
  isFirstStep,
  isLastStep,
}) => (
  <div data-testid="step-1">
    <h3>Step 1</h3>
    <input
      data-testid="step1-input"
      value={data.step1Value || ""}
      onChange={(e) => updateData({ step1Value: e.target.value })}
      placeholder="Enter step 1 value"
    />
    <div>First step: {isFirstStep ? "yes" : "no"}</div>
    <div>Last step: {isLastStep ? "yes" : "no"}</div>
  </div>
);

const MockStep2: React.FC<WizardStepProps> = ({
  data,
  updateData,
  onNext,
  isFirstStep,
  isLastStep,
}) => (
  <div data-testid="step-2">
    <h3>Step 2</h3>
    <input
      data-testid="step2-input"
      value={data.step2Value || ""}
      onChange={(e) => updateData({ step2Value: e.target.value })}
      placeholder="Enter step 2 value"
    />
    <div>First step: {isFirstStep ? "yes" : "no"}</div>
    <div>Last step: {isLastStep ? "yes" : "no"}</div>
  </div>
);

const MockStep3: React.FC<WizardStepProps> = ({
  data,
  updateData,
  onNext,
  isFirstStep,
  isLastStep,
}) => (
  <div data-testid="step-3">
    <h3>Step 3</h3>
    <input
      data-testid="step3-input"
      value={data.step3Value || ""}
      onChange={(e) => updateData({ step3Value: e.target.value })}
      placeholder="Enter step 3 value"
    />
    <div>First step: {isFirstStep ? "yes" : "no"}</div>
    <div>Last step: {isLastStep ? "yes" : "no"}</div>
  </div>
);

describe("FormWizard", () => {
  const mockAddToast = jest.fn();
  const mockOnComplete = jest.fn();
  const mockOnSave = jest.fn();

  const mockSteps: WizardStep[] = [
    {
      id: "step1",
      title: "First Step",
      description: "This is the first step",
      component: MockStep1,
      validation: (data) => !!data.step1Value,
    },
    {
      id: "step2",
      title: "Second Step",
      description: "This is the second step",
      component: MockStep2,
      validation: (data) => !!data.step2Value,
      optional: true,
    },
    {
      id: "step3",
      title: "Third Step",
      description: "This is the third step",
      component: MockStep3,
      validation: (data) => !!data.step3Value,
    },
  ];

  beforeEach(() => {
    mockUseUIStore.mockReturnValue({
      addToast: mockAddToast,
    } as any);
    jest.clearAllMocks();
  });

  it("renders wizard with title and description", () => {
    render(
      <FormWizard
        steps={mockSteps}
        onComplete={mockOnComplete}
        title="Test Wizard"
        description="This is a test wizard"
      />
    );

    expect(
      screen.getByRole("heading", { name: /test wizard/i })
    ).toBeInTheDocument();
    expect(screen.getByText(/this is a test wizard/i)).toBeInTheDocument();
  });

  it("displays progress indicator", () => {
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    expect(screen.getByText("Step 1 of 3")).toBeInTheDocument();
    expect(screen.getByRole("progressbar")).toBeInTheDocument();
  });

  it("renders step navigation with correct states", () => {
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    expect(screen.getByText("1")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("3")).toBeInTheDocument();
  });

  it("displays current step content", () => {
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    expect(screen.getByTestId("step-1")).toBeInTheDocument();
    expect(screen.getByText("First Step")).toBeInTheDocument();
    expect(screen.getByText("This is the first step")).toBeInTheDocument();
  });

  it("shows previous button as disabled on first step", () => {
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const previousButton = screen.getByRole("button", { name: /previous/i });
    expect(previousButton).toBeDisabled();
  });

  it("advances to next step when validation passes", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const input = screen.getByTestId("step1-input");
    await user.type(input, "test value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-2")).toBeInTheDocument();
      expect(screen.getByText("Step 2 of 3")).toBeInTheDocument();
    });
  });

  it("prevents advancing when validation fails", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(mockAddToast).toHaveBeenCalledWith({
        title: "Validation Error",
        description: "Please fix the errors before continuing",
        type: "error",
      });
    });

    expect(screen.getByTestId("step-1")).toBeInTheDocument();
  });

  it("allows advancing optional steps even when validation fails", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "test value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-2")).toBeInTheDocument();
    });

    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-3")).toBeInTheDocument();
    });
  });

  it("goes back to previous step", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "test value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-2")).toBeInTheDocument();
    });

    const previousButton = screen.getByRole("button", { name: /previous/i });
    await user.click(previousButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-1")).toBeInTheDocument();
    });
  });

  it("completes wizard on last step", async () => {
    const user = userEvent.setup();
    mockOnComplete.mockResolvedValue(undefined);

    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "step1 value");

    let nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-2")).toBeInTheDocument();
    });

    nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-3")).toBeInTheDocument();
    });

    const step3Input = screen.getByTestId("step3-input");
    await user.type(step3Input, "step3 value");

    const completeButton = screen.getByRole("button", { name: /complete/i });
    await user.click(completeButton);

    await waitFor(() => {
      expect(mockOnComplete).toHaveBeenCalledWith({
        step1Value: "step1 value",
        step3Value: "step3 value",
      });
    });
  });

  it("handles completion errors", async () => {
    const user = userEvent.setup();
    const errorMessage = "Completion failed";
    mockOnComplete.mockRejectedValue(new Error(errorMessage));

    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "step1 value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-3")).toBeInTheDocument();
    });

    const step3Input = screen.getByTestId("step3-input");
    await user.type(step3Input, "step3 value");

    const completeButton = screen.getByRole("button", { name: /complete/i });
    await user.click(completeButton);

    await waitFor(() => {
      expect(mockAddToast).toHaveBeenCalledWith({
        title: "Submission Failed",
        description: errorMessage,
        type: "error",
      });
    });
  });

  it("saves progress manually", async () => {
    const user = userEvent.setup();
    mockOnSave.mockResolvedValue(undefined);

    render(
      <FormWizard
        steps={mockSteps}
        onComplete={mockOnComplete}
        onSave={mockOnSave}
      />
    );

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "test value");

    const saveButton = screen.getByRole("button", { name: /save progress/i });
    await user.click(saveButton);

    await waitFor(() => {
      expect(mockOnSave).toHaveBeenCalledWith({ step1Value: "test value" });
      expect(mockAddToast).toHaveBeenCalledWith({
        title: "Saved",
        description: "Your progress has been saved",
        type: "success",
      });
    });
  });

  it("shows unsaved changes indicator", async () => {
    const user = userEvent.setup();
    render(
      <FormWizard
        steps={mockSteps}
        onComplete={mockOnComplete}
        onSave={mockOnSave}
      />
    );

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "test value");

    await waitFor(() => {
      expect(screen.getByText(/unsaved changes/i)).toBeInTheDocument();
    });
  });

  it("navigates to specific step when clicked", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "test value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    await waitFor(() => {
      expect(screen.getByTestId("step-2")).toBeInTheDocument();
    });

    const step1Button = screen.getByRole("button", { name: "1" });
    await user.click(step1Button);

    await waitFor(() => {
      expect(screen.getByTestId("step-1")).toBeInTheDocument();
    });
  });

  it("shows optional badge for optional steps", () => {
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    fireEvent.change(step1Input, { target: { value: "test" } });

    const nextButton = screen.getByRole("button", { name: /next/i });
    fireEvent.click(nextButton);

    waitFor(() => {
      expect(screen.getByText(/optional/i)).toBeInTheDocument();
    });
  });

  it("preserves data when navigating between steps", async () => {
    const user = userEvent.setup();
    render(<FormWizard steps={mockSteps} onComplete={mockOnComplete} />);

    const step1Input = screen.getByTestId("step1-input");
    await user.type(step1Input, "persistent value");

    const nextButton = screen.getByRole("button", { name: /next/i });
    await user.click(nextButton);

    const previousButton = screen.getByRole("button", { name: /previous/i });
    await user.click(previousButton);

    await waitFor(() => {
      const preservedInput = screen.getByTestId("step1-input");
      expect(preservedInput).toHaveValue("persistent value");
    });
  });

  it("applies custom className", () => {
    const customClass = "custom-wizard-class";
    const { container } = render(
      <FormWizard
        steps={mockSteps}
        onComplete={mockOnComplete}
        className={customClass}
      />
    );

    expect(container.firstChild).toHaveClass(customClass);
  });
});
