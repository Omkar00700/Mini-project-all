import React from "react";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const TestFormSchema = z
  .object({
    email: z.string().email("Invalid email address"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string(),
    age: z.number().min(18, "Must be at least 18 years old"),
    terms: z
      .boolean()
      .refine((val) => val === true, "You must accept the terms"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

type TestFormData = z.infer<typeof TestFormSchema>;

const TestForm: React.FC = () => {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<TestFormData>({
    resolver: zodResolver(TestFormSchema),
  });

  const onSubmit = async (data: TestFormData) => {
    await new Promise((resolve) => setTimeout(resolve, 100));
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} data-testid="test-form">
      <div>
        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          {...register("email")}
          aria-invalid={errors.email ? "true" : "false"}
        />
        {errors.email && (
          <span role="alert" className="error">
            {errors.email.message}
          </span>
        )}
      </div>

      <div>
        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          {...register("password")}
          aria-invalid={errors.password ? "true" : "false"}
        />
        {errors.password && (
          <span role="alert" className="error">
            {errors.password.message}
          </span>
        )}
      </div>

      <div>
        <label htmlFor="confirmPassword">Confirm Password</label>
        <input
          id="confirmPassword"
          type="password"
          {...register("confirmPassword")}
          aria-invalid={errors.confirmPassword ? "true" : "false"}
        />
        {errors.confirmPassword && (
          <span role="alert" className="error">
            {errors.confirmPassword.message}
          </span>
        )}
      </div>

      <div>
        <label htmlFor="age">Age</label>
        <input
          id="age"
          type="number"
          {...register("age", { valueAsNumber: true })}
          aria-invalid={errors.age ? "true" : "false"}
        />
        {errors.age && (
          <span role="alert" className="error">
            {errors.age.message}
          </span>
        )}
      </div>

      <div>
        <label>
          <input
            type="checkbox"
            {...register("terms")}
            aria-invalid={errors.terms ? "true" : "false"}
          />
          I accept the terms and conditions
        </label>
        {errors.terms && (
          <span role="alert" className="error">
            {errors.terms.message}
          </span>
        )}
      </div>

      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Submitting..." : "Submit"}
      </button>
    </form>
  );
};

describe("Form Validation", () => {
  it("renders form with all fields", () => {
    render(<TestForm />);

    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^password$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/confirm password/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/age/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/terms and conditions/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /submit/i })).toBeInTheDocument();
  });

  it("validates email field", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const emailInput = screen.getByLabelText(/email/i);
    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.type(emailInput, "invalid-email");
    await user.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/invalid email address/i)).toBeInTheDocument();
    });

    await user.clear(emailInput);
    await user.type(emailInput, "test@example.com");

    await waitFor(() => {
      expect(
        screen.queryByText(/invalid email address/i)
      ).not.toBeInTheDocument();
    });
  });

  it("validates password length", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const passwordInput = screen.getByLabelText(/^password$/i);
    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.type(passwordInput, "short");
    await user.click(submitButton);

    await waitFor(() => {
      expect(
        screen.getByText(/password must be at least 8 characters/i)
      ).toBeInTheDocument();
    });

    await user.clear(passwordInput);
    await user.type(passwordInput, "validpassword123");

    await waitFor(() => {
      expect(
        screen.queryByText(/password must be at least 8 characters/i)
      ).not.toBeInTheDocument();
    });
  });

  it("validates password confirmation", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const passwordInput = screen.getByLabelText(/^password$/i);
    const confirmPasswordInput = screen.getByLabelText(/confirm password/i);
    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.type(passwordInput, "password123");
    await user.type(confirmPasswordInput, "differentpassword");
    await user.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/passwords don't match/i)).toBeInTheDocument();
    });

    await user.clear(confirmPasswordInput);
    await user.type(confirmPasswordInput, "password123");

    await waitFor(() => {
      expect(
        screen.queryByText(/passwords don't match/i)
      ).not.toBeInTheDocument();
    });
  });

  it("validates age requirement", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const ageInput = screen.getByLabelText(/age/i);
    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.type(ageInput, "16");
    await user.click(submitButton);

    await waitFor(() => {
      expect(
        screen.getByText(/must be at least 18 years old/i)
      ).toBeInTheDocument();
    });

    await user.clear(ageInput);
    await user.type(ageInput, "25");

    await waitFor(() => {
      expect(
        screen.queryByText(/must be at least 18 years old/i)
      ).not.toBeInTheDocument();
    });
  });

  it("validates terms acceptance", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.click(submitButton);

    await waitFor(() => {
      expect(
        screen.getByText(/you must accept the terms/i)
      ).toBeInTheDocument();
    });

    const termsCheckbox = screen.getByLabelText(/terms and conditions/i);
    await user.click(termsCheckbox);

    await waitFor(() => {
      expect(
        screen.queryByText(/you must accept the terms/i)
      ).not.toBeInTheDocument();
    });
  });

  it("submits form with valid data", async () => {
    const user = userEvent.setup();
    const consoleSpy = jest.spyOn(console, "log").mockImplementation();

    render(<TestForm />);

    await user.type(screen.getByLabelText(/email/i), "test@example.com");
    await user.type(screen.getByLabelText(/^password$/i), "validpassword123");
    await user.type(
      screen.getByLabelText(/confirm password/i),
      "validpassword123"
    );
    await user.type(screen.getByLabelText(/age/i), "25");
    await user.click(screen.getByLabelText(/terms and conditions/i));

    const submitButton = screen.getByRole("button", { name: /submit/i });
    await user.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/submitting/i)).toBeInTheDocument();
    });

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalledWith(
        "Form submitted:",
        expect.objectContaining({
          email: "test@example.com",
          password: "validpassword123",
          confirmPassword: "validpassword123",
          age: 25,
          terms: true,
        })
      );
    });

    consoleSpy.mockRestore();
  });

  it("has proper accessibility attributes", () => {
    render(<TestForm />);

    expect(screen.getByLabelText(/email/i)).toHaveAttribute("id", "email");
    expect(screen.getByLabelText(/^password$/i)).toHaveAttribute(
      "id",
      "password"
    );
    expect(screen.getByLabelText(/confirm password/i)).toHaveAttribute(
      "id",
      "confirmPassword"
    );
    expect(screen.getByLabelText(/age/i)).toHaveAttribute("id", "age");

    expect(screen.getByLabelText(/email/i)).toHaveAttribute("type", "email");
    expect(screen.getByLabelText(/^password$/i)).toHaveAttribute(
      "type",
      "password"
    );
    expect(screen.getByLabelText(/age/i)).toHaveAttribute("type", "number");
  });

  it("shows aria-invalid when fields have errors", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const emailInput = screen.getByLabelText(/email/i);
    const submitButton = screen.getByRole("button", { name: /submit/i });

    await user.type(emailInput, "invalid");
    await user.click(submitButton);

    await waitFor(() => {
      expect(emailInput).toHaveAttribute("aria-invalid", "true");
    });
  });

  it("announces errors to screen readers", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    const submitButton = screen.getByRole("button", { name: /submit/i });
    await user.click(submitButton);

    await waitFor(() => {
      const errorMessages = screen.getAllByRole("alert");
      expect(errorMessages.length).toBeGreaterThan(0);
    });
  });

  it("prevents multiple submissions", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    await user.type(screen.getByLabelText(/email/i), "test@example.com");
    await user.type(screen.getByLabelText(/^password$/i), "validpassword123");
    await user.type(
      screen.getByLabelText(/confirm password/i),
      "validpassword123"
    );
    await user.type(screen.getByLabelText(/age/i), "25");
    await user.click(screen.getByLabelText(/terms and conditions/i));

    const submitButton = screen.getByRole("button", { name: /submit/i });
    await user.click(submitButton);

    await waitFor(() => {
      expect(submitButton).toBeDisabled();
    });
  });

  it("handles keyboard navigation", async () => {
    const user = userEvent.setup();
    render(<TestForm />);

    await user.tab();
    expect(screen.getByLabelText(/email/i)).toHaveFocus();

    await user.tab();
    expect(screen.getByLabelText(/^password$/i)).toHaveFocus();

    await user.tab();
    expect(screen.getByLabelText(/confirm password/i)).toHaveFocus();

    await user.tab();
    expect(screen.getByLabelText(/age/i)).toHaveFocus();

    await user.tab();
    expect(screen.getByLabelText(/terms and conditions/i)).toHaveFocus();

    await user.tab();
    expect(screen.getByRole("button", { name: /submit/i })).toHaveFocus();
  });
});
