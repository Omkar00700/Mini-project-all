"use client";

import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface ParticleFieldProps {
  count?: number;
  color?: string;
  size?: number;
  speed?: number;
  spread?: number;
}

function ParticleField({
  count = 200,
  color = "#10b981",
  size = 0.05,
  speed = 0.5,
  spread = 10,
}: ParticleFieldProps) {
  const particlesRef = useRef<THREE.Points>(null);

  const { positions, velocities } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * spread;
      positions[i * 3 + 1] = (Math.random() - 0.5) * spread;
      positions[i * 3 + 2] = (Math.random() - 0.5) * spread;

      velocities[i * 3] = (Math.random() - 0.5) * 0.02 * speed;
      velocities[i * 3 + 1] = (Math.random() - 0.5) * 0.02 * speed;
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.02 * speed;
    }

    return { positions, velocities };
  }, [count, spread, speed]);

  useFrame(() => {
    if (!particlesRef.current) return;

    const positionsAttr = particlesRef.current.geometry.attributes.position;
    const posArray = positionsAttr.array as Float32Array;

    for (let i = 0; i < count; i++) {
      posArray[i * 3] += velocities[i * 3];
      posArray[i * 3 + 1] += velocities[i * 3 + 1];
      posArray[i * 3 + 2] += velocities[i * 3 + 2];

      if (Math.abs(posArray[i * 3]) > spread / 2) velocities[i * 3] *= -1;
      if (Math.abs(posArray[i * 3 + 1]) > spread / 2)
        velocities[i * 3 + 1] *= -1;
      if (Math.abs(posArray[i * 3 + 2]) > spread / 2)
        velocities[i * 3 + 2] *= -1;
    }

    positionsAttr.needsUpdate = true;
  });

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={size}
        color={color}
        transparent
        opacity={0.8}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

interface CarbonParticlesProps {
  intensity?: "low" | "medium" | "high";
  className?: string;
}

export function CarbonParticles({
  intensity = "medium",
  className,
}: CarbonParticlesProps) {
  const config = {
    low: { count: 100, size: 0.03, speed: 0.3 },
    medium: { count: 200, size: 0.05, speed: 0.5 },
    high: { count: 400, size: 0.08, speed: 0.8 },
  };

  const { count, size, speed } = config[intensity];

  return (
    <div
      className={className}
      style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
    >
      <Canvas
        camera={{ position: [0, 0, 5], fov: 75 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <ParticleField count={count} size={size} speed={speed} />
      </Canvas>
    </div>
  );
}

interface FloatingOrbsSceneProps {
  count?: number;
}

function FloatingOrbsScene({ count = 6 }: FloatingOrbsSceneProps) {
  const orbsRef = useRef<THREE.Group>(null);

  const orbData = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      position: [
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 4,
      ] as [number, number, number],
      scale: 0.1 + Math.random() * 0.3,
      speed: 0.5 + Math.random() * 1,
      color: ["#10b981", "#3b82f6", "#8b5cf6", "#f59e0b"][
        Math.floor(Math.random() * 4)
      ],
    }));
  }, [count]);

  useFrame((state) => {
    if (!orbsRef.current) return;

    orbsRef.current.children.forEach((orb, i) => {
      const data = orbData[i];
      orb.position.y +=
        Math.sin(state.clock.elapsedTime * data.speed + i) * 0.002;
      orb.position.x +=
        Math.cos(state.clock.elapsedTime * data.speed * 0.5 + i) * 0.001;
    });
  });

  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <group ref={orbsRef}>
        {orbData.map((orb, i) => (
          <mesh key={i} position={orb.position} scale={orb.scale}>
            <sphereGeometry args={[1, 16, 16]} />
            <meshPhongMaterial
              color={orb.color}
              transparent
              opacity={0.6}
              emissive={orb.color}
              emissiveIntensity={0.3}
            />
          </mesh>
        ))}
      </group>
    </>
  );
}

interface FloatingOrbsProps {
  count?: number;
  className?: string;
}

export function FloatingOrbs({ count = 6, className }: FloatingOrbsProps) {
  return (
    <div
      className={className}
      style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
    >
      <Canvas
        camera={{ position: [0, 0, 10], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <FloatingOrbsScene count={count} />
      </Canvas>
    </div>
  );
}
