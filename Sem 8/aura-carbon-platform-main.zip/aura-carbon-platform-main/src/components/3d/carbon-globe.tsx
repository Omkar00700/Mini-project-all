"use client";

import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere, Stars, Float, OrbitControls } from "@react-three/drei";
import * as THREE from "three";

interface GlobeProps {
  carbonIntensity?: number;
  autoRotate?: boolean;
}

function CarbonGlobe({ carbonIntensity = 0.5, autoRotate = true }: GlobeProps) {
  const globeRef = useRef<THREE.Mesh>(null);
  const atmosphereRef = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);

  useFrame((state) => {
    if (globeRef.current && autoRotate) {
      globeRef.current.rotation.y += 0.002;
    }
    if (atmosphereRef.current && autoRotate) {
      atmosphereRef.current.rotation.y += 0.001;
    }
    if (particlesRef.current) {
      particlesRef.current.rotation.y += 0.0005;
      const positions = particlesRef.current.geometry.attributes.position;
      for (let i = 0; i < positions.count; i++) {
        const y = positions.getY(i);
        positions.setY(i, y + Math.sin(state.clock.elapsedTime + i) * 0.001);
      }
      positions.needsUpdate = true;
    }
  });

  const particlePositions = useMemo(() => {
    const positions = new Float32Array(500 * 3);
    for (let i = 0; i < 500; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const radius = 1.5 + Math.random() * 0.5;
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);
    }
    return positions;
  }, []);

  const intensity = Math.min(1, carbonIntensity);
  const globeColor = new THREE.Color().lerpColors(
    new THREE.Color("#10b981"),
    new THREE.Color("#ef4444"),
    intensity
  );

  return (
    <>
      <Stars
        radius={100}
        depth={50}
        count={5000}
        factor={4}
        saturation={0}
        fade
        speed={1}
      />

      <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
        <Sphere ref={globeRef} args={[1, 64, 64]}>
          <meshPhongMaterial
            color={globeColor}
            emissive={globeColor}
            emissiveIntensity={0.1}
            shininess={10}
            transparent
            opacity={0.9}
          />
        </Sphere>

        <Sphere ref={atmosphereRef} args={[1.05, 64, 64]}>
          <meshPhongMaterial
            color="#60a5fa"
            transparent
            opacity={0.15}
            side={THREE.BackSide}
          />
        </Sphere>

        <Sphere args={[1.15, 32, 32]}>
          <meshBasicMaterial
            color="#60a5fa"
            transparent
            opacity={0.05}
            wireframe
          />
        </Sphere>
      </Float>

      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particlePositions.length / 3}
            array={particlePositions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.02}
          color="#34d399"
          transparent
          opacity={0.6}
          sizeAttenuation
        />
      </points>
    </>
  );
}

interface CarbonGlobeSceneProps {
  carbonIntensity?: number;
  className?: string;
}

export function CarbonGlobeScene({
  carbonIntensity,
  className,
}: CarbonGlobeSceneProps) {
  return (
    <div className={className} style={{ width: "100%", height: "100%" }}>
      <Canvas
        camera={{ position: [0, 0, 3], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <pointLight position={[-10, -10, -5]} intensity={0.5} color="#60a5fa" />
        <CarbonGlobe carbonIntensity={carbonIntensity} />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          autoRotate
          autoRotateSpeed={0.5}
          maxPolarAngle={Math.PI / 1.5}
          minPolarAngle={Math.PI / 3}
        />
      </Canvas>
    </div>
  );
}
