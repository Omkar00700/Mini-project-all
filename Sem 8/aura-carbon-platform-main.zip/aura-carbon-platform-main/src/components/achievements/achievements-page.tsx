"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Trophy,
  Medal,
  Star,
  Crown,
  Lock,
  CheckCircle2,
  Share2,
  Loader2,
  Target,
  Flame,
  Leaf,
} from "lucide-react";
import { toast } from "sonner";

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: string;
  tier: "bronze" | "silver" | "gold" | "platinum";
  icon: string;
  points: number;
  progress?: number;
  unlockedAt?: Date;
}

interface UserProgress {
  level: number;
  title: string;
  points: number;
  nextLevelPoints: number;
  totalAchievements: number;
  unlockedCount: number;
}

const TIER_STYLES = {
  bronze: {
    bg: "bg-amber-100",
    border: "border-amber-300",
    text: "text-amber-700",
    glow: "shadow-amber-200",
    icon: Medal,
  },
  silver: {
    bg: "bg-slate-100",
    border: "border-slate-300",
    text: "text-slate-700",
    glow: "shadow-slate-200",
    icon: Medal,
  },
  gold: {
    bg: "bg-yellow-100",
    border: "border-yellow-400",
    text: "text-yellow-700",
    glow: "shadow-yellow-300",
    icon: Star,
  },
  platinum: {
    bg: "bg-purple-100",
    border: "border-purple-400",
    text: "text-purple-700",
    glow: "shadow-purple-300",
    icon: Crown,
  },
};

const CATEGORY_ICONS: Record<string, React.ElementType> = {
  tracking: Target,
  reduction: Leaf,
  streaks: Flame,
  social: Share2,
  goals: Trophy,
  special: Star,
};

export function AchievementsPage() {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  useEffect(() => {
    if (user) {
      fetchAchievements();
    }
  }, [user]);

  const fetchAchievements = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/achievements");
      if (response.ok) {
        const data = await response.json();
        setAchievements(data.achievements || []);
        setProgress(data.progress || null);
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const shareAchievement = async (achievement: Achievement) => {
    try {
      const response = await fetch("/api/share/achievement", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ achievementId: achievement.id }),
      });

      if (response.ok) {
        const { url } = await response.json();
        await navigator.clipboard.writeText(url);
        toast.success("Share link copied to clipboard!");
      }
    } catch (_error) {
      toast.error("Failed to generate share link");
    }
  };

  const filteredAchievements =
    selectedCategory === "all"
      ? achievements
      : achievements.filter((a) => a.category === selectedCategory);

  const categories = Array.from(new Set(achievements.map((a) => a.category)));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">Achievements</h1>
        <p className="text-muted-foreground">
          Track your progress and unlock badges as you reduce your carbon
          footprint
        </p>
      </div>

      {}
      {progress && (
        <Card className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
          <CardContent className="pt-6">
            <div className="grid gap-6 md:grid-cols-4">
              <div className="text-center">
                <div className="text-4xl font-bold">{progress.level}</div>
                <div className="text-emerald-100">Level</div>
                <Badge variant="secondary" className="mt-1">
                  {progress.title}
                </Badge>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold">{progress.points}</div>
                <div className="text-emerald-100">Total Points</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold">
                  {progress.unlockedCount}
                </div>
                <div className="text-emerald-100">Badges Earned</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold">
                  {Math.round(
                    (progress.unlockedCount / progress.totalAchievements) * 100
                  )}
                  %
                </div>
                <div className="text-emerald-100">Completion</div>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-1">
                <span>Progress to Level {progress.level + 1}</span>
                <span>
                  {progress.points} / {progress.nextLevelPoints} XP
                </span>
              </div>
              <Progress
                value={(progress.points / progress.nextLevelPoints) * 100}
                className="h-2 bg-emerald-700"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="all">All</TabsTrigger>
          {categories.map((cat) => (
            <TabsTrigger key={cat} value={cat} className="capitalize">
              {cat}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedCategory} className="mt-6">
          {}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredAchievements.map((achievement) => {
              const isUnlocked = !!achievement.unlockedAt;
              const tierStyle = TIER_STYLES[achievement.tier];
              const TierIcon = tierStyle.icon;
              const CategoryIcon =
                CATEGORY_ICONS[achievement.category] || Trophy;

              return (
                <Card
                  key={achievement.id}
                  className={`relative overflow-hidden transition-all ${
                    isUnlocked
                      ? `${tierStyle.bg} ${tierStyle.border} border-2`
                      : "opacity-75 grayscale"
                  }`}
                >
                  {isUnlocked && (
                    <div className="absolute top-2 right-2">
                      <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                    </div>
                  )}

                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      {}
                      <div
                        className={`text-4xl p-3 rounded-xl ${
                          isUnlocked ? "bg-white/50" : "bg-gray-100"
                        }`}
                      >
                        {isUnlocked ? (
                          achievement.icon
                        ) : (
                          <Lock className="h-8 w-8 text-gray-400" />
                        )}
                      </div>

                      {}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold truncate">
                            {achievement.name}
                          </h3>
                          <Badge variant="outline" className="shrink-0">
                            +{achievement.points} XP
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {achievement.description}
                        </p>

                        {}
                        {!isUnlocked && achievement.progress !== undefined && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>Progress</span>
                              <span>{Math.round(achievement.progress)}%</span>
                            </div>
                            <Progress
                              value={achievement.progress}
                              className="h-1"
                            />
                          </div>
                        )}

                        {}
                        <div className="flex items-center gap-2 mt-2">
                          <Badge
                            variant="secondary"
                            className="text-xs capitalize"
                          >
                            <TierIcon className="h-3 w-3 mr-1" />
                            {achievement.tier}
                          </Badge>
                          <Badge
                            variant="outline"
                            className="text-xs capitalize"
                          >
                            <CategoryIcon className="h-3 w-3 mr-1" />
                            {achievement.category}
                          </Badge>
                        </div>

                        {}
                        {isUnlocked && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2 w-full"
                            onClick={() => shareAchievement(achievement)}
                          >
                            <Share2 className="h-4 w-4 mr-2" />
                            Share Achievement
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              Rarest Badges
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {achievements
                .filter((a) => a.unlockedAt && a.tier === "platinum")
                .slice(0, 3)
                .map((a) => (
                  <li key={a.id} className="flex items-center gap-2 text-sm">
                    <span className="text-lg">{a.icon}</span>
                    <span>{a.name}</span>
                  </li>
                ))}
              {achievements.filter((a) => a.unlockedAt && a.tier === "platinum")
                .length === 0 && (
                <li className="text-sm text-muted-foreground">
                  No platinum badges yet. Keep going!
                </li>
              )}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Flame className="h-5 w-5 text-orange-500" />
              Current Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{}7 days</div>
            <p className="text-sm text-muted-foreground">
              Keep logging to maintain it!
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Target className="h-5 w-5 text-emerald-500" />
              Next Achievement
            </CardTitle>
          </CardHeader>
          <CardContent>
            {achievements
              .filter((a) => !a.unlockedAt && a.progress && a.progress > 0)
              .sort((a, b) => (b.progress || 0) - (a.progress || 0))[0] ? (
              <div className="flex items-center gap-2">
                <span className="text-2xl">
                  {
                    achievements
                      .filter(
                        (a) => !a.unlockedAt && a.progress && a.progress > 0
                      )
                      .sort((a, b) => (b.progress || 0) - (a.progress || 0))[0]
                      .icon
                  }
                </span>
                <div>
                  <div className="font-medium">
                    {
                      achievements
                        .filter(
                          (a) => !a.unlockedAt && a.progress && a.progress > 0
                        )
                        .sort(
                          (a, b) => (b.progress || 0) - (a.progress || 0)
                        )[0].name
                    }
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {Math.round(
                      achievements
                        .filter(
                          (a) => !a.unlockedAt && a.progress && a.progress > 0
                        )
                        .sort(
                          (a, b) => (b.progress || 0) - (a.progress || 0)
                        )[0].progress || 0
                    )}
                    % complete
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                All achievements unlocked! Amazing!
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
