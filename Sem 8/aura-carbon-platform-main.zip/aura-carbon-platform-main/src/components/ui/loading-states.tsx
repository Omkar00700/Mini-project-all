"use client";

import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Calculator,
  BarChart3,
  Target,
  TrendingDown,
  Leaf,
  Plus,
  ArrowRight,
  FileText,
  Lightbulb,
} from "lucide-react";
import Link from "next/link";

export function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-4 rounded-full" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-20 mb-1" />
              <Skeleton className="h-3 w-32" />
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-4 w-60" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      <div className="flex gap-4 p-4 bg-muted rounded-lg">
        <Skeleton className="h-4 w-1/4" />
        <Skeleton className="h-4 w-1/4" />
        <Skeleton className="h-4 w-1/4" />
        <Skeleton className="h-4 w-1/4" />
      </div>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4 p-4">
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-4 w-1/4" />
        </div>
      ))}
    </div>
  );
}

export function ChartSkeleton() {
  return (
    <div className="h-64 flex items-center justify-center">
      <div className="flex items-end gap-2 h-32">
        {[40, 65, 45, 80, 55, 70, 50].map((h, i) => (
          <Skeleton
            key={i}
            className="w-8 rounded-t"
            style={{ height: `${h}%`, animationDelay: `${i * 100}ms` }}
          />
        ))}
      </div>
    </div>
  );
}

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: {
    label: string;
    href?: string;
    onClick?: () => void;
  };
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: EmptyStateProps) {
  return (
    <Card className="border-dashed">
      <CardContent className="py-12 text-center">
        <div className="mx-auto mb-4 p-3 bg-muted rounded-full w-fit">
          {icon || <FileText className="h-8 w-8 text-muted-foreground" />}
        </div>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          {description}
        </p>
        {action &&
          (action.href ? (
            <Link href={action.href}>
              <Button className="bg-emerald-600 hover:bg-emerald-700">
                {action.label}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          ) : (
            <Button
              onClick={action.onClick}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {action.label}
            </Button>
          ))}
      </CardContent>
    </Card>
  );
}

export function NoCalculationsState() {
  return (
    <EmptyState
      icon={<Calculator className="h-8 w-8 text-muted-foreground" />}
      title="No calculations yet"
      description="Start tracking your carbon footprint by calculating your first month's emissions. It only takes a few minutes."
      action={{ label: "Calculate Now", href: "/calculator" }}
    />
  );
}

export function NoActivitiesState() {
  return (
    <EmptyState
      icon={<Plus className="h-8 w-8 text-muted-foreground" />}
      title="No activities logged"
      description="Start logging your daily activities like transportation, energy usage, and food consumption to track your impact."
      action={{ label: "Add Activity", href: "/activities?action=add" }}
    />
  );
}

export function NoGoalsState() {
  return (
    <EmptyState
      icon={<Target className="h-8 w-8 text-muted-foreground" />}
      title="No goals set"
      description="Set a carbon reduction goal to stay motivated and track your progress towards a more sustainable lifestyle."
      action={{ label: "Set a Goal", href: "/goals?action=create" }}
    />
  );
}

export function NoInsightsState() {
  return (
    <EmptyState
      icon={<Lightbulb className="h-8 w-8 text-muted-foreground" />}
      title="Not enough data for insights"
      description="We need at least a month of activity data to generate personalized insights. Keep logging!"
      action={{ label: "Log Activities", href: "/activities" }}
    />
  );
}

export function NoPredictionsState() {
  return (
    <EmptyState
      icon={<TrendingDown className="h-8 w-8 text-muted-foreground" />}
      title="Predictions coming soon"
      description="We need at least 3 months of data to generate accurate predictions. Continue tracking your emissions!"
    />
  );
}

export function NoBenchmarksState() {
  return (
    <EmptyState
      icon={<BarChart3 className="h-8 w-8 text-muted-foreground" />}
      title="Complete your profile for benchmarks"
      description="Add your location and household details to see how you compare with similar households in your area."
      action={{ label: "Update Profile", href: "/settings?tab=profile" }}
    />
  );
}

export function LoadingOverlay({
  message = "Loading...",
}: {
  message?: string;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center">
      <div className="text-center">
        <div className="relative">
          <Leaf className="h-12 w-12 text-emerald-600 animate-pulse mx-auto" />
          <div className="absolute inset-0 h-12 w-12 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
        </div>
        <p className="mt-4 text-muted-foreground">{message}</p>
      </div>
    </div>
  );
}

export function PageLoader() {
  return (
    <div className="min-h-[400px] flex items-center justify-center">
      <div className="text-center">
        <div className="relative w-12 h-12 mx-auto">
          <div className="absolute inset-0 border-4 border-muted rounded-full"></div>
          <div className="absolute inset-0 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Loading...</p>
      </div>
    </div>
  );
}
