import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Input } from "../input";

describe("Input", () => {
  it("renders input field", () => {
    render(<Input placeholder="Enter text" />);

    const input = screen.getByPlaceholderText(/enter text/i);
    expect(input).toBeInTheDocument();
  });

  it("handles text input", async () => {
    const user = userEvent.setup();
    render(<Input placeholder="Type here" />);

    const input = screen.getByPlaceholderText(/type here/i);
    await user.type(input, "Hello World");

    expect(input).toHaveValue("Hello World");
  });

  it("handles controlled input", () => {
    const handleChange = jest.fn();
    render(<Input value="controlled" onChange={handleChange} />);

    const input = screen.getByDisplayValue("controlled");
    expect(input).toHaveValue("controlled");
  });

  it("calls onChange when value changes", async () => {
    const user = userEvent.setup();
    const handleChange = jest.fn();

    render(<Input onChange={handleChange} />);

    const input = screen.getByRole("textbox");
    await user.type(input, "test");

    expect(handleChange).toHaveBeenCalledTimes(4);
  });

  it("applies different input types", () => {
    const { rerender } = render(<Input type="email" />);
    expect(screen.getByRole("textbox")).toHaveAttribute("type", "email");

    rerender(<Input type="password" />);
    expect(screen.getByRole("textbox")).toHaveAttribute("type", "password");

    rerender(<Input type="number" />);
    expect(screen.getByRole("spinbutton")).toHaveAttribute("type", "number");
  });

  it("is disabled when disabled prop is true", () => {
    render(<Input disabled placeholder="Disabled input" />);

    const input = screen.getByPlaceholderText(/disabled input/i);
    expect(input).toBeDisabled();
  });

  it("applies custom className", () => {
    const customClass = "custom-input-class";
    render(<Input className={customClass} />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveClass(customClass);
  });

  it("forwards ref correctly", () => {
    const ref = React.createRef<HTMLInputElement>();
    render(<Input ref={ref} />);

    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });

  it("has proper default styling", () => {
    render(<Input />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveClass(
      "flex",
      "h-10",
      "w-full",
      "rounded-md",
      "border",
      "border-input",
      "bg-background",
      "px-3",
      "py-2"
    );
  });

  it("has focus styles", () => {
    render(<Input />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveClass(
      "focus-visible:outline-none",
      "focus-visible:ring-2"
    );
  });

  it("has disabled styles", () => {
    render(<Input disabled />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveClass(
      "disabled:cursor-not-allowed",
      "disabled:opacity-50"
    );
  });

  it("supports placeholder text", () => {
    render(<Input placeholder="Search..." />);

    const input = screen.getByPlaceholderText("Search...");
    expect(input).toHaveAttribute("placeholder", "Search...");
  });

  it("supports required attribute", () => {
    render(<Input required />);

    const input = screen.getByRole("textbox");
    expect(input).toBeRequired();
  });

  it("supports readonly attribute", () => {
    render(<Input readOnly value="readonly value" />);

    const input = screen.getByDisplayValue("readonly value");
    expect(input).toHaveAttribute("readonly");
  });

  it("supports min and max for number inputs", () => {
    render(<Input type="number" min={0} max={100} />);

    const input = screen.getByRole("spinbutton");
    expect(input).toHaveAttribute("min", "0");
    expect(input).toHaveAttribute("max", "100");
  });

  it("supports maxLength attribute", () => {
    render(<Input maxLength={10} />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("maxLength", "10");
  });

  it("supports pattern attribute", () => {
    render(<Input pattern="[0-9]*" />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("pattern", "[0-9]*");
  });

  it("handles onFocus and onBlur events", async () => {
    const user = userEvent.setup();
    const handleFocus = jest.fn();
    const handleBlur = jest.fn();

    render(<Input onFocus={handleFocus} onBlur={handleBlur} />);

    const input = screen.getByRole("textbox");

    await user.click(input);
    expect(handleFocus).toHaveBeenCalledTimes(1);

    await user.tab();
    expect(handleBlur).toHaveBeenCalledTimes(1);
  });

  it("supports autoComplete attribute", () => {
    render(<Input autoComplete="email" />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("autoComplete", "email");
  });

  it("supports autoFocus attribute", () => {
    render(<Input autoFocus />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveFocus();
  });

  it("handles keyboard events", async () => {
    const user = userEvent.setup();
    const handleKeyDown = jest.fn();

    render(<Input onKeyDown={handleKeyDown} />);

    const input = screen.getByRole("textbox");
    await user.type(input, "a");

    expect(handleKeyDown).toHaveBeenCalled();
  });

  it("supports aria attributes for accessibility", () => {
    render(
      <Input
        aria-label="Search input"
        aria-describedby="search-help"
        aria-invalid="true"
      />
    );

    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("aria-label", "Search input");
    expect(input).toHaveAttribute("aria-describedby", "search-help");
    expect(input).toHaveAttribute("aria-invalid", "true");
  });

  it("maintains proper contrast ratios", () => {
    render(<Input />);

    const input = screen.getByRole("textbox");

    expect(input).toHaveClass("text-sm");
  });

  it("handles file input type", () => {
    render(<Input type="file" accept=".jpg,.png" />);

    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("type", "file");
    expect(input).toHaveAttribute("accept", ".jpg,.png");
  });

  it("supports step attribute for number inputs", () => {
    render(<Input type="number" step="0.01" />);

    const input = screen.getByRole("spinbutton");
    expect(input).toHaveAttribute("step", "0.01");
  });
});
