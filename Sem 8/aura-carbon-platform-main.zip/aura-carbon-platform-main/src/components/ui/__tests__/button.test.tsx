import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Button } from "../button";

describe("Button", () => {
  it("renders button with text", () => {
    render(<Button>Click me</Button>);

    const button = screen.getByRole("button", { name: /click me/i });
    expect(button).toBeInTheDocument();
  });

  it("handles click events", async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();

    render(<Button onClick={handleClick}>Click me</Button>);

    const button = screen.getByRole("button", { name: /click me/i });
    await user.click(button);

    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it("applies default variant styling", () => {
    render(<Button>Default Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("bg-primary", "text-primary-foreground");
  });

  it("applies destructive variant styling", () => {
    render(<Button variant="destructive">Delete</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("bg-destructive", "text-destructive-foreground");
  });

  it("applies outline variant styling", () => {
    render(<Button variant="outline">Outline Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("border", "border-input", "bg-background");
  });

  it("applies secondary variant styling", () => {
    render(<Button variant="secondary">Secondary</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("bg-secondary", "text-secondary-foreground");
  });

  it("applies ghost variant styling", () => {
    render(<Button variant="ghost">Ghost Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass(
      "hover:bg-accent",
      "hover:text-accent-foreground"
    );
  });

  it("applies link variant styling", () => {
    render(<Button variant="link">Link Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("text-primary", "underline-offset-4");
  });

  it("applies small size styling", () => {
    render(<Button size="sm">Small Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("h-9", "px-3");
  });

  it("applies large size styling", () => {
    render(<Button size="lg">Large Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("h-11", "px-8");
  });

  it("applies icon size styling", () => {
    render(<Button size="icon">🔍</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("h-10", "w-10");
  });

  it("is disabled when disabled prop is true", () => {
    render(<Button disabled>Disabled Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toBeDisabled();
    expect(button).toHaveClass(
      "disabled:pointer-events-none",
      "disabled:opacity-50"
    );
  });

  it("does not trigger click when disabled", async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();

    render(
      <Button disabled onClick={handleClick}>
        Disabled Button
      </Button>
    );

    const button = screen.getByRole("button");
    await user.click(button);

    expect(handleClick).not.toHaveBeenCalled();
  });

  it("applies custom className", () => {
    const customClass = "custom-button-class";
    render(<Button className={customClass}>Custom Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass(customClass);
  });

  it("forwards ref correctly", () => {
    const ref = React.createRef<HTMLButtonElement>();
    render(<Button ref={ref}>Button with Ref</Button>);

    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("supports asChild prop with Slot", () => {
    render(
      <Button asChild>
        <a href="/test">Link as Button</a>
      </Button>
    );

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/test");
    expect(link).toHaveClass("inline-flex", "items-center", "justify-center");
  });

  it("has proper accessibility attributes", () => {
    render(<Button aria-label="Custom label">Button</Button>);

    const button = screen.getByRole("button", { name: /custom label/i });
    expect(button).toHaveAttribute("aria-label", "Custom label");
  });

  it("supports keyboard navigation", async () => {
    const user = userEvent.setup();
    const handleClick = jest.fn();

    render(<Button onClick={handleClick}>Keyboard Button</Button>);

    const button = screen.getByRole("button");
    button.focus();

    expect(button).toHaveFocus();

    await user.keyboard("{Enter}");
    expect(handleClick).toHaveBeenCalledTimes(1);

    await user.keyboard(" ");
    expect(handleClick).toHaveBeenCalledTimes(2);
  });

  it("maintains focus styles", () => {
    render(<Button>Focus Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass(
      "focus-visible:outline-none",
      "focus-visible:ring-2"
    );
  });

  it("renders with loading state", () => {
    render(
      <Button disabled>
        <span className="animate-spin mr-2">⏳</span>
        Loading...
      </Button>
    );

    const button = screen.getByRole("button");
    expect(button).toBeDisabled();
    expect(screen.getByText(/loading/i)).toBeInTheDocument();
  });

  it("handles different button types", () => {
    render(<Button type="submit">Submit Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveAttribute("type", "submit");
  });

  it("supports form association", () => {
    render(
      <form data-testid="test-form">
        <Button form="external-form">External Form Button</Button>
      </form>
    );

    const button = screen.getByRole("button");
    expect(button).toHaveAttribute("form", "external-form");
  });

  it("renders with icon and text", () => {
    render(
      <Button>
        <span className="mr-2">🔍</span>
        Search
      </Button>
    );

    const button = screen.getByRole("button");
    expect(button).toHaveTextContent("🔍Search");
  });

  it("applies hover and active states", () => {
    render(<Button>Hover Button</Button>);

    const button = screen.getByRole("button");
    expect(button).toHaveClass("hover:bg-primary/90");
  });
});
