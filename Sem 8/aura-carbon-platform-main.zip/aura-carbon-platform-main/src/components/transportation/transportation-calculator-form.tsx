"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import {
  Loader2,
  Car,
  Plane,
  Bus,
  MapPin,
  Route,
  Calculator,
} from "lucide-react";

const locationSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  address: z.string().optional(),
});

const personalVehicleSchema = z.object({
  vehicle: z.object({
    make: z.string().min(1, "Make is required"),
    model: z.string().min(1, "Model is required"),
    year: z
      .number()
      .min(1990)
      .max(new Date().getFullYear() + 1),
    fuelType: z.enum(["gasoline", "diesel", "electric", "hybrid"]),
    fuelEfficiency: z.number().min(0.1, "Fuel efficiency must be positive"),
    vehicleType: z.enum([
      "compact",
      "midsize",
      "large",
      "suv",
      "truck",
      "motorcycle",
    ]),
  }),
  trips: z
    .array(
      z.object({
        distance: z.number().min(0).optional(),
        origin: locationSchema.optional(),
        destination: locationSchema.optional(),
        passengers: z.number().min(1).optional(),
        trafficCondition: z.enum(["light", "moderate", "heavy"]).optional(),
        drivingStyle: z.enum(["eco", "normal", "aggressive"]).optional(),
      })
    )
    .min(1, "At least one trip is required"),
});

const flightSchema = z.object({
  origin: z.string().min(1, "Origin is required"),
  destination: z.string().min(1, "Destination is required"),
  class: z.enum(["economy", "premium_economy", "business", "first"]),
  roundTrip: z.boolean(),
});

const publicTransportSchema = z.object({
  mode: z.enum(["bus", "train", "metro", "tram", "ferry"]),
  distance: z.number().min(0, "Distance must be positive"),
  region: z.string().min(1, "Region is required"),
});

const transportationFormSchema = z.object({
  personalVehicle: personalVehicleSchema.optional(),
  flights: z.array(flightSchema).optional(),
  publicTransport: z.array(publicTransportSchema).optional(),
});

type TransportationFormData = z.infer<typeof transportationFormSchema>;

interface TransportationResult {
  totalEmissions: number;
  breakdown: {
    personalVehicle: number;
    flights: number;
    publicTransport: number;
    ridesharing: number;
  };
  details: any[];
  recommendations?: any;
}

export function TransportationCalculatorForm() {
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<TransportationResult | null>(null);
  const [activeTab, setActiveTab] = useState("personal-vehicle");
  const [useRouteCalculation, setUseRouteCalculation] = useState(false);

  const form = useForm<TransportationFormData>({
    resolver: zodResolver(transportationFormSchema),
    defaultValues: {
      personalVehicle: {
        vehicle: {
          make: "",
          model: "",
          year: new Date().getFullYear(),
          fuelType: "gasoline",
          fuelEfficiency: 12,
          vehicleType: "midsize",
        },
        trips: [
          {
            distance: 0,
            passengers: 1,
            trafficCondition: "moderate",
            drivingStyle: "normal",
          },
        ],
      },
      flights: [],
      publicTransport: [],
    },
  });

  const onSubmit = async (data: TransportationFormData) => {
    setIsCalculating(true);
    try {
      const response = await fetch("/api/carbon/transportation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Failed to calculate transportation emissions");
      }

      const result = await response.json();
      setResult(result);
      toast.success("Transportation emissions calculated successfully!");
    } catch (error) {
      toast.error("Failed to calculate transportation emissions");
    } finally {
      setIsCalculating(false);
    }
  };

  const calculateDistance = async (origin: string, destination: string) => {
    try {
      const response = await fetch("/api/carbon/transportation/distance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "geocode",
          address: origin,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to geocode address");
      }

      const originResult = await response.json();

      const destResponse = await fetch("/api/carbon/transportation/distance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "geocode",
          address: destination,
        }),
      });

      if (!destResponse.ok) {
        throw new Error("Failed to geocode destination");
      }

      const destResult = await destResponse.json();

      const routeResponse = await fetch("/api/carbon/transportation/distance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: "route",
          origin: originResult.location,
          destination: destResult.location,
          options: { mode: "driving" },
        }),
      });

      if (!routeResponse.ok) {
        throw new Error("Failed to calculate route");
      }

      const routeResult = await routeResponse.json();
      return routeResult.distance;
    } catch (error) {
      toast.error("Failed to calculate distance");
      return null;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5" />
            Transportation Carbon Calculator
          </CardTitle>
          <CardDescription>
            Calculate emissions from personal vehicles, flights, and public
            transport
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger
                    value="personal-vehicle"
                    className="flex items-center gap-2"
                  >
                    <Car className="h-4 w-4" />
                    Personal Vehicle
                  </TabsTrigger>
                  <TabsTrigger
                    value="flights"
                    className="flex items-center gap-2"
                  >
                    <Plane className="h-4 w-4" />
                    Flights
                  </TabsTrigger>
                  <TabsTrigger
                    value="public-transport"
                    className="flex items-center gap-2"
                  >
                    <Bus className="h-4 w-4" />
                    Public Transport
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="personal-vehicle" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Vehicle Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="personalVehicle.vehicle.make"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Make</FormLabel>
                              <FormControl>
                                <Input placeholder="Toyota" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="personalVehicle.vehicle.model"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Model</FormLabel>
                              <FormControl>
                                <Input placeholder="Camry" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="personalVehicle.vehicle.year"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Year</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) =>
                                    field.onChange(parseInt(e.target.value))
                                  }
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="personalVehicle.vehicle.fuelType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Fuel Type</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select fuel type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="gasoline">
                                    Gasoline
                                  </SelectItem>
                                  <SelectItem value="diesel">Diesel</SelectItem>
                                  <SelectItem value="electric">
                                    Electric
                                  </SelectItem>
                                  <SelectItem value="hybrid">Hybrid</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="personalVehicle.vehicle.vehicleType"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Vehicle Type</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="compact">
                                    Compact
                                  </SelectItem>
                                  <SelectItem value="midsize">
                                    Midsize
                                  </SelectItem>
                                  <SelectItem value="large">Large</SelectItem>
                                  <SelectItem value="suv">SUV</SelectItem>
                                  <SelectItem value="truck">Truck</SelectItem>
                                  <SelectItem value="motorcycle">
                                    Motorcycle
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="personalVehicle.vehicle.fuelEfficiency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Fuel Efficiency (km/L or km/kWh for electric)
                            </FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                step="0.1"
                                {...field}
                                onChange={(e) =>
                                  field.onChange(parseFloat(e.target.value))
                                }
                              />
                            </FormControl>
                            <FormDescription>
                              Average fuel efficiency of your vehicle
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Route className="h-4 w-4" />
                        Trip Information
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="route-calculation"
                          checked={useRouteCalculation}
                          onCheckedChange={setUseRouteCalculation}
                        />
                        <label htmlFor="route-calculation" className="text-sm">
                          Use route calculation (requires origin/destination)
                        </label>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="personalVehicle.trips.0.distance"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Distance (km)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.1"
                                  disabled={useRouteCalculation}
                                  {...field}
                                  onChange={(e) =>
                                    field.onChange(parseFloat(e.target.value))
                                  }
                                />
                              </FormControl>
                              <FormDescription>
                                {useRouteCalculation
                                  ? "Will be calculated from route"
                                  : "Total distance traveled"}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="personalVehicle.trips.0.passengers"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Passengers</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min="1"
                                  {...field}
                                  onChange={(e) =>
                                    field.onChange(parseInt(e.target.value))
                                  }
                                />
                              </FormControl>
                              <FormDescription>
                                Total number of people in the vehicle
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="personalVehicle.trips.0.trafficCondition"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Traffic Condition</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select condition" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="light">
                                    Light Traffic
                                  </SelectItem>
                                  <SelectItem value="moderate">
                                    Moderate Traffic
                                  </SelectItem>
                                  <SelectItem value="heavy">
                                    Heavy Traffic
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="personalVehicle.trips.0.drivingStyle"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Driving Style</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select style" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="eco">
                                    Eco-friendly
                                  </SelectItem>
                                  <SelectItem value="normal">Normal</SelectItem>
                                  <SelectItem value="aggressive">
                                    Aggressive
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="flights" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Flight Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="flights.0.origin"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Origin</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="JFK or New York"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Airport code or city name
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="flights.0.destination"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Destination</FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="LAX or Los Angeles"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Airport code or city name
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="flights.0.class"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Class</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select class" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="economy">
                                    Economy
                                  </SelectItem>
                                  <SelectItem value="premium_economy">
                                    Premium Economy
                                  </SelectItem>
                                  <SelectItem value="business">
                                    Business
                                  </SelectItem>
                                  <SelectItem value="first">
                                    First Class
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="flights.0.roundTrip"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  Round Trip
                                </FormLabel>
                                <FormDescription>
                                  Is this a round trip flight?
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="public-transport" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Public Transport Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="publicTransport.0.mode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transport Mode</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select mode" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="bus">Bus</SelectItem>
                                  <SelectItem value="train">Train</SelectItem>
                                  <SelectItem value="metro">
                                    Metro/Subway
                                  </SelectItem>
                                  <SelectItem value="tram">Tram</SelectItem>
                                  <SelectItem value="ferry">Ferry</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="publicTransport.0.distance"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Distance (km)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.1"
                                  {...field}
                                  onChange={(e) =>
                                    field.onChange(parseFloat(e.target.value))
                                  }
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="publicTransport.0.region"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Region</FormLabel>
                              <FormControl>
                                <Input placeholder="US, EU, Asia" {...field} />
                              </FormControl>
                              <FormDescription>
                                Region for emission factors
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <Button type="submit" disabled={isCalculating} className="w-full">
                {isCalculating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Calculating...
                  </>
                ) : (
                  <>
                    <Calculator className="mr-2 h-4 w-4" />
                    Calculate Transportation Emissions
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Transportation Emissions Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {result.totalEmissions.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">
                  kg CO₂e Total
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {result.breakdown.personalVehicle.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">
                  Personal Vehicle
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {result.breakdown.flights.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">Flights</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {result.breakdown.publicTransport.toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">
                  Public Transport
                </div>
              </div>
            </div>

            <Separator />

            {result.recommendations && (
              <div>
                <h4 className="font-semibold mb-2">Recommendations</h4>
                <div className="space-y-2">
                  {result.recommendations.recommendations.map(
                    (rec: any, index: number) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-muted rounded-lg"
                      >
                        <div>
                          <div className="font-medium">{rec.description}</div>
                          <div className="text-sm text-muted-foreground">
                            Potential savings: {rec.potentialSavings.toFixed(1)}{" "}
                            kg CO₂e/year
                          </div>
                        </div>
                        <Badge variant="secondary">
                          {rec.paybackPeriod
                            ? `${rec.paybackPeriod} years`
                            : "Immediate"}
                        </Badge>
                      </div>
                    )
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
