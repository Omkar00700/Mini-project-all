"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  CheckCircle2,
  Circle,
  ArrowRight,
  Leaf,
  Calculator,
  Target,
  BarChart3,
} from "lucide-react";
import { toast } from "sonner";

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  action: string;
  href: string;
  completed: boolean;
  icon: React.ReactNode;
}

export function OnboardingFlow() {
  const { user } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [isVisible, setIsVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (user) {
      const onboardingKey = `onboarding_completed_${user.id}`;
      const completed = localStorage.getItem(onboardingKey);

      if (!completed) {
        const progressKey = `onboarding_progress_${user.id}`;
        const savedProgress = localStorage.getItem(progressKey);
        if (savedProgress) {
          setCurrentStep(parseInt(savedProgress, 10));
        }
        setIsVisible(true);
      }
    }
  }, [user]);

  const steps: OnboardingStep[] = [
    {
      id: "welcome",
      title: "Welcome to Aura!",
      description:
        "Your personal carbon footprint tracker. Let's get you started on your sustainability journey.",
      action: "Let's Begin",
      href: "#",
      completed: false,
      icon: <Leaf className="h-6 w-6" />,
    },
    {
      id: "profile",
      title: "Complete Your Profile",
      description:
        "Add your location and household details for personalized insights and accurate calculations.",
      action: "Update Profile",
      href: "/settings?tab=profile",
      completed: false,
      icon: <Target className="h-6 w-6" />,
    },
    {
      id: "calculate",
      title: "Calculate Your Footprint",
      description:
        "Use our calculator to measure your current carbon emissions across transportation, energy, and food.",
      action: "Start Calculator",
      href: "/calculator",
      completed: false,
      icon: <Calculator className="h-6 w-6" />,
    },
    {
      id: "set-goal",
      title: "Set Your First Goal",
      description:
        "Create a reduction target and track your progress towards a more sustainable lifestyle.",
      action: "Set Goal",
      href: "/goals?action=create",
      completed: false,
      icon: <Target className="h-6 w-6" />,
    },
    {
      id: "explore",
      title: "Explore Analytics",
      description:
        "View your dashboard to understand your emissions breakdown and get AI-powered recommendations.",
      action: "View Dashboard",
      href: "/dashboard",
      completed: false,
      icon: <BarChart3 className="h-6 w-6" />,
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      const nextStep = currentStep + 1;
      setCurrentStep(nextStep);
      if (user) {
        localStorage.setItem(
          `onboarding_progress_${user.id}`,
          String(nextStep)
        );
      }
    } else {
      handleComplete();
    }
  };

  const handleSkip = () => {
    setIsVisible(false);
    toast.info("You can complete onboarding anytime from Settings");
  };

  const handleComplete = () => {
    if (user) {
      localStorage.setItem(`onboarding_completed_${user.id}`, "true");
    }
    setIsVisible(false);
    toast.success("You're all set! Start tracking your carbon footprint.");
  };

  const handleAction = (href: string) => {
    if (href && href !== "#") {
      handleNext();
      router.push(href);
    } else {
      handleNext();
    }
  };

  if (!isVisible) return null;

  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-lg shadow-2xl border-0">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto mb-4 p-3 bg-emerald-100 rounded-full w-fit">
            {step.icon}
          </div>
          <div className="flex items-center justify-center gap-2 mb-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full transition-all ${
                  index <= currentStep
                    ? "bg-emerald-500 w-6"
                    : "bg-gray-200 w-2"
                }`}
              />
            ))}
          </div>
          <CardTitle className="text-2xl">{step.title}</CardTitle>
          <CardDescription className="text-base mt-2">
            {step.description}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>
                Step {currentStep + 1} of {steps.length}
              </span>
              <span>{Math.round(progress)}% complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="ghost" onClick={handleSkip} className="flex-1">
              Skip for now
            </Button>
            <Button
              onClick={() => handleAction(step.href)}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
            >
              {step.action}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function OnboardingChecklist() {
  const { user } = useAuth();
  const [items, setItems] = useState([
    { id: "profile", label: "Complete your profile", done: false },
    { id: "first-calc", label: "Calculate your footprint", done: false },
    { id: "first-goal", label: "Set a reduction goal", done: false },
    { id: "first-activity", label: "Log an activity", done: false },
  ]);

  useEffect(() => {
    if (user) {
      const storageKey = `checklist_${user.id}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setItems(JSON.parse(saved));
      }
    }
  }, [user]);

  const completedCount = items.filter((i) => i.done).length;
  const isComplete = completedCount === items.length;

  if (isComplete) return null;

  return (
    <Card className="border-emerald-200 bg-emerald-50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Target className="h-5 w-5 text-emerald-600" />
          Getting Started
        </CardTitle>
        <CardDescription>
          {completedCount} of {items.length} tasks completed
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress
          value={(completedCount / items.length) * 100}
          className="h-2 mb-4"
        />
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-center gap-2 text-sm">
              {item.done ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              ) : (
                <Circle className="h-4 w-4 text-gray-300" />
              )}
              <span
                className={
                  item.done ? "text-muted-foreground line-through" : ""
                }
              >
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
