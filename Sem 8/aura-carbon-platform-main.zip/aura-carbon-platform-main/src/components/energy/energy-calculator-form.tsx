"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

interface EnergyCalculationResult {
  totalEmissions: number;
  breakdown: {
    electricity: number;
    heating: number;
    cooling: number;
    renewableCredits: number;
  };
  recommendations: string[];
  userRecommendations?: Array<{
    title: string;
    description: string;
    category: string;
    impactEstimate: number;
    costEstimate?: number;
    difficultyScore: number;
  }>;
}

export function EnergyCalculatorForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<EnergyCalculationResult | null>(null);

  const [electricityData, setElectricityData] = useState({
    consumption: "",
    gridRegion: "US",
    renewablePercentage: "",
  });

  const [heatingData, setHeatingData] = useState({
    naturalGas: "",
    heatingOil: "",
    propane: "",
    systemEfficiency: "",
  });

  const [coolingData, setCoolingData] = useState({
    electricity: "",
    systemType: "central_ac",
    seer: "",
    climateZone: "",
  });

  const [renewableData, setRenewableData] = useState({
    solarGenerated: "",
    windGenerated: "",
    batteryCapacity: "",
    batteryEfficiency: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const requestData: any = {};

      if (electricityData.consumption) {
        requestData.electricity = {
          consumption: parseFloat(electricityData.consumption),
          gridRegion: electricityData.gridRegion,
          ...(electricityData.renewablePercentage && {
            renewablePercentage: parseFloat(
              electricityData.renewablePercentage
            ),
          }),
        };
      }

      const heatingFields = Object.entries(heatingData).filter(
        ([key, value]) => value && key !== "systemEfficiency"
      );
      if (heatingFields.length > 0) {
        requestData.heating = {};
        heatingFields.forEach(([key, value]) => {
          requestData.heating[key] = parseFloat(value as string);
        });
        if (heatingData.systemEfficiency) {
          requestData.heating.systemEfficiency =
            parseFloat(heatingData.systemEfficiency) / 100;
        }
      }

      if (coolingData.electricity) {
        requestData.cooling = {
          electricity: parseFloat(coolingData.electricity),
          systemType: coolingData.systemType,
          ...(coolingData.seer && { seer: parseFloat(coolingData.seer) }),
          ...(coolingData.climateZone && {
            climateZone: coolingData.climateZone,
          }),
        };
      }

      const renewableFields = Object.entries(renewableData).filter(
        ([key, value]) => value && !key.includes("battery")
      );
      if (renewableFields.length > 0 || renewableData.batteryCapacity) {
        requestData.renewable = {};
        renewableFields.forEach(([key, value]) => {
          requestData.renewable[key] = parseFloat(value as string);
        });
        if (renewableData.batteryCapacity) {
          requestData.renewable.batteryStorage = {
            capacity: parseFloat(renewableData.batteryCapacity),
            cycleEfficiency: renewableData.batteryEfficiency
              ? parseFloat(renewableData.batteryEfficiency) / 100
              : 0.9,
          };
        }
      }

      const response = await fetch("/api/carbon/energy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.error || "Failed to calculate energy emissions"
        );
      }

      const data = await response.json();
      setResult(data);
      toast.success("Energy emissions calculated successfully!");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to calculate energy emissions"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const formatEmissions = (emissions: number) => {
    return `${emissions.toFixed(1)} kg CO₂e`;
  };

  const getDifficultyColor = (score: number) => {
    if (score <= 2) return "bg-green-100 text-green-800";
    if (score <= 3) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getDifficultyText = (score: number) => {
    if (score <= 2) return "Easy";
    if (score <= 3) return "Medium";
    return "Hard";
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Energy Consumption Calculator</CardTitle>
          <CardDescription>
            Calculate your carbon footprint from electricity, heating, cooling,
            and renewable energy sources.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <Tabs defaultValue="electricity" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="electricity">Electricity</TabsTrigger>
                <TabsTrigger value="heating">Heating</TabsTrigger>
                <TabsTrigger value="cooling">Cooling</TabsTrigger>
                <TabsTrigger value="renewable">Renewable</TabsTrigger>
              </TabsList>

              <TabsContent value="electricity" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="electricity-consumption">
                      Monthly Consumption (kWh)
                    </Label>
                    <Input
                      id="electricity-consumption"
                      type="number"
                      placeholder="e.g., 1000"
                      value={electricityData.consumption}
                      onChange={(e) =>
                        setElectricityData((prev) => ({
                          ...prev,
                          consumption: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="grid-region">Grid Region</Label>
                    <Select
                      value={electricityData.gridRegion}
                      onValueChange={(value) =>
                        setElectricityData((prev) => ({
                          ...prev,
                          gridRegion: value,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="US">United States</SelectItem>
                        <SelectItem value="EU">European Union</SelectItem>
                        <SelectItem value="UK">United Kingdom</SelectItem>
                        <SelectItem value="global">Global Average</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="renewable-percentage">
                      Renewable Percentage (%)
                    </Label>
                    <Input
                      id="renewable-percentage"
                      type="number"
                      placeholder="e.g., 30"
                      min="0"
                      max="100"
                      value={electricityData.renewablePercentage}
                      onChange={(e) =>
                        setElectricityData((prev) => ({
                          ...prev,
                          renewablePercentage: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="heating" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="natural-gas">Natural Gas (kWh/month)</Label>
                    <Input
                      id="natural-gas"
                      type="number"
                      placeholder="e.g., 500"
                      value={heatingData.naturalGas}
                      onChange={(e) =>
                        setHeatingData((prev) => ({
                          ...prev,
                          naturalGas: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="heating-oil">
                      Heating Oil (liters/month)
                    </Label>
                    <Input
                      id="heating-oil"
                      type="number"
                      placeholder="e.g., 100"
                      value={heatingData.heatingOil}
                      onChange={(e) =>
                        setHeatingData((prev) => ({
                          ...prev,
                          heatingOil: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="propane">Propane (kg/month)</Label>
                    <Input
                      id="propane"
                      type="number"
                      placeholder="e.g., 50"
                      value={heatingData.propane}
                      onChange={(e) =>
                        setHeatingData((prev) => ({
                          ...prev,
                          propane: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="system-efficiency">
                      System Efficiency (%)
                    </Label>
                    <Input
                      id="system-efficiency"
                      type="number"
                      placeholder="e.g., 85"
                      min="50"
                      max="100"
                      value={heatingData.systemEfficiency}
                      onChange={(e) =>
                        setHeatingData((prev) => ({
                          ...prev,
                          systemEfficiency: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="cooling" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="cooling-electricity">
                      Electricity Usage (kWh/month)
                    </Label>
                    <Input
                      id="cooling-electricity"
                      type="number"
                      placeholder="e.g., 300"
                      value={coolingData.electricity}
                      onChange={(e) =>
                        setCoolingData((prev) => ({
                          ...prev,
                          electricity: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="system-type">System Type</Label>
                    <Select
                      value={coolingData.systemType}
                      onValueChange={(value) =>
                        setCoolingData((prev) => ({
                          ...prev,
                          systemType: value,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="central_ac">Central AC</SelectItem>
                        <SelectItem value="window_ac">Window AC</SelectItem>
                        <SelectItem value="heat_pump">Heat Pump</SelectItem>
                        <SelectItem value="evaporative">
                          Evaporative Cooler
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seer">SEER Rating</Label>
                    <Input
                      id="seer"
                      type="number"
                      placeholder="e.g., 16"
                      min="8"
                      max="30"
                      value={coolingData.seer}
                      onChange={(e) =>
                        setCoolingData((prev) => ({
                          ...prev,
                          seer: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="climate-zone">Climate Zone</Label>
                    <Select
                      value={coolingData.climateZone}
                      onValueChange={(value) =>
                        setCoolingData((prev) => ({
                          ...prev,
                          climateZone: value,
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select climate zone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hot_humid">Hot & Humid</SelectItem>
                        <SelectItem value="hot_dry">Hot & Dry</SelectItem>
                        <SelectItem value="mixed_humid">Mixed Humid</SelectItem>
                        <SelectItem value="mixed_dry">Mixed Dry</SelectItem>
                        <SelectItem value="cold">Cold</SelectItem>
                        <SelectItem value="very_cold">Very Cold</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="renewable" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="solar-generated">
                      Solar Generated (kWh/month)
                    </Label>
                    <Input
                      id="solar-generated"
                      type="number"
                      placeholder="e.g., 800"
                      value={renewableData.solarGenerated}
                      onChange={(e) =>
                        setRenewableData((prev) => ({
                          ...prev,
                          solarGenerated: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wind-generated">
                      Wind Generated (kWh/month)
                    </Label>
                    <Input
                      id="wind-generated"
                      type="number"
                      placeholder="e.g., 200"
                      value={renewableData.windGenerated}
                      onChange={(e) =>
                        setRenewableData((prev) => ({
                          ...prev,
                          windGenerated: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="battery-capacity">
                      Battery Capacity (kWh)
                    </Label>
                    <Input
                      id="battery-capacity"
                      type="number"
                      placeholder="e.g., 13.5"
                      value={renewableData.batteryCapacity}
                      onChange={(e) =>
                        setRenewableData((prev) => ({
                          ...prev,
                          batteryCapacity: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="battery-efficiency">
                      Battery Efficiency (%)
                    </Label>
                    <Input
                      id="battery-efficiency"
                      type="number"
                      placeholder="e.g., 90"
                      min="70"
                      max="100"
                      value={renewableData.batteryEfficiency}
                      onChange={(e) =>
                        setRenewableData((prev) => ({
                          ...prev,
                          batteryEfficiency: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? "Calculating..." : "Calculate Energy Emissions"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {result && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Energy Emissions Results</CardTitle>
              <CardDescription>
                Your calculated carbon footprint from energy consumption
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">
                  {formatEmissions(result.totalEmissions)}
                </div>
                <p className="text-sm text-muted-foreground">
                  Total Monthly Emissions
                </p>
              </div>

              <Separator />

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {formatEmissions(result.breakdown.electricity)}
                  </div>
                  <p className="text-sm text-muted-foreground">Electricity</p>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {formatEmissions(result.breakdown.heating)}
                  </div>
                  <p className="text-sm text-muted-foreground">Heating</p>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold">
                    {formatEmissions(result.breakdown.cooling)}
                  </div>
                  <p className="text-sm text-muted-foreground">Cooling</p>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold text-green-600">
                    {formatEmissions(result.breakdown.renewableCredits)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Renewable Credits
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {result.userRecommendations &&
            result.userRecommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Personalized Recommendations</CardTitle>
                  <CardDescription>
                    Actions you can take to reduce your energy emissions
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.userRecommendations.map((rec, index) => (
                    <div
                      key={index}
                      className="border rounded-lg p-4 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">{rec.title}</h4>
                        <div className="flex items-center gap-2">
                          <Badge
                            className={getDifficultyColor(rec.difficultyScore)}
                          >
                            {getDifficultyText(rec.difficultyScore)}
                          </Badge>
                          <Badge variant="outline">
                            {formatEmissions(rec.impactEstimate)} savings
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {rec.description}
                      </p>
                      {rec.costEstimate && (
                        <p className="text-sm font-medium">
                          Estimated cost: ${rec.costEstimate.toLocaleString()}
                        </p>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

          {result.recommendations && result.recommendations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>General Recommendations</CardTitle>
                <CardDescription>
                  Additional ways to improve your energy efficiency
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.recommendations.map((rec, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span className="text-sm">{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
