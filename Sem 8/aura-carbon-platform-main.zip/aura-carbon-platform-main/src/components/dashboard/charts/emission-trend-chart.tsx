"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { useState } from "react";

interface TrendData {
  date: string;
  total: number;
  transportation: number;
  energy: number;
  food: number;
  consumption: number;
  waste: number;
  target?: number;
}

interface EmissionTrendChartProps {
  data: TrendData[];
  period: "week" | "month" | "year";
  showTarget?: boolean;
  showCategories?: boolean;
  className?: string;
}

const CATEGORY_COLORS = {
  total: "#1f2937",
  transportation: "#ef4444",
  energy: "#f59e0b",
  food: "#10b981",
  consumption: "#3b82f6",
  waste: "#8b5cf6",
  target: "#6b7280",
};

export function EmissionTrendChart({
  data,
  period,
  showTarget = true,
  showCategories = false,
  className,
}: EmissionTrendChartProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([
    "total",
  ]);
  const [chartType, setChartType] = useState<"line" | "area">("line");

  const formatValue = (value: number) => {
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}t`;
    }
    return `${value.toFixed(0)}kg`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    switch (period) {
      case "week":
        return date.toLocaleDateString("en-US", { weekday: "short" });
      case "month":
        return date.toLocaleDateString("en-US", { day: "numeric" });
      case "year":
        return date.toLocaleDateString("en-US", { month: "short" });
      default:
        return dateStr;
    }
  };

  const calculateTrend = () => {
    if (data.length < 2) return null;

    const latest = data[data.length - 1].total;
    const previous = data[data.length - 2].total;
    const change = ((latest - previous) / previous) * 100;

    return {
      value: change,
      isPositive: change > 0,
      isNeutral: Math.abs(change) < 1,
    };
  };

  const trend = calculateTrend();

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg shadow-lg p-3">
          <p className="font-medium mb-2">{formatDate(label)}</p>
          {payload.map((entry: any, index: number) => (
            <div
              key={index}
              className="flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm capitalize">{entry.dataKey}</span>
              </div>
              <span className="text-sm font-medium">
                {formatValue(entry.value)} CO₂e
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  const categories = [
    "total",
    "transportation",
    "energy",
    "food",
    "consumption",
    "waste",
  ];

  return (
    <div className={className}>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Emission Trends</h3>
          <div className="flex items-center gap-2">
            <p className="text-sm text-muted-foreground">
              {period === "week"
                ? "Daily"
                : period === "month"
                  ? "Weekly"
                  : "Monthly"}{" "}
              emissions
            </p>
            {trend && (
              <Badge
                variant={
                  trend.isNeutral
                    ? "secondary"
                    : trend.isPositive
                      ? "destructive"
                      : "default"
                }
                className="text-xs"
              >
                {trend.isNeutral ? (
                  <Minus className="w-3 h-3 mr-1" />
                ) : trend.isPositive ? (
                  <TrendingUp className="w-3 h-3 mr-1" />
                ) : (
                  <TrendingDown className="w-3 h-3 mr-1" />
                )}
                {trend.isNeutral
                  ? "Stable"
                  : `${Math.abs(trend.value).toFixed(1)}%`}
              </Badge>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={chartType === "line" ? "default" : "outline"}
            size="sm"
            onClick={() => setChartType("line")}
          >
            Line
          </Button>
          <Button
            variant={chartType === "area" ? "default" : "outline"}
            size="sm"
            onClick={() => setChartType("area")}
          >
            Area
          </Button>
        </div>
      </div>

      {}
      {showCategories && (
        <div className="flex flex-wrap gap-2 mb-4">
          {categories.map((category) => (
            <Button
              key={category}
              variant={
                selectedCategories.includes(category) ? "default" : "outline"
              }
              size="sm"
              onClick={() => toggleCategory(category)}
              className="text-xs"
            >
              <div
                className="w-2 h-2 rounded-full mr-2"
                style={{
                  backgroundColor:
                    CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS],
                }}
              />
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>
      )}

      {}
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === "area" ? (
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis
                dataKey="date"
                tickFormatter={formatDate}
                className="text-xs"
              />
              <YAxis tickFormatter={formatValue} className="text-xs" />
              <Tooltip content={<CustomTooltip />} />

              {selectedCategories.map((category) => (
                <Area
                  key={category}
                  type="monotone"
                  dataKey={category}
                  stackId="1"
                  stroke={
                    CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS]
                  }
                  fill={
                    CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS]
                  }
                  fillOpacity={0.6}
                />
              ))}

              {showTarget && (
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke={CATEGORY_COLORS.target}
                  strokeDasharray="5 5"
                  dot={false}
                />
              )}
            </AreaChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis
                dataKey="date"
                tickFormatter={formatDate}
                className="text-xs"
              />
              <YAxis tickFormatter={formatValue} className="text-xs" />
              <Tooltip content={<CustomTooltip />} />

              {selectedCategories.map((category) => (
                <Line
                  key={category}
                  type="monotone"
                  dataKey={category}
                  stroke={
                    CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS]
                  }
                  strokeWidth={category === "total" ? 3 : 2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              ))}

              {showTarget && (
                <Line
                  type="monotone"
                  dataKey="target"
                  stroke={CATEGORY_COLORS.target}
                  strokeDasharray="5 5"
                  dot={false}
                />
              )}
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
