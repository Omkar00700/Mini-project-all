"use client";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import {
  TrendingUp,
  TrendingDown,
  PieChart as PieChartIcon,
} from "lucide-react";
import { motion } from "framer-motion";

interface EmissionData {
  category: string;
  value: number;
  percentage: number;
  color: string;
  trend?: number;
}

interface EmissionBreakdownChartProps {
  data: EmissionData[];
  totalEmissions: number;
  period: string;
  className?: string;
}

const COLORS = {
  transportation: "#ef4444",
  energy: "#f59e0b",
  food: "#10b981",
  consumption: "#3b82f6",
  waste: "#8b5cf6",
};

export function EmissionBreakdownChart({
  data,
  totalEmissions,
  period,
  className,
}: EmissionBreakdownChartProps) {
  const formatValue = (value: number) => {
    if (value >= 1000) {
      return `${(value / 1000).toFixed(1)}t`;
    }
    return `${value.toFixed(0)}kg`;
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border rounded-lg shadow-lg p-3">
          <p className="font-medium">{data.category}</p>
          <p className="text-sm text-muted-foreground">
            {formatValue(data.value)} CO₂e ({data.percentage.toFixed(1)}%)
          </p>
          {data.trend !== undefined && (
            <div className="flex items-center gap-1 text-xs">
              {data.trend > 0 ? (
                <TrendingUp className="w-3 h-3 text-red-500" />
              ) : (
                <TrendingDown className="w-3 h-3 text-green-500" />
              )}
              <span
                className={data.trend > 0 ? "text-red-500" : "text-green-500"}
              >
                {Math.abs(data.trend).toFixed(1)}% vs last {period}
              </span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const CustomLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percentage,
  }: any) => {
    if (percentage < 5) return null;

    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
        className="text-xs font-medium"
      >
        {`${percentage.toFixed(0)}%`}
      </text>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`relative rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5 overflow-hidden p-6 ${className || ""}`}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent opacity-50" />

      <div className="relative z-10 flex items-center justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <PieChartIcon className="w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold tracking-tight">
              Emissions by Category
            </h3>
          </div>
          <p className="text-sm text-muted-foreground">
            Total of {formatValue(totalEmissions)} CO₂e this {period}
          </p>
        </div>
      </div>

      <div className="relative z-10 flex flex-col gap-6">
        {}
        <div className="h-48 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                innerRadius={60}
                outerRadius={90}
                fill="#8884d8"
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    className="hover:opacity-80 transition-opacity cursor-pointer stroke-background stroke-2"
                  />
                ))}
              </Pie>
              <Tooltip
                content={<CustomTooltip />}
                cursor={{ fill: "transparent" }}
              />
            </PieChart>
          </ResponsiveContainer>
          {}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-2xl font-bold text-foreground">
              {data.length}
            </span>
            <span className="text-xs text-muted-foreground uppercase tracking-wider">
              Sources
            </span>
          </div>
        </div>

        {}
        <div className="space-y-4">
          {data.map((item, i) => (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 }}
              key={item.category}
              className="group flex items-center justify-between p-3 rounded-2xl hover:bg-secondary/50 transition-colors border border-transparent hover:border-border/50"
            >
              <div className="flex items-center gap-4">
                <div
                  className="w-10 h-10 rounded-xl shadow-sm flex items-center justify-center relative overflow-hidden"
                  style={{ backgroundColor: `${item.color}20` }}
                >
                  <div className="absolute inset-0 opacity-20 bg-gradient-to-br from-white to-transparent" />
                  <div
                    className="w-3 h-3 rounded-full shadow-inner"
                    style={{ backgroundColor: item.color }}
                  />
                </div>
                <div>
                  <p className="font-semibold capitalize text-foreground/90 group-hover:text-foreground transition-colors">
                    {item.category}
                  </p>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-mono text-muted-foreground">
                      {item.percentage.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <p className="font-bold text-lg">{formatValue(item.value)}</p>
                {item.trend !== undefined && (
                  <div
                    className={`text-xs font-semibold flex items-center justify-end gap-1 ${item.trend > 0 ? "text-red-500" : "text-emerald-500"}`}
                  >
                    {item.trend > 0 ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    {Math.abs(item.trend).toFixed(1)}%
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
