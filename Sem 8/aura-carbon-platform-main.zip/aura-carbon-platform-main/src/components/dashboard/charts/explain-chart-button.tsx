"use client";

import { useState } from "react";
import { Sparkles, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { motion, AnimatePresence } from "framer-motion";

interface ExplainChartButtonProps {
  chartType:
    | "Monthly Emissions Trend"
    | "Emission Breakdown"
    | "AI Predictions";
  data: any;
  className?: string;
  variant?: "default" | "outline" | "ghost" | "secondary";
  size?: "default" | "sm" | "lg" | "icon";
}

export function ExplainChartButton({
  chartType,
  data,
  className,
  variant = "secondary",
  size = "sm",
}: ExplainChartButtonProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchExplanation = async () => {
    if (explanation) return;

    try {
      setLoading(true);
      setError(null);

      const res = await fetch("/api/ai/explain-chart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chartType, data }),
      });

      const json = await res.json();

      if (!res.ok || !json.success) {
        throw new Error(json.error || "Failed to generate explanation");
      }

      setExplanation(json.explanation);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const parseMarkdown = (text: string) => {
    return text.split("\n\n").map((paragraph, pIdx) => {
      const parts = paragraph.split(/\\*\\*(.*?)\\*\\*/g);

      return (
        <p
          key={pIdx}
          className="mb-4 text-sm leading-relaxed text-slate-700 dark:text-slate-300"
        >
          {parts.map((part, i) =>
            i % 2 === 1 ? (
              <strong key={i} className="text-foreground font-semibold">
                {part}
              </strong>
            ) : (
              part
            )
          )}
        </p>
      );
    });
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        setOpen(isOpen);
        if (isOpen) fetchExplanation();
      }}
    >
      <DialogTrigger asChild>
        <Button variant={variant} size={size} className={className}>
          <Sparkles className="w-4 h-4 mr-2 text-purple-500" />
          Explain this
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[500px] border-purple-500/20 bg-background/95 backdrop-blur-xl">
        <DialogHeader className="pb-2 border-b border-border/50">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <div className="p-1.5 rounded-lg bg-purple-500/10 text-purple-500">
              <Sparkles className="w-5 h-5" />
            </div>
            AI Insights: {chartType}
          </DialogTitle>
        </DialogHeader>

        <div className="pt-4 min-h-[150px] relative">
          <AnimatePresence mode="wait">
            {loading && (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center space-y-3"
              >
                <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
                <p className="text-sm text-muted-foreground animate-pulse">
                  Analyzing chart patterns...
                </p>
              </motion.div>
            )}

            {error && (
              <motion.div
                key="error"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center space-y-3 text-red-500"
              >
                <AlertCircle className="w-10 h-10" />
                <p className="text-sm font-medium">{error}</p>
                <Button variant="outline" size="sm" onClick={fetchExplanation}>
                  Try Again
                </Button>
              </motion.div>
            )}

            {explanation && !loading && !error && (
              <motion.div
                key="content"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="prose prose-sm dark:prose-invert max-w-none"
              >
                {parseMarkdown(explanation)}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
}
