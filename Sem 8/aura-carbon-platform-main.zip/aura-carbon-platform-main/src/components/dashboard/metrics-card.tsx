"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Target,
  Award,
  AlertTriangle,
} from "lucide-react";
import { motion } from "framer-motion";

const clampProgress = (value: number) => {
  if (Number.isNaN(value)) {
    return 0;
  }
  return Math.min(100, Math.max(0, value));
};

const ProgressBar = ({ value }: { value: number }) => {
  const clamped = clampProgress(value);
  return (
    <div className="relative h-2 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full bg-primary transition-all"
        style={{ width: `${clamped}%` }}
        role="progressbar"
        aria-valuenow={Math.round(clamped)}
        aria-valuemin={0}
        aria-valuemax={100}
      />
    </div>
  );
};

interface MetricsCardProps {
  title: string;
  value: number;
  unit: string;
  trend?: {
    value: number;
    period: string;
    isPositive?: boolean;
  };
  target?: {
    value: number;
    label: string;
  };
  progress?: number;
  status?: "good" | "warning" | "danger";
  icon?: React.ComponentType<{ className?: string }>;
  description?: string;
  className?: string;
}

export function MetricsCard({
  title,
  value,
  unit,
  trend,
  target,
  progress,
  status,
  icon: Icon,
  description,
  className,
}: MetricsCardProps) {
  const formatValue = (val: number) => {
    if (val >= 1000000) {
      return `${(val / 1000000).toFixed(1)}M`;
    }
    if (val >= 1000) {
      return `${(val / 1000).toFixed(1)}k`;
    }
    return val.toFixed(val < 10 ? 1 : 0);
  };

  const getStatusColor = () => {
    switch (status) {
      case "good":
        return "backdrop-blur-xl bg-background/50 border-emerald-500/20 shadow-[0_8px_30px_rgba(16,185,129,0.05)] hover:shadow-[0_8px_30px_rgba(16,185,129,0.1)] hover:bg-background/70";
      case "warning":
        return "backdrop-blur-xl bg-background/50 border-amber-500/20 shadow-[0_8px_30px_rgba(245,158,11,0.05)] hover:shadow-[0_8px_30px_rgba(245,158,11,0.1)] hover:bg-background/70";
      case "danger":
        return "backdrop-blur-xl bg-background/50 border-red-500/20 shadow-[0_8px_30px_rgba(239,68,68,0.05)] hover:shadow-[0_8px_30px_rgba(239,68,68,0.1)] hover:bg-background/70";
      default:
        return "backdrop-blur-xl bg-background/50 border-border/50 shadow-xl shadow-black/5 hover:border-emerald-500/30 hover:bg-background/70 hover:shadow-emerald-500/5";
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case "good":
        return <Award className="w-4 h-4" />;
      case "warning":
        return <AlertTriangle className="w-4 h-4" />;
      case "danger":
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getTrendIcon = () => {
    if (!trend) return null;

    if (Math.abs(trend.value) < 1) {
      return <Minus className="w-4 h-4" />;
    }

    return trend.value > 0 ? (
      <TrendingUp className="w-4 h-4" />
    ) : (
      <TrendingDown className="w-4 h-4" />
    );
  };

  const getTrendColor = () => {
    if (!trend) return "";

    if (Math.abs(trend.value) < 1) {
      return "text-muted-foreground";
    }

    const isGoodTrend =
      trend.isPositive !== undefined ? trend.isPositive : trend.value < 0;

    return isGoodTrend ? "text-green-600" : "text-red-600";
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="h-full"
    >
      <Card
        className={cn(
          "relative h-full transition-all duration-500 overflow-hidden",
          getStatusColor(),
          className
        )}
      >
        {}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent dark:from-white/5 hover:opacity-100 opacity-50 transition-opacity duration-500 rounded-xl" />

        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 relative z-10">
          <CardTitle className="text-sm font-medium text-foreground">
            {title}
          </CardTitle>
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            {Icon && <Icon className="h-5 w-5 text-emerald-500/70" />}
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-3">
            {}
            <div className="flex items-baseline gap-2">
              <div className="text-2xl font-bold">{formatValue(value)}</div>
              <div className="text-sm text-muted-foreground">{unit}</div>
            </div>

            {}
            {trend && (
              <div
                className={cn(
                  "flex items-center gap-1 text-xs",
                  getTrendColor()
                )}
              >
                {getTrendIcon()}
                <span>
                  {Math.abs(trend.value) < 1
                    ? "No change"
                    : `${trend.value > 0 ? "+" : ""}${trend.value.toFixed(1)}%`}{" "}
                  vs {trend.period}
                </span>
              </div>
            )}

            {}
            {target && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1">
                    <Target className="w-3 h-3" />
                    {target.label}
                  </span>
                  <span>
                    {formatValue(target.value)} {unit}
                  </span>
                </div>

                {progress !== undefined && <ProgressBar value={progress} />}
              </div>
            )}

            {}
            {description && (
              <p className="text-xs text-muted-foreground">{description}</p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function EmissionMetricsCard({
  period,
  emissions,
  target,
  previousPeriod,
  className,
}: {
  period: string;
  emissions: number;
  target?: number;
  previousPeriod?: number;
  className?: string;
}) {
  const trend = previousPeriod
    ? {
        value: ((emissions - previousPeriod) / previousPeriod) * 100,
        period: `last ${period}`,
      }
    : undefined;

  const progress = target
    ? Math.min((emissions / target) * 100, 100)
    : undefined;
  const status = target
    ? emissions <= target * 0.8
      ? "good"
      : emissions <= target
        ? "warning"
        : "danger"
    : undefined;

  return (
    <MetricsCard
      title={`${period} Emissions`}
      value={emissions}
      unit="kg CO₂e"
      trend={trend}
      target={target ? { value: target, label: `${period} Target` } : undefined}
      progress={progress}
      status={status}
      description={`Total carbon footprint for this ${period.toLowerCase()}`}
      className={className}
    />
  );
}

export function SavingsMetricsCard({
  period,
  savings,
  target,
  previousPeriod,
  className,
}: {
  period: string;
  savings: number;
  target?: number;
  previousPeriod?: number;
  className?: string;
}) {
  const trend = previousPeriod
    ? {
        value: ((savings - previousPeriod) / previousPeriod) * 100,
        period: `last ${period}`,
        isPositive: true,
      }
    : undefined;

  const progress = target ? Math.min((savings / target) * 100, 100) : undefined;
  const status = target
    ? savings >= target * 0.8
      ? "good"
      : savings >= target * 0.5
        ? "warning"
        : "danger"
    : undefined;

  return (
    <MetricsCard
      title={`${period} Savings`}
      value={savings}
      unit="kg CO₂e"
      trend={trend}
      target={target ? { value: target, label: `${period} Goal` } : undefined}
      progress={progress}
      status={status}
      description={`Carbon emissions saved this ${period.toLowerCase()}`}
      className={className}
    />
  );
}
