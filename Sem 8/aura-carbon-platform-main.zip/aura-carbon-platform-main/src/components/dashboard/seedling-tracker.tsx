"use client";

import { Leaf, Info, Zap } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface SeedlingTrackerProps {
  level: number;
  experience: number;
}

export function SeedlingTracker({ level, experience }: SeedlingTrackerProps) {
  const xpForNextLevel = level * 100;
  const currentLevelXp = experience % 100;
  const progressPercent = (currentLevelXp / 100) * 100;

  let phaseText = "Seed";
  if (level > 20) phaseText = "Mature Tree";
  else if (level > 10) phaseText = "Sapling";
  else if (level > 5) phaseText = "Sprout";

  return (
    <Card className="relative overflow-hidden group border-2 border-green-500/20 hover:border-green-500/40 transition-all duration-500">
      {}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-green-500/10 dark:bg-green-500/10 rounded-full blur-[60px] pointer-events-none transition-transform duration-1000 group-hover:scale-150" />

      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              Aura Entity
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-[200px] text-xs">
                      Your personal digital seedling. It grows as you log
                      sustainable activities and maintain streaks.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </CardTitle>
            <CardDescription>
              Visualizing your real-world impact
            </CardDescription>
          </div>
          <Badge
            variant="outline"
            className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20"
          >
            Lvl {level} {phaseText}
          </Badge>
        </div>
      </CardHeader>

      <CardContent>
        <div className="flex flex-col items-center justify-center py-6 gap-6 relative z-10">
          {}
          <div className="relative w-24 h-24 flex items-center justify-center animate-in fade-in zoom-in duration-1000">
            {}
            <div
              className="absolute inset-0 bg-green-500/5 rounded-full animate-ping opacity-20"
              style={{ animationDuration: "3s" }}
            />
            <div className="p-4 bg-green-100 dark:bg-green-500/20 rounded-full border border-green-500/20 shadow-lg shadow-green-500/10">
              <Leaf
                className={`text-green-600 dark:text-green-400 transition-all duration-700 ${level > 5 ? "w-16 h-16" : "w-10 h-10"}`}
                strokeWidth={level > 10 ? 2.5 : 2}
              />
            </div>
          </div>

          {}
          <div className="w-full flex flex-col gap-2">
            <div className="flex justify-between items-center text-sm font-medium">
              <span className="flex items-center gap-1 text-muted-foreground">
                <Zap className="w-3 h-3 text-yellow-500" /> {experience} Total
                XP
              </span>
              <span className="text-muted-foreground">
                {currentLevelXp} / 100 XP to Lvl {level + 1}
              </span>
            </div>
            <Progress value={progressPercent} className="h-2.5 bg-muted">
              <div
                className="h-full bg-gradient-to-r from-green-400 to-green-600 border-r border-white/20 transition-all duration-1000 ease-out"
                style={{ width: `${progressPercent}%` }}
              >
                {}
                <div className="w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
              </div>
            </Progress>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
