import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Dashboard } from "../dashboard";
import { useUIStore, useCarbonStore, useUserStore } from "@/store";

jest.mock("@/store");
const mockUseUIStore = useUIStore as jest.MockedFunction<typeof useUIStore>;
const mockUseCarbonStore = useCarbonStore as jest.MockedFunction<
  typeof useCarbonStore
>;
const mockUseUserStore = useUserStore as jest.MockedFunction<
  typeof useUserStore
>;

jest.mock("../charts/emission-breakdown-chart", () => ({
  EmissionBreakdownChart: ({ data, totalEmissions }: any) => (
    <div data-testid="emission-breakdown-chart">
      <span>Total: {totalEmissions}</span>
      <span>Categories: {data.length}</span>
    </div>
  ),
}));

jest.mock("../charts/emission-trend-chart", () => ({
  EmissionTrendChart: ({ data, period, showTarget }: any) => (
    <div data-testid="emission-trend-chart">
      <span>Period: {period}</span>
      <span>Data points: {data.length}</span>
      <span>Show target: {showTarget ? "yes" : "no"}</span>
    </div>
  ),
}));

describe("Dashboard", () => {
  const mockSetDashboardEditMode = jest.fn();
  const mockAddDashboardWidget = jest.fn();
  const mockRemoveDashboardWidget = jest.fn();
  const mockAddToast = jest.fn();

  beforeEach(() => {
    mockUseUIStore.mockReturnValue({
      dashboardEditMode: false,
      setDashboardEditMode: mockSetDashboardEditMode,
      dashboardWidgets: [],
      addDashboardWidget: mockAddDashboardWidget,
      removeDashboardWidget: mockRemoveDashboardWidget,
      addToast: mockAddToast,
    });

    mockUseCarbonStore.mockReturnValue({
      currentCalculation: null,
      isCalculating: false,
    });

    mockUseUserStore.mockReturnValue({
      user: { id: "1", name: "Test User" },
      isPremium: jest.fn(() => false),
    });

    jest.clearAllMocks();
  });

  it("renders dashboard with header and main content", () => {
    render(<Dashboard />);

    expect(
      screen.getByRole("heading", { name: /dashboard/i })
    ).toBeInTheDocument();
    expect(
      screen.getByText(/track your carbon footprint/i)
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /edit/i })).toBeInTheDocument();
  });

  it("displays period selector with default month selection", () => {
    render(<Dashboard />);

    const periodButton = screen.getByRole("button", { name: /month/i });
    expect(periodButton).toBeInTheDocument();
  });

  it("changes period when different option is selected", async () => {
    const user = userEvent.setup();
    render(<Dashboard />);

    const periodButton = screen.getByRole("button", { name: /month/i });
    await user.click(periodButton);

    const weekOption = screen.getByRole("menuitem", { name: /week/i });
    await user.click(weekOption);

    expect(screen.getByRole("button", { name: /week/i })).toBeInTheDocument();
  });

  it("displays metrics cards with emission data", () => {
    render(<Dashboard />);

    expect(screen.getByText(/month/i)).toBeInTheDocument();
    expect(screen.getByText(/carbon intensity/i)).toBeInTheDocument();
    expect(screen.getByText(/streak/i)).toBeInTheDocument();
  });

  it("displays main dashboard widgets", () => {
    render(<Dashboard />);

    expect(screen.getByTestId("emission-breakdown-chart")).toBeInTheDocument();
    expect(screen.getByTestId("emission-trend-chart")).toBeInTheDocument();
    expect(screen.getByText(/transportation/i)).toBeInTheDocument();
    expect(screen.getByText(/energy/i)).toBeInTheDocument();
  });

  it("toggles edit mode when edit button is clicked", async () => {
    const user = userEvent.setup();
    render(<Dashboard />);

    const editButton = screen.getByRole("button", { name: /edit/i });
    await user.click(editButton);

    expect(mockSetDashboardEditMode).toHaveBeenCalledWith(true);
  });

  it("shows edit mode banner when in edit mode", () => {
    mockUseUIStore.mockReturnValue({
      dashboardEditMode: true,
      setDashboardEditMode: mockSetDashboardEditMode,
      dashboardWidgets: [],
      addDashboardWidget: mockAddDashboardWidget,
      removeDashboardWidget: mockRemoveDashboardWidget,
      addToast: mockAddToast,
    });

    render(<Dashboard />);

    expect(screen.getByText(/dashboard edit mode/i)).toBeInTheDocument();
    expect(
      screen.getByText(/add, remove, or configure widgets/i)
    ).toBeInTheDocument();
  });

  it("shows add widget button in edit mode", () => {
    mockUseUIStore.mockReturnValue({
      dashboardEditMode: true,
      setDashboardEditMode: mockSetDashboardEditMode,
      dashboardWidgets: [],
      addDashboardWidget: mockAddDashboardWidget,
      removeDashboardWidget: mockRemoveDashboardWidget,
      addToast: mockAddToast,
    });

    render(<Dashboard />);

    expect(
      screen.getByRole("button", { name: /add widget/i })
    ).toBeInTheDocument();
  });

  it("adds widget when selected from dropdown", async () => {
    const user = userEvent.setup();
    mockUseUIStore.mockReturnValue({
      dashboardEditMode: true,
      setDashboardEditMode: mockSetDashboardEditMode,
      dashboardWidgets: [],
      addDashboardWidget: mockAddDashboardWidget,
      removeDashboardWidget: mockRemoveDashboardWidget,
      addToast: mockAddToast,
    });

    render(<Dashboard />);

    const addWidgetButton = screen.getByRole("button", { name: /add widget/i });
    await user.click(addWidgetButton);

    const emissionBreakdownOption = screen.getByRole("menuitem", {
      name: /emissions breakdown/i,
    });
    await user.click(emissionBreakdownOption);

    expect(mockAddDashboardWidget).toHaveBeenCalledWith({
      type: "emissions-breakdown",
      title: "Emissions Breakdown",
      position: { x: 0, y: 0 },
      size: { width: 2, height: 2 },
      config: {},
      isVisible: true,
    });
  });

  it("displays recommendations widget with mock data", () => {
    render(<Dashboard />);

    expect(screen.getByText(/top recommendations/i)).toBeInTheDocument();
    expect(screen.getByText(/switch to led bulbs/i)).toBeInTheDocument();
    expect(screen.getByText(/use public transport/i)).toBeInTheDocument();
    expect(screen.getByText(/high impact/i)).toBeInTheDocument();
    expect(screen.getByText(/medium impact/i)).toBeInTheDocument();
  });

  it("shows premium features for premium users", () => {
    mockUseUserStore.mockReturnValue({
      user: { id: "1", name: "Test User" },
      isPremium: jest.fn(() => true),
    });

    render(<Dashboard />);

    const trendChart = screen.getByTestId("emission-trend-chart");
    expect(trendChart).toHaveTextContent("Show target: yes");
  });

  it("handles refresh functionality", async () => {
    const user = userEvent.setup();
    render(<Dashboard />);

    const refreshButtons = screen.getAllByRole("button");
    const refreshButton = refreshButtons.find(
      (button) =>
        button.getAttribute("aria-label")?.includes("refresh") ||
        button.textContent?.includes("refresh")
    );

    if (refreshButton) {
      await user.click(refreshButton);
    }
  });

  it("displays category-specific emission values", () => {
    render(<Dashboard />);

    expect(screen.getByText("450")).toBeInTheDocument();
    expect(screen.getByText("380")).toBeInTheDocument();

    expect(screen.getByText("-5.2% vs last month")).toBeInTheDocument();
    expect(screen.getByText("+2.1% vs last month")).toBeInTheDocument();
  });

  it("has proper responsive design classes", () => {
    const { container } = render(<Dashboard />);

    const metricsGrid = container.querySelector(".grid");
    expect(metricsGrid).toHaveClass(
      "grid-cols-1",
      "md:grid-cols-2",
      "lg:grid-cols-4"
    );
  });

  it("handles loading states properly", () => {
    mockUseCarbonStore.mockReturnValue({
      currentCalculation: null,
      isCalculating: true,
    });

    render(<Dashboard />);

    expect(
      screen.getByRole("heading", { name: /dashboard/i })
    ).toBeInTheDocument();
  });

  it("applies custom className when provided", () => {
    const customClass = "custom-dashboard-class";
    const { container } = render(<Dashboard className={customClass} />);

    expect(container.firstChild).toHaveClass(customClass);
  });

  it("displays emission breakdown chart with correct data", () => {
    render(<Dashboard />);

    const chart = screen.getByTestId("emission-breakdown-chart");
    expect(chart).toHaveTextContent("Total: 1270");
    expect(chart).toHaveTextContent("Categories: 5");
  });

  it("displays trend chart with correct configuration", () => {
    render(<Dashboard />);

    const chart = screen.getByTestId("emission-trend-chart");
    expect(chart).toHaveTextContent("Period: month");
    expect(chart).toHaveTextContent("Data points: 7");
  });
});
