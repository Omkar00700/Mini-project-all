"use client";

import { useState, useEffect } from "react";
import { DashboardWidget, WidgetContainer } from "./dashboard-widget";
import { EmissionBreakdownChart } from "./charts/emission-breakdown-chart";
import { EmissionTrendChart } from "./charts/emission-trend-chart";
import {
  MetricsCard,
  EmissionMetricsCard,
  SavingsMetricsCard,
} from "./metrics-card";
import { RecentAnomaliesWidget } from "@/components/analytics";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useUIStore, useCarbonStore, useUserStore } from "@/store";
import {
  Settings,
  Plus,
  BarChart3,
  TrendingUp,
  Target,
  Award,
  Leaf,
  Zap,
  Car,
} from "lucide-react";

const generateEmissionDataFromAPI = (topContributors: {category: string, total: number}[]) => {
  if (!topContributors || topContributors.length === 0) return [];

  const total = topContributors.reduce((sum, item) => sum + item.total, 0);

  return topContributors
    .map((item) => {
      const catLower = item.category.toLowerCase();
      let color = "#9ca3af";
      if (catLower.includes("transport")) color = "#ef4444";
      else if (catLower.includes("energy")) color = "#f59e0b";
      else if (catLower.includes("food")) color = "#10b981";
      else if (catLower.includes("waste")) color = "#8b5cf6";
      else if (catLower.includes("consumption")) color = "#3b82f6";

      return {
        category: item.category,
        value: item.total,
        percentage: total > 0 ? Math.round((item.total / total) * 100) : 0,
        color: color,
        trend: 0, 
      };
    })
    .filter((item) => item.value > 0);
};

const generateMockTrendData = () => {
  const data = [];
  const today = new Date();

  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    const dateStr = date.toISOString().split("T")[0];

    const baseTotal = 1100 + Math.floor(Math.random() * 300);

    data.push({
      date: dateStr,
      total: baseTotal,
      transportation: Math.round(baseTotal * 0.35),
      energy: Math.round(baseTotal * 0.3),
      food: Math.round(baseTotal * 0.2),
      consumption: Math.round(baseTotal * 0.1),
      waste: Math.round(baseTotal * 0.05),
      target: 1000,
    });
  }
  return data;
};

const mockTrendData = generateMockTrendData();

interface DashboardProps {
  className?: string;
}

export function Dashboard({ className }: DashboardProps) {
  const [period, setPeriod] = useState<"week" | "month" | "year">("month");
  const [isLoading, setIsLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState<{
    lastMonthTotal: number;
    currentMonthTotal: number;
    streak: number;
    streakTrend: number;
    monthSavings: number;
    monthlySeries: any[];
    topContributors: any[];
  }>({
    lastMonthTotal: 0,
    currentMonthTotal: 0,
    streak: 0,
    streakTrend: 0,
    monthSavings: 0,
    monthlySeries: [],
    topContributors: [],
  });

  const {
    dashboardEditMode,
    setDashboardEditMode,
    dashboardWidgets,
    addDashboardWidget,
    removeDashboardWidget,
  } = useUIStore();

  const { currentCalculation, isCalculating, calculationHistory } =
    useCarbonStore();
  const { user, isPremium } = useUserStore();

  const fetchDashboardData = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const res = await fetch(`/api/dashboard`);
      if (!res.ok) throw new Error("Failed to fetch dashboard data");

      const data = await res.json();
      setDashboardData(data);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch dashboard data from API
  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const emissionBreakdownData = generateEmissionDataFromAPI(dashboardData.topContributors || []);
  const totalEmissions = dashboardData.topContributors?.reduce((sum, item) => sum + item.total, 0) || 0;

  // Month savings from API (lastMonthTotal - currentMonthTotal)
  const monthSavings = dashboardData.monthSavings;

  const handleAddWidget = (widgetType: string) => {
    const widgetConfig = {
      type: widgetType,
      title: getWidgetTitle(widgetType),
      position: { x: 0, y: 0 },
      size: getWidgetSize(widgetType),
      config: {},
      isVisible: true,
    };

    addDashboardWidget(widgetConfig);
  };

  const getWidgetTitle = (type: string) => {
    const titles: Record<string, string> = {
      "emissions-breakdown": "Emissions Breakdown",
      "trend-chart": "Emission Trends",
      "monthly-metrics": "Monthly Metrics",
      "savings-metrics": "Savings Metrics",
      recommendations: "Recommendations",
      achievements: "Achievements",
    };
    return titles[type] || "Widget";
  };

  const getWidgetSize = (type: string): { width: number; height: number } => {
    const sizes: Record<string, { width: number; height: number }> = {
      "emissions-breakdown": { width: 2, height: 2 },
      "trend-chart": { width: 3, height: 2 },
      "monthly-metrics": { width: 1, height: 1 },
      "savings-metrics": { width: 1, height: 1 },
      recommendations: { width: 2, height: 2 },
      achievements: { width: 1, height: 1 },
    };
    return sizes[type] || { width: 1, height: 1 };
  };

  const refreshData = async () => {
    await fetchDashboardData();
  };

  return (
    <div className={className}>
      {}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">
            Dashboard{" "}
            <span className="text-xs font-normal text-muted-foreground ml-2">
              v2.0
            </span>
          </h1>
          <p className="text-muted-foreground">
            Track your carbon footprint and environmental impact
          </p>
        </div>

        <div className="flex items-center gap-2">
          {}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="capitalize">
                {period}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setPeriod("week")}>
                Week
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setPeriod("month")}>
                Month
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setPeriod("year")}>
                Year
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {}
          {dashboardEditMode && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Widget
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem
                  onClick={() => handleAddWidget("emissions-breakdown")}
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Emissions Breakdown
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleAddWidget("trend-chart")}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Trend Chart
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleAddWidget("monthly-metrics")}
                >
                  <Target className="w-4 h-4 mr-2" />
                  Monthly Metrics
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleAddWidget("savings-metrics")}
                >
                  <Leaf className="w-4 h-4 mr-2" />
                  Savings Metrics
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => handleAddWidget("achievements")}
                >
                  <Award className="w-4 h-4 mr-2" />
                  Achievements
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {}
          <Button
            variant={dashboardEditMode ? "default" : "outline"}
            onClick={() => setDashboardEditMode(!dashboardEditMode)}
          >
            <Settings className="w-4 h-4 mr-2" />
            {dashboardEditMode ? "Done" : "Edit"}
          </Button>
        </div>
      </div>

      {}
      {dashboardEditMode && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-medium text-blue-900">Dashboard Edit Mode</h3>
              <p className="text-sm text-blue-700">
                Add, remove, or configure widgets. Changes are saved
                automatically.
              </p>
            </div>
          </div>
        </div>
      )}

      {}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <EmissionMetricsCard
          period="Month"
          emissions={totalEmissions}
          target={1000}
          previousPeriod={dashboardData.lastMonthTotal || undefined}
        />

        <SavingsMetricsCard
          period="Month"
          savings={Math.max(0, dashboardData.monthSavings)}
          target={200}
          previousPeriod={undefined}
        />

        <MetricsCard
          title="Avg Monthly Footprint"
          value={dashboardData.monthlySeries.reduce((s, m) => s + m.total, 0) / Math.max(1, dashboardData.monthlySeries.length)}
          unit="kg CO₂e"
          trend={{ value: 0, period: "last month" }}
          status="good"
          icon={Leaf}
          description="Six-month rolling average"
        />

        <MetricsCard
          title="Streak"
          value={dashboardData.streak}
          unit="days"
          trend={{
            value: dashboardData.streakTrend || 0,
            period: "last month",
            isPositive: true,
          }}
          status="good"
          icon={Award}
          description="Days of consistent tracking"
        />
      </div>

      {}
      <WidgetContainer>
        {}
        <DashboardWidget
          id="emissions-breakdown"
          title="Emissions by Category"
          size="lg"
          refreshable
          configurable
          exportable
          isLoading={isLoading}
          onRefresh={refreshData}
          onRemove={() => removeDashboardWidget("emissions-breakdown")}
        >
          <EmissionBreakdownChart
            data={emissionBreakdownData}
            totalEmissions={totalEmissions}
            period={period}
          />
        </DashboardWidget>

        {}
        <DashboardWidget
          id="trend-chart"
          title="Emission Trends"
          size="xl"
          refreshable
          configurable
          exportable
          isLoading={isLoading}
          onRefresh={refreshData}
          onRemove={() => removeDashboardWidget("trend-chart")}
        >
          <EmissionTrendChart
            data={dashboardData.monthlySeries.map(m => ({
              date: m.month + "-01",
              total: m.total,
              transportation: m.breakdown?.transportation || 0,
              energy: m.breakdown?.energy || 0,
              food: m.breakdown?.food || 0,
              consumption: m.breakdown?.consumption || 0,
              waste: m.breakdown?.waste || 0,
              target: 1000
            }))}
            period={period}
            showTarget={true}
            showCategories={isPremium()}
          />
        </DashboardWidget>

        {}
        <DashboardWidget
          id="transportation-card"
          title="Transportation"
          size="sm"
          refreshable
          onRefresh={refreshData}
        >
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Car className="w-8 h-8 text-red-500" />
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {emissionBreakdownData.find(d => d.category.toLowerCase().includes("transport"))?.value?.toFixed(0) ?? 0}
                </div>
                <div className="text-xs text-muted-foreground">kg CO₂e</div>
              </div>
            </div>
          </div>
        </DashboardWidget>

        <DashboardWidget
          id="energy-card"
          title="Energy"
          size="sm"
          refreshable
          onRefresh={refreshData}
        >
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Zap className="w-8 h-8 text-amber-500" />
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {emissionBreakdownData.find(d => d.category.toLowerCase().includes("energy"))?.value?.toFixed(0) ?? 0}
                </div>
                <div className="text-xs text-muted-foreground">kg CO₂e</div>
              </div>
            </div>
          </div>
        </DashboardWidget>

        {}
        <DashboardWidget
          id="recent-anomalies"
          title="🔔 Recent Anomalies"
          size="md"
          refreshable
          onRefresh={refreshData}
        >
          <RecentAnomaliesWidget
            userId={user?.id || ""}
            maxItems={3}
          />
        </DashboardWidget>
      </WidgetContainer>
    </div>
  );
}
