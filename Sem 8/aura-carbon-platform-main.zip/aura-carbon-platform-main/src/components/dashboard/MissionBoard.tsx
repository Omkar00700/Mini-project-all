"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, Trophy, Zap } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

interface Mission {
  id: string;
  title: string;
  description: string;
  rewardXp: number;
  progress: number;
  target: number;
  completed: boolean;
  icon: string;
}

export function MissionBoard() {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMissions = async () => {
    try {
      const res = await fetch("/api/gamification/missions");
      if (res.ok) {
        const data = await res.json();
        setMissions(data.missions || []);
      }
    } catch (err) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMissions();
  }, []);

  return (
    <Card className="bg-background/50 backdrop-blur-xl border-border/50 overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent opacity-50 pointer-events-none" />
      <CardHeader className="pb-3 border-b border-border/50 dark:border-white/5 mb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-emerald-500" />
            <div>
              <CardTitle className="text-lg">Daily Missions</CardTitle>
              <CardDescription className="text-xs">
                Complete tasks for extra XP
              </CardDescription>
            </div>
          </div>
          <Zap className="h-4 w-4 text-amber-500 animate-pulse" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4 pt-0">
        {loading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {missions.map((mission, index) => (
                <motion.div
                  key={mission.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`group relative p-4 rounded-xl border transition-all duration-300 ${
                    mission.completed
                      ? "bg-emerald-500/10 border-emerald-500/30"
                      : "bg-secondary/20 border-border/50 hover:border-emerald-500/30"
                  }`}
                >
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{mission.icon}</div>
                      <div>
                        <h4
                          className={`font-bold text-sm ${mission.completed ? "text-emerald-400" : "text-foreground/90"}`}
                        >
                          {mission.title}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {mission.description}
                        </p>
                      </div>
                    </div>
                    {mission.completed ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    ) : (
                      <div className="text-xs font-bold text-emerald-500/80 shrink-0">
                        +{mission.rewardXp} XP
                      </div>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                      <span>Progress</span>
                      <span>
                        {mission.progress}/{mission.target}
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-background/50 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{
                          width: `${(mission.progress / mission.target) * 100}%`,
                        }}
                        className={`h-full rounded-full ${
                          mission.completed
                            ? "bg-emerald-500"
                            : "bg-emerald-500/60"
                        }`}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {missions.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm italic">
                No active missions right now. Check back tomorrow!
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
