"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Activity as ActivityIcon,
  Plus,
  Calendar as CalendarIcon,
  Leaf,
} from "lucide-react";
import { toast } from "sonner";

interface LogFormData {
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  date: string;
}

export function ActivityLogTab() {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showLogForm, setShowLogForm] = useState(false);

  const today = new Date().toISOString().split("T")[0];

  const [formData, setFormData] = useState<LogFormData>({
    category: "",
    subcategory: "",
    value: 0,
    unit: "",
    date: today,
  });

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/activities/history", {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setHistory(data.activities || []);
      }
    } catch (err) {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const getSubcategories = (category: string) => {
    const map: Record<string, string[]> = {
      energy: ["electricity", "lpg"],
      transportation: [
        "personal_vehicle_gasoline",
        "personal_vehicle_diesel",
        "cng",
        "bus",
        "train",
        "auto_rickshaw",
        "motorcycle",
      ],
      food: ["chicken", "rice", "wheat", "lentils"],
      waste: ["municipal_solid_waste"],
    };
    return map[category] || [];
  };

  const getUnitForSubcategory = (category: string, subcategory: string) => {
    const unitMap: Record<string, Record<string, string>> = {
      energy: { electricity: "kWh", lpg: "kg" },
      transportation: {
        personal_vehicle_gasoline: "km",
        personal_vehicle_diesel: "km",
        cng: "km",
        bus: "km",
        train: "km",
        auto_rickshaw: "km",
        motorcycle: "km",
      },
      food: { chicken: "kg", rice: "kg", wheat: "kg", lentils: "kg" },
      waste: { municipal_solid_waste: "kg" },
    };
    return unitMap[category]?.[subcategory] || "";
  };

  const handleLogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category || !formData.subcategory || formData.value <= 0)
      return;

    setSaving(true);
    try {
      const response = await fetch("/api/activities/log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          ...formData,
          date: new Date(formData.date).toISOString(),
        }),
      });

      if (response.ok) {
        const data = await response.json();

        setFormData({
          category: "",
          subcategory: "",
          value: 0,
          unit: "",
          date: today,
        });
        setShowLogForm(false);
        fetchHistory();

        if (data.xpEarned) {
          toast.success(`Activity Logged! +${data.xpEarned} XP`, {
            icon: "🌱",
          });
        } else {
          toast.success("Activity logged successfully");
        }

        if (data.newlyUnlocked && data.newlyUnlocked.length > 0) {
          toast("Achievement Unlocked!", {
            icon: "🏆",
            description: "Check your achievements page for details.",
          });
        }
      }
    } catch (err) {
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      {}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
        className="lg:col-span-2"
      >
        <Card className="bg-background/40 dark:bg-black/40 backdrop-blur-xl border-border/50 dark:border-emerald-500/20 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500" />
          <CardHeader className="flex flex-row items-center justify-between border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5 pb-4">
            <div>
              <CardTitle className="text-xl text-foreground dark:text-white flex items-center gap-2">
                <CalendarIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                History
              </CardTitle>
              <CardDescription className="text-muted-foreground dark:text-white/60">
                Your chronologically logged activities and their real-time
                impact
              </CardDescription>
            </div>
            <Button
              onClick={() => setShowLogForm(true)}
              disabled={showLogForm}
              className="bg-emerald-500 hover:bg-emerald-600 text-white border-0 shadow-[0_0_20px_rgba(16,185,129,0.3)]"
            >
              <Plus className="h-4 w-4 mr-2" />
              Log Entry
            </Button>
          </CardHeader>

          <CardContent className="pt-6">
            {loading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={i}
                    className="h-24 bg-muted/50 dark:bg-white/5 rounded-2xl animate-pulse"
                  />
                ))}
              </div>
            ) : history.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-muted/50 dark:bg-white/5 flex items-center justify-center mb-4 opacity-50">
                  <ActivityIcon className="w-8 h-8" />
                </div>
                <p className="font-medium mb-4">No activities logged yet</p>
                <Button onClick={() => setShowLogForm(true)} variant="outline">
                  Log your first activity
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {history.map((activity, index) => (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={activity.id}
                      className="p-5 bg-muted/50 dark:bg-white/5 border border-border/50 dark:border-white/10 rounded-2xl hover:border-emerald-500/30 transition-colors flex flex-col sm:flex-row gap-4 sm:items-center justify-between relative overflow-hidden"
                    >
                      <div className="absolute inset-y-0 left-0 w-1 bg-emerald-500 rounded-l-2xl opacity-50" />

                      <div className="pl-2">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                            {activity.category}
                          </span>
                          <span className="text-[10px] text-muted-foreground uppercase">
                            •{" "}
                            {new Date(activity.date).toLocaleDateString(
                              undefined,
                              {
                                month: "short",
                                day: "numeric",
                                year: "numeric",
                              }
                            )}
                          </span>
                        </div>
                        <h4 className="font-semibold text-lg tracking-tight mb-1 capitalize">
                          {activity.subcategory.replace(/_/g, " ")}
                        </h4>
                        <p className="text-sm text-muted-foreground font-mono">
                          {activity.value} {activity.unit}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 bg-background dark:bg-black/40 border border-border/50 dark:border-white/10 px-4 py-3 rounded-xl min-w-[120px] justify-center shadow-sm">
                        <Leaf className="w-4 h-4 text-emerald-500" />
                        <div className="text-right">
                          <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                            {activity.metadata?.co2Impact?.toFixed(2) || "0.00"}
                          </div>
                          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                            kg CO₂
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="lg:col-span-1 border-white/10"
      >
        <AnimatePresence>
          {showLogForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Card className="bg-background/40 dark:bg-transparent bg-gradient-to-br from-transparent dark:from-[#020804] to-transparent dark:to-emerald-950/30 backdrop-blur-xl border-border/50 dark:border-emerald-500/20 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-[40px]" />
                <CardHeader className="border-b border-border/50 dark:border-white/5 bg-muted/50 dark:bg-white/5">
                  <CardTitle className="text-lg">Log Activity</CardTitle>
                </CardHeader>
                <CardContent className="pt-6 relative z-10">
                  <form onSubmit={handleLogSubmit} className="space-y-4">
                    <div>
                      <Label className="text-foreground/80">Date</Label>
                      <Input
                        type="date"
                        className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 h-10 mt-1"
                        value={formData.date}
                        max={today}
                        onChange={(e) =>
                          setFormData({ ...formData, date: e.target.value })
                        }
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-foreground/80">Category</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(v) =>
                          setFormData({
                            ...formData,
                            category: v,
                            subcategory: "",
                            unit: "",
                          })
                        }
                      >
                        <SelectTrigger className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 h-10 mt-1">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="energy">Energy</SelectItem>
                          <SelectItem value="transportation">
                            Transportation
                          </SelectItem>
                          <SelectItem value="food">Food</SelectItem>
                          <SelectItem value="waste">Waste</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-foreground/80">Specifics</Label>
                      <Select
                        value={formData.subcategory}
                        disabled={!formData.category}
                        onValueChange={(v) =>
                          setFormData({
                            ...formData,
                            subcategory: v,
                            unit: getUnitForSubcategory(formData.category, v),
                          })
                        }
                      >
                        <SelectTrigger className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 h-10 mt-1">
                          <SelectValue placeholder="Select activity" />
                        </SelectTrigger>
                        <SelectContent>
                          {getSubcategories(formData.category).map((sub) => (
                            <SelectItem key={sub} value={sub}>
                              {sub
                                .replace(/_/g, " ")
                                .replace(/\b\w/g, (l) => l.toUpperCase())}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-foreground/80">Amount</Label>
                      <Input
                        type="number"
                        min="0"
                        step="any"
                        className="bg-transparent dark:bg-black/50 border-input dark:border-white/10 h-10 mt-1 font-mono"
                        value={formData.value || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            value: parseFloat(e.target.value) || 0,
                          })
                        }
                        required
                      />
                      {formData.unit && (
                        <p className="text-xs text-emerald-600 mt-1 ml-1 font-medium">
                          Unit: {formData.unit}
                        </p>
                      )}
                    </div>

                    <div className="flex gap-3 pt-2">
                      <Button
                        type="submit"
                        disabled={
                          saving || !formData.category || !formData.subcategory
                        }
                        className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
                      >
                        {saving ? "Saving..." : "Log Activity"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowLogForm(false)}
                      >
                        Close
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {!showLogForm && (
          <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center">
            <div className="text-4xl mb-4">🌟</div>
            <h3 className="font-semibold text-lg text-emerald-600 dark:text-emerald-400 mb-2">
              Log to Earn XP
            </h3>
            <p className="text-sm text-foreground/70 leading-relaxed">
              Keep your carbon timeline accurate by actively logging your daily
              actions. Each entry earns you +10 XP towards your Seedling Level.
            </p>
          </div>
        )}
      </motion.div>
    </div>
  );
}
