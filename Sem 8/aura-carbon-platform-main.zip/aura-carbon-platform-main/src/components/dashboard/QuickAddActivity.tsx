"use client";

import { useState } from "react";
import { Car, Zap, Utensils, Trash2, Plus, Loader2, Check } from "lucide-react";
import { useGamificationStore } from "@/store/gamification-store";

interface QuickAddActivityProps {
  userId: string;
  onActivityAdded?: () => void;
}

const QUICK_ACTIVITIES = [
  {
    category: "transportation",
    label: "Transport",
    icon: Car,
    color: "#ef4444",
    unit: "km",
    placeholder: "Distance driven",
    presets: [5, 20, 50],
  },
  {
    category: "energy",
    label: "Energy",
    icon: Zap,
    color: "#f59e0b",
    unit: "kWh",
    placeholder: "Electricity used",
    presets: [10, 50, 100],
  },
  {
    category: "food",
    label: "Food",
    icon: Utensils,
    color: "#10b981",
    unit: "kg CO₂",
    placeholder: "Estimated emissions",
    presets: [2, 5, 10],
  },
  {
    category: "waste",
    label: "Waste",
    icon: Trash2,
    color: "#8b5cf6",
    unit: "kg",
    placeholder: "Waste generated",
    presets: [1, 3, 5],
  },
];

export function QuickAddActivity({
  userId,
  onActivityAdded,
}: QuickAddActivityProps) {
  const [selected, setSelected] = useState<string | null>(null);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const { processServerReward } = useGamificationStore();

  const handleSave = async () => {
    if (!selected || !value) return;
    const numValue = parseFloat(value);
    if (isNaN(numValue) || numValue <= 0) return;

    try {
      setSaving(true);
      const response = await fetch("/api/activities/log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: selected,
          value: numValue,
          date: new Date().toISOString(),
          unit:
            QUICK_ACTIVITIES.find((a) => a.category === selected)?.unit || "kg",
        }),
      });
      if (response.ok) {
        const data = await response.json();
        setSuccess(true);
        setTimeout(() => {
          setSelected(null);
          setValue("");
          setSuccess(false);
          onActivityAdded?.();

          if (data.reward) {
            processServerReward(data.reward);
          }
        }, 1500);
      }
    } catch (err) {
    } finally {
      setSaving(false);
    }
  };

  const activity = QUICK_ACTIVITIES.find((a) => a.category === selected);

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span className="text-xs text-muted-foreground font-medium">
        Quick add:
      </span>
      {QUICK_ACTIVITIES.map((act) => {
        const Icon = act.icon;
        const isActive = selected === act.category;
        return (
          <button
            key={act.category}
            onClick={() => {
              setSelected(isActive ? null : act.category);
              setValue("");
              setSuccess(false);
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
              isActive
                ? "text-white shadow-sm scale-105"
                : "hover:scale-105 hover:shadow-sm"
            }`}
            style={
              isActive
                ? { backgroundColor: act.color, borderColor: act.color }
                : { borderColor: act.color, color: act.color }
            }
          >
            <Icon className="h-3 w-3" />
            {act.label}
          </button>
        );
      })}

      {}
      {selected && activity && (
        <div className="flex items-center gap-1.5 ml-1">
          {}
          {activity.presets.map((preset) => (
            <button
              key={preset}
              onClick={() => setValue(String(preset))}
              className="px-2 py-0.5 text-xs rounded border hover:bg-muted transition-colors"
              style={{
                borderColor: activity.color + "40",
                color: activity.color,
              }}
            >
              {preset}
            </button>
          ))}
          <input
            type="number"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={activity.placeholder}
            className="w-24 px-2 py-1 text-xs rounded border focus:outline-none focus:ring-1"
            style={{ borderColor: activity.color + "60" }}
          />
          <span className="text-xs text-muted-foreground">{activity.unit}</span>
          <button
            onClick={handleSave}
            disabled={saving || !value || success}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-full text-white transition-all disabled:opacity-50"
            style={{ backgroundColor: success ? "#10b981" : activity.color }}
          >
            {saving ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : success ? (
              <Check className="h-3 w-3" />
            ) : (
              <Plus className="h-3 w-3" />
            )}
            {success ? "Added!" : "Add"}
          </button>
        </div>
      )}
    </div>
  );
}
