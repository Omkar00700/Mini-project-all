"use client";

import { Flame, Info, TrendingUp, AlertCircle } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface StreakCardProps {
  currentStreak: number;
  longestStreak: number;
  lastMaintained?: Date | null;
}

export function StreakCard({
  currentStreak,
  longestStreak,
  lastMaintained,
}: StreakCardProps) {
  const isAtRisk = false;

  const nextMilestone = Math.ceil((currentStreak + 1) / 7) * 7;
  const progressToMilestone = (currentStreak / nextMilestone) * 100;

  return (
    <Card
      className={`relative overflow-hidden transition-all duration-500 border-2 ${currentStreak > 0 ? "border-orange-500/20 hover:border-orange-500/40" : "border-border"}`}
    >
      {}
      {currentStreak > 0 && (
        <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 dark:bg-orange-500/5 rounded-full blur-[50px] pointer-events-none" />
      )}

      <CardHeader className="pb-2 flex flex-row items-start justify-between">
        <div>
          <CardTitle className="text-xl flex items-center gap-2">
            Aura Streak
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-4 w-4 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-[200px] text-xs">
                    Maintain your streak by logging activities or completing
                    routines daily. Don&apos;t lose your momentum!
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </CardTitle>
          <CardDescription>
            {currentStreak === 0
              ? "Start a new sustainable streak today!"
              : "You&apos;re on fire! Keep logging daily."}
          </CardDescription>
        </div>

        <div
          className={`p-3 rounded-full flex items-center justify-center ${currentStreak > 0 ? "bg-orange-100 dark:bg-orange-500/20 text-orange-600 dark:text-orange-400" : "bg-muted text-muted-foreground"}`}
        >
          <Flame
            className={`h-6 w-6 ${currentStreak > 0 ? "animate-pulse" : ""}`}
          />
        </div>
      </CardHeader>

      <CardContent>
        <div className="flex flex-col gap-4">
          <div className="flex items-end gap-2">
            <span className="text-5xl font-bold tracking-tighter">
              {currentStreak}
            </span>
            <span className="text-muted-foreground mb-1 font-medium">days</span>
          </div>

          {currentStreak > 0 && (
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">
                  Next Milestone: {nextMilestone} Days
                </span>
                <span className="font-semibold">
                  {Math.round(progressToMilestone)}%
                </span>
              </div>
              <Progress value={progressToMilestone} className="h-2 bg-muted">
                <div
                  className="h-full bg-gradient-to-r from-orange-400 to-orange-600 transition-all duration-1000 ease-in-out"
                  style={{ width: `${progressToMilestone}%` }}
                />
              </Progress>
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t text-sm">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span>
                Personal Best: <strong>{longestStreak}</strong>
              </span>
            </div>

            {isAtRisk ? (
              <div className="flex items-center gap-1.5 text-red-500">
                <AlertCircle className="h-4 w-4" />
                <span className="font-medium">Streak at Risk!</span>
              </div>
            ) : (
              currentStreak > 0 && (
                <div className="text-green-500 font-medium">Safe for today</div>
              )
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
