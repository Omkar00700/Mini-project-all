"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  Legend,
} from "recharts";
import {
  TrendingDown,
  TrendingUp,
  Sparkles,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { ExplainChartButton } from "./charts/explain-chart-button";

interface ChartDataPoint {
  month: string;
  historical?: number;
  predicted?: number;
  lowerBound?: number;
  upperBound?: number;
  confidence?: number;
}

type ForecastModel =
  | "linear-regression"
  | "moving-average"
  | "exponential-smoothing";

const MODEL_LABELS: Record<ForecastModel, string> = {
  "linear-regression": "Linear",
  "moving-average": "Moving Avg",
  "exponential-smoothing": "Exp. Smooth",
};

const MODEL_COLORS: Record<ForecastModel, string> = {
  "linear-regression": "#a855f7",
  "moving-average": "#3b82f6",
  "exponential-smoothing": "#10b981",
};

export function PredictionChart() {
  const [data, setData] = useState<ChartDataPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [avgConfidence, setAvgConfidence] = useState(0);
  const [selectedModel, setSelectedModel] =
    useState<ForecastModel>("linear-regression");
  const [trendDirection, setTrendDirection] = useState<string>("stable");
  const [useAdvancedAPI, setUseAdvancedAPI] = useState(false);
  const [insufficientData, setInsufficientData] = useState(false);
  const [categoryForecasts, setCategoryForecasts] = useState<any[]>([]);

  useEffect(() => {
    fetchPredictions();
  }, [selectedModel, useAdvancedAPI]);

  const fetchPredictions = async () => {
    try {
      setLoading(true);
      setError(null);

      let result: any;

      if (useAdvancedAPI) {
        const response = await fetch(
          `/api/analytics/forecasts?userId=current&months=6&model=${selectedModel}`,
          { credentials: "include" }
        );
        if (!response.ok) throw new Error("Failed to fetch forecasts");
        result = await response.json();

        if (result.metadata?.trend) {
          setTrendDirection(result.metadata.trend.direction || "stable");
        }
      } else {
        const response = await fetch("/api/predictions?months=6");
        if (!response.ok) throw new Error("Failed to fetch predictions");
        result = await response.json();
      }

      const combinedData: ChartDataPoint[] = [];

      if (result.historical) {
        result.historical.forEach((point: any) => {
          combinedData.push({
            month: point.month,
            historical: point.emissions,
          });
        });
      }

      let totalConfidence = 0;
      const predictions = result.predictions || result.forecasts || [];
      predictions.forEach((point: any) => {
        combinedData.push({
          month: point.month,
          predicted: point.predictedEmissions,
          lowerBound: point.lowerBound,
          upperBound: point.upperBound,
          confidence: point.confidence,
        });
        totalConfidence += point.confidence || 0;
      });

      setAvgConfidence(
        predictions.length > 0 ? totalConfidence / predictions.length : 0
      );
      setData(combinedData);
      setInsufficientData(predictions.length === 0);
      setCategoryForecasts(result.categoryForecasts || []);
    } catch (err: any) {
      setError(err.message || "Failed to load predictions");
    } finally {
      setLoading(false);
    }
  };

  const activeColor = MODEL_COLORS[selectedModel];

  if (loading) {
    return (
      <Card className="relative rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-transparent opacity-50" />
        <CardHeader className="relative z-10">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            AI-Powered Predictions
          </CardTitle>
          <CardDescription>
            Analyzing your carbon footprint trends...
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
            <p className="text-sm text-gray-500">Generating predictions...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="relative rounded-3xl backdrop-blur-xl bg-background/50 border border-red-500/20 shadow-xl shadow-red-500/5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-transparent opacity-50" />
        <CardHeader className="relative z-10">
          <CardTitle className="flex items-center gap-2 text-red-500">
            <Sparkles className="h-5 w-5 text-red-500/70" />
            AI-Powered Predictions
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center gap-2 text-center">
            <AlertCircle className="h-8 w-8 text-red-500" />
            <p className="text-sm text-gray-600">{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="relative rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-transparent opacity-50 pointer-events-none" />
        <CardHeader className="relative z-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2 text-xl font-bold tracking-tight mb-1">
                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-500">
                  <Sparkles className="h-5 w-5" />
                </div>
                AI-Powered Predictions
              </CardTitle>
              <CardDescription>
                6-month carbon footprint forecast based on your historical data
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {trendDirection !== "stable" && (
                <Badge
                  variant="secondary"
                  className={`flex items-center gap-1 ${
                    trendDirection === "decreasing"
                      ? "bg-green-50 text-green-700 border-green-200"
                      : "bg-amber-50 text-amber-700 border-amber-200"
                  }`}
                >
                  {trendDirection === "decreasing" ? (
                    <TrendingDown className="h-3 w-3" />
                  ) : (
                    <TrendingUp className="h-3 w-3" />
                  )}
                  {trendDirection === "decreasing" ? "Improving" : "Rising"}
                </Badge>
              )}
              <Badge variant="secondary" className="flex items-center gap-1">
                <TrendingDown className="h-3 w-3" />
                {Math.round(avgConfidence * 100)}% Confidence
              </Badge>
              <ExplainChartButton
                chartType="AI Predictions"
                data={data}
                variant="outline"
              />
            </div>
          </div>

          {}
          <div className="flex items-center gap-2 mt-3">
            <span className="text-xs text-muted-foreground font-medium">
              Model:
            </span>
            <div className="flex rounded-lg border overflow-hidden">
              {(Object.keys(MODEL_LABELS) as ForecastModel[]).map((model) => (
                <button
                  key={model}
                  onClick={() => {
                    setSelectedModel(model);
                    setUseAdvancedAPI(true);
                  }}
                  className={`px-3 py-1 text-xs font-medium transition-colors ${
                    selectedModel === model && useAdvancedAPI
                      ? "text-white"
                      : "text-muted-foreground hover:bg-muted/50"
                  }`}
                  style={
                    selectedModel === model && useAdvancedAPI
                      ? { backgroundColor: MODEL_COLORS[model] }
                      : {}
                  }
                >
                  {MODEL_LABELS[model]}
                </button>
              ))}
            </div>
            {useAdvancedAPI && (
              <button
                onClick={() => setUseAdvancedAPI(false)}
                className="text-xs text-muted-foreground underline hover:text-foreground transition-colors"
              >
                Reset
              </button>
            )}
          </div>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="h-80 w-full pr-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient
                    id="confidenceGradient"
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop
                      offset="5%"
                      stopColor={activeColor}
                      stopOpacity={0.2}
                    />
                    <stop
                      offset="95%"
                      stopColor={activeColor}
                      stopOpacity={0.05}
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 12 }}
                  stroke="#6b7280"
                />
                <YAxis
                  label={{
                    value: "kg CO₂e",
                    angle: -90,
                    position: "insideLeft",
                  }}
                  tick={{ fontSize: 12 }}
                  stroke="#6b7280"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                    padding: "12px",
                  }}
                  formatter={(value: any, name: string) => {
                    if (name === "historical")
                      return [value + " kg CO₂e", "Historical"];
                    if (name === "predicted")
                      return [value + " kg CO₂e", "Predicted"];
                    if (name === "lowerBound")
                      return [value + " kg CO₂e", "Lower Bound"];
                    if (name === "upperBound")
                      return [value + " kg CO₂e", "Upper Bound"];
                    return [value, name];
                  }}
                />
                <Legend
                  wrapperStyle={{ paddingTop: "20px" }}
                  formatter={(value) => {
                    if (value === "historical") return "Historical Data";
                    if (value === "predicted") return "AI Prediction";
                    if (value === "lowerBound") return "Lower Bound";
                    if (value === "upperBound") return "Upper Bound";
                    return value;
                  }}
                />

                {}
                <Area
                  type="monotone"
                  dataKey="upperBound"
                  stroke="none"
                  fill="url(#confidenceGradient)"
                  fillOpacity={1}
                />
                <Area
                  type="monotone"
                  dataKey="lowerBound"
                  stroke="none"
                  fill="white"
                  fillOpacity={1}
                />

                {}
                <Line
                  type="monotone"
                  dataKey="historical"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ fill: "#10b981", r: 4 }}
                  activeDot={{ r: 6 }}
                />

                {}
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke={activeColor}
                  strokeWidth={3}
                  strokeDasharray="5 5"
                  dot={{ fill: activeColor, r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {insufficientData && (
            <div className="mt-4 p-4 bg-amber-500/10 rounded-xl border border-amber-500/20 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-amber-600">
                  Need More Data
                </p>
                <p className="text-xs text-amber-600/80 mt-0.5">
                  Our AI models require at least 3 months of historical data to
                  generate accurate forecasts. Keep logging your activities to
                  unlock advanced predictions!
                </p>
              </div>
            </div>
          )}

          {!insufficientData && (
            <div className="mt-8 p-4 bg-purple-500/5 rounded-2xl border border-purple-500/10 backdrop-blur-sm">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500 mt-0.5 flex-shrink-0">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div className="text-sm">
                  <p className="font-semibold text-purple-500 mb-1">
                    AI Insights
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    Based on your historical patterns, our AI predicts your
                    carbon footprint trends for the next 6 months.
                    {useAdvancedAPI && (
                      <>
                        {" "}
                        Using <strong>
                          {MODEL_LABELS[selectedModel]}
                        </strong>{" "}
                        model.{" "}
                      </>
                    )}{" "}
                    The shaded area represents the confidence interval of
                    predictions.
                  </p>
                </div>
              </div>

              {useAdvancedAPI && categoryForecasts.length > 0 && (
                <div className="mt-4 pt-4 border-t border-purple-500/10">
                  <p className="text-xs font-semibold text-purple-500/70 uppercase tracking-wider mb-3">
                    6-Month Category Outlook Average
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {categoryForecasts.map((cf) => {
                      const avgCatPred =
                        cf.forecasts.reduce(
                          (sum: number, f: any) => sum + f.predictedEmissions,
                          0
                        ) / cf.forecasts.length;
                      return (
                        <div
                          key={cf.category}
                          className="bg-background/40 rounded-lg p-2 border border-purple-500/5"
                        >
                          <p className="text-xs text-muted-foreground capitalize mb-1">
                            {cf.category}
                          </p>
                          <p className="font-bold text-sm">
                            {avgCatPred.toFixed(1)}{" "}
                            <span className="text-[10px] text-muted-foreground font-normal">
                              kg/mo
                            </span>
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
