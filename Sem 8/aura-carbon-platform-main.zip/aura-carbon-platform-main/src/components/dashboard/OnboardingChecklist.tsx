"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  Circle,
  Calculator,
  Target,
  Activity,
  Sparkles,
  ChevronRight,
  X,
} from "lucide-react";

interface OnboardingStep {
  id: string;
  label: string;
  description: string;
  completed: boolean;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface OnboardingChecklistProps {
  userId: string;
  hasCalculations: boolean;
  hasGoals: boolean;
  hasScenarios: boolean;
  onDismiss?: () => void;
}

export function OnboardingChecklist({
  userId,
  hasCalculations,
  hasGoals,
  hasScenarios,
  onDismiss,
}: OnboardingChecklistProps) {
  const router = useRouter();
  const [dismissed, setDismissed] = useState(false);

  const steps: OnboardingStep[] = [
    {
      id: "calculate",
      label: "Calculate your footprint",
      description: "Use the carbon calculator with India-specific factors",
      completed: hasCalculations,
      href: "/calculator",
      icon: Calculator,
    },
    {
      id: "goal",
      label: "Set a reduction goal",
      description: "Define a monthly target to track progress",
      completed: hasGoals,
      href: "/goals",
      icon: Target,
    },
    {
      id: "scenario",
      label: "Try a What-If scenario",
      description: "Model changes like switching transport or diet",
      completed: hasScenarios,
      href: "#scenarios",
      icon: Activity,
    },
  ];

  const completedCount = steps.filter((s) => s.completed).length;
  const allCompleted = completedCount === steps.length;
  const progressPercent = Math.round((completedCount / steps.length) * 100);

  useEffect(() => {
    if (allCompleted) {
      const timer = setTimeout(() => setDismissed(true), 3000);
      return () => clearTimeout(timer);
    }
  }, [allCompleted]);

  if (dismissed) return null;

  return (
    <div className="relative rounded-xl border bg-gradient-to-r from-emerald-50 via-blue-50 to-purple-50 p-5 shadow-sm overflow-hidden">
      {}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-emerald-100/40 to-transparent rounded-bl-full" />

      <div className="relative">
        {}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-100">
              <Sparkles className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">
                {allCompleted ? "You're all set! 🎉" : "Get started with Aura"}
              </h3>
              <p className="text-xs text-muted-foreground">
                {allCompleted
                  ? "You've completed all the basics"
                  : `${completedCount}/${steps.length} steps complete`}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setDismissed(true);
              onDismiss?.();
            }}
            className="p-1 rounded-lg hover:bg-white/60 transition-colors text-muted-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {}
        <div className="h-1.5 bg-white/60 rounded-full mb-4 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full transition-all duration-700 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <button
                key={step.id}
                onClick={() => {
                  if (!step.completed) {
                    if (step.href.startsWith("#")) {
                      const el = document.querySelector(
                        `[data-section="${step.href.slice(1)}"]`
                      );
                      el?.scrollIntoView({ behavior: "smooth" });
                    } else {
                      router.push(step.href);
                    }
                  }
                }}
                disabled={step.completed}
                className={`flex items-center gap-3 p-3 rounded-lg text-left transition-all ${
                  step.completed
                    ? "bg-white/40 opacity-70"
                    : "bg-white/70 hover:bg-white hover:shadow-sm cursor-pointer"
                }`}
              >
                {step.completed ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 flex-shrink-0" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <p
                    className={`text-sm font-medium ${step.completed ? "line-through text-muted-foreground" : ""}`}
                  >
                    {step.label}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {step.description}
                  </p>
                </div>
                {!step.completed && (
                  <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
