"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import {
  MoreHorizontal,
  Maximize2,
  Minimize2,
  Settings,
  Trash2,
  RefreshCw,
  Download,
  Share,
  Eye,
  EyeOff,
} from "lucide-react";
import { useUIStore } from "@/store";

export interface WidgetProps {
  id: string;
  title: string;
  description?: string;
  size: "sm" | "md" | "lg" | "xl";
  refreshable?: boolean;
  configurable?: boolean;
  exportable?: boolean;
  shareable?: boolean;
  className?: string;
  children: React.ReactNode;
  isLoading?: boolean;
  error?: string;
  lastUpdated?: Date;
  onRefresh?: () => void;
  onConfigure?: () => void;
  onExport?: () => void;
  onShare?: () => void;
  onRemove?: () => void;
  onToggleVisibility?: () => void;
}

const sizeClasses = {
  sm: "col-span-1 row-span-1",
  md: "col-span-2 row-span-1",
  lg: "col-span-2 row-span-2",
  xl: "col-span-3 row-span-2",
};

export function DashboardWidget({
  id,
  title,
  description,
  size,
  refreshable = false,
  configurable = false,
  exportable = false,
  shareable = false,
  className,
  children,
  isLoading = false,
  error,
  lastUpdated,
  onRefresh,
  onConfigure,
  onExport,
  onShare,
  onRemove,
  onToggleVisibility,
}: WidgetProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const { dashboardEditMode } = useUIStore();

  const handleToggleVisibility = () => {
    setIsVisible(!isVisible);
    onToggleVisibility?.();
  };

  const handleRefresh = () => {
    if (onRefresh && !isLoading) {
      onRefresh();
    }
  };

  if (!isVisible && !dashboardEditMode) {
    return null;
  }

  return (
    <Card
      className={cn(
        "relative transition-all duration-200 hover:shadow-md",
        sizeClasses[size],
        isExpanded && "fixed inset-4 z-50 col-span-full row-span-full",
        !isVisible && dashboardEditMode && "opacity-50",
        error && "border-red-200 bg-red-50/50",
        className
      )}
    >
      {}
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            {title}
            {!isVisible && dashboardEditMode && (
              <Badge variant="outline" className="text-xs">
                Hidden
              </Badge>
            )}
          </CardTitle>
          {description && (
            <p className="text-xs text-muted-foreground">{description}</p>
          )}
        </div>

        <div className="flex items-center gap-1">
          {}
          {isLoading && (
            <RefreshCw className="h-4 w-4 animate-spin text-muted-foreground" />
          )}

          {}
          {lastUpdated && !isLoading && (
            <span className="text-xs text-muted-foreground">
              {lastUpdated.toLocaleTimeString()}
            </span>
          )}

          {}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {refreshable && (
                <DropdownMenuItem onClick={handleRefresh} disabled={isLoading}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh
                </DropdownMenuItem>
              )}

              <DropdownMenuItem onClick={() => setIsExpanded(!isExpanded)}>
                {isExpanded ? (
                  <>
                    <Minimize2 className="mr-2 h-4 w-4" />
                    Minimize
                  </>
                ) : (
                  <>
                    <Maximize2 className="mr-2 h-4 w-4" />
                    Expand
                  </>
                )}
              </DropdownMenuItem>

              {dashboardEditMode && (
                <DropdownMenuItem onClick={handleToggleVisibility}>
                  {isVisible ? (
                    <>
                      <EyeOff className="mr-2 h-4 w-4" />
                      Hide
                    </>
                  ) : (
                    <>
                      <Eye className="mr-2 h-4 w-4" />
                      Show
                    </>
                  )}
                </DropdownMenuItem>
              )}

              {configurable && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onConfigure}>
                    <Settings className="mr-2 h-4 w-4" />
                    Configure
                  </DropdownMenuItem>
                </>
              )}

              {(exportable || shareable) && (
                <>
                  <DropdownMenuSeparator />
                  {exportable && (
                    <DropdownMenuItem onClick={onExport}>
                      <Download className="mr-2 h-4 w-4" />
                      Export
                    </DropdownMenuItem>
                  )}
                  {shareable && (
                    <DropdownMenuItem onClick={onShare}>
                      <Share className="mr-2 h-4 w-4" />
                      Share
                    </DropdownMenuItem>
                  )}
                </>
              )}

              {dashboardEditMode && onRemove && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onRemove} className="text-red-600">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      {}
      <CardContent className="pt-0">
        {error ? (
          <div className="flex items-center justify-center h-32 text-center">
            <div className="space-y-2">
              <p className="text-sm text-red-600">Failed to load widget</p>
              <p className="text-xs text-muted-foreground">{error}</p>
              {refreshable && (
                <Button size="sm" variant="outline" onClick={handleRefresh}>
                  Try Again
                </Button>
              )}
            </div>
          </div>
        ) : (
          children
        )}
      </CardContent>
    </Card>
  );
}

export function WidgetContainer({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 auto-rows-min",
        className
      )}
    >
      {children}
    </div>
  );
}
