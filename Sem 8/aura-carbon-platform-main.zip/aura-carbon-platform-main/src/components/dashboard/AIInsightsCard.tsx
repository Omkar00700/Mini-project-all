"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sparkles,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  Award,
  Lightbulb,
  RefreshCw,
} from "lucide-react";

interface AIRecommendation {
  id: string;
  title: string;
  description: string;
  category: string;
  impactEstimate: number;
  difficulty: "easy" | "medium" | "hard";
  costEstimate: string;
  actionSteps: string[];
  priority: number;
}

interface AIInsight {
  type: "trend" | "prediction" | "alert" | "achievement";
  message: string;
  confidence: number;
}

interface AIInsightsCardProps {
  carbonData?: {
    totalEmissions: number;
    breakdown: {
      transport?: number;
      energy?: number;
      food?: number;
      waste?: number;
    };
  };
}

export function AIInsightsCard({ carbonData }: AIInsightsCardProps) {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>(
    []
  );
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [loading, setLoading] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(false);

  useEffect(() => {
    if (carbonData) {
      fetchAIData();
    }
  }, [carbonData]);

  const fetchAIData = async () => {
    if (!carbonData) return;

    setLoading(true);
    try {
      const [recResponse, insightsResponse] = await Promise.all([
        fetch("/api/ai/recommendations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            totalEmissions: carbonData.totalEmissions,
            breakdown: carbonData.breakdown,
            location: "India",
            householdSize: 1,
            limit: 3,
          }),
        }),
        fetch("/api/ai/insights", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            totalEmissions: carbonData.totalEmissions,
            breakdown: carbonData.breakdown,
          }),
        }),
      ]);

      const recData = await recResponse.json();
      const insightsData = await insightsResponse.json();

      if (recData.success) {
        setRecommendations(recData.recommendations);
        setAiEnabled(recData.aiEnabled);
      }

      if (insightsData.success) {
        setInsights(insightsData.insights);
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case "trend":
        return <TrendingUp className="h-4 w-4" />;
      case "prediction":
        return <Sparkles className="h-4 w-4" />;
      case "alert":
        return <AlertCircle className="h-4 w-4" />;
      case "achievement":
        return <Award className="h-4 w-4" />;
      default:
        return <Lightbulb className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "hard":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons: { [key: string]: string } = {
      transport: "🚗",
      energy: "⚡",
      food: "🍽️",
      waste: "♻️",
    };
    return icons[category] || "💡";
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            AI-Powered Insights
          </CardTitle>
          <CardDescription>
            Loading personalized recommendations...
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton
              key={i}
              className="h-24 w-full bg-muted/50 dark:bg-white/5"
            />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {}
      {insights.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-600" />
                AI Insights
                {!aiEnabled && (
                  <Badge variant="outline" className="ml-2">
                    Fallback Mode
                  </Badge>
                )}
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={fetchAIData}>
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
            <CardDescription>
              {aiEnabled
                ? "Powered by OpenAI GPT - Personalized analysis of your carbon footprint"
                : "Smart insights based on your data (Configure OpenAI for AI-powered analysis)"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {insights.map((insight, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg border border-border/50 dark:border-white/10 bg-gradient-to-r from-purple-500/5 to-blue-500/5"
              >
                <div className="mt-0.5 text-purple-600 dark:text-purple-400">
                  {getInsightIcon(insight.type)}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-foreground/80 dark:text-white/80">
                    {insight.message}
                  </p>
                  <Badge
                    variant="secondary"
                    className="mt-2 text-xs bg-muted dark:bg-white/10 text-foreground dark:text-white border-0"
                  >
                    {Math.round(insight.confidence * 100)}% confidence
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {}
      {recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-600" />
              Smart Recommendations
            </CardTitle>
            <CardDescription>
              {aiEnabled
                ? "AI-generated personalized actions to reduce your carbon footprint"
                : "Curated recommendations based on your emission patterns"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recommendations.map((rec) => (
              <div
                key={rec.id}
                className="p-4 rounded-lg border border-border/50 dark:border-white/10 bg-background/50 dark:bg-white/5 hover:border-purple-500/30 dark:hover:border-purple-500/30 transition-shadow"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">
                      {getCategoryIcon(rec.category)}
                    </span>
                    <h4 className="font-semibold text-foreground dark:text-white">
                      {rec.title}
                    </h4>
                  </div>
                  <Badge className={getDifficultyColor(rec.difficulty)}>
                    {rec.difficulty}
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground dark:text-white/70 mb-3">
                  {rec.description}
                </p>

                <div className="flex items-center gap-4 text-xs text-muted-foreground dark:text-white/50 mb-3">
                  <div className="flex items-center gap-1">
                    <TrendingDown className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-medium text-emerald-600 dark:text-emerald-400">
                      {rec.impactEstimate} kg CO₂/month
                    </span>
                  </div>
                  <Badge
                    variant="outline"
                    className="border-border/50 dark:border-white/10"
                  >
                    {rec.costEstimate} cost
                  </Badge>
                  <Badge
                    variant="outline"
                    className="capitalize border-border/50 dark:border-white/10"
                  >
                    {rec.category}
                  </Badge>
                </div>

                {rec.actionSteps && rec.actionSteps.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-border/50 dark:border-white/10">
                    <p className="text-xs font-medium text-foreground/80 dark:text-white/80 mb-2">
                      Action Steps:
                    </p>
                    <ol className="text-xs text-muted-foreground dark:text-white/70 space-y-1 ml-4 list-decimal">
                      {rec.actionSteps.slice(0, 3).map((step, idx) => (
                        <li key={idx}>{step}</li>
                      ))}
                    </ol>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {!loading && recommendations.length === 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-600" />
              AI-Powered Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8 text-muted-foreground dark:text-white/50">
              <Sparkles className="h-12 w-12 mx-auto mb-4 text-muted dark:text-white/20" />
              <p>
                Start tracking your carbon footprint to get AI-powered
                recommendations
              </p>
              <Button className="mt-4" onClick={fetchAIData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Insights
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
