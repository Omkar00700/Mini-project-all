"use client";

import { motion } from "framer-motion";
import { Flame, Snowflake } from "lucide-react";
import { cn } from "@/lib/utils";

interface StreakIndicatorProps {
  streak: number;
  freezes?: number;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function StreakIndicator({
  streak,
  freezes = 0,
  className,
  size = "md",
}: StreakIndicatorProps) {
  const isActive = streak > 0;

  const sizeClasses = {
    sm: "h-8 px-2 text-xs",
    md: "h-10 px-3 text-sm",
    lg: "h-14 px-6 text-xl",
  };

  const iconSizes = {
    sm: 14,
    md: 18,
    lg: 28,
  };

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <motion.div
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "relative flex items-center gap-2 rounded-2xl border transition-all duration-500",
          sizeClasses[size],
          isActive
            ? "border-orange-500/30 bg-orange-500/10 text-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.1)]"
            : "border-slate-800 bg-slate-900/50 text-slate-500"
        )}
      >
        <div className="relative">
          {isActive && (
            <>
              {}
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute inset-0 bg-orange-500 blur-lg rounded-full"
              />
              {}
              <motion.div
                animate={{
                  y: [0, -2, 0],
                  scaleY: [1, 1.1, 1],
                }}
                transition={{
                  duration: 0.5,
                  repeat: Infinity,
                  ease: "linear",
                }}
              >
                <Flame size={iconSizes[size]} fill="currentColor" />
              </motion.div>
            </>
          )}
          {!isActive && <Flame size={iconSizes[size]} />}
        </div>

        <span className="font-black tracking-tight">{streak}</span>

        {freezes > 0 && (
          <div className="flex items-center gap-1 border-l border-orange-500/20 pl-2 ml-1">
            <Snowflake size={iconSizes[size] - 4} className="text-blue-400" />
            <span className="text-[10px] font-bold text-blue-400/80">
              {freezes}
            </span>
          </div>
        )}
      </motion.div>
    </div>
  );
}
