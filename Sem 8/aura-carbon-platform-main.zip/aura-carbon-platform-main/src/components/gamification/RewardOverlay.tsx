"use client";

import { useEffect, useState } from "react";
import { useGamificationStore, Reward } from "@/store/gamification-store";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Star, Sparkles, Leaf, Award, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

const RARITY_COLORS = {
  common: "from-slate-400 to-slate-500",
  uncommon: "from-emerald-500 to-teal-400",
  rare: "from-amber-500 to-orange-400",
  epic: "from-purple-600 to-pink-500",
};

const GLOW_COLORS = {
  common: "bg-slate-500/30",
  uncommon: "bg-emerald-500/30",
  rare: "bg-amber-500/30",
  epic: "bg-purple-500/30",
};

export function RewardOverlay() {
  const { pendingRewards, clearRewards } = useGamificationStore();
  const [currentReward, setCurrentReward] = useState<Reward | null>(null);

  useEffect(() => {
    if (pendingRewards.length > 0 && !currentReward) {
      const next = pendingRewards[0];
      setCurrentReward(next);

      const timer = setTimeout(() => {
        setCurrentReward(null);
        clearRewards();
      }, 7000);

      return () => clearTimeout(timer);
    }
  }, [pendingRewards, currentReward, clearRewards]);

  if (!currentReward) return null;

  const rarity = currentReward.rarity || "uncommon";
  const typeText =
    currentReward.type === "level_up"
      ? "NEW LEVEL REACHED"
      : currentReward.type === "achievement"
        ? "ACHIEVEMENT UNLOCKED"
        : "PROGRESS REWARD";

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] flex items-center justify-center overflow-hidden bg-black/60 backdrop-blur-[2px]">
      <AnimatePresence>
        {currentReward && (
          <>
            {}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className={cn(
                "absolute inset-0 pointer-events-none opacity-20",
                GLOW_COLORS[rarity]
              )}
            />

            {}
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0, x: 0, y: 0, rotate: 0 }}
                animate={{
                  scale: [0, 1.2, 0.8, 0],
                  x: (Math.random() - 0.5) * 1200,
                  y: (Math.random() - 0.5) * 1200,
                  rotate: Math.random() * 1080,
                }}
                transition={{ duration: 2.5, ease: "easeOut" }}
                className={cn(
                  "absolute",
                  i % 4 === 0
                    ? "text-emerald-400"
                    : i % 4 === 1
                      ? "text-yellow-400"
                      : i % 4 === 2
                        ? "text-purple-400"
                        : "text-cyan-400"
                )}
              >
                {i % 5 === 0 ? (
                  <Sparkles size={24} />
                ) : i % 5 === 1 ? (
                  <Star size={20} fill="currentColor" />
                ) : i % 5 === 2 ? (
                  <Leaf size={22} />
                ) : i % 5 === 3 ? (
                  <Zap size={20} />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-current" />
                )}
              </motion.div>
            ))}

            {}
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: 100, rotateY: 180 }}
              animate={{ opacity: 1, scale: 1, y: 0, rotateY: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -100, filter: "blur(10px)" }}
              transition={{ type: "spring", damping: 12, stiffness: 90 }}
              className={cn(
                "pointer-events-auto flex flex-col items-center gap-6 rounded-[3.5rem] border p-12 shadow-[0_0_100px_rgba(0,0,0,0.5)] backdrop-blur-3xl",
                "bg-slate-950/90 border-white/10 max-w-[450px] text-center"
              )}
            >
              <div className="relative">
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{
                    duration: 15,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                  className={cn(
                    "absolute inset-[-15px] border-2 border-dashed rounded-full opacity-20",
                    rarity === "epic"
                      ? "border-purple-500"
                      : rarity === "rare"
                        ? "border-amber-500"
                        : "border-emerald-500"
                  )}
                />

                <div
                  className={cn(
                    "absolute inset-0 blur-3xl opacity-50",
                    GLOW_COLORS[rarity]
                  )}
                />

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3, type: "spring" }}
                  className={cn(
                    "relative flex h-28 w-28 items-center justify-center rounded-[2.5rem] bg-gradient-to-br text-white shadow-2xl",
                    RARITY_COLORS[rarity]
                  )}
                >
                  {currentReward.type === "level_up" ? (
                    <Trophy className="h-14 w-14" />
                  ) : currentReward.type === "achievement" ? (
                    <Award className="h-14 w-14" />
                  ) : (
                    <Sparkles className="h-14 w-14" />
                  )}
                </motion.div>
              </div>

              <div className="space-y-3">
                <motion.p
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className={cn(
                    "text-xs font-black uppercase tracking-[0.4em]",
                    rarity === "epic"
                      ? "text-purple-400"
                      : rarity === "rare"
                        ? "text-amber-400"
                        : "text-emerald-400"
                  )}
                >
                  {typeText}
                </motion.p>

                <motion.h2
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="text-4xl font-black text-white leading-tight tracking-tight"
                >
                  {currentReward.title}
                </motion.h2>

                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: 0.7 }}
                  className="inline-flex items-center gap-2 bg-white/5 px-6 py-1.5 rounded-full border border-white/10"
                >
                  <p className="text-white/90 font-bold text-lg">
                    {currentReward.type === "xp"
                      ? `+${currentReward.value} XP`
                      : `Rare Tier`}
                  </p>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="w-full space-y-4"
              >
                <div className="h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                <p className="text-slate-300 text-base font-medium leading-relaxed px-4">
                  {currentReward.description ||
                    "Every positive action counts. You are leading the way to a greener tomorrow!"}
                </p>
              </motion.div>

              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 }}
                onClick={() => {
                  setCurrentReward(null);
                  clearRewards();
                }}
                className={cn(
                  "group relative w-full flex items-center justify-center h-14 rounded-2xl text-white font-black transition-all active:scale-95 shadow-xl",
                  "bg-white/10 hover:bg-white/20 border border-white/10"
                )}
              >
                <span className="relative z-10 tracking-widest">
                  COLLECT REWARD
                </span>
                <div
                  className={cn(
                    "absolute inset-0 blur-xl opacity-0 group-hover:opacity-40 transition-opacity rounded-2xl",
                    GLOW_COLORS[rarity]
                  )}
                />
              </motion.button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
