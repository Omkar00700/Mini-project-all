"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import QRCode from "qrcode";
import { TOTP } from "otpauth";
import { Copy, Check, Loader2, Shield, Smartphone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/auth-context";

const verifyTotpSchema = z.object({
  code: z
    .string()
    .min(6, "Code must be 6 digits")
    .max(6, "Code must be 6 digits"),
});

type VerifyTotpFormData = z.infer<typeof verifyTotpSchema>;

interface TwoFactorSetupProps {
  onComplete?: () => void;
}

export function TwoFactorSetup({ onComplete }: TwoFactorSetupProps) {
  const [step, setStep] = useState<"setup" | "verify">("setup");
  const [secret, setSecret] = useState<string>("");
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("");
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<VerifyTotpFormData>({
    resolver: zodResolver(verifyTotpSchema),
  });

  useEffect(() => {
    generateTotpSecret();
  }, []);

  const generateTotpSecret = async () => {
    try {
      setLoading(true);

      const totp = new TOTP({
        issuer: "Aura Platform",
        label: user?.email || "User",
        algorithm: "SHA1",
        digits: 6,
        period: 30,
      });

      const secretKey = totp.secret.base32;
      setSecret(secretKey);

      const otpAuthUrl = totp.toString();
      const qrCodeDataUrl = await QRCode.toDataURL(otpAuthUrl);
      setQrCodeUrl(qrCodeDataUrl);

      const codes = Array.from({ length: 8 }, () =>
        Math.random().toString(36).substring(2, 10).toUpperCase()
      );
      setBackupCodes(codes);
    } catch (error) {
      setError("Failed to generate 2FA setup. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const copySecret = async () => {
    try {
      await navigator.clipboard.writeText(secret);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {}
  };

  const verifyTotp = async (data: VerifyTotpFormData) => {
    try {
      setError(null);

      const totp = new TOTP({
        issuer: "Aura Platform",
        label: user?.email || "User",
        algorithm: "SHA1",
        digits: 6,
        period: 30,
        secret: secret,
      });

      const isValid = totp.validate({ token: data.code, window: 1 });

      if (isValid === null) {
        setError("Invalid code. Please try again.");
        return;
      }

      await new Promise((resolve) => setTimeout(resolve, 1000));

      onComplete?.();
    } catch (error) {
      setError("Failed to verify code. Please try again.");
    }
  };

  if (loading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-blue-100">
          <Shield className="h-6 w-6 text-blue-600" />
        </div>
        <CardTitle className="text-2xl font-bold">
          {step === "setup"
            ? "Set Up Two-Factor Authentication"
            : "Verify Your Setup"}
        </CardTitle>
        <CardDescription>
          {step === "setup"
            ? "Secure your account with an additional layer of protection"
            : "Enter the code from your authenticator app to complete setup"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {step === "setup" && (
          <>
            <div className="space-y-4">
              <div className="text-center">
                <h3 className="font-semibold mb-2">Step 1: Scan QR Code</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Use your authenticator app to scan this QR code
                </p>
                {qrCodeUrl && (
                  <div className="flex justify-center">
                    <Image
                      src={qrCodeUrl}
                      alt="2FA QR Code"
                      width={200}
                      height={200}
                      className="border rounded-lg"
                    />
                  </div>
                )}
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="font-semibold">
                  Step 2: Or Enter Secret Manually
                </h3>
                <p className="text-sm text-muted-foreground">
                  If you can&apos;t scan the QR code, enter this secret in your
                  authenticator app:
                </p>
                <div className="flex items-center space-x-2">
                  <Input
                    value={secret}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={copySecret}
                  >
                    {copied ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <h3 className="font-semibold">Recommended Apps</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <Smartphone className="h-4 w-4" />
                    <span>Google Authenticator</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Smartphone className="h-4 w-4" />
                    <span>Authy</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Smartphone className="h-4 w-4" />
                    <span>Microsoft Authenticator</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Smartphone className="h-4 w-4" />
                    <span>1Password</span>
                  </div>
                </div>
              </div>
            </div>

            <Button onClick={() => setStep("verify")} className="w-full">
              Continue to Verification
            </Button>
          </>
        )}

        {step === "verify" && (
          <>
            <form onSubmit={handleSubmit(verifyTotp)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="code">Verification Code</Label>
                <Input
                  id="code"
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  {...register("code")}
                  disabled={isSubmitting}
                  className="text-center text-lg tracking-widest"
                />
                {errors.code && (
                  <p className="text-sm text-red-600">{errors.code.message}</p>
                )}
                <p className="text-sm text-muted-foreground">
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>

              <div className="flex space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep("setup")}
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    "Verify & Enable"
                  )}
                </Button>
              </div>
            </form>

            <div className="space-y-2">
              <h3 className="font-semibold text-sm">Backup Codes</h3>
              <p className="text-xs text-muted-foreground">
                Save these backup codes in a safe place. You can use them to
                access your account if you lose your authenticator device.
              </p>
              <div className="grid grid-cols-2 gap-1 text-xs font-mono bg-gray-50 p-2 rounded">
                {backupCodes.map((code, index) => (
                  <div key={index} className="text-center py-1">
                    {code}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
