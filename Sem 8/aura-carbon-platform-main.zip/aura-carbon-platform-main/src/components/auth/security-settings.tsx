"use client";

import { useState } from "react";
import { Shield, Smartphone, Key, AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { TwoFactorSetup } from "./two-factor-setup";
import { UpdatePasswordForm } from "./update-password-form";

interface SecuritySettingsProps {
  twoFactorEnabled?: boolean;
  onTwoFactorToggle?: (enabled: boolean) => void;
}

export function SecuritySettings({
  twoFactorEnabled = false,
  onTwoFactorToggle,
}: SecuritySettingsProps) {
  const [showTwoFactorSetup, setShowTwoFactorSetup] = useState(false);
  const [showPasswordUpdate, setShowPasswordUpdate] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleTwoFactorComplete = () => {
    setShowTwoFactorSetup(false);
    onTwoFactorToggle?.(true);
  };

  const handleDisableTwoFactor = async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      onTwoFactorToggle?.(false);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold">Security Settings</h2>
        <p className="text-muted-foreground">
          Manage your account security and authentication methods
        </p>
      </div>

      {}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Key className="h-5 w-5" />
            <CardTitle>Password</CardTitle>
          </div>
          <CardDescription>
            Keep your account secure with a strong password
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="font-medium">Password</p>
              <p className="text-sm text-muted-foreground">
                Last updated: Never
              </p>
            </div>
            <Dialog
              open={showPasswordUpdate}
              onOpenChange={setShowPasswordUpdate}
            >
              <DialogTrigger asChild>
                <Button variant="outline">Change Password</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Change Password</DialogTitle>
                  <DialogDescription>
                    Enter your new password below
                  </DialogDescription>
                </DialogHeader>
                <UpdatePasswordForm />
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Smartphone className="h-5 w-5" />
            <CardTitle>Two-Factor Authentication</CardTitle>
          </div>
          <CardDescription>
            Add an extra layer of security to your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <p className="font-medium">Authenticator App</p>
                {twoFactorEnabled ? (
                  <Badge
                    variant="default"
                    className="bg-green-100 text-green-800"
                  >
                    Enabled
                  </Badge>
                ) : (
                  <Badge variant="secondary">Disabled</Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                {twoFactorEnabled
                  ? "Your account is protected with two-factor authentication"
                  : "Use an authenticator app to generate verification codes"}
              </p>
            </div>
            {twoFactorEnabled ? (
              <Button
                variant="outline"
                onClick={handleDisableTwoFactor}
                disabled={loading}
              >
                Disable
              </Button>
            ) : (
              <Dialog
                open={showTwoFactorSetup}
                onOpenChange={setShowTwoFactorSetup}
              >
                <DialogTrigger asChild>
                  <Button>Enable</Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <TwoFactorSetup onComplete={handleTwoFactorComplete} />
                </DialogContent>
              </Dialog>
            )}
          </div>

          {twoFactorEnabled && (
            <>
              <Separator />
              <div className="space-y-2">
                <p className="font-medium text-sm">Backup Options</p>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                  >
                    <Key className="mr-2 h-4 w-4" />
                    View Backup Codes
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                  >
                    <Smartphone className="mr-2 h-4 w-4" />
                    Regenerate Backup Codes
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {}
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <CardTitle>Security Recommendations</CardTitle>
          </div>
          <CardDescription>
            Follow these recommendations to keep your account secure
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div className="space-y-1">
                <p className="text-sm font-medium">
                  Use a strong, unique password
                </p>
                <p className="text-xs text-muted-foreground">
                  Your password should be at least 12 characters long and
                  include a mix of letters, numbers, and symbols.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div
                className={`flex-shrink-0 w-2 h-2 rounded-full mt-2 ${twoFactorEnabled ? "bg-green-500" : "bg-yellow-500"}`}
              ></div>
              <div className="space-y-1">
                <p className="text-sm font-medium">
                  Enable two-factor authentication
                </p>
                <p className="text-xs text-muted-foreground">
                  Add an extra layer of security by requiring a code from your
                  phone in addition to your password.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
              <div className="space-y-1">
                <p className="text-sm font-medium">
                  Keep your recovery information up to date
                </p>
                <p className="text-xs text-muted-foreground">
                  Make sure your email address is current so you can recover
                  your account if needed.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {}
      {!twoFactorEnabled && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Security Notice:</strong> Your account is not fully
            protected. Enable two-factor authentication to add an extra layer of
            security.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
