"use client";

import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Menu,
  Search,
  User,
  Settings,
  LogOut,
  Shield,
  Moon,
  Sun,
  Monitor,
  Leaf,
} from "lucide-react";

import { useTheme } from "next-themes";
import Link from "next/link";
import { useRouter } from "next/navigation";

interface HeaderProps {
  className?: string;
}

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export function Header({ className }: HeaderProps) {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const { user, signOut, loading } = useAuth();

  const handleLogout = async () => {
    await signOut();
    router.push("/");
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const ThemeToggle = () => {
    const { setTheme } = useTheme();
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setTheme("light")}>
            <Sun className="mr-2 h-4 w-4" /> Light
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("dark")}>
            <Moon className="mr-2 h-4 w-4" /> Dark
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("system")}>
            <Monitor className="mr-2 h-4 w-4" /> System
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  const mobileLinks = user
    ? [
        { name: "Dashboard", href: "/dashboard" },
        { name: "Calculator", href: "/calculator" },
        { name: "Activities", href: "/activities" },
        { name: "Goals", href: "/goals" },
        { name: "Achievements", href: "/achievements" },
        { name: "Recommendations", href: "/recommendations" },
        { name: "✨ AI Chat", href: "/ai-chat" },
      ]
    : [
        { name: "Home", href: "/" },
        { name: "Calculator", href: "/calculator" },
        { name: "Sign In", href: "/auth/login" },
      ];

  return (
    <header
      className={cn(
        "flex items-center justify-between h-16 px-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        className
      )}
    >
      {}
      <div className="flex items-center gap-4">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="sm" className="md:hidden h-8 w-8 p-0">
              <Menu className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent
            side="left"
            className="w-72 bg-background/95 backdrop-blur"
          >
            <SheetHeader>
              <SheetTitle className="flex items-center space-x-2">
                <Leaf className="h-5 w-5 text-emerald-500" />
                <span className="font-bold text-lg tracking-tight">Aura</span>
              </SheetTitle>
            </SheetHeader>
            <div className="flex flex-col space-y-4 mt-8">
              {mobileLinks.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-base font-medium text-muted-foreground hover:text-foreground transition-all"
                >
                  {item.name}
                </Link>
              ))}

              <div className="pt-6 border-t border-border mt-4 flex flex-col gap-4">
                {user ? (
                  <>
                    <div className="flex items-center gap-3 mb-2">
                      <Avatar className="h-8 w-8 ring-2 ring-primary/30">
                        <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
                          {getInitials(user.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{user.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {user.email}
                        </span>
                      </div>
                    </div>
                    <Link
                      href="/profile"
                      className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
                    >
                      <User className="mr-2 h-4 w-4" /> Profile
                    </Link>
                    <Link
                      href="/settings"
                      className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
                    >
                      <Settings className="mr-2 h-4 w-4" /> Settings
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="flex items-center text-sm font-medium text-destructive hover:text-destructive/80 text-left"
                    >
                      <LogOut className="mr-2 h-4 w-4" /> Sign out
                    </button>
                  </>
                ) : (
                  <Button
                    className="w-full bg-primary hover:bg-primary/90 rounded-full"
                    asChild
                  >
                    <Link href="/auth/register">Get Started Free</Link>
                  </Button>
                )}
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <Link href="/" className="flex items-center space-x-2 ml-2 md:ml-0">
          <div className="p-1.5 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-md shadow-[0_0_10px_rgba(16,185,129,0.2)]">
            <Leaf className="h-4 w-4 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight text-foreground">
            Aura
          </span>
        </Link>

        {}
        <div className="hidden md:flex items-center ml-2">
          <Button
            variant="outline"
            className="relative h-9 w-9 p-0 xl:h-10 xl:w-60 xl:justify-start xl:px-3 xl:py-2 bg-background/50 border-white/10"
          >
            <Search className="h-4 w-4 xl:mr-2" />
            <span className="hidden xl:inline-flex text-muted-foreground">
              Search...
            </span>
            <kbd className="pointer-events-none absolute right-1.5 top-2 hidden h-6 select-none items-center gap-1 rounded border border-white/10 bg-white/5 px-1.5 font-mono text-[10px] font-medium opacity-100 xl:flex text-muted-foreground">
              <span className="text-xs">⌘</span>K
            </kbd>
          </Button>
        </div>
      </div>

      {}
      <nav className="hidden md:flex items-center justify-center space-x-6 absolute left-1/2 -translate-x-1/2">
        {[
          { name: "Dashboard", href: "/dashboard" },
          { name: "Calculator", href: "/calculator" },
          { name: "Achievements", href: "/achievements" },
          { name: "✨ AI Chat", href: "/ai-chat" },
        ].map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-all hover:scale-105"
          >
            {item.name}
          </Link>
        ))}
      </nav>

      {}
      <div className="flex items-center gap-2">
        <ThemeToggle />

        {}
        {user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="relative flex items-center gap-2 h-9 px-2 rounded-full hover:bg-muted/80"
              >
                <Avatar className="h-8 w-8 ring-2 ring-primary/30">
                  <AvatarFallback className="bg-primary/15 text-primary text-xs font-bold">
                    {getInitials(user.name)}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden sm:block text-sm font-medium text-foreground max-w-[120px] truncate">
                  {user.name}
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-60" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-semibold leading-none text-foreground">
                    {user.name}
                  </p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user.email}
                  </p>
                  {user.role === "admin" && (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-500 font-medium mt-1">
                      <Shield className="w-3 h-3" />
                      Administrator
                    </span>
                  )}
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/profile" className="cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings" className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Link>
              </DropdownMenuItem>
              {user.role === "admin" && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link
                      href="/admin"
                      className="cursor-pointer text-amber-600 dark:text-amber-400"
                    >
                      <Shield className="mr-2 h-4 w-4" />
                      Admin Panel
                    </Link>
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={handleLogout}
                disabled={loading}
                className="text-destructive focus:text-destructive cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/auth/login">Sign In</Link>
            </Button>
            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-4"
              asChild
            >
              <Link href="/auth/register">Get Started</Link>
            </Button>
          </div>
        )}
      </div>
    </header>
  );
}
