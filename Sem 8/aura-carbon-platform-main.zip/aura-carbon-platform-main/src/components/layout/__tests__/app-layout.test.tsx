import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AppLayout } from "../app-layout";

jest.mock("../header", () => ({
  Header: ({ onMenuToggle }: { onMenuToggle: () => void }) => (
    <header data-testid="header">
      <button onClick={onMenuToggle} data-testid="menu-toggle">
        Toggle Menu
      </button>
    </header>
  ),
}));

jest.mock("../sidebar", () => ({
  Sidebar: ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => (
    <aside data-testid="sidebar" data-open={isOpen}>
      <button onClick={onClose} data-testid="sidebar-close">
        Close
      </button>
      <nav>
        <a href="/dashboard">Dashboard</a>
        <a href="/profile">Profile</a>
      </nav>
    </aside>
  ),
}));

jest.mock("../footer", () => ({
  Footer: () => <footer data-testid="footer">Footer Content</footer>,
}));

describe("AppLayout", () => {
  const mockChildren = <main data-testid="main-content">Main Content</main>;

  it("renders all layout components", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    expect(screen.getByTestId("header")).toBeInTheDocument();
    expect(screen.getByTestId("sidebar")).toBeInTheDocument();
    expect(screen.getByTestId("footer")).toBeInTheDocument();
    expect(screen.getByTestId("main-content")).toBeInTheDocument();
  });

  it("has proper responsive layout structure", () => {
    const { container } = render(<AppLayout>{mockChildren}</AppLayout>);

    const layoutContainer = container.firstChild;
    expect(layoutContainer).toHaveClass("min-h-screen");
  });

  it("toggles sidebar visibility on mobile", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const sidebar = screen.getByTestId("sidebar");
    const menuToggle = screen.getByTestId("menu-toggle");

    expect(sidebar).toHaveAttribute("data-open", "false");

    await user.click(menuToggle);
    expect(sidebar).toHaveAttribute("data-open", "true");

    await user.click(menuToggle);
    expect(sidebar).toHaveAttribute("data-open", "false");
  });

  it("closes sidebar when close button is clicked", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const sidebar = screen.getByTestId("sidebar");
    const menuToggle = screen.getByTestId("menu-toggle");
    const sidebarClose = screen.getByTestId("sidebar-close");

    await user.click(menuToggle);
    expect(sidebar).toHaveAttribute("data-open", "true");

    await user.click(sidebarClose);
    expect(sidebar).toHaveAttribute("data-open", "false");
  });

  it("handles keyboard navigation", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const menuToggle = screen.getByTestId("menu-toggle");

    menuToggle.focus();
    expect(menuToggle).toHaveFocus();

    await user.keyboard("{Enter}");
    const sidebar = screen.getByTestId("sidebar");
    expect(sidebar).toHaveAttribute("data-open", "true");
  });

  it("closes sidebar on escape key", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const menuToggle = screen.getByTestId("menu-toggle");

    await user.click(menuToggle);
    const sidebar = screen.getByTestId("sidebar");
    expect(sidebar).toHaveAttribute("data-open", "true");

    await user.keyboard("{Escape}");
    expect(sidebar).toHaveAttribute("data-open", "false");
  });

  it("maintains proper focus management", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const menuToggle = screen.getByTestId("menu-toggle");

    await user.click(menuToggle);

    const dashboardLink = screen.getByRole("link", { name: /dashboard/i });
    expect(dashboardLink).toBeInTheDocument();
  });

  it("has proper ARIA attributes for accessibility", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    const sidebar = screen.getByTestId("sidebar");
    expect(sidebar).toHaveAttribute("data-testid", "sidebar");

    expect(screen.getByTestId("header")).toBeInTheDocument();
    expect(screen.getByTestId("footer")).toBeInTheDocument();
  });

  it("adapts to different screen sizes", () => {
    const mockMatchMedia = jest.fn();
    mockMatchMedia.mockReturnValue({
      matches: false,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    });
    window.matchMedia = mockMatchMedia;

    render(<AppLayout>{mockChildren}</AppLayout>);

    expect(screen.getByTestId("main-content")).toBeInTheDocument();
  });

  it("handles sidebar overlay on mobile", async () => {
    const user = userEvent.setup();

    Object.defineProperty(window, "innerWidth", {
      writable: true,
      configurable: true,
      value: 768,
    });

    render(<AppLayout>{mockChildren}</AppLayout>);

    const menuToggle = screen.getByTestId("menu-toggle");
    await user.click(menuToggle);

    const sidebar = screen.getByTestId("sidebar");
    expect(sidebar).toHaveAttribute("data-open", "true");
  });

  it("preserves main content accessibility", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    const mainContent = screen.getByTestId("main-content");
    expect(mainContent).toBeInTheDocument();
    expect(mainContent).toBeVisible();
  });

  it("handles custom className", () => {
    const customClass = "custom-layout-class";
    const { container } = render(
      <AppLayout className={customClass}>{mockChildren}</AppLayout>
    );

    expect(container.firstChild).toHaveClass(customClass);
  });

  it("supports skip navigation link", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    const mainContent = screen.getByTestId("main-content");
    expect(mainContent).toBeInTheDocument();
  });

  it("maintains proper z-index stacking", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    const header = screen.getByTestId("header");
    const mainContent = screen.getByTestId("main-content");

    expect(header).toBeInTheDocument();
    expect(mainContent).toBeInTheDocument();
  });

  it("handles touch events on mobile", async () => {
    const user = userEvent.setup();
    render(<AppLayout>{mockChildren}</AppLayout>);

    const menuToggle = screen.getByTestId("menu-toggle");

    fireEvent.touchStart(menuToggle);
    fireEvent.touchEnd(menuToggle);

    await user.click(menuToggle);
    const sidebar = screen.getByTestId("sidebar");
    expect(sidebar).toHaveAttribute("data-open", "true");
  });

  it("provides proper semantic structure", () => {
    render(<AppLayout>{mockChildren}</AppLayout>);

    expect(screen.getByTestId("header")).toBeInTheDocument();
    expect(screen.getByTestId("sidebar")).toBeInTheDocument();
    expect(screen.getByTestId("footer")).toBeInTheDocument();
    expect(screen.getByTestId("main-content")).toBeInTheDocument();
  });
});
