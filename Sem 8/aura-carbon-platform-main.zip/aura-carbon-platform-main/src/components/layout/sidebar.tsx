"use client";

import { cn } from "@/lib/utils";
import { useUIStore } from "@/store";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import {
  LayoutDashboard,
  Activity,
  Calculator,
  Target,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Leaf,
  Award,
  Zap,
  Car,
  UtensilsCrossed,
  ShoppingBag,
  Trash2,
  Sparkles,
  Lightbulb,
  Trophy,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { useGamificationStore } from "@/store/gamification-store";
import { StreakIndicator } from "@/components/gamification/StreakIndicator";
import { Badge } from "@/components/ui/badge";

interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  requiresAuth?: boolean;
}

const mainNavigation: NavItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
    requiresAuth: true,
  },
  {
    title: "Activities",
    href: "/activities",
    icon: Activity,
    requiresAuth: true,
  },
  {
    title: "Goals",
    href: "/goals",
    icon: Target,
    requiresAuth: true,
  },
  {
    title: "Carbon Calculator",
    href: "/calculator",
    icon: Calculator,
    requiresAuth: true,
  },
];

const exploreNavigation: NavItem[] = [
  {
    title: "Recommendations",
    href: "/recommendations",
    icon: Lightbulb,
    requiresAuth: true,
  },
  {
    title: "What-If Analyzer",
    href: "/what-if",
    icon: Sparkles,
    requiresAuth: true,
    badge: "NEW",
  },
  {
    title: "AI Assistant",
    href: "/ai-chat",
    icon: Zap,
    requiresAuth: true,
    badge: "AI",
  },
];

const communityNavigation: NavItem[] = [
  {
    title: "Leaderboard",
    href: "/leaderboard",
    icon: Trophy,
    requiresAuth: true,
  },
  {
    title: "Achievements",
    href: "/achievements",
    icon: Award,
    requiresAuth: true,
  },
];

const categoryItems: NavItem[] = [
  {
    title: "Transportation",
    href: "/calculator/transportation",
    icon: Car,
    requiresAuth: true,
  },
  {
    title: "Energy",
    href: "/calculator/energy",
    icon: Zap,
    requiresAuth: true,
  },
  {
    title: "Food",
    href: "/calculator/food",
    icon: UtensilsCrossed,
    requiresAuth: true,
  },
  {
    title: "Consumption",
    href: "/calculator/consumption",
    icon: ShoppingBag,
    requiresAuth: true,
  },
  {
    title: "Waste",
    href: "/calculator/waste",
    icon: Trash2,
    requiresAuth: true,
  },
];

const bottomItems: NavItem[] = [
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
    requiresAuth: true,
  },
  {
    title: "Help",
    href: "/help",
    icon: HelpCircle,
  },
];

interface SidebarProps {
  className?: string;
}

function NavSection({ title, items }: { title?: string; items: NavItem[] }) {
  const pathname = usePathname();
  const { sidebarCollapsed } = useUIStore();
  const { user } = useAuth();
  const isLoggedIn = !!user;

  const filteredItems = items.filter(
    (item) => !item.requiresAuth || isLoggedIn
  );

  if (filteredItems.length === 0) return null;

  return (
    <div className="space-y-2">
      {title && !sidebarCollapsed && (
        <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
          {title}
        </h3>
      )}
      <div className="space-y-1">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors group relative",
                isActive
                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <Icon
                className={cn(
                  "w-5 h-5",
                  isActive ? "text-emerald-500" : "group-hover:text-emerald-500"
                )}
              />
              {!sidebarCollapsed && (
                <>
                  <span className="flex-1 font-medium">{item.title}</span>
                  {item.badge && (
                    <Badge
                      variant="secondary"
                      className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-0 text-[10px] px-1.5 h-4"
                    >
                      {item.badge}
                    </Badge>
                  )}
                </>
              )}
              {isActive && (
                <motion.div
                  layoutId="active-nav"
                  className="absolute left-0 w-1 h-6 bg-emerald-500 rounded-r-full"
                />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}

export default function Sidebar({ className }: SidebarProps) {
  const { sidebarCollapsed, setSidebarCollapsed } = useUIStore();
  const { user } = useAuth();
  const isLoggedIn = !!user;
  const { xp, level, streak, streakFreezes } = useGamificationStore();

  const currentXp = xp || 0;
  const currentLevel = level || 1;
  const currentStreak = streak || 0;
  const currentFreezes = streakFreezes || 0;

  const progress = currentXp % 100;

  return (
    <div
      className={cn(
        "flex flex-col h-full bg-background border-r transition-all duration-300",
        sidebarCollapsed ? "w-16" : "w-64",
        className
      )}
    >
      {}
      <div className="flex items-center justify-between p-4 border-b">
        {!sidebarCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg">Aura</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="h-8 w-8 p-0"
        >
          {sidebarCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </Button>
      </div>

      {}
      <ScrollArea className="flex-1 px-3 py-4">
        <div className="space-y-6">
          <NavSection items={mainNavigation} />

          {isLoggedIn && (
            <>
              <Separator />
              <NavSection title="Explore" items={exploreNavigation} />

              <Separator />
              <NavSection title="Community" items={communityNavigation} />

              <Separator />
              <NavSection title="Categories" items={categoryItems} />
            </>
          )}
        </div>
      </ScrollArea>

      {}
      {isLoggedIn && !sidebarCollapsed && user && (
        <div className="mx-3 mb-2 p-3 rounded-xl bg-gradient-to-br from-emerald-500/10 to-transparent border border-emerald-500/20">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3 overflow-hidden">
              <Avatar className="h-9 w-9 border border-emerald-500/30">
                <AvatarFallback className="bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold">
                  {user.name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate text-foreground dark:text-white leading-tight">
                  {user.name}
                </p>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-black uppercase tracking-widest mt-0.5">
                  Lvl {currentLevel}
                </p>
              </div>
            </div>

            <StreakIndicator
              streak={currentStreak}
              freezes={currentFreezes}
              size="sm"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-tighter">
              <span>Next Level</span>
              <span>{progress}%</span>
            </div>
            <Progress
              value={progress}
              className="h-1.5 bg-background dark:bg-black/40 border border-emerald-500/10"
            />
          </div>
        </div>
      )}

      {}
      <div className="p-3 border-t">
        <NavSection items={bottomItems} />
      </div>
    </div>
  );
}
