"use client";

import { cn } from "@/lib/utils";
import { useUIStore } from "@/store";
import { Header } from "./header";
import Sidebar from "./sidebar";
import { Footer } from "./footer";
import { useEffect } from "react";
import { useMediaQuery } from "@/hooks/use-media-query";

interface AppLayoutProps {
  children: React.ReactNode;
  showSidebar?: boolean;
  showFooter?: boolean;
  className?: string;
}

export function AppLayout({
  children,
  showSidebar = true,
  showFooter = true,
  className,
}: AppLayoutProps) {
  const { sidebarOpen, sidebarCollapsed, setSidebarOpen } = useUIStore();

  const isMobile = useMediaQuery("(max-width: 768px)");

  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  }, [isMobile, setSidebarOpen]);

  return (
    <div className="min-h-screen bg-background">
      {}
      <Header />

      <div className="flex h-[calc(100vh-4rem)]">
        {}
        {showSidebar && (
          <>
            {}
            {isMobile && sidebarOpen && (
              <div
                className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
                onClick={() => setSidebarOpen(false)}
              />
            )}

            {}
            <aside
              className={cn(
                "fixed left-0 top-16 z-50 h-[calc(100vh-4rem)] transition-transform duration-300 md:relative md:top-0 md:translate-x-0",
                isMobile && !sidebarOpen && "-translate-x-full",
                !isMobile && sidebarCollapsed && "md:w-16",
                !isMobile && !sidebarCollapsed && "md:w-64"
              )}
            >
              <Sidebar />
            </aside>
          </>
        )}

        {}
        <main className={cn("flex-1 flex flex-col overflow-hidden", className)}>
          {}
          <div className="flex-1 overflow-auto">{children}</div>

          {}
          {showFooter && <Footer className="mt-auto" />}
        </main>
      </div>
    </div>
  );
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppLayout showSidebar={true} showFooter={false}>
      <div className="p-6">{children}</div>
    </AppLayout>
  );
}

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppLayout showSidebar={false} showFooter={false}>
      <div className="flex items-center justify-center min-h-full p-4">
        {children}
      </div>
    </AppLayout>
  );
}

export function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppLayout showSidebar={false} showFooter={true}>
      {children}
    </AppLayout>
  );
}

export function CalculatorLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppLayout showSidebar={true} showFooter={false}>
      <div className="flex flex-col h-full">{children}</div>
    </AppLayout>
  );
}
