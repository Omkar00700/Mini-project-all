"use client";

import { useState, useEffect, useCallback } from "react";
import { Trophy, Loader2, Lock } from "lucide-react";

interface UserAchievement {
  key: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  unlocked: boolean;
  unlockedAt?: string;
  progress?: number;
  progressLabel?: string;
}

interface AchievementBadgesProps {
  userId: string;
  className?: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  milestone: "#3b82f6",
  streak: "#f59e0b",
  impact: "#10b981",
  exploration: "#8b5cf6",
};

export function AchievementBadges({
  userId,
  className,
}: AchievementBadgesProps) {
  const [achievements, setAchievements] = useState<UserAchievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [unlockedCount, setUnlockedCount] = useState(0);

  const fetchAchievements = useCallback(async () => {
    try {
      const response = await fetch(
        `/api/analytics/achievements?userId=${userId}`
      );
      if (!response.ok) throw new Error("Failed");
      const data = await response.json();
      setAchievements(data.achievements || []);
      setUnlockedCount(data.unlocked || 0);
    } catch (err) {
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const checkAchievements = async () => {
    try {
      setChecking(true);
      const response = await fetch("/api/analytics/achievements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (!response.ok) throw new Error("Failed");
      const data = await response.json();
      setAchievements(data.achievements || []);
      setUnlockedCount(data.unlocked || 0);
    } catch (err) {
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    fetchAchievements();
  }, [fetchAchievements]);

  if (loading) {
    return (
      <div className={className}>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  const unlocked = achievements.filter((a) => a.unlocked);
  const locked = achievements.filter((a) => !a.unlocked);

  return (
    <div className={className}>
      {}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold">{unlockedCount}</span>
          <span className="text-sm text-muted-foreground">
            / {achievements.length}
          </span>
        </div>
        <button
          onClick={checkAchievements}
          disabled={checking}
          className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-full bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors disabled:opacity-50"
        >
          {checking ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <Trophy className="h-3 w-3" />
          )}
          Check
        </button>
      </div>

      {}
      {unlocked.length > 0 && (
        <div className="grid grid-cols-4 gap-2 mb-3">
          {unlocked.map((a) => (
            <div
              key={a.key}
              className="group relative flex flex-col items-center p-2 rounded-lg bg-gradient-to-b from-amber-50 to-white border border-amber-100 hover:shadow-md hover:scale-105 transition-all cursor-default"
              title={`${a.title}: ${a.description}`}
            >
              <span className="text-2xl mb-1 drop-shadow-sm">{a.icon}</span>
              <span className="text-[10px] font-medium text-center leading-tight truncate w-full">
                {a.title}
              </span>
              {}
              <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 hidden group-hover:block z-10 w-36">
                <div className="bg-gray-900 text-white text-[10px] rounded-lg px-2 py-1.5 text-center shadow-lg">
                  {a.description}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {}
      {locked.length > 0 && (
        <div className="space-y-1.5">
          {locked.slice(0, 4).map((a) => (
            <div
              key={a.key}
              className="flex items-center gap-2.5 p-2 rounded-lg bg-muted/30 border border-transparent"
            >
              <span className="text-lg grayscale opacity-40">{a.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-muted-foreground">
                  {a.title}
                </p>
                {a.progress !== undefined && a.progress > 0 && (
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{
                          width: `${a.progress}%`,
                          backgroundColor:
                            CATEGORY_COLORS[a.category] || "#6b7280",
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                      {a.progressLabel}
                    </span>
                  </div>
                )}
              </div>
              <Lock className="h-3 w-3 text-muted-foreground/40 flex-shrink-0" />
            </div>
          ))}
          {locked.length > 4 && (
            <p className="text-[10px] text-muted-foreground text-center pt-1">
              +{locked.length - 4} more to unlock
            </p>
          )}
        </div>
      )}

      {}
      {achievements.length === 0 && (
        <div className="text-center py-4">
          <Trophy className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">No achievements yet</p>
          <button
            onClick={checkAchievements}
            className="mt-2 text-xs text-primary hover:underline"
          >
            Check for achievements
          </button>
        </div>
      )}
    </div>
  );
}
