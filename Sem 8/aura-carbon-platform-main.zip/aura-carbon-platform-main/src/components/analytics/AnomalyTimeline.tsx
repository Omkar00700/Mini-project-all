"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";
import {
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  Zap,
  Car,
  Utensils,
  Trash2,
  Droplet,
  Filter,
  Lightbulb,
  Search,
} from "lucide-react";
import { getAnomalyInsights } from "@/lib/anomaly-insights";

const categoryIcons: Record<
  string,
  React.ComponentType<{ className?: string }>
> = {
  energy: Zap,
  electricity: Zap,
  transportation: Car,
  vehicle: Car,
  food: Utensils,
  waste: Trash2,
  water: Droplet,
};

const severityColors = {
  high: "bg-red-100 text-red-800 border-red-300",
  medium: "bg-amber-100 text-amber-800 border-amber-300",
  low: "bg-blue-100 text-blue-800 border-blue-300",
};

const severityBadgeColors = {
  high: "destructive",
  medium: "default",
  low: "secondary",
} as const;

export interface Anomaly {
  id: string;
  date: Date | string;
  category: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: "low" | "medium" | "high";
  acknowledged: boolean;
}

interface AnomalyTimelineProps {
  userId: string;
  className?: string;
}

export function AnomalyTimeline({ userId, className }: AnomalyTimelineProps) {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<{
    severity?: "low" | "medium" | "high";
    category?: string;
    acknowledged?: boolean;
  }>({});

  useEffect(() => {
    async function fetchAnomalies() {
      try {
        setLoading(true);
        const params = new URLSearchParams({ userId });

        if (filter.severity) params.append("severity", filter.severity);
        if (filter.category) params.append("category", filter.category);
        if (filter.acknowledged !== undefined) {
          params.append("acknowledged", String(filter.acknowledged));
        }

        const response = await fetch(`/api/analytics/anomalies?${params}`);

        if (!response.ok) {
          throw new Error("Failed to fetch anomalies");
        }

        const data = await response.json();
        setAnomalies(data.anomalies || []);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred");
      } finally {
        setLoading(false);
      }
    }

    fetchAnomalies();
  }, [userId, filter]);

  const handleAcknowledge = async (anomalyId: string) => {
    try {
      const response = await fetch(
        `/api/analytics/anomalies?anomalyId=${anomalyId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ acknowledged: true }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to acknowledge anomaly");
      }

      setAnomalies((prev) =>
        prev.map((a) => (a.id === anomalyId ? { ...a, acknowledged: true } : a))
      );
    } catch (err) {}
  };

  const groupedAnomalies = anomalies.reduce(
    (acc, anomaly) => {
      const date = new Date(anomaly.date).toLocaleDateString();
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(anomaly);
      return acc;
    },
    {} as Record<string, Anomaly[]>
  );

  if (loading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>Anomaly Timeline</CardTitle>
          <CardDescription>Loading anomalies...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>Anomaly Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  const unacknowledgedCount = anomalies.filter((a) => !a.acknowledged).length;

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Anomaly Timeline</CardTitle>
            <CardDescription>
              {anomalies.length === 0
                ? "No anomalies detected"
                : `${anomalies.length} anomalies found${unacknowledgedCount > 0 ? `, ${unacknowledgedCount} unacknowledged` : ""}`}
            </CardDescription>
          </div>

          {}
          <div className="flex items-center gap-2">
            <Button
              variant={filter.acknowledged === false ? "default" : "outline"}
              size="sm"
              onClick={() =>
                setFilter((prev) => ({
                  ...prev,
                  acknowledged: prev.acknowledged === false ? undefined : false,
                }))
              }
            >
              <Filter className="w-4 h-4 mr-1" />
              Unacknowledged
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {anomalies.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-green-500" />
            <p>No anomalies detected. Keep up the great work!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {}
            {Object.entries(groupedAnomalies)
              .sort(([a], [b]) => new Date(b).getTime() - new Date(a).getTime())
              .map(([date, dateAnomalies]) => (
                <div key={date} className="relative">
                  {}
                  <div className="sticky top-0 z-10 bg-background pb-2">
                    <h3 className="text-sm font-semibold text-muted-foreground">
                      {date}
                    </h3>
                  </div>

                  {}
                  <div className="space-y-3 border-l-2 border-muted pl-4 ml-2">
                    {dateAnomalies.map((anomaly) => (
                      <AnomalyCard
                        key={anomaly.id}
                        anomaly={anomaly}
                        onAcknowledge={handleAcknowledge}
                      />
                    ))}
                  </div>
                </div>
              ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface AnomalyCardProps {
  anomaly: Anomaly;
  onAcknowledge: (id: string) => void;
}

function AnomalyCard({ anomaly, onAcknowledge }: AnomalyCardProps) {
  const Icon = categoryIcons[anomaly.category.toLowerCase()] || AlertTriangle;
  const isIncrease = anomaly.actualValue > anomaly.expectedValue;
  const percentChange =
    ((anomaly.actualValue - anomaly.expectedValue) / anomaly.expectedValue) *
    100;
  const insights = getAnomalyInsights(anomaly);

  return (
    <div
      className={cn(
        "relative rounded-lg border p-4 transition-all hover:shadow-md",
        severityColors[anomaly.severity],
        anomaly.acknowledged && "opacity-60"
      )}
    >
      {}
      <div className="absolute -left-[1.3rem] top-6 w-3 h-3 rounded-full bg-background border-2 border-primary" />

      {}
      <div className="space-y-3">
        {}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <Icon className="w-5 h-5" />
            <h4 className="font-semibold capitalize">{anomaly.category}</h4>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant={severityBadgeColors[anomaly.severity]}>
              {anomaly.severity}
            </Badge>
            {anomaly.acknowledged && (
              <Badge
                variant="outline"
                className="bg-green-50 text-green-700 border-green-300"
              >
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Acknowledged
              </Badge>
            )}
          </div>
        </div>

        {}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Expected</p>
            <p className="font-semibold">
              {anomaly.expectedValue.toFixed(2)} kg CO₂
            </p>
          </div>
          <div>
            <p className="text-muted-foreground">Actual</p>
            <div className="flex items-center gap-1">
              <p className="font-semibold">
                {anomaly.actualValue.toFixed(2)} kg CO₂
              </p>
              {isIncrease ? (
                <TrendingUp className="w-4 h-4 text-red-600" />
              ) : (
                <TrendingDown className="w-4 h-4 text-green-600" />
              )}
            </div>
          </div>
        </div>

        {}
        {!anomaly.acknowledged && insights.possibleCauses.length > 0 && (
          <div className="mt-3 bg-white/50 p-3 rounded-md border border-black/5 text-sm">
            <div className="flex items-center gap-2 mb-1 text-xs font-semibold uppercase tracking-wider opacity-70">
              <Search className="w-3 h-3" />
              Analysis
            </div>
            <div className="grid gap-2">
              {insights.possibleCauses.length > 0 && (
                <div>
                  <span className="font-medium">Potential Cause:</span>{" "}
                  {insights.possibleCauses[0]}
                </div>
              )}
              {insights.recommendations.length > 0 && (
                <div className="flex items-start gap-2 text-xs mt-1">
                  <Lightbulb className="w-3 h-3 mt-0.5 text-amber-600" />
                  <span>
                    <span className="font-medium text-amber-800">
                      Recommendation:
                    </span>{" "}
                    {insights.recommendations[0]}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {}
        <div className="flex items-center justify-between pt-2">
          <div className="text-sm">
            <span className="font-semibold">
              {percentChange > 0 ? "+" : ""}
              {percentChange.toFixed(1)}%
            </span>
            <span className="text-muted-foreground"> from expected</span>
            <span className="block text-xs text-muted-foreground mt-1">
              Deviation: {anomaly.deviation.toFixed(2)}σ
            </span>
          </div>

          {!anomaly.acknowledged && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onAcknowledge(anomaly.id)}
              className="hover:bg-green-50 hover:text-green-700 hover:border-green-300"
            >
              <CheckCircle2 className="w-4 h-4 mr-1" />
              Acknowledge
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
