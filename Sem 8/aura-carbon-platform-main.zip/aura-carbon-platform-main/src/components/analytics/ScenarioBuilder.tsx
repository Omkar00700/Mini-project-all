"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Leaf,
  Zap,
  Car,
  Utensils,
  Trash2,
  Plus,
  X,
  Save,
  Loader2,
  TrendingDown,
  Lightbulb,
} from "lucide-react";

interface Modification {
  id: string;
  category: string;
  action: "reduce" | "replace" | "eliminate";
  percentage: number;
  description: string;
}

interface CategoryBreakdown {
  category: string;
  emissions: number;
}

interface SavedScenario {
  id: string;
  name: string;
  description: string | null;
  baselineEmissions: number;
  projectedEmissions: number;
  savingsPercentage: number;
  createdAt: string;
}

interface ScenarioBuilderProps {
  userId: string;
  className?: string;
}

const CATEGORIES = [
  { key: "transportation", label: "Transport", icon: Car, color: "#ef4444" },
  { key: "energy", label: "Energy", icon: Zap, color: "#f59e0b" },
  { key: "food", label: "Food", icon: Utensils, color: "#10b981" },
  { key: "waste", label: "Waste", icon: Trash2, color: "#8b5cf6" },
];

const PRESET_SCENARIOS = [
  {
    name: "Go Green Commute",
    description: "Switch to public transport & cycling",
    mods: [
      {
        category: "transportation",
        action: "reduce" as const,
        percentage: 50,
        description: "Public transport & cycling",
      },
    ],
  },
  {
    name: "Solar Home",
    description: "Switch to renewable energy",
    mods: [
      {
        category: "energy",
        action: "reduce" as const,
        percentage: 60,
        description: "Solar panels + green energy",
      },
    ],
  },
  {
    name: "Plant-Based Diet",
    description: "Shift to mostly plant-based meals",
    mods: [
      {
        category: "food",
        action: "reduce" as const,
        percentage: 40,
        description: "Plant-based meals",
      },
    ],
  },
];

export function ScenarioBuilder({ userId, className }: ScenarioBuilderProps) {
  const [baseline, setBaseline] = useState<CategoryBreakdown[]>([]);
  const [savedScenarios, setSavedScenarios] = useState<SavedScenario[]>([]);
  const [modifications, setModifications] = useState<Modification[]>([]);
  const [scenarioName, setScenarioName] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showBuilder, setShowBuilder] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/analytics/scenarios?userId=${userId}`);
      if (!response.ok) throw new Error("Failed to fetch");
      const data = await response.json();
      setBaseline(data.baseline || []);
      setSavedScenarios(data.scenarios || []);
    } catch (err) {
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const baselineTotal = baseline.reduce((s, b) => s + b.emissions, 0);
  const projectedBreakdown = baseline.map((b) => {
    const mod = modifications.find((m) => m.category === b.category);
    if (!mod) return { ...b };
    const factor = Math.max(0, Math.min(100, mod.percentage)) / 100;
    return {
      ...b,
      emissions:
        mod.action === "eliminate"
          ? 0
          : Math.round(b.emissions * (1 - factor) * 100) / 100,
    };
  });
  const projectedTotal = projectedBreakdown.reduce(
    (s, b) => s + b.emissions,
    0
  );
  const savingsKg = Math.round((baselineTotal - projectedTotal) * 100) / 100;
  const savingsPct =
    baselineTotal > 0 ? Math.round((savingsKg / baselineTotal) * 100) : 0;

  const addModification = (category: string) => {
    if (modifications.find((m) => m.category === category)) return;
    setModifications([
      ...modifications,
      {
        id: crypto.randomUUID(),
        category,
        action: "reduce",
        percentage: 30,
        description: "",
      },
    ]);
  };

  const updateModification = (id: string, updates: Partial<Modification>) => {
    setModifications(
      modifications.map((m) => (m.id === id ? { ...m, ...updates } : m))
    );
  };

  const removeModification = (id: string) => {
    setModifications(modifications.filter((m) => m.id !== id));
  };

  const applyPreset = (preset: (typeof PRESET_SCENARIOS)[0]) => {
    setScenarioName(preset.name);
    setModifications(
      preset.mods.map((m) => ({
        id: crypto.randomUUID(),
        ...m,
      }))
    );
    setShowBuilder(true);
  };

  const handleSave = async () => {
    if (!scenarioName.trim() || modifications.length === 0) return;
    try {
      setSaving(true);
      const response = await fetch("/api/analytics/scenarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          name: scenarioName,
          modifications: modifications.map((m) => ({
            category: m.category,
            action: m.action,
            percentage: m.percentage,
            description: m.description,
          })),
        }),
      });
      if (!response.ok) throw new Error("Failed to save");
      setScenarioName("");
      setModifications([]);
      setShowBuilder(false);
      await fetchData();
    } catch (err) {
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/analytics/scenarios?id=${id}`, { method: "DELETE" });
      await fetchData();
    } catch (err) {}
  };

  if (loading) {
    return (
      <div className={className}>
        <div className="flex items-center justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      {}
      {!showBuilder && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground font-medium mb-2">
            Quick scenarios:
          </p>
          <div className="grid grid-cols-1 gap-2">
            {PRESET_SCENARIOS.map((preset) => (
              <button
                key={preset.name}
                onClick={() => applyPreset(preset)}
                className="flex items-center gap-3 p-3 rounded-lg border text-left hover:bg-muted/50 transition-colors group"
              >
                <Lightbulb className="h-4 w-4 text-amber-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{preset.name}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {preset.description}
                  </p>
                </div>
                <Plus className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>

          <button
            onClick={() => setShowBuilder(true)}
            className="w-full flex items-center justify-center gap-2 p-2.5 rounded-lg border-2 border-dashed text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors"
          >
            <Plus className="h-4 w-4" />
            Custom Scenario
          </button>
        </div>
      )}

      {}
      {showBuilder && (
        <div className="space-y-4">
          {}
          <input
            type="text"
            placeholder="Scenario name..."
            value={scenarioName}
            onChange={(e) => setScenarioName(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          />

          {}
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => {
              const isActive = modifications.some(
                (m) => m.category === cat.key
              );
              const Icon = cat.icon;
              return (
                <button
                  key={cat.key}
                  onClick={() => addModification(cat.key)}
                  disabled={isActive}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                    isActive
                      ? "opacity-40 cursor-not-allowed"
                      : "hover:shadow-sm hover:scale-105"
                  }`}
                  style={
                    !isActive
                      ? { borderColor: cat.color, color: cat.color }
                      : {}
                  }
                >
                  <Icon className="h-3.5 w-3.5" />
                  {cat.label}
                </button>
              );
            })}
          </div>

          {}
          {modifications.length > 0 && (
            <div className="space-y-2">
              {modifications.map((mod) => {
                const cat = CATEGORIES.find((c) => c.key === mod.category);
                const Icon = cat?.icon || Leaf;
                return (
                  <div
                    key={mod.id}
                    className="p-3 rounded-lg border space-y-2"
                    style={{ borderLeftWidth: 3, borderLeftColor: cat?.color }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon
                          className="h-4 w-4"
                          style={{ color: cat?.color }}
                        />
                        <span className="text-sm font-medium capitalize">
                          {mod.category}
                        </span>
                      </div>
                      <button
                        onClick={() => removeModification(mod.id)}
                        className="p-1 rounded hover:bg-muted transition-colors"
                      >
                        <X className="h-3.5 w-3.5 text-muted-foreground" />
                      </button>
                    </div>

                    {}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">Reduction</span>
                        <span
                          className="font-semibold"
                          style={{ color: cat?.color }}
                        >
                          {mod.percentage}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={5}
                        value={mod.percentage}
                        onChange={(e) =>
                          updateModification(mod.id, {
                            percentage: parseInt(e.target.value),
                          })
                        }
                        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                        style={{
                          background: `linear-gradient(to right, ${cat?.color} ${mod.percentage}%, #e5e7eb ${mod.percentage}%)`,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {}
          {modifications.length > 0 && (
            <div
              className={`p-3 rounded-lg border ${
                savingsKg > 0 ? "bg-emerald-50 border-emerald-200" : "bg-muted"
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingDown
                    className={`h-4 w-4 ${savingsKg > 0 ? "text-emerald-600" : "text-muted-foreground"}`}
                  />
                  <span className="text-sm font-medium">
                    {savingsKg > 0 ? "Projected Savings" : "No change"}
                  </span>
                </div>
                <div className="text-right">
                  <p
                    className={`text-lg font-bold ${savingsKg > 0 ? "text-emerald-700" : "text-muted-foreground"}`}
                  >
                    -{savingsKg} kg
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {savingsPct}% reduction / month
                  </p>
                </div>
              </div>

              {}
              <div className="mt-3 space-y-1.5">
                {baseline
                  .filter((b) => b.emissions > 0)
                  .map((b) => {
                    const proj = projectedBreakdown.find(
                      (p) => p.category === b.category
                    );
                    const pctOriginal =
                      baselineTotal > 0
                        ? (b.emissions / baselineTotal) * 100
                        : 0;
                    const pctProjected =
                      baselineTotal > 0
                        ? ((proj?.emissions || 0) / baselineTotal) * 100
                        : 0;
                    const cat = CATEGORIES.find((c) => c.key === b.category);
                    return (
                      <div
                        key={b.category}
                        className="flex items-center gap-2 text-xs"
                      >
                        <span className="w-20 capitalize truncate text-muted-foreground">
                          {b.category}
                        </span>
                        <div className="flex-1 h-3 bg-white/50 rounded-full overflow-hidden relative">
                          <div
                            className="absolute inset-y-0 left-0 rounded-full opacity-30"
                            style={{
                              width: `${pctOriginal}%`,
                              backgroundColor: cat?.color || "#6b7280",
                            }}
                          />
                          <div
                            className="absolute inset-y-0 left-0 rounded-full transition-all"
                            style={{
                              width: `${pctProjected}%`,
                              backgroundColor: cat?.color || "#6b7280",
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {}
          <div className="flex gap-2">
            <button
              onClick={() => {
                setShowBuilder(false);
                setModifications([]);
                setScenarioName("");
              }}
              className="flex-1 px-3 py-2 text-sm rounded-lg border hover:bg-muted transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={
                saving || !scenarioName.trim() || modifications.length === 0
              }
              className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              Save Scenario
            </button>
          </div>
        </div>
      )}

      {}
      {savedScenarios.length > 0 && !showBuilder && (
        <div className="mt-4 pt-4 border-t space-y-2">
          <p className="text-xs text-muted-foreground font-medium">
            Saved scenarios:
          </p>
          {savedScenarios.map((s) => (
            <div
              key={s.id}
              className="flex items-center justify-between p-3 rounded-lg border hover:shadow-sm transition-shadow"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{s.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span
                    className={`text-xs font-semibold ${
                      s.savingsPercentage > 0
                        ? "text-emerald-600"
                        : "text-muted-foreground"
                    }`}
                  >
                    {s.savingsPercentage > 0 ? "-" : ""}
                    {s.savingsPercentage}%
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {s.baselineEmissions.toFixed(0)} →{" "}
                    {s.projectedEmissions.toFixed(0)} kg/mo
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleDelete(s.id)}
                className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
