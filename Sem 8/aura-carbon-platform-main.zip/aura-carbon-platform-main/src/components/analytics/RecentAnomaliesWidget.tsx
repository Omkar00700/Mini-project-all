"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Zap,
  Car,
  Utensils,
  Trash2,
  Droplet,
  ArrowRight,
} from "lucide-react";
import { getAnomalyInsights } from "@/lib/anomaly-insights";

const categoryIcons: Record<
  string,
  React.ComponentType<{ className?: string }>
> = {
  energy: Zap,
  electricity: Zap,
  transportation: Car,
  vehicle: Car,
  food: Utensils,
  waste: Trash2,
  water: Droplet,
};

const severityColors = {
  high: "bg-red-100 text-red-800 border-red-200",
  medium: "bg-amber-100 text-amber-800 border-amber-200",
  low: "bg-blue-100 text-blue-800 border-blue-200",
};

interface Anomaly {
  id: string;
  date: string;
  category: string;
  expectedValue: number;
  actualValue: number;
  deviation: number;
  severity: "low" | "medium" | "high";
  acknowledged: boolean;
}

interface RecentAnomaliesWidgetProps {
  userId: string;
  maxItems?: number;
  className?: string;
}

export function RecentAnomaliesWidget({
  userId,
  maxItems = 3,
  className,
}: RecentAnomaliesWidgetProps) {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchAnomalies() {
      try {
        setLoading(true);
        const params = new URLSearchParams({
          userId,
          acknowledged: "false",
        });

        const response = await fetch(`/api/analytics/anomalies?${params}`);

        if (!response.ok) {
          throw new Error("Failed to fetch anomalies");
        }

        const data = await response.json();

        const sorted = (data.anomalies || [])
          .sort((a: Anomaly, b: Anomaly) => b.deviation - a.deviation)
          .slice(0, maxItems);

        setAnomalies(sorted);
        setError(null);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Error loading anomalies"
        );
      } finally {
        setLoading(false);
      }
    }

    fetchAnomalies();
  }, [userId, maxItems]);

  const highSeverityCount = anomalies.filter(
    (a) => a.severity === "high"
  ).length;

  if (loading) {
    return (
      <div className={className}>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={className}>
        <div className="text-center py-4 text-muted-foreground">
          <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-amber-500" />
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  if (anomalies.length === 0) {
    return (
      <div className={className}>
        <div className="text-center py-6 text-muted-foreground">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-2 text-green-500" />
          <p className="font-medium text-green-700">All Clear!</p>
          <p className="text-sm">No new anomalies detected</p>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      {}
      <div className="space-y-3">
        {anomalies.map((anomaly, index) => {
          const Icon =
            categoryIcons[anomaly.category.toLowerCase()] || AlertTriangle;
          const percentChange =
            ((anomaly.actualValue - anomaly.expectedValue) /
              anomaly.expectedValue) *
            100;
          const insights = getAnomalyInsights(anomaly);
          const showInsight = index === 0 && insights.possibleCauses.length > 0;

          return (
            <div
              key={anomaly.id}
              className={`p-3 rounded-lg border ${severityColors[anomaly.severity]} transition-all hover:shadow-sm`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium capitalize text-sm">
                        {anomaly.category}
                      </span>
                      <Badge
                        variant={
                          anomaly.severity === "high"
                            ? "destructive"
                            : "secondary"
                        }
                        className="text-xs py-0"
                      >
                        {anomaly.severity}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 text-xs mt-0.5">
                      <span className="font-semibold">
                        {percentChange > 0 ? "+" : ""}
                        {percentChange.toFixed(0)}%
                      </span>
                      <span className="text-muted-foreground">
                        from expected
                      </span>
                      <TrendingUp className="w-3 h-3 text-red-600" />
                    </div>

                    {}
                    {showInsight && (
                      <div className="mt-2 text-xs bg-white/50 p-1.5 rounded border border-black/5">
                        <span className="font-medium">Potential cause:</span>{" "}
                        {insights.possibleCauses[0]}
                      </div>
                    )}
                  </div>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(anomaly.date).toLocaleDateString()}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {}
      <div className="mt-4 pt-3 border-t">
        <Link href="/analytics/anomalies">
          <Button variant="ghost" size="sm" className="w-full justify-between">
            View All Anomalies
            <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </div>
    </div>
  );
}
