"use client";

import { useState, useEffect } from "react";
import {
  Award,
  TrendingDown,
  TrendingUp,
  Users,
  BarChart3,
  Loader2,
  Sparkles,
} from "lucide-react";
import { motion } from "framer-motion";

interface BenchmarkData {
  userId: string;
  period: string;
  cohortKey: string;
  cohortAverage: number;
  userValue: number;
  percentile: number;
  rank: number;
  totalInCohort: number;
}

interface BenchmarkCardProps {
  userId: string;
  className?: string;
}

function getPercentileLabel(percentile: number): {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  emoji: string;
} {
  if (percentile >= 90)
    return {
      label: "Exceptional",
      color: "text-emerald-700",
      bgColor: "bg-emerald-50",
      borderColor: "border-emerald-200",
      emoji: "🏆",
    };
  if (percentile >= 75)
    return {
      label: "Great",
      color: "text-green-700",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      emoji: "⭐",
    };
  if (percentile >= 50)
    return {
      label: "Good",
      color: "text-blue-700",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      emoji: "👍",
    };
  if (percentile >= 25)
    return {
      label: "Average",
      color: "text-amber-700",
      bgColor: "bg-amber-50",
      borderColor: "border-amber-200",
      emoji: "📊",
    };
  return {
    label: "Needs Work",
    color: "text-red-700",
    bgColor: "bg-red-50",
    borderColor: "border-red-200",
    emoji: "💪",
  };
}

function formatCohortKey(key: string): string {
  return key
    .split("_")
    .slice(0, 2)
    .map((part) => part.replace(/-/g, " "))
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(", ");
}

function PercentileGauge({
  percentile,
  size = 120,
}: {
  percentile: number;
  size?: number;
}) {
  const [animatedPercentile, setAnimatedPercentile] = useState(0);
  const strokeWidth = 8;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (animatedPercentile / 100) * circumference;
  const tier = getPercentileLabel(percentile);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedPercentile(percentile);
    }, 300);
    return () => clearTimeout(timer);
  }, [percentile]);

  const getStrokeColor = () => {
    if (percentile >= 75) return "#10b981";
    if (percentile >= 50) return "#3b82f6";
    if (percentile >= 25) return "#f59e0b";
    return "#ef4444";
  };

  return (
    <div className="relative flex flex-col items-center">
      <svg width={size} height={size} className="-rotate-90">
        {}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className="text-muted/20"
        />
        {}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={getStrokeColor()}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className="text-2xl font-bold"
          style={{ color: getStrokeColor() }}
        >
          {Math.round(animatedPercentile)}
        </span>
        <span className="text-xs text-muted-foreground font-medium -mt-0.5">
          percentile
        </span>
      </div>
      <div
        className={`mt-2 px-3 py-1 rounded-full text-xs font-semibold ${tier.bgColor} ${tier.color} ${tier.borderColor} border`}
      >
        {tier.emoji} {tier.label}
      </div>
    </div>
  );
}

export function BenchmarkCard({ userId, className }: BenchmarkCardProps) {
  const [benchmark, setBenchmark] = useState<BenchmarkData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [calculating, setCalculating] = useState(false);

  useEffect(() => {
    async function fetchBenchmark() {
      try {
        setLoading(true);
        const response = await fetch(
          `/api/analytics/benchmarks?userId=${userId}&latest=true`
        );
        if (!response.ok) throw new Error("Failed to fetch benchmark");

        const data = await response.json();
        setBenchmark(data.benchmark);
        setError(null);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Error loading benchmark"
        );
      } finally {
        setLoading(false);
      }
    }

    fetchBenchmark();
  }, [userId]);

  const handleCalculate = async () => {
    try {
      setCalculating(true);
      const response = await fetch("/api/analytics/benchmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (!response.ok) throw new Error("Failed to calculate benchmark");

      const data = await response.json();
      if (data.benchmark) {
        setBenchmark(data.benchmark);
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Error calculating benchmark"
      );
    } finally {
      setCalculating(false);
    }
  };

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={className}
      >
        <div className="flex flex-col items-center justify-center py-16 space-y-4 rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-500" />
          <p className="text-sm font-medium text-muted-foreground">
            Analyzing peer data...
          </p>
        </div>
      </motion.div>
    );
  }

  if (!benchmark) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={className}
      >
        <div className="text-center py-10 px-6 space-y-4 rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent opacity-50 pointer-events-none" />
          <div className="relative z-10 space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 flex items-center justify-center mx-auto text-emerald-500 mb-2">
              <BarChart3 className="w-8 h-8" />
            </div>
            <div>
              <p className="text-lg font-bold text-foreground">
                No benchmark data yet
              </p>
              <p className="text-sm text-muted-foreground mt-1 max-w-[250px] mx-auto">
                Calculate your ranking against similar users in your region to
                unlock these insights.
              </p>
            </div>
            <button
              onClick={handleCalculate}
              disabled={calculating}
              className="inline-flex items-center justify-center w-full sm:w-auto gap-2 px-6 py-3 mt-4 text-sm font-bold rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 disabled:opacity-50 transition-all shadow-[0_4px_14px_0_rgba(16,185,129,0.39)] hover:shadow-[0_6px_20px_rgba(16,185,129,0.23)] hover:-translate-y-0.5"
            >
              {calculating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Calculate Benchmark
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    );
  }

  if (error) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={className}
      >
        <div className="text-center py-8 px-6 rounded-3xl backdrop-blur-xl bg-background/50 border border-red-500/20 shadow-xl shadow-red-500/5 text-muted-foreground">
          <p className="text-sm text-red-500">{error}</p>
        </div>
      </motion.div>
    );
  }

  const isBelowAverage = benchmark.userValue < benchmark.cohortAverage;
  const diffPercent =
    benchmark.cohortAverage > 0
      ? Math.abs(
          ((benchmark.userValue - benchmark.cohortAverage) /
            benchmark.cohortAverage) *
            100
        )
      : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={className}
    >
      <div className="flex flex-col items-center gap-6 p-4 sm:p-6 rounded-3xl backdrop-blur-xl bg-background/50 border border-border/50 shadow-xl shadow-black/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(16,185,129,0.05)_0%,transparent_70%)] pointer-events-none" />

        {}
        <div className="relative z-10 w-full flex justify-center py-4 bg-background/40 rounded-2xl border border-white/5">
          <PercentileGauge percentile={benchmark.percentile} />
        </div>

        {}
        <div className="w-full space-y-4 relative z-10">
          {}
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl border border-border/50 bg-background/60 p-4 text-center hover:bg-secondary/40 transition-colors shadow-sm">
              <p className="text-xs text-muted-foreground font-medium mb-1">
                Your Emissions
              </p>
              <p className="text-2xl font-black text-foreground">
                {benchmark.userValue.toFixed(1)}
              </p>
              <p className="text-xs text-emerald-500 font-medium">kg CO₂</p>
            </div>
            <div className="rounded-2xl border border-border/50 bg-background/60 p-4 text-center hover:bg-secondary/40 transition-colors shadow-sm">
              <p className="text-xs text-muted-foreground font-medium mb-1">
                Cohort Average
              </p>
              <p className="text-2xl font-black text-foreground">
                {benchmark.cohortAverage.toFixed(1)}
              </p>
              <p className="text-xs text-emerald-500 font-medium">kg CO₂</p>
            </div>
          </div>

          {}
          <div
            className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-bold shadow-sm ${
              isBelowAverage
                ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                : "bg-amber-50 text-amber-700 border-amber-200"
            }`}
          >
            {isBelowAverage ? (
              <TrendingDown className="h-5 w-5" />
            ) : (
              <TrendingUp className="h-5 w-5" />
            )}
            <span>
              {diffPercent.toFixed(0)}% {isBelowAverage ? "below" : "above"}{" "}
              average
            </span>
          </div>

          {}
          <div className="pt-4 border-t border-border/50 space-y-3">
            <div className="text-sm font-medium text-center text-foreground flex items-center justify-center gap-1.5">
              📍 {formatCohortKey(benchmark.cohortKey)}
            </div>
            <div className="flex items-center justify-between text-xs font-medium text-muted-foreground bg-secondary/30 p-3 rounded-xl">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-emerald-500" />
                <span>
                  {benchmark.totalInCohort} user
                  {benchmark.totalInCohort !== 1 ? "s" : ""}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-4 w-4 text-emerald-500" />
                <span>Rank #{benchmark.rank}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
