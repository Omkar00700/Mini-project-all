"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function Navigation() {
  const pathname = usePathname();

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/dashboard", label: "Dashboard" },
    { href: "/calculator", label: "Calculator" },
    { href: "/activities", label: "Activities" },
    { href: "/goals", label: "Goals" },
  ];

  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-4">
          <Link href="/" className="text-xl font-bold text-green-600">
            Aura
          </Link>
          <nav className="flex space-x-2">
            {navItems.map((item) => (
              <Button
                key={item.href}
                variant={pathname === item.href ? "default" : "ghost"}
                size="sm"
                asChild
              >
                <Link href={item.href}>{item.label}</Link>
              </Button>
            ))}
          </nav>
        </div>
        <div className="text-sm text-muted-foreground">
          India-focused Carbon Tracking
        </div>
      </div>
    </Card>
  );
}
