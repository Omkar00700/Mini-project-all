"use client";

import { AuthProvider } from "@/contexts/auth-context-simple";

export function NextAuthProvider({ children }: { children: React.ReactNode }) {
  return <AuthProvider>{children}</AuthProvider>;
}
