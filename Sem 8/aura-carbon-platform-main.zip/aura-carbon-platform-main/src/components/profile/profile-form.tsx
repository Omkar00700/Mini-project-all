"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import {
  userProfileFormSchema,
  type UserProfileFormData,
} from "@/lib/validations/user";
import type { UserProfile } from "@/types/user";

interface ProfileFormProps {
  profile?: UserProfile;
  onSubmit: (data: UserProfileFormData) => Promise<void>;
  isLoading?: boolean;
}

export function ProfileForm({
  profile,
  onSubmit,
  isLoading = false,
}: ProfileFormProps) {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<UserProfileFormData>({
    resolver: zodResolver(userProfileFormSchema),
    defaultValues: profile
      ? {
          name: profile.name,
          country: profile.location.country,
          region: profile.location.region,
          city: profile.location.city,
          householdSize: profile.household.size,
          householdType: profile.household.type,
          incomeBracket: profile.household.income_bracket,
          units: profile.preferences.units,
          privacyLevel: profile.preferences.privacy_level,
          language: profile.preferences.language,
          timezone: profile.preferences.timezone,
          currency: profile.preferences.currency,
          notifications: profile.preferences.notifications,
        }
      : {
          householdSize: 1,
          householdType: "individual",
          units: "metric",
          privacyLevel: "private",
          notifications: {
            email: true,
            push: true,
            sms: false,
            marketing: false,
            recommendations: true,
            achievements: true,
            weekly_reports: true,
          },
        },
  });

  const handleFormSubmit = async (data: UserProfileFormData) => {
    setError(null);
    setSuccess(null);

    try {
      await onSubmit(data);
      setSuccess("Profile updated successfully!");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update profile");
    }
  };

  const notifications = watch("notifications");

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
        {}
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>
              Update your personal details and contact information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                {...register("name")}
                disabled={isSubmitting || isLoading}
              />
              {errors.name && (
                <p className="text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {}
        <Card>
          <CardHeader>
            <CardTitle>Location</CardTitle>
            <CardDescription>
              Your location helps us provide accurate carbon calculations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Input
                  id="country"
                  {...register("country")}
                  disabled={isSubmitting || isLoading}
                />
                {errors.country && (
                  <p className="text-sm text-red-600">
                    {errors.country.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="region">Region/State</Label>
                <Input
                  id="region"
                  {...register("region")}
                  disabled={isSubmitting || isLoading}
                />
                {errors.region && (
                  <p className="text-sm text-red-600">
                    {errors.region.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  {...register("city")}
                  disabled={isSubmitting || isLoading}
                />
                {errors.city && (
                  <p className="text-sm text-red-600">{errors.city.message}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {}
        <Card>
          <CardHeader>
            <CardTitle>Household</CardTitle>
            <CardDescription>
              Information about your household for accurate calculations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="householdSize">Household Size</Label>
                <Input
                  id="householdSize"
                  type="number"
                  min="1"
                  max="20"
                  {...register("householdSize", { valueAsNumber: true })}
                  disabled={isSubmitting || isLoading}
                />
                {errors.householdSize && (
                  <p className="text-sm text-red-600">
                    {errors.householdSize.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="householdType">Household Type</Label>
                <Select
                  value={watch("householdType")}
                  onValueChange={(value) =>
                    setValue(
                      "householdType",
                      value as "individual" | "family" | "shared"
                    )
                  }
                  disabled={isSubmitting || isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select household type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">Individual</SelectItem>
                    <SelectItem value="family">Family</SelectItem>
                    <SelectItem value="shared">Shared Living</SelectItem>
                  </SelectContent>
                </Select>
                {errors.householdType && (
                  <p className="text-sm text-red-600">
                    {errors.householdType.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="incomeBracket">Income Bracket (Optional)</Label>
              <Select
                value={watch("incomeBracket") || ""}
                onValueChange={(value) =>
                  setValue("incomeBracket", value || undefined)
                }
                disabled={isSubmitting || isLoading}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select income bracket" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="under-25k">Under $25,000</SelectItem>
                  <SelectItem value="25k-50k">$25,000 - $50,000</SelectItem>
                  <SelectItem value="50k-75k">$50,000 - $75,000</SelectItem>
                  <SelectItem value="75k-100k">$75,000 - $100,000</SelectItem>
                  <SelectItem value="100k-150k">$100,000 - $150,000</SelectItem>
                  <SelectItem value="over-150k">Over $150,000</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {}
        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
            <CardDescription>
              Customize your experience and privacy settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="units">Unit System</Label>
                <Select
                  value={watch("units")}
                  onValueChange={(value) =>
                    setValue("units", value as "metric" | "imperial")
                  }
                  disabled={isSubmitting || isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select unit system" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="metric">Metric (kg, km, °C)</SelectItem>
                    <SelectItem value="imperial">
                      Imperial (lbs, miles, °F)
                    </SelectItem>
                  </SelectContent>
                </Select>
                {errors.units && (
                  <p className="text-sm text-red-600">{errors.units.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="privacyLevel">Privacy Level</Label>
                <Select
                  value={watch("privacyLevel")}
                  onValueChange={(value) =>
                    setValue(
                      "privacyLevel",
                      value as "public" | "friends" | "private"
                    )
                  }
                  disabled={isSubmitting || isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select privacy level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Public</SelectItem>
                    <SelectItem value="friends">Friends Only</SelectItem>
                    <SelectItem value="private">Private</SelectItem>
                  </SelectContent>
                </Select>
                {errors.privacyLevel && (
                  <p className="text-sm text-red-600">
                    {errors.privacyLevel.message}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {}
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>
              Choose which notifications you&apos;d like to receive
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive important updates via email
                  </p>
                </div>
                <Switch
                  checked={notifications?.email || false}
                  onCheckedChange={(checked) =>
                    setValue("notifications.email", checked)
                  }
                  disabled={isSubmitting || isLoading}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Push Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive push notifications on your devices
                  </p>
                </div>
                <Switch
                  checked={notifications?.push || false}
                  onCheckedChange={(checked) =>
                    setValue("notifications.push", checked)
                  }
                  disabled={isSubmitting || isLoading}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Recommendations</Label>
                  <p className="text-sm text-muted-foreground">
                    Get personalized carbon reduction recommendations
                  </p>
                </div>
                <Switch
                  checked={notifications?.recommendations || false}
                  onCheckedChange={(checked) =>
                    setValue("notifications.recommendations", checked)
                  }
                  disabled={isSubmitting || isLoading}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Achievements</Label>
                  <p className="text-sm text-muted-foreground">
                    Celebrate your carbon reduction milestones
                  </p>
                </div>
                <Switch
                  checked={notifications?.achievements || false}
                  onCheckedChange={(checked) =>
                    setValue("notifications.achievements", checked)
                  }
                  disabled={isSubmitting || isLoading}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Weekly Reports</Label>
                  <p className="text-sm text-muted-foreground">
                    Get weekly summaries of your carbon footprint
                  </p>
                </div>
                <Switch
                  checked={notifications?.weekly_reports || false}
                  onCheckedChange={(checked) =>
                    setValue("notifications.weekly_reports", checked)
                  }
                  disabled={isSubmitting || isLoading}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={isSubmitting || isLoading}
            className="min-w-[120px]"
          >
            {isSubmitting || isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
