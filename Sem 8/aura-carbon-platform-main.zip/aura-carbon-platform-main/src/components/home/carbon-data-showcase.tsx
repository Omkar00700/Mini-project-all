"use client";

import { useRef, useMemo, useState, useEffect, useCallback } from "react";
import { motion, useScroll, useTransform, animate } from "framer-motion";
import {
  Leaf,
  Zap,
  Wind,
  Globe2,
  Flame,
  RefreshCw,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";

interface Co2ApiResponse {
  success: boolean;
  fallback?: boolean;
  data: {
    ppm: number;
    year: number;
    month: number;
    day: number;
    ppmYearAgo: number;
    increaseFromLastYear: number;
    source: string;
    lastUpdated: string;
  };
}

interface ClimateApiResponse {
  success: boolean;
  fallback?: boolean;
  data: {
    year: number;
    annualMeanAnomaly: number;
    source: string;
    lastUpdated: string;
  };
}

interface LiveData {
  co2Ppm: number | null;
  co2Increase: number | null;
  co2Source: string;
  co2LastUpdated: string;
  co2IsFallback: boolean;
  tempAnomaly: number | null;
  tempSource: string;
  tempIsFallback: boolean;
  loading: boolean;
  error: string | null;
  fetchedAt: Date | null;
}

function useAnimatedCounter(target: number | null, suffix = "", decimals = 0) {
  const [display, setDisplay] = useState("—");
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  const prevTarget = useRef<number | null>(null);

  useEffect(() => {
    if (target === null) return;

    if (prevTarget.current === target && started.current) return;
    prevTarget.current = target;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const val = { v: 0 };
          const controls = animate(val.v, target, {
            duration: 2.5,
            ease: "easeOut",
            onUpdate: (v) => setDisplay(v.toFixed(decimals) + suffix),
          });
          return () => controls.stop();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, suffix, decimals]);

  return { display, ref };
}

const CO2Molecule = ({
  position,
  scale = 1,
  speed = 1,
  color = "#00ff94",
}: {
  position: [number, number, number];
  scale?: number;
  speed?: number;
  color?: string;
}) => {
  const group = useRef<THREE.Group>(null);
  const t = useRef(Math.random() * 100);

  useFrame((_, delta) => {
    t.current += delta * speed;
    if (group.current) {
      group.current.position.y = position[1] + Math.sin(t.current * 0.8) * 0.3;
      group.current.rotation.y += delta * 0.6;
      group.current.rotation.x = Math.sin(t.current * 0.4) * 0.2;
    }
  });

  const c = new THREE.Color(color);
  const o = new THREE.Color("#ccf5e7");

  return (
    <group ref={group} position={position} scale={scale}>
      <mesh>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial
          color={c}
          emissive={c}
          emissiveIntensity={0.6}
          roughness={0.2}
          metalness={0.4}
        />
      </mesh>
      <mesh position={[-0.2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.025, 0.025, 0.2, 8]} />
        <meshStandardMaterial color={c} emissive={c} emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[-0.35, 0, 0]}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshStandardMaterial
          color={o}
          emissive={o}
          emissiveIntensity={0.15}
          roughness={0.5}
        />
      </mesh>
      <mesh position={[0.2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.025, 0.025, 0.2, 8]} />
        <meshStandardMaterial color={c} emissive={c} emissiveIntensity={0.3} />
      </mesh>
      <mesh position={[0.35, 0, 0]}>
        <sphereGeometry args={[0.09, 16, 16]} />
        <meshStandardMaterial
          color={o}
          emissive={o}
          emissiveIntensity={0.15}
          roughness={0.5}
        />
      </mesh>
      <mesh>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshBasicMaterial
          color={c}
          transparent
          opacity={0.04}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  );
};

const EmissionParticles = ({
  count = 400,
  isDark,
}: {
  count?: number;
  isDark: boolean;
}) => {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const data = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        theta: Math.random() * Math.PI * 2,
        phi: Math.acos(2 * Math.random() - 1),
        radius: 2.5 + Math.random() * 1.8,
        speed: 0.1 + Math.random() * 0.4,
        offset: Math.random() * 100,
        size: 0.5 + Math.random() * 1.5,
      })),
    [count]
  );

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    data.forEach((p, i) => {
      const r = p.radius + Math.sin(t * p.speed + p.offset) * 0.4;
      const x = r * Math.sin(p.phi) * Math.cos(p.theta + t * 0.05);
      const y = r * Math.cos(p.phi);
      const z = r * Math.sin(p.phi) * Math.sin(p.theta + t * 0.05);
      dummy.position.set(x, y, z);
      const s = p.size * (0.7 + Math.sin(t * 2 + p.offset) * 0.3);
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      mesh.current?.setMatrixAt(i, dummy.matrix);
    });
    if (mesh.current) mesh.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
      <sphereGeometry args={[0.018, 6, 6]} />
      <meshBasicMaterial
        color={isDark ? "#00ff94" : "#059669"}
        transparent
        opacity={isDark ? 0.65 : 0.45}
        blending={THREE.AdditiveBlending}
      />
    </instancedMesh>
  );
};

const MoleculeScene = ({ isDark }: { isDark: boolean }) => {
  const molecules = useMemo(
    () => [
      {
        position: [-1.8, 0.4, 0.2] as [number, number, number],
        scale: 1.2,
        speed: 0.8,
        color: isDark ? "#00ff94" : "#059669",
      },
      {
        position: [1.9, -0.6, -0.3] as [number, number, number],
        scale: 0.9,
        speed: 1.2,
        color: isDark ? "#34d399" : "#10b981",
      },
      {
        position: [0, 1.5, 0.1] as [number, number, number],
        scale: 1.0,
        speed: 0.6,
        color: isDark ? "#6ee7b7" : "#047857",
      },
      {
        position: [-0.8, -1.2, 0.4] as [number, number, number],
        scale: 0.7,
        speed: 1.5,
        color: isDark ? "#a7f3d0" : "#065f46",
      },
      {
        position: [1.2, 0.9, -0.5] as [number, number, number],
        scale: 0.85,
        speed: 1.0,
        color: isDark ? "#00ff94" : "#059669",
      },
    ],
    [isDark]
  );

  return (
    <>
      <ambientLight intensity={isDark ? 0.2 : 0.5} />
      <pointLight
        position={[3, 3, 3]}
        intensity={isDark ? 1.5 : 2}
        color={isDark ? "#00ff94" : "#059669"}
      />
      <pointLight
        position={[-3, -2, 2]}
        intensity={isDark ? 0.8 : 1}
        color={isDark ? "#34d399" : "#10b981"}
      />
      <EmissionParticles isDark={isDark} />
      {molecules.map((m, i) => (
        <CO2Molecule key={i} {...m} />
      ))}
    </>
  );
};

const DataBadge = ({
  isLive,
  isFallback,
  label,
}: {
  isLive: boolean;
  isFallback: boolean;
  label: string;
}) => {
  if (!isLive) {
    return (
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
        <CheckCircle className="w-3 h-3" />
        2024 VERIFIED
      </div>
    );
  }

  if (isFallback) {
    return (
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-amber-500">
        <AlertCircle className="w-3 h-3" />
        CACHED
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-emerald-500">
      <span className="w-1.5 h-1.5 rounded-full animate-pulse bg-emerald-500" />
      {label}
    </div>
  );
};

const StatCard = ({
  value,
  suffix,
  label,
  sublabel,
  icon: Icon,
  color,
  delay,
  decimals = 0,
  isLive = false,
  isFallback = false,
  liveBadge = "WEEKLY",
  sourceNote,
}: {
  value: number | null;
  suffix: string;
  label: string;
  sublabel: string;
  icon: React.ElementType;
  color: string;
  delay: number;
  decimals?: number;
  isLive?: boolean;
  isFallback?: boolean;
  liveBadge?: string;
  sourceNote?: string;
}) => {
  const { display, ref } = useAnimatedCounter(value, suffix, decimals);

  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay }}
      whileHover={{ scale: 1.02, y: -4 }}
      className="relative group flex flex-col justify-between p-6 rounded-2xl border bg-background/80 backdrop-blur-xl overflow-hidden cursor-default"
      style={{ borderColor: `${color}20` }}
    >
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 0%, ${color}12 0%, transparent 70%)`,
        }}
      />
      <div
        className="absolute top-0 left-0 right-0 h-[1px]"
        style={{
          background: `linear-gradient(90deg, transparent, ${color}60, transparent)`,
        }}
      />

      <div className="flex justify-between items-start mb-6">
        <div
          className="p-2.5 rounded-xl"
          style={{
            backgroundColor: `${color}15`,
            border: `1px solid ${color}25`,
          }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <DataBadge isLive={isLive} isFallback={isFallback} label={liveBadge} />
      </div>

      <div>
        <div className="font-mono font-black text-4xl text-foreground dark:text-white mb-1 tracking-tighter">
          {value === null ? (
            <span className="text-muted-foreground text-2xl animate-pulse">
              Loading…
            </span>
          ) : (
            <span ref={ref}>{display}</span>
          )}
        </div>
        <div className="text-sm font-semibold text-foreground/80 dark:text-white/80 mb-1">
          {label}
        </div>
        <div className="text-xs text-muted-foreground leading-relaxed">
          {sublabel}
        </div>
        {sourceNote && (
          <div className="text-[10px] text-muted-foreground/60 mt-2 font-mono">
            {sourceNote}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default function CarbonDataShowcase({ isDark }: { isDark: boolean }) {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const canvasY = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);
  const canvasScale = useTransform(scrollYProgress, [0, 0.4, 1], [0.8, 1, 0.9]);
  const canvasOpacity = useTransform(
    scrollYProgress,
    [0, 0.15, 0.8, 1],
    [0, 1, 1, 0]
  );

  const [liveData, setLiveData] = useState<LiveData>({
    co2Ppm: null,
    co2Increase: null,
    co2Source: "",
    co2LastUpdated: "",
    co2IsFallback: false,
    tempAnomaly: null,
    tempSource: "",
    tempIsFallback: false,
    loading: true,
    error: null,
    fetchedAt: null,
  });

  const fetchRealData = useCallback(async () => {
    setLiveData((prev) => ({ ...prev, loading: true, error: null }));

    try {
      const [co2Res, climateRes] = await Promise.allSettled([
        fetch("/api/environmental/co2").then(
          (r) => r.json() as Promise<Co2ApiResponse>
        ),
        fetch("/api/environmental/climate").then(
          (r) => r.json() as Promise<ClimateApiResponse>
        ),
      ]);

      const co2 = co2Res.status === "fulfilled" ? co2Res.value : null;
      const climate =
        climateRes.status === "fulfilled" ? climateRes.value : null;

      setLiveData({
        co2Ppm: co2?.data.ppm ?? null,
        co2Increase: co2?.data.increaseFromLastYear ?? null,
        co2Source: co2?.data.source ?? "NOAA GML",
        co2LastUpdated: co2?.data.lastUpdated ?? "",
        co2IsFallback: co2?.fallback ?? false,
        tempAnomaly: climate?.data.annualMeanAnomaly ?? null,
        tempSource: climate?.data.source ?? "NASA GISS",
        tempIsFallback: climate?.fallback ?? false,
        loading: false,
        error: null,
        fetchedAt: new Date(),
      });
    } catch (err) {
      setLiveData((prev) => ({
        ...prev,
        loading: false,
        error: "Could not reach data sources. Showing verified 2024 values.",
      }));
    }
  }, []);

  useEffect(() => {
    fetchRealData();
  }, [fetchRealData]);

  const stats = [
    {
      value: liveData.co2Ppm,
      suffix: " ppm",
      label: "Atmospheric CO₂",
      sublabel: `Mauna Loa Observatory${liveData.co2LastUpdated ? ` · ${liveData.co2LastUpdated}` : ""}`,
      icon: Wind,
      color: "#3b82f6",
      delay: 0,
      decimals: 1,
      isLive: true,
      isFallback: liveData.co2IsFallback,
      liveBadge: "WEEKLY NOAA",
      sourceNote: liveData.co2IsFallback
        ? "Fallback — NOAA temporarily unreachable"
        : liveData.co2Source,
    },
    {
      value: liveData.tempAnomaly,
      suffix: "°C",
      label: "Temperature anomaly",
      sublabel: `vs 1951-1980 baseline — NASA GISS ${liveData.tempIsFallback ? "" : "2024"}`,
      icon: Flame,
      color: "#ef4444",
      delay: 0.1,
      decimals: 2,
      isLive: true,
      isFallback: liveData.tempIsFallback,
      liveBadge: "NASA ANNUAL",
      sourceNote: liveData.tempIsFallback
        ? "Fallback — NASA temporarily unreachable"
        : "NASA GISS Surface Temperature Analysis v4",
    },
    {
      value: 4.1,
      suffix: "T",
      label: "Global per capita CO₂",
      sublabel: "Tonnes per person per year — IEA 2024",
      icon: Globe2,
      color: "#10b981",
      delay: 0.2,
      decimals: 1,
      isLive: false,
      isFallback: false,
      liveBadge: "2024 VERIFIED",
      sourceNote: "IEA World Energy Outlook 2024",
    },
    {
      value: 37.4,
      suffix: " Gt",
      label: "Annual CO₂ emissions",
      sublabel: "Billion tonnes emitted globally — Global Carbon Project 2023",
      icon: Flame,
      color: "#f97316",
      delay: 0.3,
      decimals: 1,
      isLive: false,
      isFallback: false,
      liveBadge: "2023 VERIFIED",
      sourceNote: "Global Carbon Project 2023 report",
    },
    {
      value: 82,
      suffix: "%",
      label: "Emissions we can reduce",
      sublabel: "Through smarter individual & team choices tracked by Aura",
      icon: Zap,
      color: "#a855f7",
      delay: 0.4,
      isLive: false,
      isFallback: false,
      liveBadge: "IPCC AR6",
      sourceNote: "IPCC Sixth Assessment Report (2022)",
    },
    {
      value: 128,
      suffix: " kg",
      label: "Avg monthly footprint",
      sublabel: "Typical individual's carbon tracked through Aura",
      icon: Leaf,
      color: "#22c55e",
      delay: 0.5,
      isLive: false,
      isFallback: false,
      liveBadge: "AURA DATA",
      sourceNote: "Based on platform usage aggregates",
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="relative py-40 bg-background overflow-hidden border-t border-border/50"
    >
      {}
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full bg-emerald-500/5 dark:bg-emerald-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-blue-500/5 dark:bg-blue-500/8 blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        {}
        <div className="text-center mb-24 max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary mb-6 bg-primary/10 px-4 py-2 rounded-full border border-primary/20"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            Live & Verified Environmental Data
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-6xl font-black tracking-tighter mb-6 text-foreground dark:text-white"
          >
            The carbon crisis, <span className="text-primary">in numbers.</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-muted-foreground mb-6"
          >
            These aren&apos;t just statistics. They&apos;re the reason Aura
            exists.
          </motion.p>

          {}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="inline-flex items-center gap-3 text-xs text-muted-foreground/70 bg-muted/50 px-4 py-2 rounded-full"
          >
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
              <span>NOAA GML (weekly)</span>
            </div>
            <span className="text-border">·</span>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
              <span>NASA GISS (annual)</span>
            </div>
            <span className="text-border">·</span>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-3 h-3 text-emerald-500" />
              <span>IEA / IPCC verified</span>
            </div>
            {liveData.fetchedAt && (
              <>
                <span className="text-border">·</span>
                <button
                  onClick={fetchRealData}
                  className="flex items-center gap-1 hover:text-foreground transition-colors group cursor-pointer"
                  title="Refresh data"
                >
                  <RefreshCw
                    className={`w-3 h-3 ${liveData.loading ? "animate-spin" : "group-hover:animate-spin"}`}
                  />
                  <span>Refresh</span>
                </button>
              </>
            )}
          </motion.div>

          {liveData.error && (
            <p className="text-xs text-amber-500 mt-3 flex items-center justify-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" />
              {liveData.error}
            </p>
          )}
        </div>

        {}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {}
          <motion.div
            style={{ y: canvasY, scale: canvasScale, opacity: canvasOpacity }}
            className="relative h-[420px] lg:h-[560px] rounded-3xl overflow-hidden border border-border/30 dark:border-white/5"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-background/20 to-blue-500/5 dark:from-emerald-500/10 dark:via-black/30 dark:to-blue-500/8" />
            <Canvas camera={{ position: [0, 0, 6], fov: 50 }} dpr={[1, 2]}>
              <MoleculeScene isDark={isDark} />
            </Canvas>

            {}
            <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
              <div className="flex items-center gap-2 bg-background/70 dark:bg-black/50 backdrop-blur-xl px-4 py-2 rounded-full border border-border/50 dark:border-white/10">
                <span className="w-2 h-2 rounded-full bg-primary animate-ping" />
                <span className="text-xs font-bold text-foreground/80 dark:text-white/80 uppercase tracking-widest">
                  CO₂ Molecular Simulation
                </span>
              </div>
              <div
                className="bg-background/70 dark:bg-black/50 backdrop-blur-xl px-3 py-2 rounded-full border border-border/50 dark:border-white/10 text-xs font-mono font-bold"
                style={{
                  color: liveData.co2IsFallback
                    ? "#f59e0b"
                    : "hsl(var(--primary))",
                }}
              >
                {liveData.co2Ppm !== null
                  ? `${liveData.co2Ppm} ppm`
                  : "Loading…"}
              </div>
            </div>
            <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-b from-background/60 to-transparent pointer-events-none" />
          </motion.div>

          {}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {stats.map((stat, i) => (
              <StatCard key={i} {...stat} />
            ))}
          </div>
        </div>

        {}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
          className="mt-24 relative rounded-3xl overflow-hidden border border-primary/20 dark:border-primary/30 p-10 md:p-16 flex flex-col md:flex-row items-center justify-between gap-8"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-background to-teal-500/5 dark:from-primary/12 dark:via-black/80 dark:to-teal-500/8" />
          <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
          <div className="absolute bottom-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

          <div className="relative z-10 max-w-xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-xl bg-primary/15 border border-primary/25">
                <Leaf className="w-5 h-5 text-primary" />
              </div>
              <span className="text-sm font-bold text-primary uppercase tracking-widest">
                Aura&apos;s Mission
              </span>
            </div>
            <h3 className="text-3xl md:text-4xl font-black tracking-tighter text-foreground dark:text-white mb-4">
              Track it. Understand it.{" "}
              <span className="text-primary">Reduce it.</span>
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Aura transforms these real global numbers — sourced from NOAA and
              NASA — into personal, actionable clarity. Know exactly where you
              stand and what to do next.
            </p>
          </div>

          {}
          <div className="relative z-10 flex flex-col items-center gap-3 flex-shrink-0">
            <div className="relative w-40 h-40">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="currentColor"
                  className="text-border/50"
                  strokeWidth="6"
                />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="hsl(var(--primary))"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  initial={{ strokeDashoffset: `${2 * Math.PI * 42}` }}
                  whileInView={{
                    strokeDashoffset: `${2 * Math.PI * 42 * (1 - 0.82)}`,
                  }}
                  viewport={{ once: true }}
                  transition={{ duration: 2.5, ease: "easeOut", delay: 0.5 }}
                  style={{ filter: "drop-shadow(0 0 8px hsl(var(--primary)))" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-black text-primary font-mono">
                  82%
                </span>
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest text-center leading-tight">
                  reducible
                  <br />
                  emissions
                </span>
              </div>
            </div>
            <span className="text-xs text-muted-foreground text-center max-w-[140px] leading-relaxed">
              of personal carbon can be reduced with the right data — IPCC AR6
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
