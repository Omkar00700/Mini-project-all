"use client";

import { useMemo, useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere } from "@react-three/drei";
import { useTheme } from "next-themes";

const GlobeMesh = ({ isDark }: { isDark: boolean }) => {
  const count = 4000;
  const starCount = 1500;

  const mesh = useRef<THREE.InstancedMesh>(null);
  const starMesh = useRef<THREE.InstancedMesh>(null);
  const coreRef = useRef<THREE.Mesh>(null);
  const wireframeRef = useRef<THREE.Mesh>(null);

  const dummy = useMemo(() => new THREE.Object3D(), []);
  const starDummy = useMemo(() => new THREE.Object3D(), []);

  const baseColor = new THREE.Color(isDark ? "#00ff94" : "#10b981");
  const highlightColor = new THREE.Color(isDark ? "#ffffff" : "#059669");

  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count);
      const theta = Math.sqrt(count * Math.PI) * phi;
      const x = Math.cos(theta) * Math.sin(phi);
      const y = Math.sin(theta) * Math.sin(phi);
      const z = Math.cos(phi);
      temp.push({
        x,
        y,
        z,
        baseRadius: 2.45,
        offset: Math.random() * 100,
        speed: 0.5 + Math.random() * 1.5,
        colorVector: new THREE.Color().lerpColors(
          baseColor,
          highlightColor,
          Math.random()
        ),
      });
    }
    return temp;
  }, [count, baseColor, highlightColor]);

  const stars = useMemo(() => {
    const temp = [];
    for (let i = 0; i < starCount; i++) {
      const radius = 3.0 + Math.random() * 2.5;
      const theta = 2 * Math.PI * Math.random();
      const phi = Math.acos(2 * Math.random() - 1);
      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      temp.push({
        x,
        y,
        z,
        offset: Math.random() * 100,
        speed: 0.1 + Math.random() * 0.3,
      });
    }
    return temp;
  }, [starCount]);

  const colorArray = useMemo(() => {
    const colors = new Float32Array(count * 3);
    particles.forEach((p, i) => {
      colors[i * 3] = p.colorVector.r;
      colors[i * 3 + 1] = p.colorVector.g;
      colors[i * 3 + 2] = p.colorVector.b;
    });
    return colors;
  }, [particles]);

  const pointerVelocity = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const lastPointer = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useFrame((state) => {
    const time = state.clock.getElapsedTime();

    const vX = state.pointer.x - lastPointer.current.x;
    const vY = state.pointer.y - lastPointer.current.y;
    pointerVelocity.current.x += (vX - pointerVelocity.current.x) * 0.1;
    pointerVelocity.current.y += (vY - pointerVelocity.current.y) * 0.1;
    lastPointer.current = { x: state.pointer.x, y: state.pointer.y };

    const velocityMagnitude = Math.sqrt(
      pointerVelocity.current.x ** 2 + pointerVelocity.current.y ** 2
    );
    const dynamicWaveAmp = 0.05 + Math.min(velocityMagnitude * 5, 0.4);

    if (mesh.current) {
      particles.forEach((particle, i) => {
        const { x, y, z, baseRadius, offset, speed } = particle;

        const wave1 = Math.sin(time * speed + offset + y * 3) * dynamicWaveAmp;
        const wave2 = Math.cos(time * speed * 0.5 + x * 2) * 0.02;
        const finalRadius = baseRadius + wave1 + wave2;

        dummy.position.set(x * finalRadius, y * finalRadius, z * finalRadius);

        const isHub = i % 80 === 0;
        const scale = isHub ? 1.5 + Math.sin(time * 3 + offset) * 1.5 : 0.6;
        dummy.scale.set(scale, scale, scale);

        dummy.updateMatrix();
        mesh.current?.setMatrixAt(i, dummy.matrix);
      });
      if (mesh.current) mesh.current.instanceMatrix.needsUpdate = true;
    }

    if (starMesh.current) {
      stars.forEach((star, i) => {
        const { x, y, z, offset, speed } = star;

        const newX = x + Math.sin(time * speed + offset) * 0.2;
        const newY = y + Math.cos(time * speed * 1.2 + offset) * 0.2;
        const newZ = z + Math.sin(time * speed * 0.8 + offset) * 0.2;

        starDummy.position.set(newX, newY, newZ);

        const scale = 0.3 + Math.sin(time * 2 + offset) * 0.2;
        starDummy.scale.set(scale, scale, scale);

        starDummy.updateMatrix();
        starMesh.current?.setMatrixAt(i, starDummy.matrix);
      });
      if (starMesh.current) starMesh.current.instanceMatrix.needsUpdate = true;
    }

    const targetRotY = state.pointer.x * 1.2;
    const targetRotX = state.pointer.y * 1.2;

    const baseSpinSpeed = time * 0.08;

    if (mesh.current) {
      const finalY = baseSpinSpeed + targetRotY;
      const finalX = targetRotX;

      mesh.current.rotation.y = THREE.MathUtils.lerp(
        mesh.current.rotation.y,
        finalY,
        0.06
      );
      mesh.current.rotation.x = THREE.MathUtils.lerp(
        mesh.current.rotation.x,
        finalX,
        0.06
      );
      mesh.current.rotation.z = Math.sin(time * 0.2) * 0.05;
    }

    if (coreRef.current && wireframeRef.current && mesh.current) {
      coreRef.current.rotation.y = mesh.current.rotation.y;
      coreRef.current.rotation.x = mesh.current.rotation.x;
      wireframeRef.current.rotation.y = mesh.current.rotation.y + time * 0.05;
      wireframeRef.current.rotation.x = mesh.current.rotation.x;
    }

    if (starMesh.current && mesh.current) {
      starMesh.current.rotation.y = mesh.current.rotation.y * -0.4;
      starMesh.current.rotation.x = mesh.current.rotation.x * 0.6;
    }

    if (groupRef.current) {
      const targetPosX = state.pointer.x * 0.6;
      const targetPosY = state.pointer.y * 0.6;
      groupRef.current.position.x = THREE.MathUtils.lerp(
        groupRef.current.position.x,
        targetPosX,
        0.04
      );
      groupRef.current.position.y = THREE.MathUtils.lerp(
        groupRef.current.position.y,
        targetPosY,
        0.04
      );
    }
  });

  const groupRef = useRef<THREE.Group>(null);

  return (
    <group ref={groupRef} rotation={[0.1, 0, 0]}>
      {}
      <instancedMesh ref={mesh} args={[null as any, null as any, count]}>
        <sphereGeometry args={[isDark ? 0.015 : 0.02, 8, 8]}>
          <instancedBufferAttribute
            attach="attributes-color"
            args={[colorArray, 3]}
          />
        </sphereGeometry>
        <meshBasicMaterial
          vertexColors
          transparent
          opacity={isDark ? 0.9 : 0.8}
          blending={THREE.AdditiveBlending}
        />
      </instancedMesh>

      {}
      <instancedMesh
        ref={starMesh}
        args={[null as any, null as any, starCount]}
      >
        <sphereGeometry args={[0.012, 4, 4]} />
        <meshBasicMaterial
          color={isDark ? "#a7f3d0" : "#34d399"}
          transparent
          opacity={isDark ? 0.4 : 0.6}
          blending={THREE.AdditiveBlending}
        />
      </instancedMesh>

      {}
      <Sphere ref={coreRef} args={[2.35, 64, 64]}>
        <meshBasicMaterial
          color={isDark ? "#010804" : "#ffffff"}
          transparent
          opacity={1}
        />
      </Sphere>

      {}
      <Sphere ref={wireframeRef} args={[2.42, 32, 32]}>
        <meshBasicMaterial
          color={isDark ? "#00ff94" : "#10b981"}
          wireframe
          transparent
          opacity={isDark ? 0.08 : 0.15}
          blending={THREE.AdditiveBlending}
        />
      </Sphere>

      {}
      <Sphere args={[2.9, 32, 32]}>
        <meshBasicMaterial
          color={isDark ? "#00ff94" : "#10b981"}
          transparent
          opacity={isDark ? 0.06 : 0.1}
          side={THREE.BackSide}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </Sphere>
    </group>
  );
};

export default function InteractiveGlobe() {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [fov, setFov] = useState(45);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setFov(window.innerWidth < 768 ? 60 : 45);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  if (!mounted) return null;

  const isDark = resolvedTheme !== "light";

  return (
    <div
      className="w-full h-[120vh] absolute top-[-10vh] inset-x-0 z-0"
      style={{ touchAction: "pan-y" }}
    >
      <div className="absolute inset-0 z-0 opacity-100">
        <Canvas camera={{ position: [0, 0, 8.5], fov }} dpr={[1, 2]}>
          <GlobeMesh isDark={isDark} />
        </Canvas>
      </div>

      {}
      <div className="absolute inset-x-0 bottom-0 h-80 bg-gradient-to-t from-background via-background/90 to-transparent z-10 pointer-events-none" />
      <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-background via-background/80 to-transparent z-10 pointer-events-none" />

      {}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_30%,var(--background)_100%)] z-10 pointer-events-none opacity-80" />
    </div>
  );
}
