"use client";

import { useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  Environment,
  MeshDistortMaterial,
  Float,
  ContactShadows,
  Points,
  PointMaterial,
} from "@react-three/drei";
import * as THREE from "three";
import { useTheme } from "next-themes";

const AuraSphere = ({ isDark }: { isDark: boolean }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const color = isDark ? "#10b981" : "#059669";
  const emissiveColor = isDark ? "#047857" : "#34d399";

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.getElapsedTime() * 0.1;
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.15;
    }
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={1.5}>
      <mesh ref={meshRef} scale={1.8}>
        <icosahedronGeometry args={[1, 64]} />
        <MeshDistortMaterial
          color={color}
          emissive={emissiveColor}
          emissiveIntensity={isDark ? 0.3 : 0.1}
          envMapIntensity={isDark ? 0.8 : 1.2}
          clearcoat={1}
          clearcoatRoughness={0.1}
          metalness={0.1}
          roughness={0.3}
          distort={0.4}
          speed={2.5}
          transparent
          opacity={isDark ? 0.8 : 0.6}
        />
      </mesh>
      {}
      <mesh scale={1.1}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial
          color={isDark ? "#ffffff" : "#f0fdf4"}
          transparent
          opacity={isDark ? 0.3 : 0.5}
        />
      </mesh>
    </Float>
  );
};

const ParticleVortex = ({ isDark }: { isDark: boolean }) => {
  const [positions] = useState(() => {
    const pos = new Float32Array(500 * 3);
    for (let i = 0; i < 500; i++) {
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = 2.5 + Math.random() * 1.5;
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);
    }
    return pos;
  });

  const ref = useRef<THREE.Points>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.getElapsedTime() * 0.08;
      ref.current.rotation.z = state.clock.getElapsedTime() * 0.03;
    }
  });

  return (
    <Points ref={ref} positions={positions} stride={3}>
      <PointMaterial
        transparent
        color={isDark ? "#34d399" : "#059669"}
        size={0.06}
        sizeAttenuation={true}
        depthWrite={false}
        opacity={isDark ? 0.6 : 0.4}
      />
    </Points>
  );
};

export default function InteractiveAura() {
  const { resolvedTheme } = useTheme();

  const isDark = resolvedTheme !== "light";

  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 0, 8], fov: 45 }} dpr={[1, 2]}>
        <ambientLight intensity={isDark ? 0.2 : 0.8} />
        <directionalLight position={[10, 10, 5]} intensity={isDark ? 0.5 : 1} />
        <directionalLight
          position={[-10, -10, -5]}
          intensity={isDark ? 0.2 : 0.5}
          color="#10b981"
        />
        <AuraSphere isDark={isDark} />
        <ParticleVortex isDark={isDark} />
        <Environment preset={isDark ? "night" : "dawn"} />
        <ContactShadows
          position={[0, -3.5, 0]}
          opacity={isDark ? 0.5 : 0.2}
          scale={15}
          blur={3}
          far={5}
        />
      </Canvas>
    </div>
  );
}
