export { useUserStore } from "./user-store";
export { useUIStore } from "./ui-store";
export { useCarbonStore } from "./carbon-store";

export type { UserProfile, Organization } from "./user-store";
export type { Toast, Modal, DashboardWidget } from "./ui-store";
export type {
  CarbonCalculation,
  ActivityData,
  Prediction,
  Recommendation,
  EmissionBreakdown,
} from "./carbon-store";

export const userSelectors = {
  isAuthenticated: (state: any) => state.isAuthenticated(),
  isPremium: (state: any) => state.isPremium(),
  hasFeature: (feature: string) => (state: any) => state.hasFeature(feature),
};

export const carbonSelectors = {
  getActiveRecommendations: (state: any) => state.getActiveRecommendations(),
  getImplementedRecommendations: (state: any) =>
    state.getImplementedRecommendations(),
  getTotalEmissions: (startDate: string, endDate: string) => (state: any) =>
    state.getTotalEmissionsForPeriod(startDate, endDate),
  getEmissionsByCategory: (category: string) => (state: any) =>
    state.getEmissionsByCategory(category),
};
