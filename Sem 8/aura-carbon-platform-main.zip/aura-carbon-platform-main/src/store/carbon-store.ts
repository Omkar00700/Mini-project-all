import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";

export interface EmissionBreakdown {
  transportation: number;
  energy: number;
  food: number;
  consumption: number;
  waste: number;
  [key: string]: number;
}

export interface CarbonCalculation {
  id: string;
  user_id: string;
  period_start: string;
  period_end: string;
  total_emissions: number;
  breakdown: EmissionBreakdown;
  confidence_score: number;
  created_at: string;
  updated_at: string;
}

export interface ActivityData {
  id: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  date: string;
  source: string;
  metadata?: Record<string, any>;
}

export interface Prediction {
  id: string;
  user_id: string;
  prediction_type: string;
  forecast_period: string;
  predicted_emissions: number;
  confidence_score: number;
  scenario_data?: Record<string, any>;
  created_at: string;
}

export interface Recommendation {
  id: string;
  user_id: string;
  title: string;
  description: string;
  category: string;
  impact_estimate: number;
  cost_estimate?: number;
  difficulty_score: number;
  confidence_score: number;
  status: "active" | "implemented" | "dismissed";
  user_feedback?: Record<string, any>;
  created_at: string;
}

interface CarbonState {
  currentCalculation: CarbonCalculation | null;
  calculationHistory: CarbonCalculation[];

  activityData: ActivityData[];
  pendingActivities: ActivityData[];

  predictions: Prediction[];

  recommendations: Recommendation[];

  isCalculating: boolean;
  isLoadingHistory: boolean;
  isLoadingPredictions: boolean;
  isLoadingRecommendations: boolean;

  calculationError: string | null;

  setCurrentCalculation: (calculation: CarbonCalculation | null) => void;
  addCalculationToHistory: (calculation: CarbonCalculation) => void;
  setCalculationHistory: (history: CarbonCalculation[]) => void;

  addActivityData: (activity: ActivityData) => void;
  updateActivityData: (id: string, updates: Partial<ActivityData>) => void;
  removeActivityData: (id: string) => void;
  setActivityData: (activities: ActivityData[]) => void;

  addPendingActivity: (activity: ActivityData) => void;
  removePendingActivity: (id: string) => void;
  clearPendingActivities: () => void;

  setPredictions: (predictions: Prediction[]) => void;
  addPrediction: (prediction: Prediction) => void;

  setRecommendations: (recommendations: Recommendation[]) => void;
  updateRecommendation: (id: string, updates: Partial<Recommendation>) => void;

  setCalculating: (calculating: boolean) => void;
  setLoadingHistory: (loading: boolean) => void;
  setLoadingPredictions: (loading: boolean) => void;
  setLoadingRecommendations: (loading: boolean) => void;

  setCalculationError: (error: string | null) => void;

  getTotalEmissionsForPeriod: (startDate: string, endDate: string) => number;
  getEmissionsByCategory: (category: string) => number;
  getActiveRecommendations: () => Recommendation[];
  getImplementedRecommendations: () => Recommendation[];
}

export const useCarbonStore = create<CarbonState>()(
  devtools(
    persist(
      immer((set, get) => ({
        currentCalculation: null,
        calculationHistory: [],
        activityData: [],
        pendingActivities: [],
        predictions: [],
        recommendations: [],
        isCalculating: false,
        isLoadingHistory: false,
        isLoadingPredictions: false,
        isLoadingRecommendations: false,
        calculationError: null,

        setCurrentCalculation: (calculation) =>
          set((state) => {
            state.currentCalculation = calculation;
            state.calculationError = null;
          }),

        addCalculationToHistory: (calculation) =>
          set((state) => {
            const exists = state.calculationHistory.some(
              (c) => c.id === calculation.id
            );
            if (!exists) {
              state.calculationHistory.unshift(calculation);

              if (state.calculationHistory.length > 50) {
                state.calculationHistory = state.calculationHistory.slice(
                  0,
                  50
                );
              }
            }
          }),

        setCalculationHistory: (history) =>
          set((state) => {
            state.calculationHistory = history;
          }),

        addActivityData: (activity) =>
          set((state) => {
            state.activityData.push(activity);
          }),

        updateActivityData: (id, updates) =>
          set((state) => {
            const activity = state.activityData.find((a) => a.id === id);
            if (activity) {
              Object.assign(activity, updates);
            }
          }),

        removeActivityData: (id) =>
          set((state) => {
            state.activityData = state.activityData.filter((a) => a.id !== id);
          }),

        setActivityData: (activities) =>
          set((state) => {
            state.activityData = activities;
          }),

        addPendingActivity: (activity) =>
          set((state) => {
            state.pendingActivities.push(activity);
          }),

        removePendingActivity: (id) =>
          set((state) => {
            state.pendingActivities = state.pendingActivities.filter(
              (a) => a.id !== id
            );
          }),

        clearPendingActivities: () =>
          set((state) => {
            state.pendingActivities = [];
          }),

        setPredictions: (predictions) =>
          set((state) => {
            state.predictions = predictions;
          }),

        addPrediction: (prediction) =>
          set((state) => {
            state.predictions.push(prediction);
          }),

        setRecommendations: (recommendations) =>
          set((state) => {
            state.recommendations = recommendations;
          }),

        updateRecommendation: (id, updates) =>
          set((state) => {
            const recommendation = state.recommendations.find(
              (r) => r.id === id
            );
            if (recommendation) {
              Object.assign(recommendation, updates);
            }
          }),

        setCalculating: (calculating) =>
          set((state) => {
            state.isCalculating = calculating;
          }),

        setLoadingHistory: (loading) =>
          set((state) => {
            state.isLoadingHistory = loading;
          }),

        setLoadingPredictions: (loading) =>
          set((state) => {
            state.isLoadingPredictions = loading;
          }),

        setLoadingRecommendations: (loading) =>
          set((state) => {
            state.isLoadingRecommendations = loading;
          }),

        setCalculationError: (error) =>
          set((state) => {
            state.calculationError = error;
            state.isCalculating = false;
          }),

        getTotalEmissionsForPeriod: (startDate: string, endDate: string) => {
          const { calculationHistory } = get();
          return calculationHistory
            .filter(
              (calc) =>
                calc.period_start >= startDate && calc.period_end <= endDate
            )
            .reduce((total, calc) => total + calc.total_emissions, 0);
        },

        getEmissionsByCategory: (category: string) => {
          const { currentCalculation } = get();
          return currentCalculation?.breakdown[category] || 0;
        },

        getActiveRecommendations: () => {
          const { recommendations } = get();
          return recommendations.filter((r) => r.status === "active");
        },

        getImplementedRecommendations: () => {
          const { recommendations } = get();
          return recommendations.filter((r) => r.status === "implemented");
        },
      })),
      {
        name: "carbon-store",
        partialize: (state) => ({
          calculationHistory: state.calculationHistory,
          activityData: state.activityData,
          recommendations: state.recommendations,
        }),
      }
    ),
    {
      name: "carbon-store",
    }
  )
);
