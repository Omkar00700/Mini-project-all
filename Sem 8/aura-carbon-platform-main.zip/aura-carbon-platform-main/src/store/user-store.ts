import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  location: {
    country: string;
    region: string;
    city: string;
    coordinates?: [number, number];
  };
  household: {
    size: number;
    type: "individual" | "family" | "shared";
    income_bracket?: string;
  };
  preferences: {
    units: "metric" | "imperial";
    privacy_level: "public" | "friends" | "private";
    notifications: {
      email: boolean;
      push: boolean;
      weekly_reports: boolean;
      recommendations: boolean;
      achievements: boolean;
    };
  };
  subscription: {
    tier: "free" | "premium" | "enterprise";
    features: string[];
  };
  created_at: string;
  updated_at: string;
}

export interface Organization {
  id: string;
  name: string;
  industry: string;
  size: "startup" | "sme" | "enterprise";
  role: string;
  permissions: string[];
}

interface UserState {
  user: UserProfile | null;
  organizations: Organization[];
  isLoading: boolean;
  error: string | null;

  setUser: (user: UserProfile | null) => void;
  updateUser: (updates: Partial<UserProfile>) => void;
  setOrganizations: (organizations: Organization[]) => void;
  addOrganization: (organization: Organization) => void;
  removeOrganization: (organizationId: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearUser: () => void;

  isAuthenticated: () => boolean;
  isPremium: () => boolean;
  hasFeature: (feature: string) => boolean;
}

export const useUserStore = create<UserState>()(
  devtools(
    persist(
      immer((set, get) => ({
        user: null,
        organizations: [],
        isLoading: false,
        error: null,

        setUser: (user) =>
          set((state) => {
            state.user = user;
            state.error = null;
          }),

        updateUser: (updates) =>
          set((state) => {
            if (state.user) {
              Object.assign(state.user, updates);
              state.user.updated_at = new Date().toISOString();
            }
          }),

        setOrganizations: (organizations) =>
          set((state) => {
            state.organizations = organizations;
          }),

        addOrganization: (organization) =>
          set((state) => {
            state.organizations.push(organization);
          }),

        removeOrganization: (organizationId) =>
          set((state) => {
            state.organizations = state.organizations.filter(
              (org) => org.id !== organizationId
            );
          }),

        setLoading: (loading) =>
          set((state) => {
            state.isLoading = loading;
          }),

        setError: (error) =>
          set((state) => {
            state.error = error;
            state.isLoading = false;
          }),

        clearUser: () =>
          set((state) => {
            state.user = null;
            state.organizations = [];
            state.error = null;
            state.isLoading = false;
          }),

        isAuthenticated: () => {
          const { user } = get();
          return user !== null;
        },

        isPremium: () => {
          const { user } = get();
          return (
            user?.subscription.tier === "premium" ||
            user?.subscription.tier === "enterprise"
          );
        },

        hasFeature: (feature: string) => {
          const { user } = get();
          return user?.subscription.features.includes(feature) ?? false;
        },
      })),
      {
        name: "user-store",
        partialize: (state) => ({
          user: state.user,
          organizations: state.organizations,
        }),
      }
    ),
    {
      name: "user-store",
    }
  )
);
