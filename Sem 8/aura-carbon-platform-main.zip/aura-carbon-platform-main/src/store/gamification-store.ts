import { create } from "zustand";
import { persist } from "zustand/middleware";
import { LEVEL_CONFIG } from "@/config/gamification";

export interface Reward {
  id: string;
  type: "xp" | "achievement" | "level_up";
  value: number | string;
  title: string;
  description?: string;
  icon?: string;
  rarity?: "common" | "uncommon" | "rare" | "epic";
}

interface GamificationState {
  xp: number;
  level: number;
  streak: number;
  streakFreezes: number;
  pendingRewards: Reward[];

  setXp: (xp: number) => void;
  setLevel: (level: number) => void;
  setStreak: (streak: number) => void;
  setStreakFreezes: (freezes: number) => void;
  addReward: (reward: Reward) => void;
  processServerReward: (result: {
    xpEarned: number;
    totalXp: number;
    newLevel: number;
    leveledUp: boolean;
    levelTitle: string;
    newAchievements: any[];
  }) => void;
  clearRewards: () => void;
  syncWithServer: (data: {
    xp: number;
    level: number;
    streak?: number;
    streakFreezes?: number;
  }) => void;
}

export const useGamificationStore = create<GamificationState>()(
  persist(
    (set) => ({
      xp: 0,
      level: 1,
      streak: 0,
      streakFreezes: 0,
      pendingRewards: [],

      setXp: (xp) => set({ xp }),
      setLevel: (level) => set({ level }),
      setStreak: (streak) => set({ streak }),
      setStreakFreezes: (streakFreezes) => set({ streakFreezes }),

      processServerReward: (result) =>
        set((state) => {
          const rewards: Reward[] = [...state.pendingRewards];

          if (result.newAchievements && result.newAchievements.length > 0) {
            result.newAchievements.forEach((a) => {
              rewards.push({
                id: `achievement-${a.id}-${Date.now()}`,
                type: "achievement",
                title: a.name,
                description: a.description,
                icon: a.icon,
                value: a.points,
                rarity:
                  a.tier === "platinum"
                    ? "epic"
                    : a.tier === "gold"
                      ? "rare"
                      : "uncommon",
              });
            });
          }

          if (result.leveledUp) {
            const levelInfo = LEVEL_CONFIG.find(
              (c) => c.level === result.newLevel
            );
            rewards.push({
              id: `level-up-${result.newLevel}-${Date.now()}`,
              type: "level_up",
              title: `Level Up: ${result.levelTitle}!`,
              description: `You've reached level ${result.newLevel}. Your impact is growing!`,
              icon: levelInfo?.icon || "⭐",
              value: result.newLevel,
              rarity: "rare",
            });
          }

          return {
            xp: result.totalXp,
            level: result.newLevel,
            pendingRewards: rewards,
          };
        }),

      addReward: (reward) =>
        set((state) => ({
          pendingRewards: [...state.pendingRewards, reward],
        })),

      clearRewards: () => set({ pendingRewards: [] }),

      syncWithServer: (data) =>
        set({
          xp: data.xp,
          level: data.level,
          streak: data.streak ?? 0,
          streakFreezes: data.streakFreezes ?? 0,
        }),
    }),
    {
      name: "aura-gamification-storage",
    }
  )
);
