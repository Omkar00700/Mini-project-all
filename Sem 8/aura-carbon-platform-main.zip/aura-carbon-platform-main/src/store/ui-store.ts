import { create } from "zustand";
import { devtools } from "zustand/middleware";
import { immer } from "zustand/middleware/immer";

export interface Toast {
  id: string;
  title: string;
  description?: string;
  type: "success" | "error" | "warning" | "info";
  duration?: number;
}

export interface Modal {
  id: string;
  component: React.ComponentType<any>;
  props?: Record<string, any>;
  size?: "sm" | "md" | "lg" | "xl" | "full";
}

export interface DashboardWidget {
  id: string;
  type: string;
  title: string;
  position: { x: number; y: number };
  size: { width: number; height: number };
  config: Record<string, any>;
  isVisible: boolean;
}

interface UIState {
  sidebarOpen: boolean;
  sidebarCollapsed: boolean;

  globalLoading: boolean;
  loadingStates: Record<string, boolean>;

  toasts: Toast[];

  modals: Modal[];

  dashboardWidgets: DashboardWidget[];
  dashboardEditMode: boolean;

  formStates: Record<
    string,
    {
      isDirty: boolean;
      isSubmitting: boolean;
      errors: Record<string, string>;
    }
  >;

  theme: "light" | "dark" | "system";

  setSidebarOpen: (open: boolean) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;

  setGlobalLoading: (loading: boolean) => void;
  setLoadingState: (key: string, loading: boolean) => void;

  addToast: (toast: Omit<Toast, "id">) => void;
  removeToast: (id: string) => void;
  clearToasts: () => void;

  openModal: (modal: Omit<Modal, "id">) => void;
  closeModal: (id: string) => void;
  closeAllModals: () => void;

  updateDashboardWidget: (
    id: string,
    updates: Partial<DashboardWidget>
  ) => void;
  addDashboardWidget: (widget: Omit<DashboardWidget, "id">) => void;
  removeDashboardWidget: (id: string) => void;
  setDashboardEditMode: (editMode: boolean) => void;

  setFormState: (
    formId: string,
    state: Partial<UIState["formStates"][string]>
  ) => void;
  clearFormState: (formId: string) => void;

  setTheme: (theme: UIState["theme"]) => void;
}

export const useUIStore = create<UIState>()(
  devtools(
    immer((set, get) => ({
      sidebarOpen: true,
      sidebarCollapsed: false,
      globalLoading: false,
      loadingStates: {},
      toasts: [],
      modals: [],
      dashboardWidgets: [],
      dashboardEditMode: false,
      formStates: {},
      theme: "system",

      setSidebarOpen: (open) =>
        set((state) => {
          state.sidebarOpen = open;
        }),

      setSidebarCollapsed: (collapsed) =>
        set((state) => {
          state.sidebarCollapsed = collapsed;
        }),

      toggleSidebar: () =>
        set((state) => {
          state.sidebarOpen = !state.sidebarOpen;
        }),

      setGlobalLoading: (loading) =>
        set((state) => {
          state.globalLoading = loading;
        }),

      setLoadingState: (key, loading) =>
        set((state) => {
          if (loading) {
            state.loadingStates[key] = true;
          } else {
            delete state.loadingStates[key];
          }
        }),

      addToast: (toast) =>
        set((state) => {
          const id = Math.random().toString(36).substr(2, 9);
          state.toasts.push({ ...toast, id });
        }),

      removeToast: (id) =>
        set((state) => {
          state.toasts = state.toasts.filter((toast) => toast.id !== id);
        }),

      clearToasts: () =>
        set((state) => {
          state.toasts = [];
        }),

      openModal: (modal) =>
        set((state) => {
          const id = Math.random().toString(36).substr(2, 9);
          state.modals.push({ ...modal, id });
        }),

      closeModal: (id) =>
        set((state) => {
          state.modals = state.modals.filter((modal) => modal.id !== id);
        }),

      closeAllModals: () =>
        set((state) => {
          state.modals = [];
        }),

      updateDashboardWidget: (id, updates) =>
        set((state) => {
          const widget = state.dashboardWidgets.find((w) => w.id === id);
          if (widget) {
            Object.assign(widget, updates);
          }
        }),

      addDashboardWidget: (widget) =>
        set((state) => {
          const id = Math.random().toString(36).substr(2, 9);
          state.dashboardWidgets.push({ ...widget, id });
        }),

      removeDashboardWidget: (id) =>
        set((state) => {
          state.dashboardWidgets = state.dashboardWidgets.filter(
            (w) => w.id !== id
          );
        }),

      setDashboardEditMode: (editMode) =>
        set((state) => {
          state.dashboardEditMode = editMode;
        }),

      setFormState: (formId, formState) =>
        set((state) => {
          if (!state.formStates[formId]) {
            state.formStates[formId] = {
              isDirty: false,
              isSubmitting: false,
              errors: {},
            };
          }
          Object.assign(state.formStates[formId], formState);
        }),

      clearFormState: (formId) =>
        set((state) => {
          delete state.formStates[formId];
        }),

      setTheme: (theme) =>
        set((state) => {
          state.theme = theme;
        }),
    })),
    {
      name: "ui-store",
    }
  )
);
