import { describe, it, expect, beforeAll, afterAll } from "@jest/globals";

function calculateEmissions(
  items: any[],
  emissionFactors: Map<string, number>
) {
  let total = 0;
  const breakdown: Record<string, number> = {};

  for (const item of items) {
    const key = `${item.category}__${item.subcategory}`;
    const factor = emissionFactors.get(key) || 1.0;
    const emission = item.quantity * factor;
    breakdown[item.category] = (breakdown[item.category] || 0) + emission;
    total += emission;
  }

  return { total, breakdown };
}

describe("Carbon Calculation Logic", () => {
  const mockEmissionFactors = new Map([
    ["transport__petrol", 2.31],
    ["transport__diesel", 2.68],
    ["energy__grid", 0.82],
    ["food__rice", 2.7],
  ]);

  it("should calculate emissions for a single item correctly", () => {
    const items = [
      {
        category: "transport",
        subcategory: "petrol",
        quantity: 10,
        unit: "liter",
      },
    ];

    const result = calculateEmissions(items, mockEmissionFactors);

    expect(result.total).toBe(23.1);
    expect(result.breakdown.transport).toBe(23.1);
  });

  it("should calculate emissions for multiple categories correctly", () => {
    const items = [
      {
        category: "transport",
        subcategory: "petrol",
        quantity: 10,
        unit: "liter",
      },
      { category: "energy", subcategory: "grid", quantity: 100, unit: "kWh" },
      { category: "food", subcategory: "rice", quantity: 5, unit: "kg" },
    ];

    const result = calculateEmissions(items, mockEmissionFactors);

    expect(result.total).toBe(118.6);
    expect(result.breakdown.transport).toBe(23.1);
    expect(result.breakdown.energy).toBe(82);
    expect(result.breakdown.food).toBe(13.5);
  });

  it("should use fallback factor for missing emission factors", () => {
    const items = [
      { category: "unknown", subcategory: "unknown", quantity: 10, unit: "kg" },
    ];

    const result = calculateEmissions(items, mockEmissionFactors);

    expect(result.total).toBe(10);
    expect(result.breakdown.unknown).toBe(10);
  });
});
