import { describe, it, expect, beforeAll, afterAll } from "@jest/globals";

global.fetch = jest.fn();

describe("Authentication Integration", () => {
  beforeAll(() => {});

  afterAll(() => {
    jest.restoreAllMocks();
  });

  it("should register a new user successfully", async () => {
    const mockResponse = {
      ok: true,
      json: async () => ({
        user: { id: "1", email: "test@example.com", name: "Test User" },
      }),
    };

    (fetch as jest.Mock).mockResolvedValueOnce(mockResponse);

    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: "test@example.com",
        password: "password123",
        name: "Test User",
      }),
    });

    const data = await response.json();

    expect(response.ok).toBe(true);
    expect(data.user.email).toBe("test@example.com");
    expect(data.user.name).toBe("Test User");
  });

  it("should login with valid credentials", async () => {
    const mockResponse = {
      ok: true,
      json: async () => ({
        user: { id: "1", email: "test@example.com", name: "Test User" },
      }),
    };

    (fetch as jest.Mock).mockResolvedValueOnce(mockResponse);

    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: "test@example.com",
        password: "password123",
      }),
    });

    const data = await response.json();

    expect(response.ok).toBe(true);
    expect(data.user.email).toBe("test@example.com");
  });

  it("should reject login with invalid credentials", async () => {
    const mockResponse = {
      ok: false,
      status: 401,
      json: async () => ({
        error: "Invalid credentials",
      }),
    };

    (fetch as jest.Mock).mockResolvedValueOnce(mockResponse);

    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: "test@example.com",
        password: "wrongpassword",
      }),
    });

    const data = await response.json();

    expect(response.ok).toBe(false);
    expect(response.status).toBe(401);
    expect(data.error).toBe("Invalid credentials");
  });
});
