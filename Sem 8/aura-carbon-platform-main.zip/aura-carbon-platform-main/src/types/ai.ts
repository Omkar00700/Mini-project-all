export interface ModelPerformanceMetrics {
  mae: number;
  rmse: number;
  r2_score: number;
  validation_accuracy: number;
  training_loss?: number;
  validation_loss?: number;
  precision?: number;
  recall?: number;
  f1_score?: number;
}

export interface TrainingDataInfo {
  training_samples: number;
  validation_samples: number;
  test_samples?: number;
  features: string[];
  training_date: string;
  data_version?: string;
  preprocessing_steps?: string[];
  feature_importance?: Record<string, number>;
}

export interface DeploymentInfo {
  endpoint: string;
  deployment_date: string;
  environment: "development" | "staging" | "production";
  version: string;
  container_image?: string;
  scaling_config?: {
    min_instances: number;
    max_instances: number;
    target_cpu_utilization: number;
  };
}

export interface MlModel {
  id: string;
  name: string;
  version: string;
  type:
    | "time_series_forecasting"
    | "classification"
    | "regression"
    | "recommendation"
    | "anomaly_detection";
  status: "training" | "active" | "inactive" | "deprecated" | "failed";
  performanceMetrics: ModelPerformanceMetrics;
  trainingDataInfo: TrainingDataInfo;
  deploymentInfo?: DeploymentInfo;
  createdAt: Date;

  predictions?: Prediction[];
}

export interface CreateMlModelInput {
  name: string;
  version: string;
  type:
    | "time_series_forecasting"
    | "classification"
    | "regression"
    | "recommendation"
    | "anomaly_detection";
  status: "training" | "active" | "inactive" | "deprecated" | "failed";
  performanceMetrics: ModelPerformanceMetrics;
  trainingDataInfo: TrainingDataInfo;
  deploymentInfo?: DeploymentInfo;
}

export interface UpdateMlModelInput {
  name?: string;
  version?: string;
  type?:
    | "time_series_forecasting"
    | "classification"
    | "regression"
    | "recommendation"
    | "anomaly_detection";
  status?: "training" | "active" | "inactive" | "deprecated" | "failed";
  performanceMetrics?: Partial<ModelPerformanceMetrics>;
  trainingDataInfo?: Partial<TrainingDataInfo>;
  deploymentInfo?: Partial<DeploymentInfo>;
}

export interface PredictionInputData {
  historical_data?: number[];
  user_profile?: string;
  seasonal_factor?: string;
  weather_data?: Record<string, any>;
  behavioral_patterns?: Record<string, any>;
  demographic_data?: Record<string, any>;
  [key: string]: any;
}

export interface PredictionOutputData {
  predicted_emissions?: number;
  confidence_interval?: [number, number];
  trend?: "increasing" | "decreasing" | "stable";
  seasonal_adjustment?: number;
  uncertainty_factors?: string[];
  contributing_factors?: Record<string, number>;
  [key: string]: any;
}

export interface Prediction {
  id: string;
  userId: string;
  modelId: string;
  predictionType:
    | "monthly_emissions"
    | "yearly_emissions"
    | "category_breakdown"
    | "reduction_potential"
    | "anomaly_detection";
  inputData: PredictionInputData;
  outputData: PredictionOutputData;
  confidenceScore?: number;
  createdAt: Date;

  user?: any;
  model?: MlModel;
}

export interface CreatePredictionInput {
  userId: string;
  modelId: string;
  predictionType:
    | "monthly_emissions"
    | "yearly_emissions"
    | "category_breakdown"
    | "reduction_potential"
    | "anomaly_detection";
  inputData: PredictionInputData;
  outputData: PredictionOutputData;
  confidenceScore?: number;
}

export interface UpdatePredictionInput {
  predictionType?:
    | "monthly_emissions"
    | "yearly_emissions"
    | "category_breakdown"
    | "reduction_potential"
    | "anomaly_detection";
  inputData?: PredictionInputData;
  outputData?: PredictionOutputData;
  confidenceScore?: number;
}

export interface UserFeedback {
  rating: number;
  implemented: boolean;
  implementation_date?: Date;
  effectiveness_rating?: number;
  comments?: string;
  barriers_encountered?: string[];
  time_to_implement?: number;
}

export interface Recommendation {
  id: string;
  userId: string;
  title: string;
  description: string;
  category:
    | "transportation"
    | "energy"
    | "food"
    | "consumption"
    | "waste"
    | "lifestyle";
  impactEstimate: number;
  costEstimate?: number;
  difficultyScore?: number;
  confidenceScore?: number;
  status: "active" | "implemented" | "dismissed" | "expired";
  userFeedback?: UserFeedback;
  createdAt: Date;

  user?: any;
}

export interface CreateRecommendationInput {
  userId: string;
  title: string;
  description: string;
  category:
    | "transportation"
    | "energy"
    | "food"
    | "consumption"
    | "waste"
    | "lifestyle";
  impactEstimate: number;
  costEstimate?: number;
  difficultyScore?: number;
  confidenceScore?: number;
  status?: "active" | "implemented" | "dismissed" | "expired";
  userFeedback?: UserFeedback;
}

export interface UpdateRecommendationInput {
  title?: string;
  description?: string;
  category?:
    | "transportation"
    | "energy"
    | "food"
    | "consumption"
    | "waste"
    | "lifestyle";
  impactEstimate?: number;
  costEstimate?: number;
  difficultyScore?: number;
  confidenceScore?: number;
  status?: "active" | "implemented" | "dismissed" | "expired";
  userFeedback?: UserFeedback;
}

export interface RecommendationContext {
  user_preferences: Record<string, any>;
  budget_constraints?: {
    min_budget: number;
    max_budget: number;
  };
  time_constraints?: {
    available_time: number;
    implementation_timeline: number;
  };
  lifestyle_constraints?: string[];
  geographic_constraints?: {
    region: string;
    climate_zone: string;
    urban_rural: "urban" | "suburban" | "rural";
  };
  current_emissions_profile: Record<string, number>;
}

export interface PredictionResult {
  prediction_id: string;
  forecast_horizon: number;
  predictions: {
    date: Date;
    predicted_value: number;
    confidence_lower: number;
    confidence_upper: number;
  }[];
  model_metadata: {
    model_name: string;
    model_version: string;
    prediction_accuracy: number;
    last_trained: Date;
  };
  influencing_factors: {
    factor: string;
    importance: number;
    trend: "positive" | "negative" | "neutral";
  }[];
}

export interface AnomalyDetectionResult {
  is_anomaly: boolean;
  anomaly_score: number;
  anomaly_type?: "spike" | "drop" | "trend_change" | "seasonal_deviation";
  affected_categories: string[];
  potential_causes: string[];
  recommended_actions: string[];
  confidence: number;
}

export interface ModelTrainingJob {
  id: string;
  model_name: string;
  model_version: string;
  status: "queued" | "running" | "completed" | "failed" | "cancelled";
  progress: number;
  started_at?: Date;
  completed_at?: Date;
  error_message?: string;
  training_config: {
    dataset_size: number;
    epochs: number;
    batch_size: number;
    learning_rate: number;
    validation_split: number;
  };
  performance_metrics?: ModelPerformanceMetrics;
}

export interface BatchPredictionJob {
  id: string;
  model_id: string;
  user_ids: string[];
  prediction_type: string;
  status: "queued" | "running" | "completed" | "failed";
  progress: number;
  results?: Prediction[];
  created_at: Date;
  completed_at?: Date;
}

export interface BatchRecommendationJob {
  id: string;
  user_ids: string[];
  recommendation_engine_version: string;
  status: "queued" | "running" | "completed" | "failed";
  progress: number;
  results?: Recommendation[];
  created_at: Date;
  completed_at?: Date;
}
