export interface UserLocation {
  country: string;
  region: string;
  city: string;
  coordinates?: [number, number];
}

export interface UserHousehold {
  size: number;
  type: "individual" | "family" | "shared";
  income_bracket?: string;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  sms: boolean;
  marketing: boolean;
  recommendations: boolean;
  achievements: boolean;
  weekly_reports: boolean;
}

export interface UserPreferences {
  units: "metric" | "imperial";
  privacy_level: "public" | "friends" | "private";
  notifications: NotificationPreferences;
  language?: string;
  timezone?: string;
  currency?: string;
}

export interface UserSubscription {
  tier: "free" | "premium" | "enterprise";
  features: string[];
  expires_at?: Date;
  auto_renew?: boolean;
}

export interface DashboardWidget {
  id: string;
  type: string;
  title: string;
  description: string;
  size: "sm" | "md" | "lg" | "xl";
  position: { x: number; y: number };
  config: Record<string, any>;
  isVisible: boolean;
}

export interface DashboardConfig {
  widgets: DashboardWidget[];
  layout: "grid" | "list" | "custom";
  version: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  location: UserLocation;
  household: UserHousehold;
  preferences: UserPreferences;
  subscription: UserSubscription;
  dashboardConfig?: DashboardConfig;
  createdAt: Date;
  updatedAt: Date;
}

export interface UpdateUserProfileData {
  name?: string;
  location?: Partial<UserLocation>;
  household?: Partial<UserHousehold>;
  preferences?: Partial<UserPreferences>;
}

export interface UserProfileFormData {
  name: string;
  country: string;
  region: string;
  city: string;
  householdSize: number;
  householdType: "individual" | "family" | "shared";
  incomeBracket?: string;
  units: "metric" | "imperial";
  privacyLevel: "public" | "friends" | "private";
  language?: string;
  timezone?: string;
  currency?: string;
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
    marketing: boolean;
    recommendations: boolean;
    achievements: boolean;
    weekly_reports: boolean;
  };
}
