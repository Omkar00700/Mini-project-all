export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: string;
  currentStreak?: number;
  longestStreak?: number;
  streakLastMaintained?: Date | string | null;
  currentLevel?: number;
  totalXp?: number;
  image?: string | null;
}

export interface AuthError {
  message: string;
  status?: number;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  confirmPassword: string;
  fullName: string;
}

export interface ResetPasswordCredentials {
  email: string;
}

export interface UpdatePasswordCredentials {
  password: string;
  confirmPassword: string;
}

export interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  signIn: (credentials: LoginCredentials) => Promise<{ error?: AuthError }>;
  signUp: (credentials: RegisterCredentials) => Promise<{ error?: AuthError }>;
  signOut: () => Promise<void>;
}

export type AuthProvider = "google";
