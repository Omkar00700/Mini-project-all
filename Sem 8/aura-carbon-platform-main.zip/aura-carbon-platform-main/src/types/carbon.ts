export interface EmissionBreakdown {
  transportation: number;
  energy: number;
  food: number;
  consumption: number;
  waste?: number;
  travel?: number;
  [category: string]: number | undefined;
}

export interface CalculationMetadata {
  calculation_method: "ghg_protocol" | "ipcc" | "custom";
  emission_factors_version: string;
  data_completeness: number;
  calculation_timestamp?: Date;
  confidence_factors?: Record<string, number>;
  assumptions?: string[];
  data_sources?: string[];
}

export interface CarbonCalculation {
  id: string;
  userId?: string;
  organizationId?: string;
  periodStart: Date;
  periodEnd: Date;
  totalEmissions: number;
  breakdown: EmissionBreakdown;
  confidenceScore?: number;
  metadata: CalculationMetadata;
  createdAt: Date;

  user?: any;
  organization?: any;
}

export interface CreateCarbonCalculationInput {
  userId?: string;
  organizationId?: string;
  periodStart: Date;
  periodEnd: Date;
  totalEmissions: number;
  breakdown: EmissionBreakdown;
  confidenceScore?: number;
  metadata: CalculationMetadata;
}

export interface UpdateCarbonCalculationInput {
  periodStart?: Date;
  periodEnd?: Date;
  totalEmissions?: number;
  breakdown?: Partial<EmissionBreakdown>;
  confidenceScore?: number;
  metadata?: Partial<CalculationMetadata>;
}

export interface EmissionFactor {
  id: string;
  category: string;
  subcategory: string;
  region: string;
  value: number;
  unit: string;
  source: string;
  confidenceLevel?: number;
  validFrom: Date;
  validTo?: Date;
  createdAt: Date;
}

export interface CreateEmissionFactorInput {
  category: string;
  subcategory: string;
  region: string;
  value: number;
  unit: string;
  source: string;
  confidenceLevel?: number;
  validFrom: Date;
  validTo?: Date;
}

export interface UpdateEmissionFactorInput {
  category?: string;
  subcategory?: string;
  region?: string;
  value?: number;
  unit?: string;
  source?: string;
  confidenceLevel?: number;
  validFrom?: Date;
  validTo?: Date;
}

export interface ActivityMetadata {
  vehicle_type?: string;
  fuel_type?: string;
  utility_provider?: string;
  billing_period?: string;
  food_type?: string;
  organic_percentage?: number;
  product_category?: string;
  brand?: string;
  location?: string;
  weather_conditions?: string;
  [key: string]: any;
}

export interface ActivityData {
  id: string;
  userId: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  date: Date;
  source: "manual" | "api" | "estimated" | "imported" | "calculated";
  metadata?: ActivityMetadata;
  createdAt: Date;

  user?: any;
}

export interface CreateActivityDataInput {
  userId: string;
  category: string;
  subcategory: string;
  value: number;
  unit: string;
  date: Date;
  source: "manual" | "api" | "estimated" | "imported" | "calculated";
  metadata?: ActivityMetadata;
}

export interface UpdateActivityDataInput {
  category?: string;
  subcategory?: string;
  value?: number;
  unit?: string;
  date?: Date;
  source?: "manual" | "api" | "estimated" | "imported" | "calculated";
  metadata?: ActivityMetadata;
}

export interface TransportationData {
  personal_vehicles?: {
    distance: number;
    fuel_type: "gasoline" | "diesel" | "electric" | "hybrid";
    vehicle_class: "compact" | "midsize" | "large" | "suv" | "truck";
    efficiency?: number;
  };
  public_transport?: {
    bus_distance?: number;
    train_distance?: number;
    subway_distance?: number;
    tram_distance?: number;
  };
  flights?: {
    domestic_short?: number;
    domestic_medium?: number;
    domestic_long?: number;
    international_short?: number;
    international_long?: number;
    class: "economy" | "business" | "first";
  };
  ride_sharing?: {
    distance: number;
    vehicle_type: "standard" | "premium" | "electric";
    shared: boolean;
  };
}

export interface EnergyData {
  electricity?: {
    consumption: number;
    grid_region: string;
    renewable_percentage?: number;
    source_mix?: Record<string, number>;
  };
  heating?: {
    natural_gas?: number;
    heating_oil?: number;
    propane?: number;
    wood?: number;
    district_heating?: number;
  };
  cooling?: {
    electricity: number;
    efficiency_rating?: string;
  };
  renewable?: {
    solar_generated?: number;
    wind_generated?: number;
    other_generated?: number;
  };
}

export interface FoodData {
  meat?: {
    beef?: number;
    pork?: number;
    chicken?: number;
    fish?: number;
    lamb?: number;
    other?: number;
  };
  dairy?: {
    milk?: number;
    cheese?: number;
    yogurt?: number;
    butter?: number;
  };
  plant_based?: {
    vegetables?: number;
    fruits?: number;
    grains?: number;
    legumes?: number;
    nuts?: number;
  };
  beverages?: {
    coffee?: number;
    tea?: number;
    alcohol?: number;
    soft_drinks?: number;
  };
  dining_out?: {
    restaurant_meals?: number;
    fast_food_meals?: number;
    delivery_meals?: number;
  };
}

export interface ConsumptionData {
  shopping?: {
    clothing?: number;
    electronics?: number;
    furniture?: number;
    books?: number;
    other_goods?: number;
  };
  services?: {
    banking?: number;
    insurance?: number;
    telecommunications?: number;
    entertainment?: number;
  };
  waste?: {
    general_waste?: number;
    recycling?: number;
    organic_waste?: number;
    electronic_waste?: number;
  };
}

export interface CarbonFootprintInput {
  user_id: string;
  period: {
    start: Date;
    end: Date;
  };
  categories: {
    transportation?: TransportationData;
    energy?: EnergyData;
    food?: FoodData;
    consumption?: ConsumptionData;
  };
}

export interface CarbonFootprintResult {
  total_emissions: number;
  breakdown: EmissionBreakdown;
  confidence_score: number;
  calculation_metadata: CalculationMetadata;
  detailed_breakdown?: {
    [category: string]: {
      [subcategory: string]: {
        emissions: number;
        activity_data: number;
        emission_factor: number;
        unit: string;
        confidence: number;
        methodology?: string;
        data_quality?: number;
      };
    };
  };
}

export interface EmissionTimeSeries {
  date: Date;
  total_emissions: number;
  category_breakdown: EmissionBreakdown;
  data_quality: number;
}

export interface CarbonTrend {
  period: "daily" | "weekly" | "monthly" | "yearly";
  data: EmissionTimeSeries[];
  trend_direction: "increasing" | "decreasing" | "stable";
  trend_percentage: number;
  seasonal_patterns?: {
    [month: string]: number;
  };
}
