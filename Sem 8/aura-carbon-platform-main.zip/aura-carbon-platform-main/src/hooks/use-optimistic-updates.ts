import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useUIStore } from "@/store/ui-store";
import { createOptimisticUpdate } from "@/lib/query-client";

interface OptimisticUpdateOptions<TData, TVariables> {
  queryKey: readonly unknown[];
  mutationFn: (variables: TVariables) => Promise<TData>;
  updater: (oldData: TData | undefined, variables: TVariables) => TData;
  successMessage?: string;
  errorMessage?: string;
}

export function useOptimisticUpdate<TData, TVariables>({
  queryKey,
  mutationFn,
  updater,
  successMessage = "Operation completed successfully",
  errorMessage = "Operation failed",
}: OptimisticUpdateOptions<TData, TVariables>) {
  const queryClient = useQueryClient();
  const addToast = useUIStore((state) => state.addToast);

  return useMutation({
    mutationFn,
    ...createOptimisticUpdate<TData>(queryKey, (oldData) =>
      updater(oldData, {} as TVariables)
    ),
    onMutate: async (variables: TVariables) => {
      await queryClient.cancelQueries({ queryKey });

      const previousData = queryClient.getQueryData<TData>(queryKey);

      queryClient.setQueryData<TData>(queryKey, (oldData) =>
        updater(oldData, variables)
      );

      return { previousData };
    },
    onError: (error, variables, context) => {
      if (context?.previousData) {
        queryClient.setQueryData<TData>(queryKey, context.previousData);
      }

      addToast({
        title: "Error",
        description: error instanceof Error ? error.message : errorMessage,
        type: "error",
      });
    },
    onSuccess: () => {
      addToast({
        title: "Success",
        description: successMessage,
        type: "success",
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });
}

export function useOptimisticArrayUpdate<TItem, TVariables>({
  queryKey,
  mutationFn,
  updateType,
  getId,
  successMessage,
  errorMessage,
}: {
  queryKey: readonly unknown[];
  mutationFn: (variables: TVariables) => Promise<TItem>;
  updateType: "add" | "update" | "remove";
  getId: (item: TItem) => string;
  successMessage?: string;
  errorMessage?: string;
}) {
  return useOptimisticUpdate<TItem[], TVariables>({
    queryKey,
    mutationFn: async (variables: TVariables) => {
      const item = await mutationFn(variables);
      return [item];
    },
    updater: (oldData = [], variables) => {
      switch (updateType) {
        case "add":
          return [...oldData];

        case "remove":
          const removeId = (variables as any).id;
          return oldData.filter((item) => getId(item) !== removeId);

        case "update":
          const updateId = (variables as any).id;
          const updates = (variables as any).updates;
          return oldData.map((item) =>
            getId(item) === updateId ? { ...item, ...updates } : item
          );

        default:
          return oldData;
      }
    },
    successMessage,
    errorMessage,
  });
}

export function useOptimisticForm<TData, TFormData>({
  queryKey,
  mutationFn,
  onSuccess,
  formId,
}: {
  queryKey: readonly unknown[];
  mutationFn: (data: TFormData) => Promise<TData>;
  onSuccess?: (data: TData) => void;
  formId: string;
}) {
  const setFormState = useUIStore((state) => state.setFormState);
  const clearFormState = useUIStore((state) => state.clearFormState);

  const mutation = useOptimisticUpdate({
    queryKey,
    mutationFn,
    updater: (oldData, variables) => {
      return oldData ?? ({} as TData);
    },
  });

  const handleSubmit = async (data: TFormData) => {
    setFormState(formId, { isSubmitting: true, errors: {} });

    try {
      const result = await mutation.mutateAsync(data);
      clearFormState(formId);
      onSuccess?.(result);
      return result;
    } catch (error) {
      setFormState(formId, {
        isSubmitting: false,
        errors: {
          submit: error instanceof Error ? error.message : "Submission failed",
        },
      });
      throw error;
    }
  };

  return {
    ...mutation,
    handleSubmit,
    isSubmitting: mutation.isPending,
  };
}
