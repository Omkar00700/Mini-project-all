"use client";

import { useState, useEffect } from "react";

export interface DeviceCapabilities {
  hasWebGL: boolean;
  hasGoodGPU: boolean;
  isMobile: boolean;
  isLowPowerMode: boolean;
  canRender3D: boolean;
  tier: "high" | "medium" | "low";
}

export function useDeviceCapabilities(): DeviceCapabilities {
  const [capabilities, setCapabilities] = useState<DeviceCapabilities>({
    hasWebGL: false,
    hasGoodGPU: false,
    isMobile: false,
    isLowPowerMode: false,
    canRender3D: false,
    tier: "low",
  });

  useEffect(() => {
    const checkCapabilities = () => {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
      const hasWebGL = !!gl;

      const isMobile =
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
          navigator.userAgent
        );

      let hasGoodGPU = false;
      let tier: "high" | "medium" | "low" = "low";

      if (gl && hasWebGL) {
        const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
        if (debugInfo) {
          const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
          const rendererLower = renderer.toLowerCase();

          if (
            rendererLower.includes("nvidia") ||
            rendererLower.includes("amd") ||
            rendererLower.includes("radeon") ||
            rendererLower.includes("intel uhd") ||
            rendererLower.includes("apple m1") ||
            rendererLower.includes("apple m2") ||
            rendererLower.includes("apple m3")
          ) {
            hasGoodGPU = true;
            tier = "high";
          } else if (
            rendererLower.includes("intel hd") ||
            rendererLower.includes("intel iris") ||
            rendererLower.includes("adreno") ||
            rendererLower.includes("mali")
          ) {
            tier = "medium";
          }
        }

        if (!hasGoodGPU && !isMobile) {
          tier = "medium";
        }
      }

      let isLowPowerMode = false;
      if ("getBattery" in navigator) {
        (
          navigator as Navigator & {
            getBattery: () => Promise<{ charging: boolean }>;
          }
        )
          .getBattery()
          .then((battery) => {
            isLowPowerMode = !battery.charging;
          })
          .catch(() => {});
      }

      const canRender3D = hasWebGL && tier !== "low";

      setCapabilities({
        hasWebGL,
        hasGoodGPU,
        isMobile,
        isLowPowerMode,
        canRender3D,
        tier,
      });
    };

    checkCapabilities();
  }, []);

  return capabilities;
}
