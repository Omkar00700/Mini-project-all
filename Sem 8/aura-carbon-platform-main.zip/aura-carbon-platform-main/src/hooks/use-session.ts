"use client";

import { useAuth } from "@/contexts/auth-context";

export function useSession() {
  const { user, loading } = useAuth();

  return {
    user,
    loading,
    isAuthenticated: !!user,
  };
}
