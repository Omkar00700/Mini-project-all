import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY
  ? new Resend(process.env.RESEND_API_KEY)
  : null;

export const sendWelcomeEmail = async (email: string, name: string) => {
  if (!resend) {
    return false;
  }

  try {
    const { data, error } = await resend.emails.send({
      from: "Aura Support <onboarding@resend.dev>",
      to: [email],
      subject: "Welcome to Aura - Your Carbon Intelligence Platform",
      html: `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f9fafb; padding: 40px 0;">
          <div style="max-w-md mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 p-8 max-width: 600px; margin: 0 auto;">
            
            <div style="text-align: center; margin-bottom: 32px;">
              <h1 style="color: #059669; margin: 0; font-size: 28px; letter-spacing: -0.5px;">Aura</h1>
            </div>

            <h2 style="color: #111827; font-size: 24px; font-weight: 600; margin-bottom: 16px;">Welcome to Aura, ${name}! 🌱</h2>
            
            <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 24px;">
              We're thrilled to have you join our community. Your journey towards maintaining a sustainable, zero-carbon future begins today. 
            </p>

            <div style="background-color: #ecfdf5; border-left: 4px solid #10b981; padding: 16px; margin-bottom: 32px; border-radius: 4px;">
              <p style="color: #065f46; margin: 0; font-size: 15px;">
                <strong>Pro Tip:</strong> Check out your dashboard to see your <em>Aura Entity</em>—a digital seedling that grows as you log your sustainable activities and maintain your streaks!
              </p>
            </div>

            <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 32px;">
              We provide localized carbon insights, AI-driven recommendations, and what-if scenario forecasting to empower your decisions.
            </p>

            <div style="text-align: center; margin-top: 40px;">
              <a href="https://your-aura-domain.com/dashboard" style="background-color: #10b981; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; display: inline-block;">
                Access Dashboard
              </a>
            </div>

            <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 40px 0;" />
            
            <p style="color: #9ca3af; font-size: 14px; text-align: center; margin: 0;">
              Made with ❤️ for the Planet.<br/>
              © ${new Date().getFullYear()} Aura Intelligence.
            </p>
          </div>
        </div>
      `,
    });

    if (error) {
      return false;
    }

    return true;
  } catch (error) {
    return false;
  }
};
