import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

export interface RateLimitOptions {
  limit: number;
  windowSeconds: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

interface RateLimitEntry {
  count: number;
  resetAt: number;
}
const localStore = new Map<string, RateLimitEntry>();

if (typeof setInterval !== "undefined") {
  setInterval(
    () => {
      const now = Date.now();
      for (const [key, entry] of Array.from(localStore.entries())) {
        if (entry.resetAt < now) {
          localStore.delete(key);
        }
      }
    },
    5 * 60 * 1000
  );
}

function fallbackRateLimit(
  identifier: string,
  options: RateLimitOptions
): RateLimitResult {
  const { limit, windowSeconds } = options;
  const now = Date.now();
  const windowMs = windowSeconds * 1000;

  const existing = localStore.get(identifier);

  if (!existing || existing.resetAt < now) {
    const resetAt = now + windowMs;
    localStore.set(identifier, { count: 1, resetAt });
    return { allowed: true, remaining: limit - 1, resetAt };
  }

  if (existing.count >= limit) {
    return { allowed: false, remaining: 0, resetAt: existing.resetAt };
  }

  existing.count += 1;
  return {
    allowed: true,
    remaining: limit - existing.count,
    resetAt: existing.resetAt,
  };
}

const redis =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN
    ? new Redis({
        url: process.env.UPSTASH_REDIS_REST_URL,
        token: process.env.UPSTASH_REDIS_REST_TOKEN,
      })
    : null;

const ratelimitCache = new Map<string, Ratelimit>();

export async function rateLimit(
  identifier: string,
  options: RateLimitOptions
): Promise<RateLimitResult> {
  if (redis) {
    const key = `${options.limit}_${options.windowSeconds}s`;
    let limiter = ratelimitCache.get(key);

    if (!limiter) {
      limiter = new Ratelimit({
        redis,
        limiter: Ratelimit.slidingWindow(
          options.limit,
          `${options.windowSeconds} s`
        ),
        analytics: true,
      });
      ratelimitCache.set(key, limiter);
    }

    try {
      const { success, limit, remaining, reset } = await limiter.limit(
        `ratelimit_${identifier}`
      );
      return {
        allowed: success,
        remaining,
        resetAt: reset,
      };
    } catch (error) {}
  }

  return fallbackRateLimit(identifier, options);
}

export function getClientIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    return forwarded.split(",")[0].trim();
  }
  return request.headers.get("x-real-ip") ?? "unknown";
}
