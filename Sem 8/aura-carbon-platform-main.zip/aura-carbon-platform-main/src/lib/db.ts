export { prisma as db, prisma } from "@/lib/prisma";

export async function testDatabaseConnection(): Promise<boolean> {
  const { prisma } = await import("@/lib/prisma");
  try {
    await prisma.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}

export async function disconnectDatabase(): Promise<void> {
  const { prisma } = await import("@/lib/prisma");
  await prisma.$disconnect();
}

export async function getDatabaseHealth() {
  const { prisma } = await import("@/lib/prisma");
  try {
    const start = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    return {
      status: "healthy",
      responseTime: Date.now() - start,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      status: "unhealthy",
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    };
  }
}
