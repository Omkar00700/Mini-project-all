import { z } from "zod";

export const electricityDataSchema = z.object({
  consumption: z.number().min(0, "Consumption must be non-negative"),
  grid_region: z.string().min(1, "Grid region is required"),
  renewable_percentage: z.number().min(0).max(100).optional(),
  source_mix: z.record(z.string(), z.number().min(0).max(100)).optional(),
});

export const heatingDataSchema = z.object({
  natural_gas: z.number().min(0).optional(),
  heating_oil: z.number().min(0).optional(),
  propane: z.number().min(0).optional(),
  wood: z.number().min(0).optional(),
  district_heating: z.number().min(0).optional(),
});

export const coolingDataSchema = z.object({
  electricity: z
    .number()
    .min(0, "Cooling electricity consumption must be non-negative"),
  efficiency_rating: z.string().optional(),
});

export const renewableDataSchema = z.object({
  solar_generated: z.number().min(0).optional(),
  wind_generated: z.number().min(0).optional(),
  other_generated: z.number().min(0).optional(),
});

export const energyDataSchema = z
  .object({
    electricity: electricityDataSchema.optional(),
    heating: heatingDataSchema.optional(),
    cooling: coolingDataSchema.optional(),
    renewable: renewableDataSchema.optional(),
  })
  .refine(
    (data) => {
      return data.electricity || data.heating || data.cooling || data.renewable;
    },
    {
      message:
        "At least one energy category (electricity, heating, cooling, or renewable) must be provided",
    }
  );

export const energyCalculationRequestSchema = z.object({
  user_id: z.string().cuid("Invalid user ID format"),
  period_start: z.string().datetime("Invalid start date format"),
  period_end: z.string().datetime("Invalid end date format"),
  energy_data: energyDataSchema,
});

export const gridEmissionFactorSchema = z.object({
  region: z.string().min(1, "Region is required"),
  emission_factor: z.number().min(0, "Emission factor must be non-negative"),
  renewable_percentage: z.number().min(0).max(100),
  source_mix: z.object({
    coal: z.number().min(0).max(100),
    natural_gas: z.number().min(0).max(100),
    nuclear: z.number().min(0).max(100),
    hydro: z.number().min(0).max(100),
    wind: z.number().min(0).max(100),
    solar: z.number().min(0).max(100),
    other: z.number().min(0).max(100),
  }),
  timestamp: z.string().datetime(),
});

export const energyRecommendationSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  category: z.enum([
    "electricity",
    "heating",
    "cooling",
    "renewable",
    "efficiency",
  ]),
  impact_estimate: z.number().min(0, "Impact estimate must be non-negative"),
  cost_estimate: z.number().min(0).optional(),
  difficulty_score: z.number().min(1).max(5),
  confidence_score: z.number().min(0).max(1).optional(),
  payback_period_months: z.number().min(0).optional(),
  annual_savings: z.number().min(0).optional(),
});

export const energyAuditSchema = z.object({
  home_size: z.number().min(0, "Home size must be non-negative"),
  home_age: z.number().min(0, "Home age must be non-negative"),
  insulation_rating: z.enum(["poor", "fair", "good", "excellent"]).optional(),
  window_type: z.enum(["single", "double", "triple", "storm"]).optional(),
  hvac_age: z.number().min(0).optional(),
  hvac_type: z
    .enum(["furnace", "boiler", "heat_pump", "baseboard", "other"])
    .optional(),
  water_heater_type: z
    .enum(["electric", "gas", "heat_pump", "solar", "tankless"])
    .optional(),
  appliance_efficiency: z
    .enum(["standard", "energy_star", "high_efficiency"])
    .optional(),
});

export const timeOfUseSchema = z.object({
  peak_hours: z.object({
    consumption: z.number().min(0),
    rate: z.number().min(0),
    hours: z.array(z.number().min(0).max(23)),
  }),
  off_peak_hours: z.object({
    consumption: z.number().min(0),
    rate: z.number().min(0),
    hours: z.array(z.number().min(0).max(23)),
  }),
  shoulder_hours: z
    .object({
      consumption: z.number().min(0),
      rate: z.number().min(0),
      hours: z.array(z.number().min(0).max(23)),
    })
    .optional(),
});

export const smartHomeDataSchema = z.object({
  devices: z.array(
    z.object({
      id: z.string(),
      type: z.enum([
        "thermostat",
        "smart_meter",
        "solar_inverter",
        "battery",
        "ev_charger",
      ]),
      consumption: z.number().min(0),
      timestamp: z.string().datetime(),
      metadata: z.record(z.string(), z.any()).optional(),
    })
  ),
  automation_rules: z
    .array(
      z.object({
        id: z.string(),
        name: z.string(),
        trigger: z.string(),
        action: z.string(),
        energy_impact: z.number().optional(),
      })
    )
    .optional(),
});

export const energyGoalSchema = z.object({
  target_reduction_percentage: z.number().min(0).max(100),
  target_date: z.string().datetime(),
  baseline_emissions: z.number().min(0),
  current_emissions: z.number().min(0),
  goal_type: z.enum(["absolute", "intensity", "renewable_percentage"]),
  tracking_frequency: z.enum(["daily", "weekly", "monthly", "quarterly"]),
});

export const utilityBillSchema = z.object({
  provider: z.string().min(1, "Utility provider is required"),
  account_number: z.string().min(1, "Account number is required"),
  billing_period: z.object({
    start: z.string().datetime(),
    end: z.string().datetime(),
  }),
  electricity: z
    .object({
      consumption: z.number().min(0),
      cost: z.number().min(0),
      rate_structure: z.enum(["flat", "tiered", "time_of_use"]).optional(),
    })
    .optional(),
  gas: z
    .object({
      consumption: z.number().min(0),
      cost: z.number().min(0),
      unit: z.enum(["ccf", "mcf", "therms", "kwh"]),
    })
    .optional(),
});

export const energyValidationSchemas = {
  electricityData: electricityDataSchema,
  heatingData: heatingDataSchema,
  coolingData: coolingDataSchema,
  renewableData: renewableDataSchema,
  energyData: energyDataSchema,
  energyCalculationRequest: energyCalculationRequestSchema,
  gridEmissionFactor: gridEmissionFactorSchema,
  energyRecommendation: energyRecommendationSchema,
  energyAudit: energyAuditSchema,
  timeOfUse: timeOfUseSchema,
  smartHomeData: smartHomeDataSchema,
  energyGoal: energyGoalSchema,
  utilityBill: utilityBillSchema,
};
