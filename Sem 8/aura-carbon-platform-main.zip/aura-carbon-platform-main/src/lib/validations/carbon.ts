import { z } from "zod";

export const emissionBreakdownSchema = z
  .object({
    transportation: z.number().min(0),
    energy: z.number().min(0),
    food: z.number().min(0),
    consumption: z.number().min(0),
    waste: z.number().min(0).optional(),
    travel: z.number().min(0).optional(),
  })
  .catchall(z.number().min(0));

export const calculationMetadataSchema = z.object({
  calculation_method: z.enum(["ghg_protocol", "ipcc", "custom"]),
  emission_factors_version: z.string().min(1),
  data_completeness: z.number().min(0).max(1),
  calculation_timestamp: z.date().optional(),
  confidence_factors: z.record(z.string(), z.number().min(0).max(1)).optional(),
  assumptions: z.array(z.string()).optional(),
  data_sources: z.array(z.string()).optional(),
});

export const createCarbonCalculationSchema = z
  .object({
    userId: z.string().cuid().optional(),
    organizationId: z.string().cuid().optional(),
    periodStart: z.date(),
    periodEnd: z.date(),
    totalEmissions: z.number().min(0),
    breakdown: emissionBreakdownSchema,
    confidenceScore: z.number().min(0).max(1).optional(),
    metadata: calculationMetadataSchema,
  })
  .refine((data) => data.userId || data.organizationId, {
    message: "Either userId or organizationId must be provided",
    path: ["userId", "organizationId"],
  })
  .refine((data) => data.periodEnd > data.periodStart, {
    message: "Period end must be after period start",
    path: ["periodEnd"],
  });

const baseCarbonCalculationSchema = z.object({
  userId: z.string().cuid().optional(),
  organizationId: z.string().cuid().optional(),
  periodStart: z.date(),
  periodEnd: z.date(),
  totalEmissions: z.number().min(0),
  breakdown: emissionBreakdownSchema,
  confidenceScore: z.number().min(0).max(1).optional(),
  metadata: calculationMetadataSchema,
});

export const updateCarbonCalculationSchema = baseCarbonCalculationSchema
  .omit({
    userId: true,
    organizationId: true,
  })
  .partial();

export const createEmissionFactorSchema = z
  .object({
    category: z.string().min(1).max(100),
    subcategory: z.string().min(1).max(100),
    region: z.string().min(1).max(100),
    value: z.number().min(0),
    unit: z.string().min(1).max(50),
    source: z.string().min(1).max(255),
    confidenceLevel: z.number().min(0).max(1).optional(),
    validFrom: z.date(),
    validTo: z.date().optional(),
  })
  .refine((data) => !data.validTo || data.validTo > data.validFrom, {
    message: "Valid to date must be after valid from date",
    path: ["validTo"],
  });

const baseEmissionFactorSchema = z.object({
  category: z.string().min(1),
  subcategory: z.string().min(1),
  region: z.string().min(1),
  value: z.number().min(0),
  unit: z.string().min(1),
  source: z.string().min(1),
  confidenceLevel: z.number().min(0).max(1).optional(),
  validFrom: z.date(),
  validTo: z.date().optional(),
});

export const updateEmissionFactorSchema = baseEmissionFactorSchema.partial();

export const activityMetadataSchema = z
  .object({
    vehicle_type: z.string().optional(),
    fuel_type: z.string().optional(),
    utility_provider: z.string().optional(),
    billing_period: z.string().optional(),
    food_type: z.string().optional(),
    organic_percentage: z.number().min(0).max(1).optional(),
    product_category: z.string().optional(),
    brand: z.string().optional(),
    location: z.string().optional(),
    weather_conditions: z.string().optional(),
  })
  .catchall(z.any());

export const createActivityDataSchema = z.object({
  userId: z.string().cuid(),
  category: z.string().min(1).max(100),
  subcategory: z.string().min(1).max(100),
  value: z.number().min(0),
  unit: z.string().min(1).max(50),
  date: z.date(),
  source: z.enum(["manual", "api", "estimated", "imported", "calculated"]),
  metadata: activityMetadataSchema.optional(),
});

export const updateActivityDataSchema = createActivityDataSchema
  .partial()
  .omit({
    userId: true,
  });

export const transportationDataSchema = z.object({
  personal_vehicles: z
    .object({
      distance: z.number().min(0),
      fuel_type: z.enum(["gasoline", "diesel", "electric", "hybrid"]),
      vehicle_class: z.enum(["compact", "midsize", "large", "suv", "truck"]),
      efficiency: z.number().min(0).optional(),
    })
    .optional(),
  public_transport: z
    .object({
      bus_distance: z.number().min(0).optional(),
      train_distance: z.number().min(0).optional(),
      subway_distance: z.number().min(0).optional(),
      tram_distance: z.number().min(0).optional(),
    })
    .optional(),
  flights: z
    .object({
      domestic_short: z.number().min(0).optional(),
      domestic_medium: z.number().min(0).optional(),
      domestic_long: z.number().min(0).optional(),
      international_short: z.number().min(0).optional(),
      international_long: z.number().min(0).optional(),
      class: z.enum(["economy", "business", "first"]),
    })
    .optional(),
  ride_sharing: z
    .object({
      distance: z.number().min(0),
      vehicle_type: z.enum(["standard", "premium", "electric"]),
      shared: z.boolean(),
    })
    .optional(),
});

export const energyDataSchema = z.object({
  electricity: z
    .object({
      consumption: z.number().min(0),
      grid_region: z.string().min(1),
      renewable_percentage: z.number().min(0).max(1).optional(),
      source_mix: z.record(z.string(), z.number().min(0)).optional(),
    })
    .optional(),
  heating: z
    .object({
      natural_gas: z.number().min(0).optional(),
      heating_oil: z.number().min(0).optional(),
      propane: z.number().min(0).optional(),
      wood: z.number().min(0).optional(),
      district_heating: z.number().min(0).optional(),
    })
    .optional(),
  cooling: z
    .object({
      electricity: z.number().min(0),
      efficiency_rating: z.string().optional(),
    })
    .optional(),
  renewable: z
    .object({
      solar_generated: z.number().min(0).optional(),
      wind_generated: z.number().min(0).optional(),
      other_generated: z.number().min(0).optional(),
    })
    .optional(),
});

export const foodDataSchema = z.object({
  meat: z
    .object({
      pork: z.number().min(0).optional(),
      chicken: z.number().min(0).optional(),
      fish: z.number().min(0).optional(),
      lamb: z.number().min(0).optional(),
      other: z.number().min(0).optional(),
    })
    .optional(),
  dairy: z
    .object({
      milk: z.number().min(0).optional(),
      cheese: z.number().min(0).optional(),
      yogurt: z.number().min(0).optional(),
      butter: z.number().min(0).optional(),
    })
    .optional(),
  plant_based: z
    .object({
      vegetables: z.number().min(0).optional(),
      fruits: z.number().min(0).optional(),
      grains: z.number().min(0).optional(),
      legumes: z.number().min(0).optional(),
      nuts: z.number().min(0).optional(),
    })
    .optional(),
  beverages: z
    .object({
      coffee: z.number().min(0).optional(),
      tea: z.number().min(0).optional(),
      alcohol: z.number().min(0).optional(),
      soft_drinks: z.number().min(0).optional(),
    })
    .optional(),
  dining_out: z
    .object({
      restaurant_meals: z.number().min(0).optional(),
      fast_food_meals: z.number().min(0).optional(),
      delivery_meals: z.number().min(0).optional(),
    })
    .optional(),
});

export const consumptionDataSchema = z.object({
  shopping: z
    .object({
      clothing: z.number().min(0).optional(),
      electronics: z.number().min(0).optional(),
      furniture: z.number().min(0).optional(),
      books: z.number().min(0).optional(),
      other_goods: z.number().min(0).optional(),
    })
    .optional(),
  services: z
    .object({
      banking: z.number().min(0).optional(),
      insurance: z.number().min(0).optional(),
      telecommunications: z.number().min(0).optional(),
      entertainment: z.number().min(0).optional(),
    })
    .optional(),
  waste: z
    .object({
      general_waste: z.number().min(0).optional(),
      recycling: z.number().min(0).optional(),
      organic_waste: z.number().min(0).optional(),
      electronic_waste: z.number().min(0).optional(),
    })
    .optional(),
});

export const carbonFootprintInputSchema = z.object({
  user_id: z.string().cuid(),
  period: z
    .object({
      start: z.date(),
      end: z.date(),
    })
    .refine((data) => data.end > data.start, {
      message: "End date must be after start date",
      path: ["end"],
    }),
  categories: z.object({
    transportation: transportationDataSchema.optional(),
    energy: energyDataSchema.optional(),
    food: foodDataSchema.optional(),
    consumption: consumptionDataSchema.optional(),
  }),
});

export const carbonCalculationQuerySchema = z.object({
  userId: z.string().cuid().optional(),
  organizationId: z.string().cuid().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export const emissionFactorQuerySchema = z.object({
  category: z.string().optional(),
  subcategory: z.string().optional(),
  region: z.string().optional(),
  validAt: z.string().datetime().optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export const activityDataQuerySchema = z.object({
  userId: z.string().cuid(),
  category: z.string().optional(),
  subcategory: z.string().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  source: z
    .enum(["manual", "api", "estimated", "imported", "calculated"])
    .optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export type CreateCarbonCalculationInput = z.infer<
  typeof createCarbonCalculationSchema
>;
export type UpdateCarbonCalculationInput = z.infer<
  typeof updateCarbonCalculationSchema
>;
export type CreateEmissionFactorInput = z.infer<
  typeof createEmissionFactorSchema
>;
export type UpdateEmissionFactorInput = z.infer<
  typeof updateEmissionFactorSchema
>;
export type CreateActivityDataInput = z.infer<typeof createActivityDataSchema>;
export type UpdateActivityDataInput = z.infer<typeof updateActivityDataSchema>;
export type TransportationData = z.infer<typeof transportationDataSchema>;
export type EnergyData = z.infer<typeof energyDataSchema>;
export type FoodData = z.infer<typeof foodDataSchema>;
export type ConsumptionData = z.infer<typeof consumptionDataSchema>;
export type CarbonFootprintInput = z.infer<typeof carbonFootprintInputSchema>;
export type CarbonCalculationQuery = z.infer<
  typeof carbonCalculationQuerySchema
>;
export type EmissionFactorQuery = z.infer<typeof emissionFactorQuerySchema>;
export type ActivityDataQuery = z.infer<typeof activityDataQuerySchema>;
