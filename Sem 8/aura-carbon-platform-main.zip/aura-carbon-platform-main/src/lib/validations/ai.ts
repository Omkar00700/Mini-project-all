import { z } from "zod";

export const modelPerformanceMetricsSchema = z.object({
  mae: z.number().min(0),
  rmse: z.number().min(0),
  r2_score: z.number().min(-1).max(1),
  validation_accuracy: z.number().min(0).max(1),
  training_loss: z.number().min(0).optional(),
  validation_loss: z.number().min(0).optional(),
  precision: z.number().min(0).max(1).optional(),
  recall: z.number().min(0).max(1).optional(),
  f1_score: z.number().min(0).max(1).optional(),
});

export const trainingDataInfoSchema = z.object({
  training_samples: z.number().int().min(1),
  validation_samples: z.number().int().min(1),
  test_samples: z.number().int().min(0).optional(),
  features: z.array(z.string().min(1)),
  training_date: z.string(),
  data_version: z.string().optional(),
  preprocessing_steps: z.array(z.string()).optional(),
  feature_importance: z.record(z.string(), z.number()).optional(),
});

export const deploymentInfoSchema = z.object({
  endpoint: z.string().url(),
  deployment_date: z.string(),
  environment: z.enum(["development", "staging", "production"]),
  version: z.string().min(1),
  container_image: z.string().optional(),
  scaling_config: z
    .object({
      min_instances: z.number().int().min(0),
      max_instances: z.number().int().min(1),
      target_cpu_utilization: z.number().min(0).max(100),
    })
    .optional(),
});

export const createMlModelSchema = z.object({
  name: z.string().min(1).max(255),
  version: z.string().min(1).max(50),
  type: z.enum([
    "time_series_forecasting",
    "classification",
    "regression",
    "recommendation",
    "anomaly_detection",
  ]),
  status: z.enum(["training", "active", "inactive", "deprecated", "failed"]),
  performanceMetrics: modelPerformanceMetricsSchema,
  trainingDataInfo: trainingDataInfoSchema,
  deploymentInfo: deploymentInfoSchema.optional(),
});

export const updateMlModelSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  version: z.string().min(1).max(50).optional(),
  type: z
    .enum([
      "time_series_forecasting",
      "classification",
      "regression",
      "recommendation",
      "anomaly_detection",
    ])
    .optional(),
  status: z
    .enum(["training", "active", "inactive", "deprecated", "failed"])
    .optional(),
  performanceMetrics: modelPerformanceMetricsSchema.partial().optional(),
  trainingDataInfo: trainingDataInfoSchema.partial().optional(),
  deploymentInfo: deploymentInfoSchema.partial().optional(),
});

export const predictionInputDataSchema = z
  .object({
    historical_data: z.array(z.number()).optional(),
    user_profile: z.string().optional(),
    seasonal_factor: z.string().optional(),
    weather_data: z.record(z.string(), z.any()).optional(),
    behavioral_patterns: z.record(z.string(), z.any()).optional(),
    demographic_data: z.record(z.string(), z.any()).optional(),
  })
  .catchall(z.any());

export const predictionOutputDataSchema = z
  .object({
    predicted_emissions: z.number().min(0).optional(),
    confidence_interval: z.tuple([z.number(), z.number()]).optional(),
    trend: z.enum(["increasing", "decreasing", "stable"]).optional(),
    seasonal_adjustment: z.number().optional(),
    uncertainty_factors: z.array(z.string()).optional(),
    contributing_factors: z.record(z.string(), z.number()).optional(),
  })
  .catchall(z.any());

export const createPredictionSchema = z.object({
  userId: z.string().cuid(),
  modelId: z.string().cuid(),
  predictionType: z.enum([
    "monthly_emissions",
    "yearly_emissions",
    "category_breakdown",
    "reduction_potential",
    "anomaly_detection",
  ]),
  inputData: predictionInputDataSchema,
  outputData: predictionOutputDataSchema,
  confidenceScore: z.number().min(0).max(1).optional(),
});

export const updatePredictionSchema = z.object({
  predictionType: z
    .enum([
      "monthly_emissions",
      "yearly_emissions",
      "category_breakdown",
      "reduction_potential",
      "anomaly_detection",
    ])
    .optional(),
  inputData: predictionInputDataSchema.optional(),
  outputData: predictionOutputDataSchema.optional(),
  confidenceScore: z.number().min(0).max(1).optional(),
});

export const userFeedbackSchema = z.object({
  rating: z.number().int().min(1).max(5),
  implemented: z.boolean(),
  implementation_date: z.date().optional(),
  effectiveness_rating: z.number().int().min(1).max(5).optional(),
  comments: z.string().max(1000).optional(),
  barriers_encountered: z.array(z.string()).optional(),
  time_to_implement: z.number().int().min(0).optional(),
});

export const createRecommendationSchema = z.object({
  userId: z.string().cuid(),
  title: z.string().min(1).max(255),
  description: z.string().min(1),
  category: z.enum([
    "transportation",
    "energy",
    "food",
    "consumption",
    "waste",
    "lifestyle",
  ]),
  impactEstimate: z.number().min(0),
  costEstimate: z.number().optional(),
  difficultyScore: z.number().int().min(1).max(5).optional(),
  confidenceScore: z.number().min(0).max(1).optional(),
  status: z
    .enum(["active", "implemented", "dismissed", "expired"])
    .default("active"),
  userFeedback: userFeedbackSchema.optional(),
});

export const updateRecommendationSchema = z.object({
  title: z.string().min(1).max(255).optional(),
  description: z.string().min(1).optional(),
  category: z
    .enum([
      "transportation",
      "energy",
      "food",
      "consumption",
      "waste",
      "lifestyle",
    ])
    .optional(),
  impactEstimate: z.number().min(0).optional(),
  costEstimate: z.number().optional(),
  difficultyScore: z.number().int().min(1).max(5).optional(),
  confidenceScore: z.number().min(0).max(1).optional(),
  status: z.enum(["active", "implemented", "dismissed", "expired"]).optional(),
  userFeedback: userFeedbackSchema.optional(),
});

export const recommendationContextSchema = z.object({
  user_preferences: z.record(z.string(), z.any()),
  budget_constraints: z
    .object({
      min_budget: z.number().min(0),
      max_budget: z.number().min(0),
    })
    .optional(),
  time_constraints: z
    .object({
      available_time: z.number().min(0),
      implementation_timeline: z.number().min(0),
    })
    .optional(),
  lifestyle_constraints: z.array(z.string()).optional(),
  geographic_constraints: z
    .object({
      region: z.string(),
      climate_zone: z.string(),
      urban_rural: z.enum(["urban", "suburban", "rural"]),
    })
    .optional(),
  current_emissions_profile: z.record(z.string(), z.number()),
});

export const modelTrainingJobSchema = z.object({
  model_name: z.string().min(1),
  model_version: z.string().min(1),
  training_config: z.object({
    dataset_size: z.number().int().min(1),
    epochs: z.number().int().min(1),
    batch_size: z.number().int().min(1),
    learning_rate: z.number().min(0).max(1),
    validation_split: z.number().min(0).max(1),
  }),
});

export const batchPredictionJobSchema = z.object({
  model_id: z.string().cuid(),
  user_ids: z.array(z.string().cuid()).min(1),
  prediction_type: z.string().min(1),
});

export const batchRecommendationJobSchema = z.object({
  user_ids: z.array(z.string().cuid()).min(1),
  recommendation_engine_version: z.string().min(1),
});

export const mlModelQuerySchema = z.object({
  name: z.string().optional(),
  type: z
    .enum([
      "time_series_forecasting",
      "classification",
      "regression",
      "recommendation",
      "anomaly_detection",
    ])
    .optional(),
  status: z
    .enum(["training", "active", "inactive", "deprecated", "failed"])
    .optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export const predictionQuerySchema = z.object({
  userId: z.string().cuid().optional(),
  modelId: z.string().cuid().optional(),
  predictionType: z
    .enum([
      "monthly_emissions",
      "yearly_emissions",
      "category_breakdown",
      "reduction_potential",
      "anomaly_detection",
    ])
    .optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export const recommendationQuerySchema = z.object({
  userId: z.string().cuid().optional(),
  category: z
    .enum([
      "transportation",
      "energy",
      "food",
      "consumption",
      "waste",
      "lifestyle",
    ])
    .optional(),
  status: z.enum(["active", "implemented", "dismissed", "expired"]).optional(),
  minImpact: z.number().min(0).optional(),
  maxCost: z.number().min(0).optional(),
  maxDifficulty: z.number().int().min(1).max(5).optional(),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
});

export const carbonPredictionRequestSchema = z.object({
  userId: z.string().cuid(),
  forecastHorizon: z.number().int().min(1).max(24),
  includeConfidenceInterval: z.boolean().default(true),
  includeSeasonalAdjustment: z.boolean().default(true),
  categories: z.array(z.string()).optional(),
});

export const recommendationRequestSchema = z.object({
  userId: z.string().cuid(),
  maxRecommendations: z.number().int().min(1).max(20).default(5),
  categories: z
    .array(
      z.enum([
        "transportation",
        "energy",
        "food",
        "consumption",
        "waste",
        "lifestyle",
      ])
    )
    .optional(),
  context: recommendationContextSchema.optional(),
});

export const anomalyDetectionRequestSchema = z.object({
  userId: z.string().cuid(),
  timeRange: z.object({
    start: z.date(),
    end: z.date(),
  }),
  categories: z.array(z.string()).optional(),
  sensitivity: z.enum(["low", "medium", "high"]).default("medium"),
});

export type CreateMlModelInput = z.infer<typeof createMlModelSchema>;
export type UpdateMlModelInput = z.infer<typeof updateMlModelSchema>;
export type CreatePredictionInput = z.infer<typeof createPredictionSchema>;
export type UpdatePredictionInput = z.infer<typeof updatePredictionSchema>;
export type CreateRecommendationInput = z.infer<
  typeof createRecommendationSchema
>;
export type UpdateRecommendationInput = z.infer<
  typeof updateRecommendationSchema
>;
export type RecommendationContext = z.infer<typeof recommendationContextSchema>;
export type ModelTrainingJobInput = z.infer<typeof modelTrainingJobSchema>;
export type BatchPredictionJobInput = z.infer<typeof batchPredictionJobSchema>;
export type BatchRecommendationJobInput = z.infer<
  typeof batchRecommendationJobSchema
>;
export type MlModelQuery = z.infer<typeof mlModelQuerySchema>;
export type PredictionQuery = z.infer<typeof predictionQuerySchema>;
export type RecommendationQuery = z.infer<typeof recommendationQuerySchema>;
export type CarbonPredictionRequest = z.infer<
  typeof carbonPredictionRequestSchema
>;
export type RecommendationRequest = z.infer<typeof recommendationRequestSchema>;
export type AnomalyDetectionRequest = z.infer<
  typeof anomalyDetectionRequestSchema
>;
