import { z } from "zod";

export const userLocationSchema = z.object({
  country: z.string().min(1, "Country is required"),
  region: z.string().min(1, "Region/State is required"),
  city: z.string().min(1, "City is required"),
  coordinates: z.tuple([z.number(), z.number()]).optional(),
});

export const userHouseholdSchema = z.object({
  size: z
    .number()
    .min(1, "Household size must be at least 1")
    .max(20, "Household size cannot exceed 20"),
  type: z.enum(["individual", "family", "shared"], {
    required_error: "Please select a household type",
  }),
  income_bracket: z.string().optional(),
});

export const notificationPreferencesSchema = z.object({
  email: z.boolean().default(true),
  push: z.boolean().default(true),
  sms: z.boolean().default(false),
  marketing: z.boolean().default(false),
  recommendations: z.boolean().default(true),
  achievements: z.boolean().default(true),
  weekly_reports: z.boolean().default(true),
});

export const userPreferencesSchema = z.object({
  units: z.enum(["metric", "imperial"], {
    required_error: "Please select a unit system",
  }),
  privacy_level: z.enum(["public", "friends", "private"], {
    required_error: "Please select a privacy level",
  }),
  notifications: notificationPreferencesSchema,
  language: z.string().optional(),
  timezone: z.string().optional(),
  currency: z.string().optional(),
});

export const userProfileFormSchema = z.object({
  name: z
    .string()
    .min(1, "Name is required")
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name must be less than 100 characters"),
  country: z.string().min(1, "Country is required"),
  region: z.string().min(1, "Region/State is required"),
  city: z.string().min(1, "City is required"),
  householdSize: z
    .number()
    .min(1, "Household size must be at least 1")
    .max(20, "Household size cannot exceed 20"),
  householdType: z.enum(["individual", "family", "shared"], {
    required_error: "Please select a household type",
  }),
  incomeBracket: z.string().optional(),
  units: z.enum(["metric", "imperial"], {
    required_error: "Please select a unit system",
  }),
  privacyLevel: z.enum(["public", "friends", "private"], {
    required_error: "Please select a privacy level",
  }),
  language: z.string().optional(),
  timezone: z.string().optional(),
  currency: z.string().optional(),
  notifications: notificationPreferencesSchema,
});

export const updateUserProfileSchema = z.object({
  name: z
    .string()
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name must be less than 100 characters")
    .optional(),
  location: userLocationSchema.partial().optional(),
  household: userHouseholdSchema.partial().optional(),
  preferences: userPreferencesSchema.partial().optional(),
});

export type UserLocationFormData = z.infer<typeof userLocationSchema>;
export type UserHouseholdFormData = z.infer<typeof userHouseholdSchema>;
export type UserPreferencesFormData = z.infer<typeof userPreferencesSchema>;
export type UserProfileFormData = z.infer<typeof userProfileFormSchema>;
export type UpdateUserProfileData = z.infer<typeof updateUserProfileSchema>;
