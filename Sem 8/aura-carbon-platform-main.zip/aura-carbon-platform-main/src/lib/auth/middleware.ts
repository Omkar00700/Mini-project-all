import { NextRequest, NextResponse } from "next/server";
import { authService } from "@/services/auth/simple-auth.service";

async function getAuthenticatedUser(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value;
  if (!token) return null;
  return authService.verifyTokenAndGetUser(token);
}

export async function withAuth(
  request: NextRequest,
  handler: (
    request: NextRequest,
    user: { id: string; email: string; name: string; role: string }
  ) => Promise<NextResponse>
) {
  try {
    const user = await getAuthenticatedUser(request);

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    return await handler(request, user);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function withOptionalAuth(
  request: NextRequest,
  handler: (
    request: NextRequest,
    user: { id: string; email: string; name: string; role: string } | null
  ) => Promise<NextResponse>
) {
  try {
    const user = await getAuthenticatedUser(request);
    return await handler(request, user);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export function createAuthenticatedRoute(
  handler: (
    request: NextRequest,
    user: { id: string; email: string; name: string; role: string }
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest) => {
    return withAuth(request, handler);
  };
}

export function createOptionalAuthRoute(
  handler: (
    request: NextRequest,
    user: { id: string; email: string; name: string; role: string } | null
  ) => Promise<NextResponse>
) {
  return async (request: NextRequest) => {
    return withOptionalAuth(request, handler);
  };
}
