export interface TokenRefreshResult {
  success: boolean;
  error?: string;
}

export async function refreshAccessToken(): Promise<TokenRefreshResult> {
  return { success: true };
}

export function validateTokenExpiry(token: string): boolean {
  const expiry = getTokenExpiry(token);
  if (!expiry) return false;
  return expiry.getTime() > Date.now();
}

export function getTokenExpiry(token: string): Date | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(atob(parts[1]));
    if (!payload.exp) return null;
    return new Date(payload.exp * 1000);
  } catch {
    return null;
  }
}

export function isTokenExpired(token: string): boolean {
  const expiry = getTokenExpiry(token);
  if (!expiry) return true;
  return expiry.getTime() <= Date.now();
}

export function shouldRefreshToken(
  token: string,
  bufferMinutes: number = 5
): boolean {
  const expiry = getTokenExpiry(token);
  if (!expiry) return true;
  const bufferMs = bufferMinutes * 60 * 1000;
  return expiry.getTime() <= Date.now() + bufferMs;
}
