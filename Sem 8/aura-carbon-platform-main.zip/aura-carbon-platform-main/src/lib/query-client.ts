import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,

      gcTime: 10 * 60 * 1000,

      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),

      refetchOnWindowFocus: true,

      refetchOnReconnect: "always",
    },
    mutations: {
      retry: 1,

      retryDelay: 1000,
    },
  },
});

export const queryKeys = {
  user: {
    all: ["user"] as const,
    profile: () => [...queryKeys.user.all, "profile"] as const,
    preferences: () => [...queryKeys.user.all, "preferences"] as const,
    organizations: () => [...queryKeys.user.all, "organizations"] as const,
  },

  carbon: {
    all: ["carbon"] as const,
    calculations: (userId: string) =>
      [...queryKeys.carbon.all, "calculations", userId] as const,
    breakdown: (userId: string, period: string) =>
      [...queryKeys.carbon.all, "breakdown", userId, period] as const,
    history: (userId: string) =>
      [...queryKeys.carbon.all, "history", userId] as const,
    predictions: (userId: string) =>
      [...queryKeys.carbon.all, "predictions", userId] as const,
  },

  analytics: {
    all: ["analytics"] as const,
    dashboard: (userId: string) =>
      [...queryKeys.analytics.all, "dashboard", userId] as const,
    benchmarks: (userId: string) =>
      [...queryKeys.analytics.all, "benchmarks", userId] as const,
    trends: (userId: string, period: string) =>
      [...queryKeys.analytics.all, "trends", userId, period] as const,
  },

  recommendations: {
    all: ["recommendations"] as const,
    active: (userId: string) =>
      [...queryKeys.recommendations.all, "active", userId] as const,
    history: (userId: string) =>
      [...queryKeys.recommendations.all, "history", userId] as const,
  },

  integrations: {
    all: ["integrations"] as const,
    connected: (userId: string) =>
      [...queryKeys.integrations.all, "connected", userId] as const,
    available: () => [...queryKeys.integrations.all, "available"] as const,
  },
} as const;

export const handleQueryError = (error: unknown) => {
  if (error instanceof Error) {
    return error.message;
  }

  return "An unexpected error occurred";
};

export const createOptimisticUpdate = <T>(
  queryKey: readonly unknown[],
  updater: (oldData: T | undefined) => T
) => {
  return {
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey });

      const previousData = queryClient.getQueryData<T>(queryKey);

      queryClient.setQueryData<T>(queryKey, updater);

      return { previousData };
    },
    onError: (
      err: unknown,
      variables: unknown,
      context: { previousData: T } | undefined
    ) => {
      if (context?.previousData) {
        queryClient.setQueryData<T>(queryKey, context.previousData);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  };
};
