import { Anomaly } from "@/components/analytics/AnomalyTimeline";

interface AnomalyInsight {
  possibleCauses: string[];
  recommendations: string[];
}

export function getAnomalyInsights(anomaly: Anomaly): AnomalyInsight {
  const date = new Date(anomaly.date);
  const month = date.getMonth();
  const day = date.getDay();
  const hour = date.getHours();
  const isWeekend = day === 0 || day === 6;
  const isWinter = month >= 11 || month <= 1;
  const isSummer = month >= 5 && month <= 7;

  const causes: string[] = [];
  const recs: string[] = [];
  const category = anomaly.category.toLowerCase();
  const percentChange =
    ((anomaly.actualValue - anomaly.expectedValue) / anomaly.expectedValue) *
    100;

  if (anomaly.severity === "high") {
    causes.push("Significant deviation from your typical baseline");
    recs.push("Review this activity in detail");
  }

  switch (category) {
    case "transportation":
    case "vehicle":
      if (isWeekend) {
        causes.push("Weekend travel or road trip");
        recs.push("Consider carpooling or public transit for weekend trips");
      }
      if (percentChange > 50) {
        causes.push("Long-distance travel detected");
        recs.push("Offset flight emissions if applicable");
      }
      recs.push("Check tire pressure and vehicle maintenance");
      break;

    case "energy":
    case "electricity":
      if (isWinter) {
        causes.push("Heating usage during cold weather");
        recs.push("Lower thermostat by 1-2 degrees to save ~10%");
        recs.push("Check insulation for drafts");
      } else if (isSummer) {
        causes.push("AC usage during hot weather");
        recs.push("Use fans and close blinds during the day");
      }
      if (isWeekend) {
        causes.push("increased home activity during weekend");
      }
      recs.push("Unplug phantom energy loads");
      break;

    case "food":
      if (isWeekend) {
        causes.push("Weekend dining out or hosting");
      }
      if (percentChange > 40) {
        causes.push("High-impact meat consumption or large grocery haul");
        recs.push("Try a plant-based meal replacement");
      }
      recs.push("Reduce food waste by meal planning");
      break;

    case "waste":
      recs.push("Verify recycling separation");
      recs.push("Compost organic variance");
      break;

    case "water":
      if (isSummer) {
        causes.push("Lawn watering or gardening");
        recs.push("Water plants early morning or late evening");
      }
      recs.push("Check for leaking faucets or toilets");
      break;

    default:
      causes.push("Unusual activity pattern detected");
      recs.push("Monitor this category for recurring spikes");
  }

  return {
    possibleCauses: Array.from(new Set(causes)),
    recommendations: Array.from(new Set(recs)).slice(0, 2),
  };
}
