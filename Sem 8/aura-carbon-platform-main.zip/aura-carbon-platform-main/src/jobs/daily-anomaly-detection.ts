import { PrismaClient } from "../../generated/prisma";
import { runAnomalyDetectionForUser } from "../services/analytics/anomaly-detection.service";

const prisma = new PrismaClient();

export async function runDailyAnomalyDetection() {
  const startTime = Date.now();

  try {
    const users = await prisma.user.findMany({
      select: { id: true, email: true, name: true },
    });

    let totalDetected = 0;
    let totalSaved = 0;
    let successCount = 0;
    let errorCount = 0;

    for (const user of users) {
      try {
        const result = await runAnomalyDetectionForUser(user.id);
        totalDetected += result.detected;
        totalSaved += result.saved;
        successCount++;

        if (result.saved > 0) {
        }
      } catch (error) {
        errorCount++;
      }
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    return {
      success: true,
      totalDetected,
      totalSaved,
      usersProcessed: successCount,
      errors: errorCount,
      durationSeconds: parseFloat(duration),
    };
  } catch (error) {
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

if (require.main === module) {
  runDailyAnomalyDetection()
    .then((result) => {
      process.exit(0);
    })
    .catch((error) => {
      process.exit(1);
    });
}
