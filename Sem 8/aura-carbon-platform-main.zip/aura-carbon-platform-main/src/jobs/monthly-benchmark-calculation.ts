import { PrismaClient } from "../../generated/prisma";
import {
  generateCohortKey,
  calculateCohortEmissions,
  calculatePercentile,
  calculateRank,
  saveBenchmark,
} from "../services/analytics/benchmarking.service";

import type { BenchmarkResult } from "../services/analytics/benchmarking.service";

const prisma = new PrismaClient();

export async function runMonthlyBenchmarks(targetDate?: Date) {
  const startTime = Date.now();

  try {
    const now = targetDate || new Date();
    const periodStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const periodEnd = new Date(now.getFullYear(), now.getMonth(), 1);

    const users = await prisma.user.findMany({
      select: { id: true, email: true, location: true, household: true },
    });

    const cohorts = new Map<string, { userId: string; email: string }[]>();

    for (const user of users) {
      const loc = user.location as {
        country?: string;
        city?: string;
        region?: string;
      } | null;
      const hh = user.household as { size?: number } | null;
      const cohortKey = generateCohortKey(loc || {}, hh || {});

      if (!cohorts.has(cohortKey)) {
        cohorts.set(cohortKey, []);
      }
      cohorts.get(cohortKey)!.push({ userId: user.id, email: user.email });
    }

    let totalBenchmarksCreated = 0;
    let totalErrors = 0;

    const cohortEntries = Array.from(cohorts.entries());
    for (const [cohortKey, members] of cohortEntries) {
      try {
        const userIds = members.map(
          (m: { userId: string; email: string }) => m.userId
        );

        const emissions = await calculateCohortEmissions(
          userIds,
          periodStart,
          periodEnd
        );
        const activeEmissions = emissions.filter((e) => e.totalEmissions > 0);

        if (activeEmissions.length === 0) {
          continue;
        }

        const allValues = activeEmissions.map((e) => e.totalEmissions);
        const cohortAverage =
          allValues.reduce((s, v) => s + v, 0) / allValues.length;

        for (const emission of activeEmissions) {
          try {
            const result: BenchmarkResult = {
              userId: emission.userId,
              period: periodStart,
              cohortKey,
              cohortAverage: Math.round(cohortAverage * 100) / 100,
              userValue: Math.round(emission.totalEmissions * 100) / 100,
              percentile: calculatePercentile(
                emission.totalEmissions,
                allValues
              ),
              rank: calculateRank(emission.totalEmissions, allValues),
              totalInCohort: activeEmissions.length,
            };

            await saveBenchmark(result);
            totalBenchmarksCreated++;
          } catch (error) {
            totalErrors++;
          }
        }
      } catch (error) {
        totalErrors++;
      }
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    return {
      success: true,
      benchmarksCreated: totalBenchmarksCreated,
      cohortsProcessed: cohorts.size,
      errors: totalErrors,
      durationSeconds: parseFloat(duration),
    };
  } catch (error) {
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

if (require.main === module) {
  runMonthlyBenchmarks()
    .then((result) => {
      process.exit(0);
    })
    .catch((error) => {
      process.exit(1);
    });
}
