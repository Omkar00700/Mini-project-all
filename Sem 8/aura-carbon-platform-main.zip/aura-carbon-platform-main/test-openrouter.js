const fs = require('fs');
const apiKey = "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";
const models = [
  "meta-llama/llama-3.3-70b-instruct:free",
  "google/gemini-2.0-flash-lite-preview-02-05:free",
  "google/gemma-3-27b-it:free",
  "mistralai/mistral-small-3.1-24b-instruct:free"
];

async function test() {
  const results = {};
  for (const model of models) {
    try {
      const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [{role: "user", content: "Hi"}]
        })
      });
      const txt = await res.text();
      results[model] = { status: res.status, ok: res.ok, response: txt };
    } catch (e) {
      results[model] = { error: e.message };
    }
  }
  fs.writeFileSync('api-results.json', JSON.stringify(results, null, 2));
}
test();
