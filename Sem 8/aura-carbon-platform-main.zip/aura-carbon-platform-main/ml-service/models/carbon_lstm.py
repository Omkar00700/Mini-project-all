"""
LSTM model for carbon footprint time series forecasting
"""

import torch
import torch.nn as nn
from typing import Dict, Any, List
import numpy as np
from datetime import datetime, timedelta
import json
import os
from pathlib import Path

class CarbonLSTM(nn.Module):
    """LSTM model for carbon footprint prediction"""
    
    def __init__(
        self, 
        input_size: int = 10, 
        hidden_size: int = 64, 
        num_layers: int = 2, 
        output_size: int = 1,
        dropout: float = 0.2
    ):
        super(CarbonLSTM, self).__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        # Fully connected layers
        self.fc1 = nn.Linear(hidden_size, 32)
        self.fc2 = nn.Linear(32, output_size)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        
    def forward(self, x):
        # LSTM forward pass
        lstm_out, _ = self.lstm(x)
        
        # Use the last output
        last_output = lstm_out[:, -1, :]
        
        # Fully connected layers
        out = self.fc1(last_output)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc2(out)
        
        return out


def create_carbon_lstm_model() -> CarbonLSTM:
    """Create and initialize a carbon LSTM model"""
    model = CarbonLSTM(
        input_size=10,  # Features: energy, transport, food, waste, weather, etc.
        hidden_size=64,
        num_layers=2,
        output_size=1,  # Predicted carbon footprint
        dropout=0.2
    )
    return model


def prepare_training_data(data: List[Dict[str, Any]]) -> tuple:
    """
    Prepare training data for the LSTM model
    
    Args:
        data: List of dictionaries with carbon footprint data
        
    Returns:
        tuple: (X, y) training data
    """
    # Extract features and targets
    features = []
    targets = []
    
    for item in data:
        # Extract features (example features)
        feature_vector = [
            item.get('energy_consumption', 0),
            item.get('transport_distance', 0),
            item.get('food_consumption', 0),
            item.get('waste_produced', 0),
            item.get('temperature', 0),
            item.get('humidity', 0),
            item.get('day_of_week', 0),
            item.get('month', 0),
            item.get('is_weekend', 0),
            item.get('holiday_factor', 0)
        ]
        features.append(feature_vector)
        
        # Extract target
        targets.append(item.get('carbon_footprint', 0))
    
    # Convert to numpy arrays
    X = np.array(features, dtype=np.float32)
    y = np.array(targets, dtype=np.float32)
    
    # Reshape for LSTM (batch_size, sequence_length, input_size)
    # For simplicity, we're using sequence_length=1
    X = X.reshape(X.shape[0], 1, X.shape[1])
    
    return X, y


def save_model_with_metadata(model: CarbonLSTM, model_path: str, metadata: Dict[str, Any]):
    """
    Save the model with metadata
    
    Args:
        model: The trained model
        model_path: Path to save the model
        metadata: Model metadata
    """
    path = Path(model_path)
    path.mkdir(parents=True, exist_ok=True)
    
    # Save model state dict
    model_file = path / "model.pth"
    torch.save({
        'model_state_dict': model.state_dict(),
        'model_class': CarbonLSTM,
        'input_size': model.input_size,
        'hidden_size': model.hidden_size,
        'num_layers': model.num_layers,
        'output_size': model.output_size
    }, str(model_file))
    
    # Save metadata
    metadata_file = path / "metadata.json"
    metadata['created_at'] = datetime.utcnow().isoformat()
    with open(metadata_file, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    # Save model config
    config_file = path / "config.json"
    config = {
        "input_signature": {
            "energy_consumption": "float",
            "transport_distance": "float",
            "food_consumption": "float",
            "waste_produced": "float",
            "temperature": "float",
            "humidity": "float",
            "day_of_week": "int",
            "month": "int",
            "is_weekend": "int",
            "holiday_factor": "float"
        },
        "output_signature": {
            "carbon_footprint": "float"
        }
    }
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)


def load_model_with_metadata(model_path: str) -> tuple:
    """
    Load the model with metadata
    
    Args:
        model_path: Path to the saved model
        
    Returns:
        tuple: (model, metadata)
    """
    path = Path(model_path)
    
    # Load model
    model_file = path / "model.pth"
    checkpoint = torch.load(str(model_file))
    
    # Create model instance
    model = CarbonLSTM(
        input_size=checkpoint['input_size'],
        hidden_size=checkpoint['hidden_size'],
        num_layers=checkpoint['num_layers'],
        output_size=checkpoint['output_size']
    )
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # Load metadata
    metadata_file = path / "metadata.json"
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)
    
    return model, metadata


# Example usage for creating and saving a model
if __name__ == "__main__":
    # Create model
    model = create_carbon_lstm_model()
    
    # Example metadata
    metadata = {
        "name": "carbon_prediction_lstm",
        "version": "1.0.0",
        "model_type": "pytorch",
        "description": "LSTM model for carbon footprint prediction",
        "author": "Aura Platform Team",
        "metrics": {
            "rmse": 2.5,
            "mae": 1.8,
            "r2": 0.85
        },
        "tags": ["carbon", "prediction", "lstm", "time-series"]
    }
    
    # Save model
    save_model_with_metadata(model, "./models/carbon_prediction/latest", metadata)
    print("Model saved successfully")