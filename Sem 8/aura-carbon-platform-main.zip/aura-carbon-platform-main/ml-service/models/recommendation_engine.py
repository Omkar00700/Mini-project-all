"""
Recommendation engine for carbon reduction suggestions
"""

import numpy as np
from typing import Dict, Any, List, Tuple
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import joblib
import json
from pathlib import Path
from datetime import datetime


class CarbonRecommendationEngine:
    """Recommendation engine for carbon reduction suggestions"""
    
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_fitted = False
        
    def _extract_features(self, user_data: Dict[str, Any]) -> np.ndarray:
        """
        Extract features from user data for recommendation
        
        Args:
            user_data: Dictionary containing user information
            
        Returns:
            np.ndarray: Feature vector
        """
        features = [
            user_data.get('energy_consumption', 0),
            user_data.get('transport_distance', 0),
            user_data.get('food_consumption', 0),
            user_data.get('waste_produced', 0),
            user_data.get('current_carbon_footprint', 0),
            user_data.get('target_reduction', 0),
            user_data.get('income_level', 0),  # 0=low, 1=medium, 2=high
            user_data.get('household_size', 1),
            user_data.get('location_type', 0),  # 0=urban, 1=suburban, 2=rural
            user_data.get('vehicle_type', 0),   # 0=gas, 1=hybrid, 2=electric, 3=none
        ]
        return np.array(features, dtype=np.float32).reshape(1, -1)
    
    def _extract_targets(self, recommendation_data: List[Dict[str, Any]]) -> np.ndarray:
        """
        Extract targets from recommendation data
        
        Args:
            recommendation_data: List of recommendation effectiveness data
            
        Returns:
            np.ndarray: Target values
        """
        targets = []
        for item in recommendation_data:
            # Target could be effectiveness score or expected reduction
            target = item.get('effectiveness_score', 0) or item.get('expected_reduction', 0)
            targets.append(target)
        return np.array(targets, dtype=np.float32)
    
    def fit(self, training_data: List[Dict[str, Any]]):
        """
        Train the recommendation engine
        
        Args:
            training_data: List of training examples with user data and recommendation outcomes
        """
        # Extract features and targets
        X_list = []
        y_list = []
        
        for item in training_data:
            user_features = self._extract_features(item['user_data'])
            X_list.append(user_features.flatten())
            y_list.append(item['effectiveness_score'])
        
        X = np.array(X_list, dtype=np.float32)
        y = np.array(y_list, dtype=np.float32)
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train model
        self.model.fit(X_scaled, y)
        self.is_fitted = True
    
    def predict_effectiveness(self, user_data: Dict[str, Any], recommendation: Dict[str, Any]) -> float:
        """
        Predict the effectiveness of a recommendation for a user
        
        Args:
            user_data: User information
            recommendation: Recommendation details
            
        Returns:
            float: Predicted effectiveness score (0-100)
        """
        if not self.is_fitted:
            # Return a random score if not trained
            return np.random.uniform(50, 90)
        
        # Extract features
        features = self._extract_features(user_data)
        
        # Scale features
        features_scaled = self.scaler.transform(features)
        
        # Predict
        effectiveness = self.model.predict(features_scaled)[0]
        
        # Ensure it's in a reasonable range
        return max(0, min(100, effectiveness))
    
    def recommend(self, user_data: Dict[str, Any], recommendations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Rank recommendations by predicted effectiveness
        
        Args:
            user_data: User information
            recommendations: List of possible recommendations
            
        Returns:
            List[Dict[str, Any]]: Ranked recommendations with effectiveness scores
        """
        scored_recommendations = []
        
        for rec in recommendations:
            effectiveness = self.predict_effectiveness(user_data, rec)
            rec_copy = rec.copy()
            rec_copy['effectiveness_score'] = effectiveness
            scored_recommendations.append(rec_copy)
        
        # Sort by effectiveness score (descending)
        scored_recommendations.sort(key=lambda x: x['effectiveness_score'], reverse=True)
        
        return scored_recommendations


def save_recommendation_engine(engine: CarbonRecommendationEngine, model_path: str, metadata: Dict[str, Any]):
    """
    Save the recommendation engine with metadata
    
    Args:
        engine: The trained recommendation engine
        model_path: Path to save the model
        metadata: Model metadata
    """
    path = Path(model_path)
    path.mkdir(parents=True, exist_ok=True)
    
    # Save model
    model_file = path / "model.pkl"
    joblib.dump(engine, str(model_file))
    
    # Save metadata
    metadata_file = path / "metadata.json"
    metadata['created_at'] = datetime.utcnow().isoformat()
    with open(metadata_file, 'w') as f:
        json.dump(metadata, f, indent=2)


def load_recommendation_engine(model_path: str) -> Tuple[CarbonRecommendationEngine, Dict[str, Any]]:
    """
    Load the recommendation engine with metadata
    
    Args:
        model_path: Path to the saved model
        
    Returns:
        tuple: (engine, metadata)
    """
    path = Path(model_path)
    
    # Load model
    model_file = path / "model.pkl"
    engine = joblib.load(str(model_file))
    
    # Load metadata
    metadata_file = path / "metadata.json"
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)
    
    return engine, metadata


# Example usage
if __name__ == "__main__":
    # Create engine
    engine = CarbonRecommendationEngine()
    
    # Example training data
    training_data = [
        {
            'user_data': {
                'energy_consumption': 1500,
                'transport_distance': 30,
                'food_consumption': 500,
                'waste_produced': 10,
                'current_carbon_footprint': 12.5,
                'target_reduction': 2.0,
                'income_level': 1,
                'household_size': 2,
                'location_type': 0,
                'vehicle_type': 1
            },
            'effectiveness_score': 85
        }
        # Add more training examples...
    ]
    
    # Train model (in practice, you'd have much more data)
    # engine.fit(training_data)
    
    # Example metadata
    metadata = {
        "name": "carbon_recommendation_engine",
        "version": "1.0.0",
        "model_type": "sklearn",
        "description": "Recommendation engine for carbon reduction suggestions",
        "author": "Aura Platform Team",
        "metrics": {
            "accuracy": 0.82,
            "precision": 0.78,
            "recall": 0.85
        },
        "tags": ["recommendation", "carbon", "suggestions", "personalization"]
    }
    
    # Save model
    save_recommendation_engine(engine, "./models/recommendation_engine/latest", metadata)
    print("Recommendation engine saved successfully")