"""
Unit tests for ML models
"""

import pytest
import torch
import numpy as np
from datetime import datetime
from app.models.base import ModelMetadata
from app.models.pytorch_model import PyTorchModel
from app.models.sklearn_model import SklearnModel


class TestModelMetadata:
    """Test ModelMetadata class"""
    
    def test_model_metadata_creation(self):
        """Test creating ModelMetadata instance"""
        metadata = ModelMetadata(
            name="test_model",
            version="1.0",
            model_type="test",
            description="Test model",
            created_at=datetime.utcnow(),
            input_schema={},
            output_schema={},
            metrics={}
        )
        
        assert metadata.name == "test_model"
        assert metadata.version == "1.0"
        assert metadata.model_type == "test"
        assert metadata.description == "Test model"


class TestPyTorchModel:
    """Test PyTorchModel class"""
    
    def test_pytorch_model_initialization(self):
        """Test PyTorchModel initialization"""
        metadata = ModelMetadata(
            name="test_pytorch_model",
            version="1.0",
            model_type="pytorch",
            description="Test PyTorch model",
            created_at=datetime.utcnow(),
            input_schema={},
            output_schema={},
            metrics={}
        )
        
        model = PyTorchModel(metadata)
        assert model.metadata == metadata
        assert model.model is None
        assert model.is_loaded is False


class TestSklearnModel:
    """Test SklearnModel class"""
    
    def test_sklearn_model_initialization(self):
        """Test SklearnModel initialization"""
        metadata = ModelMetadata(
            name="test_sklearn_model",
            version="1.0",
            model_type="sklearn",
            description="Test Scikit-learn model",
            created_at=datetime.utcnow(),
            input_schema={},
            output_schema={},
            metrics={}
        )
        
        model = SklearnModel(metadata)
        assert model.metadata == metadata
        assert model.model is None
        assert model.is_loaded is False


if __name__ == "__main__":
    pytest.main([__file__])