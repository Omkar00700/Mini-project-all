"""
PyTorch model implementation
"""

import asyncio
import json
import psutil
from typing import Any, Dict, List
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from torch import Tensor

from app.models.base import BaseModel, ModelMetadata


class PyTorchModel(BaseModel):
    """PyTorch model wrapper"""
    
    def __init__(self, metadata: ModelMetadata):
        super().__init__(metadata)
        self.model: nn.Module = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.input_signature = None
        self.output_signature = None
    
    @classmethod
    async def load(cls, model_path: Path, metadata: ModelMetadata) -> 'PyTorchModel':
        """Load PyTorch model from storage"""
        instance = cls(metadata)
        
        try:
            # Load model
            model_file = model_path / "model.pth"
            if model_file.exists():
                # Load model state dict
                checkpoint = torch.load(str(model_file), map_location=instance.device)
                if 'model_state_dict' in checkpoint:
                    # If checkpoint contains state dict
                    model_class = checkpoint.get('model_class', nn.Module)
                    instance.model = model_class()
                    instance.model.load_state_dict(checkpoint['model_state_dict'])
                else:
                    # If checkpoint is just the model
                    instance.model = checkpoint
            else:
                raise FileNotFoundError(f"No model file found in {model_path}")
            
            # Load preprocessing/postprocessing configs if available
            config_file = model_path / "config.json"
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    instance.input_signature = config.get("input_signature")
                    instance.output_signature = config.get("output_signature")
            
            # Move model to device
            instance.model.to(instance.device)
            instance.model.eval()
            
            instance.is_loaded = True
            instance.logger.info("PyTorch model loaded successfully", device=str(instance.device))
            
            return instance
            
        except Exception as e:
            instance.logger.error("Failed to load PyTorch model", error=str(e))
            raise
    
    async def predict(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Make single prediction"""
        if not self.is_loaded or self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            # Validate input
            if not await self.validate_input(input_data):
                raise ValueError("Invalid input data")
            
            # Preprocess
            processed_input = await self.preprocess(input_data)
            
            # Convert to tensor
            if isinstance(processed_input, dict):
                # Handle dictionary input
                tensor_input = {}
                for key, value in processed_input.items():
                    if isinstance(value, (list, np.ndarray)):
                        tensor_input[key] = torch.tensor(value, dtype=torch.float32).to(self.device)
                    else:
                        tensor_input[key] = torch.tensor([value], dtype=torch.float32).to(self.device)
            elif isinstance(processed_input, (list, np.ndarray)):
                # Handle array input
                tensor_input = torch.tensor(processed_input, dtype=torch.float32).to(self.device)
            else:
                # Handle single value
                tensor_input = torch.tensor([processed_input], dtype=torch.float32).to(self.device)
            
            # Make prediction
            with torch.no_grad():
                if isinstance(tensor_input, dict):
                    output = self.model(**tensor_input)
                else:
                    output = self.model(tensor_input)
            
            # Convert output to dict
            if isinstance(output, dict):
                result = output
            elif isinstance(output, (Tensor, list, np.ndarray)):
                result = {"prediction": output}
            else:
                result = {"prediction": output}
            
            # Postprocess
            final_result = await self.postprocess(result)
            return final_result
            
        except Exception as e:
            self.logger.error("Prediction failed", error=str(e))
            raise
    
    async def predict_batch(self, input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make batch predictions"""
        if not self.is_loaded or self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            results = []
            for item in input_data:
                result = await self.predict(item)
                results.append(result)
            return results
            
        except Exception as e:
            self.logger.error("Batch prediction failed", error=str(e))
            raise
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input data against schema"""
        # Basic validation - in a real implementation, this would check against the schema
        return isinstance(input_data, dict)
    
    async def get_memory_usage(self) -> int:
        """Get model memory usage in bytes"""
        if not self.is_loaded:
            return 0
        
        # Estimate memory usage
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated(self.device)
        else:
            # Rough estimate for CPU memory
            param_size = 0
            for param in self.model.parameters():
                param_size += param.nelement() * param.element_size()
            buffer_size = 0
            for buffer in self.model.buffers():
                buffer_size += buffer.nelement() * buffer.element_size()
            return param_size + buffer_size
    
    async def is_healthy(self) -> bool:
        """Check if model is healthy and ready for inference"""
        return self.is_loaded and self.model is not None
    
    async def cleanup(self):
        """Cleanup model resources"""
        if self.model is not None:
            del self.model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        self.is_loaded = False