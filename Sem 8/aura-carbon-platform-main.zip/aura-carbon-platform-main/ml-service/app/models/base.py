"""
Base model classes and interfaces
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
import structlog

logger = structlog.get_logger()


@dataclass
class ModelMetadata:
    """Model metadata structure"""
    name: str
    version: str
    model_type: str  # tensorflow, pytorch, sklearn
    description: str
    created_at: datetime
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    metrics: Dict[str, float]
    tags: List[str] = None
    author: str = "system"
    framework_version: str = None


class BaseModel(ABC):
    """Base class for all ML models"""
    
    def __init__(self, metadata: ModelMetadata):
        self.metadata = metadata
        self.model = None
        self.is_loaded = False
        self.logger = structlog.get_logger().bind(
            model_name=metadata.name,
            model_version=metadata.version
        )
    
    @classmethod
    @abstractmethod
    async def load(cls, model_path: Path, metadata: ModelMetadata) -> 'BaseModel':
        """Load model from storage"""
        pass
    
    @abstractmethod
    async def predict(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Make predictions"""
        pass
    
    @abstractmethod
    async def predict_batch(self, input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make batch predictions"""
        pass
    
    @abstractmethod
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input data against schema"""
        pass
    
    @abstractmethod
    async def get_memory_usage(self) -> int:
        """Get model memory usage in bytes"""
        pass
    
    @abstractmethod
    async def is_healthy(self) -> bool:
        """Check if model is healthy and ready for inference"""
        pass
    
    @abstractmethod
    async def cleanup(self):
        """Cleanup model resources"""
        pass
    
    async def preprocess(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Preprocess input data (override if needed)"""
        return input_data
    
    async def postprocess(self, output_data: Dict[str, Any]) -> Dict[str, Any]:
        """Postprocess output data (override if needed)"""
        return output_data
    
    def get_info(self) -> Dict[str, Any]:
        """Get model information"""
        return {
            "name": self.metadata.name,
            "version": self.metadata.version,
            "type": self.metadata.model_type,
            "description": self.metadata.description,
            "created_at": self.metadata.created_at.isoformat(),
            "metrics": self.metadata.metrics,
            "is_loaded": self.is_loaded,
            "input_schema": self.metadata.input_schema,
            "output_schema": self.metadata.output_schema
        }