"""
Scikit-learn model implementation
"""

import asyncio
import json
import psutil
from typing import Any, Dict, List
from pathlib import Path
import numpy as np
import joblib
from sklearn.base import BaseEstimator

from app.models.base import BaseModel, ModelMetadata


class SklearnModel(BaseModel):
    """Scikit-learn model wrapper"""
    
    def __init__(self, metadata: ModelMetadata):
        super().__init__(metadata)
        self.model: BaseEstimator = None
        self.input_signature = None
        self.output_signature = None
    
    @classmethod
    async def load(cls, model_path: Path, metadata: ModelMetadata) -> 'SklearnModel':
        """Load Scikit-learn model from storage"""
        instance = cls(metadata)
        
        try:
            # Load model
            model_file = model_path / "model.pkl"
            if model_file.exists():
                instance.model = joblib.load(str(model_file))
            else:
                raise FileNotFoundError(f"No model file found in {model_path}")
            
            # Load preprocessing/postprocessing configs if available
            config_file = model_path / "config.json"
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    instance.input_signature = config.get("input_signature")
                    instance.output_signature = config.get("output_signature")
            
            instance.is_loaded = True
            instance.logger.info("Scikit-learn model loaded successfully")
            
            return instance
            
        except Exception as e:
            instance.logger.error("Failed to load Scikit-learn model", error=str(e))
            raise
    
    async def predict(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Make single prediction"""
        if not self.is_loaded or self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            # Validate input
            if not await self.validate_input(input_data):
                raise ValueError("Invalid input data")
            
            # Preprocess
            processed_input = await self.preprocess(input_data)
            
            # Convert to array
            if isinstance(processed_input, dict):
                # Handle dictionary input - convert to array based on keys
                # This is a simplified approach - in practice, you'd want to maintain key order
                input_array = np.array(list(processed_input.values()))
            elif isinstance(processed_input, list):
                input_array = np.array(processed_input)
            else:
                input_array = np.array([processed_input])
            
            # Ensure 2D array for sklearn
            if input_array.ndim == 1:
                input_array = input_array.reshape(1, -1)
            
            # Make prediction
            prediction = self.model.predict(input_array)
            
            # Convert output to dict
            result = {"prediction": prediction.tolist()}
            
            # Postprocess
            final_result = await self.postprocess(result)
            return final_result
            
        except Exception as e:
            self.logger.error("Prediction failed", error=str(e))
            raise
    
    async def predict_batch(self, input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Make batch predictions"""
        if not self.is_loaded or self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            # Convert batch to array
            processed_batch = []
            for item in input_data:
                processed_item = await self.preprocess(item)
                if isinstance(processed_item, dict):
                    processed_batch.append(list(processed_item.values()))
                else:
                    processed_batch.append(processed_item)
            
            input_array = np.array(processed_batch)
            
            # Make batch prediction
            predictions = self.model.predict(input_array)
            
            # Convert to list of dicts
            results = []
            for pred in predictions:
                result = {"prediction": pred.tolist() if hasattr(pred, 'tolist') else pred}
                final_result = await self.postprocess(result)
                results.append(final_result)
            
            return results
            
        except Exception as e:
            self.logger.error("Batch prediction failed", error=str(e))
            raise
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input data against schema"""
        # Basic validation - in a real implementation, this would check against the schema
        return isinstance(input_data, dict)
    
    async def get_memory_usage(self) -> int:
        """Get model memory usage in bytes"""
        if not self.is_loaded:
            return 0
        
        # Estimate memory usage using psutil
        process = psutil.Process()
        return process.memory_info().rss
    
    async def is_healthy(self) -> bool:
        """Check if model is healthy and ready for inference"""
        return self.is_loaded and self.model is not None
    
    async def cleanup(self):
        """Cleanup model resources"""
        if self.model is not None:
            del self.model
        self.is_loaded = False