"""
TensorFlow model implementation
"""

import asyncio
import json
import psutil
from typing import Any, Dict, List
from pathlib import Path
import numpy as np
import tensorflow as tf
from tensorflow import keras

from app.models.base import BaseModel, ModelMetadata


class TensorFlowModel(BaseModel):
    """TensorFlow model wrapper"""
    
    def __init__(self, metadata: ModelMetadata):
        super().__init__(metadata)
        self.model: tf.keras.Model = None
        self.input_signature = None
        self.output_signature = None
    
    @classmethod
    async def load(cls, model_path: Path, metadata: ModelMetadata) -> 'TensorFlowModel':
        """Load TensorFlow model from storage"""
        instance = cls(metadata)
        
        try:
            # Load model
            model_file = model_path / "model.h5"
            if model_file.exists():
                instance.model = keras.models.load_model(str(model_file))
            else:
                # Try SavedModel format
                saved_model_path = model_path / "saved_model"
                if saved_model_path.exists():
                    instance.model = tf.saved_model.load(str(saved_model_path))
                else:
                    raise FileNotFoundError(f"No model file found in {model_path}")
            
            # Load preprocessing/postprocessing configs if available
            config_file = model_path / "config.json"
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    instance.input_signature = config.get("input_signature")
                    instance.output_signature = config.get("output_signature")
            
            instance.is_loaded = True
            instance.logger.info("TensorFlow model loaded successfully")
            
            return instance
            
        except Exception as e:
            instance.logger.error("Failed to load TensorFlow model", error=str(e))
            raise
    
    async def predict(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Make single prediction"""
        if not self.is_loaded or self.model is None:
            raise RuntimeError("Model not loaded")
        
        try:
            # Validate input
            if not await self.validate_input(input_data):
                raise ValueError("Invalid input data")
            
            # Preprocess
            processed_input = await self.preprocess(input_data)
            
            # Convert to tenso