"""
Prometheus metrics configuration
"""

from prometheus_client import Counter, Histogram, Gauge, Info
import time
from functools import wraps
from typing import Callable, Any
import structlog

logger = structlog.get_logger()

# Metrics
REQUEST_COUNT = Counter(
    'ml_service_requests_total',
    'Total number of requests',
    ['method', 'endpoint', 'status_code']
)

REQUEST_DURATION = Histogram(
    'ml_service_request_duration_seconds',
    'Request duration in seconds',
    ['method', 'endpoint']
)

PREDICTION_COUNT = Counter(
    'ml_service_predictions_total',
    'Total number of predictions made',
    ['model_name', 'model_version', 'status']
)

PREDICTION_DURATION = Histogram(
    'ml_service_prediction_duration_seconds',
    'Prediction duration in seconds',
    ['model_name', 'model_version']
)

MODEL_LOAD_COUNT = Counter(
    'ml_service_model_loads_total',
    'Total number of model loads',
    ['model_name', 'model_version', 'status']
)

ACTIVE_MODELS = Gauge(
    'ml_service_active_models',
    'Number of currently loaded models'
)

MEMORY_USAGE = Gauge(
    'ml_service_memory_usage_bytes',
    'Memory usage in bytes'
)

AB_TEST_ASSIGNMENTS = Counter(
    'ml_service_ab_test_assignments_total',
    'Total A/B test assignments',
    ['experiment_name', 'variant']
)

SERVICE_INFO = Info(
    'ml_service_info',
    'ML Service information'
)


def setup_metrics():
    """Initialize metrics"""
    SERVICE_INFO.info({
        'version': '1.0.0',
        'service': 'aura-ml-service'
    })
    logger.info("Metrics initialized")


def track_predictions(func: Callable) -> Callable:
    """Decorator to track prediction metrics"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        model_name = kwargs.get('model_name', 'unknown')
        model_version = kwargs.get('model_version', 'unknown')
        
        start_time = time.time()
        status = 'success'
        
        try:
            result = await func(*args, **kwargs)
            return result
        except Exception as e:
            status = 'error'
            logger.error("Prediction failed", error=str(e), model_name=model_name)
            raise
        finally:
            duration = time.time() - start_time
            PREDICTION_COUNT.labels(
                model_name=model_name,
                model_version=model_version,
                status=status
            ).inc()
            PREDICTION_DURATION.labels(
                model_name=model_name,
                model_version=model_version
            ).observe(duration)
    
    return wrapper


def track_model_loading(func: Callable) -> Callable:
    """Decorator to track model loading metrics"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        model_name = kwargs.get('model_name', 'unknown')
        model_version = kwargs.get('model_version', 'unknown')
        status = 'success'
        
        try:
            result = await func(*args, **kwargs)
            return result
        except Exception as e:
            status = 'error'
            logger.error("Model loading failed", error=str(e), model_name=model_name)
            raise
        finally:
            MODEL_LOAD_COUNT.labels(
                model_name=model_name,
                model_version=model_version,
                status=status
            ).inc()
    
    return wrapper


class MetricsMiddleware:
    """Middleware to track request metrics"""
    
    def __init__(self):
        self.logger = structlog.get_logger()
    
    async def track_request(self, request, response, process_time: float):
        """Track request metrics"""
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.url.path,
            status_code=response.status_code
        ).inc()
        
        REQUEST_DURATION.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(process_time)