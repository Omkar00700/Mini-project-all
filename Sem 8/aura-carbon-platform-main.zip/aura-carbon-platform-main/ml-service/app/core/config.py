"""
Configuration settings for the ML service
"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import os


class Settings(BaseSettings):
    """Application settings"""
    
    # Basic service configuration
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 4
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS and trusted hosts
    ALLOWED_HOSTS: List[str] = ["*"]
    
    # Model storage configuration
    MODEL_STORAGE_TYPE: str = "local"  # local, s3, gcs
    MODEL_STORAGE_PATH: str = "./models"
    AWS_S3_BUCKET: Optional[str] = None
    AWS_REGION: str = "us-east-1"
    
    # Redis configuration
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PASSWORD: Optional[str] = None
    
    # MLflow configuration
    MLFLOW_TRACKING_URI: str = "http://localhost:5000"
    MLFLOW_EXPERIMENT_NAME: str = "aura-carbon-predictions"
    
    # Database
    DATABASE_URL: Optional[str] = None
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    # Monitoring
    PROMETHEUS_PORT: int = 8001
    ENABLE_METRICS: bool = True
    
    # A/B Testing
    AB_TEST_ENABLED: bool = True
    AB_TEST_REDIS_KEY_PREFIX: str = "ab_test:"
    
    # Model configuration
    DEFAULT_MODEL_VERSION: str = "latest"
    MODEL_CACHE_TTL: int = 3600
    PREDICTION_TIMEOUT: int = 30
    
    # TensorFlow/PyTorch settings
    TF_CPP_MIN_LOG_LEVEL: str = "2"
    CUDA_VISIBLE_DEVICES: str = ""
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()

# Set TensorFlow logging level
os.environ["TF_CPP_MIN_LOG_LEVEL"] = settings.TF_CPP_MIN_LOG_LEVEL
if settings.CUDA_VISIBLE_DEVICES:
    os.environ["CUDA_VISIBLE_DEVICES"] = settings.CUDA_VISIBLE_DEVICES