"""
Aura ML Service - FastAPI application for ML model serving
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager
import structlog
from prometheus_client import make_asgi_app
import uvicorn

from app.core.config import settings
from app.core.logging import setup_logging
from app.api.v1.router import api_router
from app.services.model_manager import ModelManager
from app.services.ab_testing import ABTestingService
from app.core.metrics import setup_metrics

# Setup structured logging
setup_logging()
logger = structlog.get_logger()

# Global services
model_manager: ModelManager = None
ab_testing_service: ABTestingService = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global model_manager, ab_testing_service
    
    logger.info("Starting ML Service", version=settings.VERSION)
    
    try:
        # Initialize services
        model_manager = ModelManager()
        await model_manager.initialize()
        
        ab_testing_service = ABTestingService()
        await ab_testing_service.initialize()
        
        # Setup metrics
        setup_metrics()
        
        logger.info("ML Service started successfully")
        yield
        
    except Exception as e:
        logger.error("Failed to start ML Service", error=str(e))
        raise
    finally:
        # Cleanup
        if model_manager:
            await model_manager.cleanup()
        if ab_testing_service:
            await ab_testing_service.cleanup()
        logger.info("ML Service shutdown complete")


# Create FastAPI application
app = FastAPI(
    title="Aura ML Service",
    description="AI/ML service for carbon footprint prediction and recommendations",
    version=settings.VERSION,
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT != "production" else None,
    lifespan=lifespan
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings.ALLOWED_HOSTS
)

# Include API routes
app.include_router(api_router, prefix="/api/v1")

# Add Prometheus metrics endpoint
if settings.ENABLE_METRICS:
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Check model manager status
        if model_manager and not await model_manager.is_healthy():
            raise HTTPException(status_code=503, detail="Model manager unhealthy")
        
        # Check A/B testing service status
        if ab_testing_service and not await ab_testing_service.is_healthy():
            raise HTTPException(status_code=503, detail="A/B testing service unhealthy")
        
        return {
            "status": "healthy",
            "version": settings.VERSION,
            "models_loaded": len(model_manager.loaded_models) if model_manager else 0
        }
    except Exception as e:
        logger.error("Health check failed", error=str(e))
        raise HTTPException(status_code=503, detail="Service unhealthy")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Aura ML Service",
        "version": settings.VERSION,
        "docs": "/docs" if settings.ENVIRONMENT != "production" else "disabled"
    }


# Dependency injection
async def get_model_manager() -> ModelManager:
    """Get model manager instance"""
    if not model_manager:
        raise HTTPException(status_code=503, detail="Model manager not initialized")
    return model_manager


async def get_ab_testing_service() -> ABTestingService:
    """Get A/B testing service instance"""
    if not ab_testing_service:
        raise HTTPException(status_code=503, detail="A/B testing service not initialized")
    return ab_testing_service


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        workers=settings.WORKERS,
        log_config=None,  # Use our custom logging
        access_log=False
    )