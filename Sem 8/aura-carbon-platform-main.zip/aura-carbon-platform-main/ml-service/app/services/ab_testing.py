"""
A/B Testing Service for ML model experimentation
"""

import asyncio
import json
import hashlib
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import structlog
import redis.asyncio as redis

from app.core.config import settings
from app.core.metrics import AB_TEST_ASSIGNMENTS

logger = structlog.get_logger()


class ExperimentStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"


@dataclass
class ExperimentVariant:
    name: str
    model_name: str
    model_version: str
    traffic_percentage: float
    metadata: Dict[str, Any] = None


@dataclass
class Experiment:
    id: str
    name: str
    description: str
    status: ExperimentStatus
    variants: List[ExperimentVariant]
    start_date: datetime
    end_date: Optional[datetime]
    success_metrics: List[str]
    created_by: str
    created_at: datetime
    updated_at: datetime


@dataclass
class Assignment:
    user_id: str
    experiment_id: str
    variant_name: str
    assigned_at: datetime
    metadata: Dict[str, Any] = None


class ABTestingService:
    """A/B Testing service for ML model experiments"""
    
    def __init__(self):
        self.redis_client: Optional[redis.Redis] = None
        self.experiments: Dict[str, Experiment] = {}
        self.assignments: Dict[str, Dict[str, Assignment]] = {}  # user_id -> experiment_id -> assignment
        self.key_prefix = settings.AB_TEST_REDIS_KEY_PREFIX
        self._lock = asyncio.Lock()
    
    async def initialize(self):
        """Initialize the A/B testing service"""
        if not settings.AB_TEST_ENABLED:
            logger.info("A/B testing disabled")
            return
        
        logger.info("Initializing A/B Testing Service")
        
        # Initialize Redis connection
        try:
            self.redis_client = redis.from_url(
                settings.REDIS_URL,
                password=settings.REDIS_PASSWORD,
                decode_responses=True
            )
            await self.redis_client.ping()
            logger.info("A/B Testing Redis connection established")
        except Exception as e:
            logger.error("A/B Testing Redis connection failed", error=str(e))
            raise
        
        # Load existing experiments
        await self._load_experiments()
        
        # Start background tasks
        asyncio.create_task(self._cleanup_expired_assignments())
        
        logger.info("A/B Testing Service initialized", experiments=len(self.experiments))
    
    async def cleanup(self):
        """Cleanup resources"""
        if self.redis_client:
            await self.redis_client.close()
        logger.info("A/B Testing Service cleanup complete")
    
    async def create_experiment(
        self,
        name: str,
        description: str,
        variants: List[ExperimentVariant],
        start_date: datetime,
        end_date: Optional[datetime] = None,
        success_metrics: List[str] = None,
        created_by: str = "system"
    ) -> Experiment:
        """Create a new A/B test experiment"""
        async with self._lock:
            # Validate variants
            total_traffic = sum(v.traffic_percentage for v in variants)
            if abs(total_traffic - 100.0) > 0.01:
                raise ValueError(f"Variant traffic percentages must sum to 100%, got {total_traffic}%")
            
            # Generate experiment ID
            experiment_id = hashlib.md5(f"{name}_{datetime.utcnow().isoformat()}".encode()).hexdigest()[:16]
            
            experiment = Experiment(
                id=experiment_id,
                name=name,
                description=description,
                status=ExperimentStatus.DRAFT,
                variants=variants,
                start_date=start_date,
                end_date=end_date,
                success_metrics=success_metrics or [],
                created_by=created_by,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Store experiment
            self.experiments[experiment_id] = experiment
            await self._save_experiment(experiment)
            
            logger.info("Experiment created", experiment_id=experiment_id, name=name)
            return experiment
    
    async def start_experiment(self, experiment_id: str) -> bool:
        """Start an experiment"""
        async with self._lock:
            if experiment_id not in self.experiments:
                logger.error("Experiment not found", experiment_id=experiment_id)
                return False
            
            experiment = self.experiments[experiment_id]
            
            if experiment.status != ExperimentStatus.DRAFT:
                logger.error("Can only start draft experiments", experiment_id=experiment_id, status=experiment.status)
                return False
            
            # Check if start date is in the future
            if experiment.start_date > datetime.utcnow():
                logger.error("Cannot start experiment before start date", experiment_id=experiment_id)
                return False
            
            experiment.status = ExperimentStatus.ACTIVE
            experiment.updated_at = datetime.utcnow()
            
            await self._save_experiment(experiment)
            
            logger.info("Experiment started", experiment_id=experiment_id)
            return True
    
    async def stop_experiment(self, experiment_id: str) -> bool:
        """Stop an active experiment"""
        async with self._lock:
            if experiment_id not in self.experiments:
                return False
            
            experiment = self.experiments[experiment_id]
            experiment.status = ExperimentStatus.COMPLETED
            experiment.updated_at = datetime.utcnow()
            
            await self._save_experiment(experiment)
            
            logger.info("Experiment stopped", experiment_id=experiment_id)
            return True
    
    async def get_assignment(
        self,
        user_id: str,
        experiment_name: str,
        context: Dict[str, Any] = None
    ) -> Optional[Assignment]:
        """Get user assignment for an experiment"""
        # Find active experiment by name
        experiment = None
        for exp in self.experiments.values():
            if exp.name == experiment_name and exp.status == ExperimentStatus.ACTIVE:
                experiment = exp
                break
        
        if not experiment:
            return None
        
        # Check if experiment is within date range
        now = datetime.utcnow()
        if now < experiment.start_date or (experiment.end_date and now > experiment.end_date):
            return None
        
        # Check existing assignment
        if user_id in self.assignments and experiment.id in self.assignments[user_id]:
            assignment = self.assignments[user_id][experiment.id]
            logger.debug("Returning existing assignment", user_id=user_id, experiment_id=experiment.id, variant=assignment.variant_name)
            return assignment
        
        # Create new assignment
        variant = self._assign_variant(user_id, experiment)
        assignment = Assignment(
            user_id=user_id,
            experiment_id=experiment.id,
            variant_name=variant.name,
            assigned_at=now,
            metadata=context
        )
        
        # Store assignment
        if user_id not in self.assignments:
            self.assignments[user_id] = {}
        self.assignments[user_id][experiment.id] = assignment
        
        await self._save_assignment(assignment)
        
        # Track metrics
        AB_TEST_ASSIGNMENTS.labels(
            experiment_name=experiment.name,
            variant=variant.name
        ).inc()
        
        logger.info("New assignment created", user_id=user_id, experiment_id=experiment.id, variant=variant.name)
        return assignment
    
    async def get_model_for_user(
        self,
        user_id: str,
        experiment_name: str,
        default_model: str = "default",
        default_version: str = "latest"
    ) -> tuple[str, str]:
        """Get the model name and version for a user based on A/B test assignment"""
        assignment = await self.get_assignment(user_id, experiment_name)
        
        if not assignment:
            return default_model, default_version
        
        # Find the variant
        experiment = self.experiments[assignment.experiment_id]
        for variant in experiment.variants:
            if variant.name == assignment.variant_name:
                return variant.model_name, variant.model_version
        
        return default_model, default_version
    
    async def record_metric(
        self,
        user_id: str,
        experiment_id: str,
        metric_name: str,
        value: float,
        metadata: Dict[str, Any] = None
    ):
        """Record a metric for an experiment"""
        if not self.redis_client:
            return
        
        metric_key = f"{self.key_prefix}metrics:{experiment_id}:{metric_name}"
        
        metric_data = {
            "user_id": user_id,
            "value": value,
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": metadata or {}
        }
        
        await self.redis_client.lpush(metric_key, json.dumps(metric_data))
        await self.redis_client.expire(metric_key, 86400 * 30)  # Keep for 30 days
        
        logger.debug("Metric recorded", user_id=user_id, experiment_id=experiment_id, metric=metric_name, value=value)
    
    async def get_experiment_results(self, experiment_id: str) -> Dict[str, Any]:
        """Get experiment results and statistics"""
        if experiment_id not in self.experiments:
            return {}
        
        experiment = self.experiments[experiment_id]
        results = {
            "experiment": asdict(experiment),
            "assignments": {},
            "metrics": {}
        }
        
        # Count assignments per variant
        for user_assignments in self.assignments.values():
            if experiment_id in user_assignments:
                assignment = user_assignments[experiment_id]
                variant_name = assignment.variant_name
                if variant_name not in results["assignments"]:
                    results["assignments"][variant_name] = 0
                results["assignments"][variant_name] += 1
        
        # Get metrics
        if self.redis_client:
            for metric_name in experiment.success_metrics:
                metric_key = f"{self.key_prefix}metrics:{experiment_id}:{metric_name}"
                metric_data = await self.redis_client.lrange(metric_key, 0, -1)
                
                variant_metrics = {}
                for data_str in metric_data:
                    data = json.loads(data_str)
                    user_id = data["user_id"]
                    
                    # Find user's variant
                    if user_id in self.assignments and experiment_id in self.assignments[user_id]:
                        variant_name = self.assignments[user_id][experiment_id].variant_name
                        if variant_name not in variant_metrics:
                            variant_metrics[variant_name] = []
                        variant_metrics[variant_name].append(data["value"])
                
                results["metrics"][metric_name] = variant_metrics
        
        return results
    
    async def list_experiments(self) -> List[Dict[str, Any]]:
        """List all experiments"""
        return [asdict(exp) for exp in self.experiments.values()]
    
    async def is_healthy(self) -> bool:
        """Check if A/B testing service is healthy"""
        if not settings.AB_TEST_ENABLED:
            return True
        
        try:
            if self.redis_client:
                await self.redis_client.ping()
            return True
        except Exception as e:
            logger.error("A/B testing health check failed", error=str(e))
            return False
    
    def _assign_variant(self, user_id: str, experiment: Experiment) -> ExperimentVariant:
        """Assign a variant to a user using consistent hashing"""
        # Create a hash based on user_id and experiment_id for consistency
        hash_input = f"{user_id}:{experiment.id}"
        hash_value = int(hashlib.md5(hash_input.encode()).hexdigest(), 16)
        
        # Convert to percentage (0-100)
        percentage = (hash_value % 10000) / 100.0
        
        # Find the variant based on traffic allocation
        cumulative_percentage = 0.0
        for variant in experiment.variants:
            cumulative_percentage += variant.traffic_percentage
            if percentage < cumulative_percentage:
                return variant
        
        # Fallback to last variant
        return experiment.variants[-1]
    
    async def _load_experiments(self):
        """Load experiments from Redis"""
        if not self.redis_client:
            return
        
        try:
            experiment_keys = await self.redis_client.keys(f"{self.key_prefix}experiment:*")
            
            for key in experiment_keys:
                experiment_data = await self.redis_client.get(key)
                if experiment_data:
                    experiment_dict = json.loads(experiment_data)
                    # Convert datetime strings back to datetime objects
                    experiment_dict["start_date"] = datetime.fromisoformat(experiment_dict["start_date"])
                    if experiment_dict["end_date"]:
                        experiment_dict["end_date"] = datetime.fromisoformat(experiment_dict["end_date"])
                    experiment_dict["created_at"] = datetime.fromisoformat(experiment_dict["created_at"])
                    experiment_dict["updated_at"] = datetime.fromisoformat(experiment_dict["updated_at"])
                    experiment_dict["status"] = ExperimentStatus(experiment_dict["status"])
                    
                    # Convert variants
                    variants = []
                    for variant_dict in experiment_dict["variants"]:
                        variants.append(ExperimentVariant(**variant_dict))
                    experiment_dict["variants"] = variants
                    
                    experiment = Experiment(**experiment_dict)
                    self.experiments[experiment.id] = experiment
            
            logger.info("Experiments loaded", count=len(self.experiments))
            
        except Exception as e:
            logger.error("Failed to load experiments", error=str(e))
    
    async def _save_experiment(self, experiment: Experiment):
        """Save experiment to Redis"""
        if not self.redis_client:
            return
        
        try:
            experiment_dict = asdict(experiment)
            # Convert datetime objects to strings
            experiment_dict["start_date"] = experiment.start_date.isoformat()
            if experiment.end_date:
                experiment_dict["end_date"] = experiment.end_date.isoformat()
            experiment_dict["created_at"] = experiment.created_at.isoformat()
            experiment_dict["updated_at"] = experiment.updated_at.isoformat()
            experiment_dict["status"] = experiment.status.value
            
            key = f"{self.key_prefix}experiment:{experiment.id}"
            await self.redis_client.set(key, json.dumps(experiment_dict))
            
        except Exception as e:
            logger.error("Failed to save experiment", experiment_id=experiment.id, error=str(e))
    
    async def _save_assignment(self, assignment: Assignment):
        """Save assignment to Redis"""
        if not self.redis_client:
            return
        
        try:
            assignment_dict = asdict(assignment)
            assignment_dict["assigned_at"] = assignment.assigned_at.isoformat()
            
            key = f"{self.key_prefix}assignment:{assignment.user_id}:{assignment.experiment_id}"
            await self.redis_client.setex(key, 86400 * 30, json.dumps(assignment_dict))  # Keep for 30 days
            
        except Exception as e:
            logger.error("Failed to save assignment", error=str(e))
    
    async def _cleanup_expired_assignments(self):
        """Background task to cleanup expired assignments"""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour
                
                now = datetime.utcnow()
                expired_assignments = []
                
                for user_id, user_assignments in self.assignments.items():
                    for experiment_id, assignment in user_assignments.items():
                        experiment = self.experiments.get(experiment_id)
                        if experiment and experiment.end_date and now > experiment.end_date:
                            expired_assignments.append((user_id, experiment_id))
                
                # Remove expired assignments
                for user_id, experiment_id in expired_assignments:
                    del self.assignments[user_id][experiment_id]
                    if not self.assignments[user_id]:
                        del self.assignments[user_id]
                
                if expired_assignments:
                    logger.info("Cleaned up expired assignments", count=len(expired_assignments))
                
            except Exception as e:
                logger.error("Assignment cleanup failed", error=str(e))