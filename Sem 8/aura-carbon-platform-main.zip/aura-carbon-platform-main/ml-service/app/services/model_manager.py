"""
Model Manager for loading, versioning, and serving ML models
"""

import asyncio
import os
import pickle
import json
from typing import Dict, Any, Optional, List
from pathlib import Path
import structlog
import tensorflow as tf
import torch
import joblib
from datetime import datetime, timedelta
import hashlib
import redis.asyncio as redis

from app.core.config import settings
from app.core.metrics import track_model_loading, ACTIVE_MODELS, MEMORY_USAGE
from app.models.base import BaseModel, ModelMetadata
from app.models.tensorflow_model import TensorFlowModel
from app.models.pytorch_model import PyTorchModel
from app.models.sklearn_model import SklearnModel

logger = structlog.get_logger()


class ModelManager:
    """Manages ML model loading, versioning, and serving"""
    
    def __init__(self):
        self.loaded_models: Dict[str, BaseModel] = {}
        self.model_metadata: Dict[str, ModelMetadata] = {}
        self.redis_client: Optional[redis.Redis] = None
        self.model_cache_ttl = settings.MODEL_CACHE_TTL
        self._lock = asyncio.Lock()
    
    async def initialize(self):
        """Initialize the model manager"""
        logger.info("Initializing Model Manager")
        
        # Initialize Redis connection
        try:
            self.redis_client = redis.from_url(
                settings.REDIS_URL,
                password=settings.REDIS_PASSWORD,
                decode_responses=True
            )
            await self.redis_client.ping()
            logger.info("Redis connection established")
        except Exception as e:
            logger.warning("Redis connection failed, using in-memory cache", error=str(e))
            self.redis_client = None
        
        # Load default models
        await self._load_default_models()
        
        # Start background tasks
        asyncio.create_task(self._model_health_check())
        asyncio.create_task(self._update_metrics())
        
        logger.info("Model Manager initialized", models_loaded=len(self.loaded_models))
    
    async def cleanup(self):
        """Cleanup resources"""
        logger.info("Cleaning up Model Manager")
        
        # Unload all models
        for model_name in list(self.loaded_models.keys()):
            await self.unload_model(model_name)
        
        # Close Redis connection
        if self.redis_client:
            await self.redis_client.close()
        
        logger.info("Model Manager cleanup complete")
    
    @track_model_loading
    async def load_model(
        self, 
        model_name: str, 
        model_version: str = "latest",
        force_reload: bool = False
    ) -> BaseModel:
        """Load a model into memory"""
        async with self._lock:
            model_key = f"{model_name}:{model_version}"
            
            # Check if model is already loaded
            if model_key in self.loaded_models and not force_reload:
                logger.info("Model already loaded", model_key=model_key)
                return self.loaded_models[model_key]
            
            logger.info("Loading model", model_key=model_key)
            
            try:
                # Get model metadata
                metadata = await self._get_model_metadata(model_name, model_version)
                if not metadata:
                    raise ValueError(f"Model metadata not found: {model_key}")
                
                # Load model based on type
                model = await self._load_model_by_type(metadata)
                
                # Cache model
                self.loaded_models[model_key] = model
                self.model_metadata[model_key] = metadata
                
                # Update cache timestamp
                if self.redis_client:
                    await self.redis_client.setex(
                        f"model_cache:{model_key}",
                        self.model_cache_ttl,
                        datetime.utcnow().isoformat()
                    )
                
                logger.info("Model loaded successfully", model_key=model_key)
                return model
                
            except Exception as e:
                logger.error("Failed to load model", model_key=model_key, error=str(e))
                raise
    
    async def unload_model(self, model_name: str, model_version: str = "latest"):
        """Unload a model from memory"""
        async with self._lock:
            model_key = f"{model_name}:{model_version}"
            
            if model_key in self.loaded_models:
                model = self.loaded_models[model_key]
                await model.cleanup()
                del self.loaded_models[model_key]
                del self.model_metadata[model_key]
                
                # Remove from cache
                if self.redis_client:
                    await self.redis_client.delete(f"model_cache:{model_key}")
                
                logger.info("Model unloaded", model_key=model_key)
    
    async def get_model(self, model_name: str, model_version: str = "latest") -> Optional[BaseModel]:
        """Get a loaded model"""
        model_key = f"{model_name}:{model_version}"
        
        # Check if model is loaded
        if model_key in self.loaded_models:
            return self.loaded_models[model_key]
        
        # Try to load model
        try:
            return await self.load_model(model_name, model_version)
        except Exception as e:
            logger.error("Failed to get model", model_key=model_key, error=str(e))
            return None
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List all available models"""
        models = []
        
        for model_key, metadata in self.model_metadata.items():
            model_name, model_version = model_key.split(":", 1)
            models.append({
                "name": model_name,
                "version": model_version,
                "type": metadata.model_type,
                "status": "loaded" if model_key in self.loaded_models else "available",
                "created_at": metadata.created_at,
                "metrics": metadata.metrics
            })
        
        return models
    
    async def get_model_info(self, model_name: str, model_version: str = "latest") -> Optional[Dict[str, Any]]:
        """Get detailed model information"""
        model_key = f"{model_name}:{model_version}"
        
        if model_key not in self.model_metadata:
            return None
        
        metadata = self.model_metadata[model_key]
        model = self.loaded_models.get(model_key)
        
        return {
            "name": model_name,
            "version": model_version,
            "type": metadata.model_type,
            "status": "loaded" if model else "available",
            "created_at": metadata.created_at,
            "metrics": metadata.metrics,
            "input_schema": metadata.input_schema,
            "output_schema": metadata.output_schema,
            "memory_usage": await model.get_memory_usage() if model else None
        }
    
    async def is_healthy(self) -> bool:
        """Check if model manager is healthy"""
        try:
            # Check Redis connection
            if self.redis_client:
                await self.redis_client.ping()
            
            # Check if at least one model is loaded
            if not self.loaded_models:
                logger.warning("No models loaded")
                return False
            
            # Check model health
            for model_key, model in self.loaded_models.items():
                if not await model.is_healthy():
                    logger.warning("Unhealthy model detected", model_key=model_key)
                    return False
            
            return True
            
        except Exception as e:
            logger.error("Health check failed", error=str(e))
            return False
    
    async def _load_default_models(self):
        """Load default models on startup"""
        default_models = [
            ("carbon_prediction", "latest"),
            ("recommendation_engine", "latest")
        ]
        
        for model_name, model_version in default_models:
            try:
                await self.load_model(model_name, model_version)
            except Exception as e:
                logger.warning(
                    "Failed to load default model",
                    model_name=model_name,
                    model_version=model_version,
                    error=str(e)
                )
    
    async def _get_model_metadata(self, model_name: str, model_version: str) -> Optional[ModelMetadata]:
        """Get model metadata from storage"""
        try:
            # Try to load from local storage first
            metadata_path = Path(settings.MODEL_STORAGE_PATH) / model_name / model_version / "metadata.json"
            
            if metadata_path.exists():
                with open(metadata_path, 'r') as f:
                    metadata_dict = json.load(f)
                return ModelMetadata(**metadata_dict)
            
            # TODO: Add support for S3/GCS storage
            logger.warning("Model metadata not found", model_name=model_name, model_version=model_version)
            return None
            
        except Exception as e:
            logger.error("Failed to load model metadata", error=str(e))
            return None
    
    async def _load_model_by_type(self, metadata: ModelMetadata) -> BaseModel:
        """Load model based on its type"""
        model_path = Path(settings.MODEL_STORAGE_PATH) / metadata.name / metadata.version
        
        if metadata.model_type == "tensorflow":
            return await TensorFlowModel.load(model_path, metadata)
        elif metadata.model_type == "pytorch":
            return await PyTorchModel.load(model_path, metadata)
        elif metadata.model_type == "sklearn":
            return await SklearnModel.load(model_path, metadata)
        else:
            raise ValueError(f"Unsupported model type: {metadata.model_type}")
    
    async def _model_health_check(self):
        """Background task to check model health"""
        while True:
            try:
                await asyncio.sleep(60)  # Check every minute
                
                unhealthy_models = []
                for model_key, model in self.loaded_models.items():
                    if not await model.is_healthy():
                        unhealthy_models.append(model_key)
                
                # Reload unhealthy models
                for model_key in unhealthy_models:
                    model_name, model_version = model_key.split(":", 1)
                    logger.warning("Reloading unhealthy model", model_key=model_key)
                    try:
                        await self.load_model(model_name, model_version, force_reload=True)
                    except Exception as e:
                        logger.error("Failed to reload model", model_key=model_key, error=str(e))
                
            except Exception as e:
                logger.error("Model health check failed", error=str(e))
    
    async def _update_metrics(self):
        """Background task to update metrics"""
        while True:
            try:
                await asyncio.sleep(30)  # Update every 30 seconds
                
                # Update active models count
                ACTIVE_MODELS.set(len(self.loaded_models))
                
                # Update memory usage
                total_memory = 0
                for model in self.loaded_models.values():
                    total_memory += await model.get_memory_usage()
                MEMORY_USAGE.set(total_memory)
                
            except Exception as e:
                logger.error("Metrics update failed", error=str(e))