"""
API v1 router
"""

from fastapi import APIRouter

from app.api.v1.endpoints import predictions, models, ab_testing

api_router = APIRouter()
api_router.include_router(predictions.router, prefix="/predictions", tags=["predictions"])
api_router.include_router(models.router, prefix="/models", tags=["models"])
api_router.include_router(ab_testing.router, prefix="/ab-testing", tags=["ab-testing"])