"""
Dependency injection for API endpoints
"""

from fastapi import Depends, HTTPException

from app.main import model_manager, ab_testing_service


async def get_model_manager():
    """Get model manager instance"""
    if not model_manager:
        raise HTTPException(status_code=503, detail="Model manager not initialized")
    return model_manager


async def get_ab_testing_service():
    """Get A/B testing service instance"""
    if not ab_testing_service:
        raise HTTPException(status_code=503, detail="A/B testing service not initialized")
    return ab_testing_service