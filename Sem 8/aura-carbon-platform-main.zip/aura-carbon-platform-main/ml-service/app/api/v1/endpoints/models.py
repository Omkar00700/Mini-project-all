"""
Model management endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import structlog

from app.services.model_manager import ModelManager

router = APIRouter()
logger = structlog.get_logger()


class ModelLoadRequest(BaseModel):
    model_name: str
    model_version: str = "latest"
    force_reload: bool = False


class ModelUnloadRequest(BaseModel):
    model_name: str
    model_version: str = "latest"


@router.get("/list")
async def list_models(model_manager: ModelManager = Depends(lambda: None)):
    """List all available models"""
    try:
        models = await model_manager.list_models()
        return {"models": models}
    except Exception as e:
        logger.error("Failed to list models", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/load")
async def load_model(
    request: ModelLoadRequest,
    model_manager: ModelManager = Depends(lambda: None)
):
    """Load a model into memory"""
    try:
        model = await model_manager.load_model(
            request.model_name,
            request.model_version,
            request.force_reload
        )
        return {"message": "Model loaded successfully", "model_info": model.get_info()}
    except Exception as e:
        logger.error("Failed to load model", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/unload")
async def unload_model(
    request: ModelUnloadRequest,
    model_manager: ModelManager = Depends(lambda: None)
):
    """Unload a model from memory"""
    try:
        await model_manager.unload_model(request.model_name, request.model_version)
        return {"message": "Model unloaded successfully"}
    except Exception as e:
        logger.error("Failed to unload model", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{model_name}/{model_version}")
async def get_model_info(
    model_name: str,
    model_version: str = "latest",
    model_manager: ModelManager = Depends(lambda: None)
):
    """Get detailed information about a specific model"""
    try:
        model_info = await model_manager.get_model_info(model_name, model_version)
        if not model_info:
            raise HTTPException(status_code=404, detail=f"Model {model_name}:{model_version} not found")
        return {"model_info": model_info}
    except Exception as e:
        logger.error("Failed to get model info", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))