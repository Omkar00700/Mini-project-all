"""
Prediction endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import structlog

from app.services.model_manager import ModelManager
from app.services.ab_testing import ABTestingService

# Note: Dependencies will be imported when the app is fully set up
# from app.api.v1.dependencies import get_model_manager, get_ab_testing_service

router = APIRouter()
logger = structlog.get_logger()


class PredictionRequest(BaseModel):
    model_name: str
    model_version: str = "latest"
    input_data: Dict[str, Any]
    user_id: Optional[str] = None


class BatchPredictionRequest(BaseModel):
    model_name: str
    model_version: str = "latest"
    input_data: List[Dict[str, Any]]
    user_id: Optional[str] = None


class PredictionResponse(BaseModel):
    prediction: Dict[str, Any]
    model_info: Dict[str, Any]


class BatchPredictionResponse(BaseModel):
    predictions: List[Dict[str, Any]]
    model_info: Dict[str, Any]


# Temporary dependency functions for now
async def get_model_manager():
    # This will be properly implemented when the app is fully set up
    pass

async def get_ab_testing_service():
    # This will be properly implemented when the app is fully set up
    pass


@router.post("/predict", response_model=PredictionResponse)
async def predict(
    request: PredictionRequest,
    model_manager: ModelManager = Depends(get_model_manager),
    ab_testing_service: ABTestingService = Depends(get_ab_testing_service)
):
    """Make a prediction using the specified model"""
    try:
        # If user_id is provided and we have A/B testing, get the appropriate model
        if request.user_id:
            model_name, model_version = await ab_testing_service.get_model_for_user(
                request.user_id, 
                "carbon_prediction_experiment",
                request.model_name,
                request.model_version
            )
        else:
            model_name, model_version = request.model_name, request.model_version
        
        # Get the model
        model = await model_manager.get_model(model_name, model_version)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {model_name}:{model_version} not found")
        
        # Make prediction
        prediction = await model.predict(request.input_data)
        
        # Get model info
        model_info = model.get_info()
        
        return PredictionResponse(prediction=prediction, model_info=model_info)
        
    except Exception as e:
        logger.error("Prediction failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/predict-batch", response_model=BatchPredictionResponse)
async def predict_batch(
    request: BatchPredictionRequest,
    model_manager: ModelManager = Depends(get_model_manager),
    ab_testing_service: ABTestingService = Depends(get_ab_testing_service)
):
    """Make batch predictions using the specified model"""
    try:
        # If user_id is provided and we have A/B testing, get the appropriate model
        if request.user_id and len(request.input_data) > 0:
            model_name, model_version = await ab_testing_service.get_model_for_user(
                request.user_id, 
                "carbon_prediction_experiment",
                request.model_name,
                request.model_version
            )
        else:
            model_name, model_version = request.model_name, request.model_version
        
        # Get the model
        model = await model_manager.get_model(model_name, model_version)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {model_name}:{model_version} not found")
        
        # Make batch prediction
        predictions = await model.predict_batch(request.input_data)
        
        # Get model info
        model_info = model.get_info()
        
        return BatchPredictionResponse(predictions=predictions, model_info=model_info)
        
    except Exception as e:
        logger.error("Batch prediction failed", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))