"""
A/B Testing endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from datetime import datetime
import structlog

from app.services.ab_testing import ABTestingService, ExperimentVariant, ExperimentStatus

router = APIRouter()
logger = structlog.get_logger()


class CreateExperimentRequest(BaseModel):
    name: str
    description: str
    variants: List[Dict[str, Any]]
    start_date: datetime
    end_date: Optional[datetime] = None
    success_metrics: List[str] = []
    created_by: str = "api"


class AssignmentRequest(BaseModel):
    user_id: str
    experiment_name: str
    context: Optional[Dict[str, Any]] = {}


class MetricRequest(BaseModel):
    user_id: str
    experiment_id: str
    metric_name: str
    value: float
    metadata: Optional[Dict[str, Any]] = {}


@router.post("/experiments")
async def create_experiment(
    request: CreateExperimentRequest,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Create a new A/B test experiment"""
    try:
        # Convert variants to ExperimentVariant objects
        variants = []
        for v in request.variants:
            variant = ExperimentVariant(
                name=v["name"],
                model_name=v["model_name"],
                model_version=v["model_version"],
                traffic_percentage=v["traffic_percentage"],
                metadata=v.get("metadata", {})
            )
            variants.append(variant)
        
        experiment = await ab_testing_service.create_experiment(
            name=request.name,
            description=request.description,
            variants=variants,
            start_date=request.start_date,
            end_date=request.end_date,
            success_metrics=request.success_metrics,
            created_by=request.created_by
        )
        
        return {"message": "Experiment created successfully", "experiment": experiment}
    except Exception as e:
        logger.error("Failed to create experiment", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/experiments/{experiment_id}/start")
async def start_experiment(
    experiment_id: str,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Start an experiment"""
    try:
        success = await ab_testing_service.start_experiment(experiment_id)
        if success:
            return {"message": "Experiment started successfully"}
        else:
            raise HTTPException(status_code=400, detail="Failed to start experiment")
    except Exception as e:
        logger.error("Failed to start experiment", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/experiments/{experiment_id}/stop")
async def stop_experiment(
    experiment_id: str,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Stop an experiment"""
    try:
        success = await ab_testing_service.stop_experiment(experiment_id)
        if success:
            return {"message": "Experiment stopped successfully"}
        else:
            raise HTTPException(status_code=400, detail="Failed to stop experiment")
    except Exception as e:
        logger.error("Failed to stop experiment", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/assignments")
async def get_assignment(
    request: AssignmentRequest,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Get user assignment for an experiment"""
    try:
        context = request.context if request.context is not None else {}
        assignment = await ab_testing_service.get_assignment(
            request.user_id,
            request.experiment_name,
            context
        )
        
        if not assignment:
            raise HTTPException(status_code=404, detail="No assignment found")
        
        return {"assignment": assignment}
    except Exception as e:
        logger.error("Failed to get assignment", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/metrics")
async def record_metric(
    request: MetricRequest,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Record a metric for an experiment"""
    try:
        metadata = request.metadata if request.metadata is not None else {}
        await ab_testing_service.record_metric(
            request.user_id,
            request.experiment_id,
            request.metric_name,
            request.value,
            metadata
        )
        
        return {"message": "Metric recorded successfully"}
    except Exception as e:
        logger.error("Failed to record metric", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/experiments/{experiment_id}/results")
async def get_experiment_results(
    experiment_id: str,
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """Get experiment results and statistics"""
    try:
        results = await ab_testing_service.get_experiment_results(experiment_id)
        if not results:
            raise HTTPException(status_code=404, detail="Experiment not found")
        
        return {"results": results}
    except Exception as e:
        logger.error("Failed to get experiment results", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/experiments")
async def list_experiments(
    ab_testing_service: ABTestingService = Depends(lambda: None)
):
    """List all experiments"""
    try:
        experiments = await ab_testing_service.list_experiments()
        return {"experiments": experiments}
    except Exception as e:
        logger.error("Failed to list experiments", error=str(e))
        raise HTTPException(status_code=500, detail=str(e))