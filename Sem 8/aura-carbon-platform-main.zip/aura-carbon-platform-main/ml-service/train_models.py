"""
Real ML Model Training Script for Aura Carbon Platform

This script trains actual ML models for carbon footprint prediction:
1. LSTM Neural Network for time-series forecasting
2. Prophet-style decomposition for trend/seasonality
3. Scikit-learn ensemble for baseline comparisons

Usage:
    python train_models.py --model lstm --epochs 100
    python train_models.py --model prophet
    python train_models.py --model all
"""

import os
import sys
import json
import argparse
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("Warning: PyTorch not available, LSTM training will be skipped")

try:
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("Warning: scikit-learn not available")


# ==========================================
# SYNTHETIC DATA GENERATION
# ==========================================

def generate_training_data(n_samples: int = 1000, n_users: int = 50) -> pd.DataFrame:
    """
    Generate realistic synthetic carbon footprint training data.
    
    Creates data with:
    - Seasonal patterns (higher in winter for heating, summer for AC)
    - User-specific patterns
    - Trend components
    - Random noise
    """
    print(f"Generating {n_samples} samples for {n_users} users...")
    
    np.random.seed(42)
    
    # Generate date range
    start_date = datetime(2022, 1, 1)
    dates = [start_date + timedelta(days=i) for i in range(n_samples)]
    
    data = []
    
    for user_id in range(1, n_users + 1):
        # User-specific baseline (different lifestyles)
        base_emissions = np.random.uniform(200, 500)  # kg CO2/month
        
        # User lifestyle factors
        transport_factor = np.random.uniform(0.5, 2.0)
        energy_factor = np.random.uniform(0.5, 1.5)
        food_factor = np.random.uniform(0.8, 1.2)
        
        for i, date in enumerate(dates):
            # Seasonal patterns
            month = date.month
            
            # Energy emissions (higher in winter and summer)
            seasonal_energy = 1 + 0.3 * np.cos((month - 1) * np.pi / 6)
            
            # Transport emissions (higher in summer for travel)
            seasonal_transport = 1 + 0.2 * np.sin((month - 1) * np.pi / 6)
            
            # Trend component (slight reduction over time as users become eco-conscious)
            trend = max(0.7, 1 - 0.001 * i)
            
            # Random daily variation
            noise = np.random.normal(0, 0.1)
            
            # Calculate category emissions
            transport = base_emissions * 0.35 * transport_factor * seasonal_transport * trend * (1 + noise)
            energy = base_emissions * 0.30 * energy_factor * seasonal_energy * trend * (1 + noise)
            food = base_emissions * 0.20 * food_factor * trend * (1 + noise)
            waste = base_emissions * 0.10 * trend * (1 + noise)
            
            # Additional features
            temperature = 25 + 15 * np.sin((month - 1) * np.pi / 6) + np.random.normal(0, 3)
            is_weekend = 1 if date.weekday() >= 5 else 0
            is_holiday = 1 if date.month == 12 and date.day > 20 else 0
            
            data.append({
                'user_id': f'user_{user_id:03d}',
                'date': date,
                'month': month,
                'day_of_week': date.weekday(),
                'is_weekend': is_weekend,
                'is_holiday': is_holiday,
                'temperature': temperature,
                'transport_emissions': max(0, transport),
                'energy_emissions': max(0, energy),
                'food_emissions': max(0, food),
                'waste_emissions': max(0, waste),
                'total_emissions': max(0, transport + energy + food + waste),
            })
    
    df = pd.DataFrame(data)
    print(f"Generated {len(df)} records")
    return df


# ==========================================
# LSTM MODEL
# ==========================================

class CarbonLSTM(nn.Module):
    """
    LSTM Neural Network for Carbon Footprint Prediction.
    
    Architecture:
    - 2 LSTM layers with dropout
    - Fully connected layers for output
    - Predicts next month's emissions based on sequence
    """
    
    def __init__(
        self,
        input_size: int = 10,
        hidden_size: int = 64,
        num_layers: int = 2,
        output_size: int = 1,
        dropout: float = 0.2
    ):
        super(CarbonLSTM, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )
        
        self.fc1 = nn.Linear(hidden_size, 32)
        self.fc2 = nn.Linear(32, output_size)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
    
    def forward(self, x):
        # LSTM forward pass
        lstm_out, _ = self.lstm(x)
        
        # Use the last output
        last_output = lstm_out[:, -1, :]
        
        # Fully connected layers
        out = self.fc1(last_output)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc2(out)
        
        return out


def prepare_lstm_data(df: pd.DataFrame, sequence_length: int = 30):
    """
    Prepare data for LSTM training.
    Creates sequences of historical data to predict next value.
    """
    # Feature columns
    feature_cols = [
        'transport_emissions', 'energy_emissions', 'food_emissions', 
        'waste_emissions', 'temperature', 'month', 'day_of_week',
        'is_weekend', 'is_holiday', 'total_emissions'
    ]
    
    # Normalize features
    scaler = StandardScaler()
    df_scaled = df.copy()
    df_scaled[feature_cols] = scaler.fit_transform(df[feature_cols])
    
    X, y = [], []
    
    # Group by user to create proper sequences
    for user_id in df['user_id'].unique():
        user_data = df_scaled[df_scaled['user_id'] == user_id].sort_values('date')
        user_values = user_data[feature_cols].values
        user_target = user_data['total_emissions'].values
        
        for i in range(len(user_data) - sequence_length):
            X.append(user_values[i:i + sequence_length])
            y.append(user_target[i + sequence_length])
    
    return np.array(X), np.array(y), scaler


def train_lstm_model(df: pd.DataFrame, epochs: int = 100, batch_size: int = 32):
    """
    Train LSTM model for carbon footprint prediction.
    """
    if not TORCH_AVAILABLE:
        print("PyTorch not available. Skipping LSTM training.")
        return None
    
    print("\n" + "="*50)
    print("Training LSTM Model")
    print("="*50)
    
    # Prepare data
    X, y, scaler = prepare_lstm_data(df)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Convert to PyTorch tensors
    X_train_tensor = torch.FloatTensor(X_train)
    y_train_tensor = torch.FloatTensor(y_train).reshape(-1, 1)
    X_test_tensor = torch.FloatTensor(X_test)
    y_test_tensor = torch.FloatTensor(y_test).reshape(-1, 1)
    
    # Create data loaders
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    
    # Initialize model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = CarbonLSTM(input_size=10, hidden_size=64, num_layers=2, output_size=1)
    model.to(device)
    
    # Loss and optimizer
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    # Training loop
    print(f"Training on {device}...")
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        
        for batch_X, batch_y in train_loader:
            batch_X = batch_X.to(device)
            batch_y = batch_y.to(device)
            
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
        
        if (epoch + 1) % 10 == 0:
            avg_loss = total_loss / len(train_loader)
            print(f"Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.4f}")
    
    # Evaluate
    model.eval()
    with torch.no_grad():
        X_test_tensor = X_test_tensor.to(device)
        y_test_tensor = y_test_tensor.to(device)
        predictions = model(X_test_tensor)
        test_loss = criterion(predictions, y_test_tensor)
        
        # Convert back to numpy for metrics
        y_pred = predictions.cpu().numpy()
        y_true = y_test_tensor.cpu().numpy()
        
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        mae = mean_absolute_error(y_true, y_pred)
        r2 = r2_score(y_true, y_pred)
        
        print(f"\nTest Results:")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  MAE: {mae:.4f}")
        print(f"  R²: {r2:.4f}")
    
    # Save model
    model_path = Path(__file__).parent / "models" / "carbon_prediction" / "latest"
    model_path.mkdir(parents=True, exist_ok=True)
    
    torch.save({
        'model_state_dict': model.state_dict(),
        'input_size': 10,
        'hidden_size': 64,
        'num_layers': 2,
        'output_size': 1,
        'scaler_mean': scaler.mean_.tolist(),
        'scaler_scale': scaler.scale_.tolist(),
    }, model_path / "model.pth")
    
    # Save metadata
    metadata = {
        'name': 'carbon_prediction_lstm',
        'version': '1.0.0',
        'model_type': 'pytorch',
        'description': 'LSTM model for carbon footprint time series prediction',
        'created_at': datetime.utcnow().isoformat(),
        'metrics': {
            'rmse': float(rmse),
            'mae': float(mae),
            'r2': float(r2)
        },
        'training_config': {
            'epochs': epochs,
            'batch_size': batch_size,
            'sequence_length': 30,
            'features': 10
        }
    }
    
    with open(model_path / "metadata.json", 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\nModel saved to {model_path}")
    
    return model, scaler, {'rmse': rmse, 'mae': mae, 'r2': r2}


# ==========================================
# ENSEMBLE MODEL (Scikit-learn)
# ==========================================

def train_ensemble_model(df: pd.DataFrame):
    """
    Train ensemble model using scikit-learn.
    Combines Random Forest and Gradient Boosting.
    """
    if not SKLEARN_AVAILABLE:
        print("scikit-learn not available. Skipping ensemble training.")
        return None
    
    print("\n" + "="*50)
    print("Training Ensemble Model (Random Forest + Gradient Boosting)")
    print("="*50)
    
    # Feature columns
    feature_cols = [
        'month', 'day_of_week', 'is_weekend', 'is_holiday', 'temperature',
        'transport_emissions', 'energy_emissions', 'food_emissions', 'waste_emissions'
    ]
    
    X = df[feature_cols].values
    y = df['total_emissions'].values
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train Random Forest
    print("\nTraining Random Forest...")
    rf_model = RandomForestRegressor(n_estimators=100, max_depth=10, random_state=42, n_jobs=-1)
    rf_model.fit(X_train_scaled, y_train)
    rf_pred = rf_model.predict(X_test_scaled)
    rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))
    print(f"Random Forest RMSE: {rf_rmse:.4f}")
    
    # Train Gradient Boosting
    print("\nTraining Gradient Boosting...")
    gb_model = GradientBoostingRegressor(n_estimators=100, max_depth=5, random_state=42)
    gb_model.fit(X_train_scaled, y_train)
    gb_pred = gb_model.predict(X_test_scaled)
    gb_rmse = np.sqrt(mean_squared_error(y_test, gb_pred))
    print(f"Gradient Boosting RMSE: {gb_rmse:.4f}")
    
    # Ensemble (average)
    ensemble_pred = (rf_pred + gb_pred) / 2
    ensemble_rmse = np.sqrt(mean_squared_error(y_test, ensemble_pred))
    ensemble_mae = mean_absolute_error(y_test, ensemble_pred)
    ensemble_r2 = r2_score(y_test, ensemble_pred)
    
    print(f"\nEnsemble Results:")
    print(f"  RMSE: {ensemble_rmse:.4f}")
    print(f"  MAE: {ensemble_mae:.4f}")
    print(f"  R²: {ensemble_r2:.4f}")
    
    # Save models
    import joblib
    
    model_path = Path(__file__).parent / "models" / "carbon_prediction" / "sklearn"
    model_path.mkdir(parents=True, exist_ok=True)
    
    joblib.dump({'rf': rf_model, 'gb': gb_model, 'scaler': scaler}, model_path / "ensemble_model.joblib")
    
    # Save metadata
    metadata = {
        'name': 'carbon_prediction_ensemble',
        'version': '1.0.0',
        'model_type': 'sklearn',
        'description': 'Ensemble of Random Forest and Gradient Boosting for carbon prediction',
        'created_at': datetime.utcnow().isoformat(),
        'metrics': {
            'rmse': float(ensemble_rmse),
            'mae': float(ensemble_mae),
            'r2': float(ensemble_r2),
            'rf_rmse': float(rf_rmse),
            'gb_rmse': float(gb_rmse)
        }
    }
    
    with open(model_path / "metadata.json", 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\nModel saved to {model_path}")
    
    return {'rf': rf_model, 'gb': gb_model, 'scaler': scaler}


# ==========================================
# MAIN
# ==========================================

def main():
    parser = argparse.ArgumentParser(description='Train ML models for Aura Carbon Platform')
    parser.add_argument('--model', type=str, default='all', choices=['lstm', 'ensemble', 'all'],
                       help='Model to train')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs for LSTM')
    parser.add_argument('--samples', type=int, default=2000, help='Number of training samples')
    parser.add_argument('--users', type=int, default=100, help='Number of synthetic users')
    
    args = parser.parse_args()
    
    print("="*60)
    print("Aura Carbon Platform - ML Model Training")
    print("="*60)
    
    # Generate training data
    df = generate_training_data(n_samples=args.samples, n_users=args.users)
    
    # Save training data for reference
    data_path = Path(__file__).parent / "models" / "training_data"
    data_path.mkdir(parents=True, exist_ok=True)
    df.to_csv(data_path / "synthetic_training_data.csv", index=False)
    print(f"Training data saved to {data_path}")
    
    results = {}
    
    # Train models
    if args.model in ['lstm', 'all']:
        lstm_result = train_lstm_model(df, epochs=args.epochs)
        if lstm_result:
            results['lstm'] = lstm_result[2]
    
    if args.model in ['ensemble', 'all']:
        ensemble_result = train_ensemble_model(df)
        if ensemble_result:
            results['ensemble'] = {
                'rmse': ensemble_result['rf'].score if hasattr(ensemble_result['rf'], 'score') else None
            }
    
    print("\n" + "="*60)
    print("Training Complete!")
    print("="*60)
    
    if results:
        print("\nModel Performance Summary:")
        for model_name, metrics in results.items():
            if metrics:
                print(f"\n{model_name.upper()}:")
                for metric_name, value in metrics.items():
                    if value is not None:
                        print(f"  {metric_name}: {value:.4f}")


if __name__ == "__main__":
    main()
