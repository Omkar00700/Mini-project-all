# Aura ML Service

AI/ML service for carbon footprint prediction and recommendations.

## Overview

The Aura ML Service provides machine learning capabilities for the Aura Carbon Platform, including:

- Carbon footprint prediction using time series forecasting
- Personalized recommendation engine for emission reduction
- A/B testing framework for model experimentation
- Model versioning and management

## Features Implemented

### 1. Model Infrastructure (Task 6.1)

- FastAPI service for ML model serving
- TensorFlow/PyTorch model loading and inference
- Model versioning and A/B testing framework

### 2. Time Series Forecasting (Task 6.2)

- LSTM networks for carbon footprint prediction
- Seasonal pattern detection and incorporation
- Confidence interval calculation and uncertainty quantification

### 3. AI-powered Data Estimation (Task 6.3)

- Models for filling missing data using demographic patterns
- Behavioral pattern recognition for automatic categorization
- Anomaly detection for unusual consumption patterns

### 4. Scenario Analysis Engine (Task 6.4)

- Lifestyle change impact prediction models
- "What-if" analysis for different behavioral scenarios
- Market trend incorporation for future predictions

## API Endpoints

### Predictions

- `POST /api/v1/predictions/predict` - Make a single prediction
- `POST /api/v1/predictions/predict-batch` - Make batch predictions

### Models

- `GET /api/v1/models/list` - List all available models
- `POST /api/v1/models/load` - Load a model into memory
- `POST /api/v1/models/unload` - Unload a model from memory
- `GET /api/v1/models/{model_name}/{model_version}` - Get model information

### A/B Testing

- `POST /api/v1/ab-testing/experiments` - Create a new experiment
- `POST /api/v1/ab-testing/experiments/{experiment_id}/start` - Start an experiment
- `POST /api/v1/ab-testing/experiments/{experiment_id}/stop` - Stop an experiment
- `POST /api/v1/ab-testing/assignments` - Get user assignment for an experiment
- `POST /api/v1/ab-testing/metrics` - Record a metric for an experiment
- `GET /api/v1/ab-testing/experiments/{experiment_id}/results` - Get experiment results
- `GET /api/v1/ab-testing/experiments` - List all experiments

## Model Types

The service supports three types of models:

1. **TensorFlow Models** - For deep learning models
2. **PyTorch Models** - For deep learning models with PyTorch
3. **Scikit-learn Models** - For traditional ML models

## Directory Structure

```
ml-service/
├── app/
│   ├── api/              # API endpoints
│   │   └── v1/
│   │       ├── endpoints/ # Individual endpoint handlers
│   │       ├── dependencies.py # Dependency injection
│   │       └── router.py      # API router
│   ├── core/             # Core configuration and utilities
│   ├── models/           # Model implementations
│   ├── services/         # Business logic services
│   └── main.py           # Application entry point
├── models/               # Actual model files
├── tests/                # Unit and integration tests
├── Dockerfile            # Docker configuration
├── requirements.txt      # Python dependencies
└── README.md             # This file
```

## Running the Service

### Using Docker

```bash
docker build -t aura-ml-service .
docker run -p 8000:8000 aura-ml-service
```

### Using Python

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Environment Variables

The service can be configured using environment variables:

- `VERSION` - Service version (default: "1.0.0")
- `ENVIRONMENT` - Environment (default: "development")
- `HOST` - Host to bind to (default: "0.0.0.0")
- `PORT` - Port to listen on (default: 8000)
- `WORKERS` - Number of workers (default: 4)
- `SECRET_KEY` - Secret key for security
- `ALLOWED_HOSTS` - Allowed hosts for CORS
- `MODEL_STORAGE_PATH` - Path to model storage (default: "./models")
- `REDIS_URL` - Redis connection URL
- `ENABLE_METRICS` - Enable Prometheus metrics (default: True)

## Testing

Run the test suite:

```bash
python -m pytest tests/
```

## Monitoring

The service exposes Prometheus metrics at `/metrics` and provides health checks at `/health`.
