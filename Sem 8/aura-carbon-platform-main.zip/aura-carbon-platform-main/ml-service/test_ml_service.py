"""
Test script for ML service
"""

import asyncio
import sys
import os
from pathlib import Path

# Add the app directory to the path
sys.path.insert(0, str(Path(__file__).parent / "app"))

async def test_model_loading():
    """Test model loading functionality"""
    try:
        from app.models.base import ModelMetadata
        from app.models.tensorflow_model import TensorFlowModel
        from app.models.pytorch_model import PyTorchModel
        from app.models.sklearn_model import SklearnModel
        from datetime import datetime
        
        print("✓ Model imports successful")
        
        # Test metadata creation
        metadata = ModelMetadata(
            name="test_model",
            version="1.0",
            model_type="test",
            description="Test model",
            created_at=datetime.utcnow(),
            input_schema={},
            output_schema={},
            metrics={}
        )
        print("✓ Model metadata creation successful")
        
        print("✓ All tests passed")
        return True
        
    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


async def test_service_imports():
    """Test service imports"""
    try:
        from app.services.model_manager import ModelManager
        from app.services.ab_testing import ABTestingService
        print("✓ Service imports successful")
        return True
    except Exception as e:
        print(f"✗ Service import test failed: {e}")
        return False


async def main():
    """Main test function"""
    print("Running ML service tests...")
    
    tests = [
        test_model_loading,
        test_service_imports
    ]
    
    results = []
    for test in tests:
        result = await test()
        results.append(result)
    
    if all(results):
        print("\n✓ All tests passed!")
        return 0
    else:
        print("\n✗ Some tests failed!")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)