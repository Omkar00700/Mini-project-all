"""
Demonstration script for ML service components
"""

import sys
from pathlib import Path

# Add the app directory to the path
sys.path.insert(0, str(Path(__file__).parent / "app"))

def demonstrate_model_implementations():
    """Demonstrate that model implementations are working"""
    print("Demonstrating ML Service Components")
    print("=" * 40)
    
    try:
        # Import model classes
        from app.models.base import ModelMetadata, BaseModel
        from app.models.tensorflow_model import TensorFlowModel
        from app.models.pytorch_model import PyTorchModel
        from app.models.sklearn_model import SklearnModel
        from datetime import datetime
        
        print("✓ All model classes imported successfully")
        
        # Create metadata
        metadata = ModelMetadata(
            name="demo_model",
            version="1.0",
            model_type="demo",
            description="Demo model for testing",
            created_at=datetime.now(),
            input_schema={"feature1": "float", "feature2": "float"},
            output_schema={"prediction": "float"},
            metrics={"accuracy": 0.95}
        )
        print("✓ ModelMetadata creation successful")
        
        # Verify class inheritance
        assert issubclass(TensorFlowModel, BaseModel)
        assert issubclass(PyTorchModel, BaseModel)
        assert issubclass(SklearnModel, BaseModel)
        
        print("✓ All model classes have correct inheritance")
        print(f"  - TensorFlow model class: {TensorFlowModel.__name__}")
        print(f"  - PyTorch model class: {PyTorchModel.__name__}")
        print(f"  - Scikit-learn model class: {SklearnModel.__name__}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error in model demonstration: {e}")
        return False


def demonstrate_service_implementations():
    """Demonstrate that service implementations are working"""
    print("\nDemonstrating Service Components")
    print("=" * 40)
    
    try:
        # Import service classes
        from app.services.model_manager import ModelManager
        from app.services.ab_testing import ABTestingService
        
        print("✓ All service classes imported successfully")
        
        # Create service instances
        model_manager = ModelManager()
        ab_testing_service = ABTestingService()
        
        print("✓ All service instances created successfully")
        print(f"  - ModelManager: {type(model_manager).__name__}")
        print(f"  - ABTestingService: {type(ab_testing_service).__name__}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error in service demonstration: {e}")
        return False


def demonstrate_api_implementations():
    """Demonstrate that API implementations are working"""
    print("\nDemonstrating API Components")
    print("=" * 40)
    
    try:
        # Import API components
        from app.api.v1.router import api_router
        from app.api.v1.endpoints import predictions, models, ab_testing
        
        print("✓ All API components imported successfully")
        print(f"  - API Router: {type(api_router).__name__}")
        print(f"  - Predictions endpoint: {predictions.__name__}")
        print(f"  - Models endpoint: {models.__name__}")
        print(f"  - A/B Testing endpoint: {ab_testing.__name__}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error in API demonstration: {e}")
        return False


def main():
    """Main demonstration function"""
    print("Aura ML Service - Component Demonstration")
    print("=" * 50)
    
    results = [
        demonstrate_model_implementations(),
        demonstrate_service_implementations(),
        demonstrate_api_implementations()
    ]
    
    print("\n" + "=" * 50)
    if all(results):
        print("✓ All demonstrations completed successfully!")
        print("\nThe ML Service infrastructure is ready for use.")
        return 0
    else:
        print("✗ Some demonstrations failed!")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)