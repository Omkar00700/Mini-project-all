# Aura Platform – India-Focused Carbon Tracking

AI-powered carbon footprint calculation and prediction platform designed for individuals and businesses in India to track, analyze, and reduce their environmental impact using India-specific emission factors.

---

## Quick Start (Local Development)

```bash
# Install dependencies
npm install

# Set up database schema (dev)
npx prisma db push
npm run db:seed

# Generate Prisma client (if needed)
npx prisma generate

# Start development server
npm run dev
```

Visit `http://localhost:3000` to see the application.

### Troubleshooting (Local)

- **Database**
  - `npx prisma migrate reset --force` – reset dev DB
  - `npm run db:seed` – re-seed demo data
  - `npx prisma generate` – regenerate client
- **Authentication**
  - Ensure cookies are enabled
  - Check that `JWT_SECRET` is set in `.env.local`
- **AI Features**
  - Set `OPENAI_API_KEY` in `.env.local` to enable full GPT-based recommendations
  - Without API key, the app uses rule-based fallbacks where possible

---

## Methodology & India-Specific Data

The project uses India-specific emission factors seeded into the database to ensure deterministic, reproducible calculations.

**Example emission factors (kg CO₂):**

- Electricity (India grid average): 0.82 kg CO₂ / kWh
- Petrol: 2.27193 kg CO₂ / litre
- Diesel: 2.6444 kg CO₂ / litre
- LPG (cooking): 2.983 kg CO₂ / kg
- Rice (India-specific): 4.0 kg CO₂ / kg
- CNG: 2.692 kg CO₂ / kg
- Auto Rickshaw: 0.085 kg CO₂ / km
- Indian Railways: 0.041 kg CO₂ / km

Emission factors are stored in `data/emission_factors_india.json` and loaded via `prisma/seed.ts`. Each input item is multiplied by the factor (after unit harmonization) to produce kg CO₂ per item; results include category breakdowns and factor provenance.

---

## 🌱 Implemented Features

- **Carbon Calculator**
  - `/calculator` page – India-specific, multi-category calculator
  - `/api/carbon/calculate` – REST API for emission calculations
  - `/api/carbon/save-calculation` – persists results to PostgreSQL

- **User Accounts & Authentication**
  - Email + password registration and login
  - JWT-based custom auth with:
    - `auth-token` HttpOnly cookie (7-day expiry, `Secure` in production)
    - `JWT_SECRET` required at startup (process will throw if missing)
  - Auth helpers:
    - `getUserFromRequest` (reads and validates JWT)
    - `createAuthenticatedRoute` / `withAuth` middleware

- **Dashboard & Analytics**
  - Personalized dashboard showing recent calculations, 6-month trends, top categories, and goal progress
  - `/api/dashboard` – aggregates user’s emissions, goals, and recent activity
  - Forecasting and predictions from historical calculation data (`/api/predictions`, `/api/analytics/forecasts`)

- **Activities & History**
  - `/api/activities` – CRUD for user-saved activities
  - `/api/activities/history` – historical activity/time-series data

- **Gamification**
  - XP and level system driven by `AchievementService`
  - Achievements unlocked based on:
    - Activities logged
    - CO₂ saved over time
    - Streaks and goals completed
  - Frontend store in `src/store/gamification-store.ts`
  - Leaderboard (`/leaderboard`, `/api/leaderboard`) with weekly and all-time views

- **AI-Powered Insights (Hybrid)**
  - OpenAI/OpenRouter-backed recommendations and insights when `OPENAI_API_KEY` is configured
  - Fallback rule-based logic when AI is disabled:
    - `/api/ai/recommendations`
    - `/api/ai/insights`
    - `/api/ai/chat`
    - `/api/ai/whatif`

- **Exports**
  - `/api/export` – CSV/JSON/HTML export of user data (requires auth)

## 🛠️ Development Setup

### Prerequisites

- Node.js 18+
- npm
- Git
- PostgreSQL instance

### Installation

1. **Clone the repository**

   ```bash
   git clone <repository-url>
   cd aura-platform
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Set up environment variables**

   ```bash
   cp .env.example .env.local
   # Edit .env.local with your configuration
   ```

4. **Run the development server**

   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Available Scripts

- `npm run dev` – Start development server
- `npm run build` – Build for production
- `npm run start` – Start production server
- `npm run lint` – Run ESLint
- `npm run lint:fix` – Fix ESLint issues
- `npm run type-check` – Run TypeScript type checking
- `npm run format` – Format code with Prettier
- `npm run format:check` – Check code formatting

## 📁 Project Structure

```
aura-platform/
├── src/
│   ├── app/                 # Next.js App Router pages
│   ├── components/          # Reusable React components
│   │   └── ui/             # shadcn/ui components
│   ├── hooks/              # Custom React hooks
│   ├── lib/                # Utility libraries
│   ├── services/           # API services and business logic
│   ├── store/              # Zustand store configurations
│   ├── types/              # TypeScript type definitions
│   └── utils/              # Helper functions
├── public/                 # Static assets
├── .husky/                 # Git hooks
└── docs/                   # Documentation (planned)
```

## 🔧 Configuration

### Environment Variables

Copy `.env.example` to `.env.local` and configure:

```env
# Database (SQLite for development)
DATABASE_URL="file:./dev.db"

# Authentication (required)
JWT_SECRET="your-super-secret-jwt-key-change-in-production-please"

# AI Features (optional - fallback recommendations used if not set)
OPENAI_API_KEY="sk-your-openai-api-key-here"

# Application
NEXT_PUBLIC_APP_URL="http://localhost:3000"
NODE_ENV="development"
NEXT_PUBLIC_ENVIRONMENT="development"
```

**Required for full functionality:**

- `JWT_SECRET`: Used for session management
- `DATABASE_URL`: Database connection string

**Optional:**

- `OPENAI_API_KEY`: Enables AI-powered recommendations (fallback used if missing)

### Code Quality

The project uses several tools to maintain code quality:

- **ESLint**: Linting with Next.js and TypeScript rules
- **Prettier**: Code formatting
- **Husky**: Git hooks for pre-commit checks
- **lint-staged**: Run linters on staged files
- **TypeScript**: Static type checking

## 🏗️ Architecture

### Microservices-Ready Design

The project is structured to support future microservices architecture:

- **Modular Components**: Loosely coupled, reusable components
- **Service Layer**: Abstracted API calls and business logic
- **Type Safety**: Comprehensive TypeScript coverage
- **Configuration**: Environment-based configuration management

### Design System

Built with a comprehensive design system:

- **Color Palette**: HSL-based color system with dark mode support
- **Typography**: Inter font with display variants
- **Components**: shadcn/ui components with custom styling
- **Animations**: Smooth transitions and spring animations
- **Glassmorphism**: Modern glass-effect UI elements

## 🧪 Testing (Planned)

- **Unit Tests**: Jest + React Testing Library
- **Integration Tests**: API and database integration tests
- **E2E Tests**: Playwright for end-to-end testing
- **Performance Tests**: Load testing with Artillery

## 📈 Roadmap

### Phase 1: Foundation ✅

- [x] Next.js 14 setup with TypeScript
- [x] Tailwind CSS + shadcn/ui integration
- [x] Development tools configuration
- [x] Project structure and architecture

### Phase 2: Core Features ✅

- [x] Database schema and models (Prisma + SQLite)
- [x] Authentication system (JWT-based)
- [x] Carbon calculation engine (India-specific factors)
- [x] Basic UI components (shadcn/ui)
- [x] Dashboard with real-time data
- [x] AI-powered insights and recommendations

### Phase 3: AI Integration ✅

- [x] ML service infrastructure (FastAPI)
- [x] Prediction engine (LSTM models)
- [x] Recommendation system (OpenAI GPT integration)
- [x] Data integration platform

### Phase 4: Advanced Features (Planned)

- [ ] Mobile applications
- [ ] Enterprise features (multi-tenant)
- [ ] Gamification system
- [ ] Performance optimization
- [ ] Production deployment

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow the existing code style and conventions
- Write meaningful commit messages
- Add tests for new features
- Update documentation as needed
- Ensure all checks pass before submitting PR

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🌍 Environmental Impact

Aura Platform is committed to environmental sustainability:

- **Carbon Neutral Hosting**: Deployed on renewable energy infrastructure
- **Efficient Code**: Optimized for minimal resource consumption
- **Green Practices**: Following sustainable development practices
- **Impact Measurement**: Tracking our own platform's environmental impact

## 📞 Support

- **Documentation**: [Coming Soon]
- **Issues**: [GitHub Issues](https://github.com/your-org/aura-platform/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/aura-platform/discussions)
- **Email**: support@auraplatform.com

---

**Building the future of carbon tracking with AI** 🌱✨
