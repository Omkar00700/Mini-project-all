import { PrismaClient } from "../generated/prisma";

const prisma = new PrismaClient();

async function testAnomalyDetectionSystem() {
  try {
    const demoUser = await prisma.user.findUnique({
      where: { email: "demo@aura.com" },
      select: { id: true, name: true, email: true },
    });

    if (!demoUser) {
      return;
    }

    const activityCount = await prisma.activityData.count({
      where: { userId: demoUser.id },
    });

    if (activityCount === 0) {
      return;
    }

    const categories = ["electricity", "vehicle", "waste", "water"];
    for (const category of categories) {
      const count = await prisma.activityData.count({
        where: { userId: demoUser.id, category },
      });
    }

    const anomalies = await prisma.anomaly.findMany({
      where: { userId: demoUser.id },
      orderBy: { createdAt: "desc" },
    });

    if (anomalies.length > 0) {
      anomalies.slice(0, 5).forEach((a, i) => {
        const date = new Date(a.date).toLocaleDateString();
      });

      for (const category of categories) {
        const count = anomalies.filter((a) => a.category === category).length;
        if (count > 0) {
        }
      }

      const severities = ["low", "medium", "high"];
      for (const severity of severities) {
        const count = anomalies.filter((a) => a.severity === severity).length;
        if (count > 0) {
        }
      }
    }

    const { runAnomalyDetectionForUser } = await import(
      "../src/services/analytics/anomaly-detection.service"
    );

    const result = await runAnomalyDetectionForUser(demoUser.id);

    const oldestActivity = await prisma.activityData.findFirst({
      where: { userId: demoUser.id },
      orderBy: { date: "asc" },
    });

    const newestActivity = await prisma.activityData.findFirst({
      where: { userId: demoUser.id },
      orderBy: { date: "desc" },
    });

    if (oldestActivity && newestActivity) {
      const oldest = new Date(oldestActivity.date).toLocaleDateString();
      const newest = new Date(newestActivity.date).toLocaleDateString();
      const daysDiff = Math.ceil(
        (new Date(newestActivity.date).getTime() -
          new Date(oldestActivity.date).getTime()) /
          (1000 * 60 * 60 * 24)
      );
    }

    for (const category of categories) {
      const activities = await prisma.activityData.findMany({
        where: { userId: demoUser.id, category },
        orderBy: { date: "asc" },
      });

      if (activities.length > 0) {
        const values = activities.map((a) => a.value);
        const sum = values.reduce((acc, v) => acc + v, 0);
        const mean = sum / values.length;
        const max = Math.max(...values);
        const min = Math.min(...values);
      }
    }
  } catch (error) {
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

testAnomalyDetectionSystem()
  .then(() => {
    process.exit(0);
  })
  .catch((error) => {
    process.exit(1);
  });
