const { neon } = require("@neondatabase/serverless");
const bcrypt = require("bcryptjs");
require("dotenv").config({ path: ".env.local" });

const NEON_URL = process.env.DATABASE_URL;
if (!NEON_URL) {
  process.exit(1);
}
const sql = neon(NEON_URL);

async function main() {
  const test = await sql`SELECT current_database(), current_user`;

  const demoPassword = await bcrypt.hash("demo123", 10);
  const adminPassword = await bcrypt.hash("admin123", 10);

  await sql`
    INSERT INTO users (id, email, password_hash, name, role, location, household, preferences, subscription, created_at, updated_at)
    VALUES (
      gen_random_uuid()::text,
      'admin@aura.com',
      ${adminPassword},
      'Admin User',
      'admin',
      '{"country":"India","region":"Maharashtra","city":"Mumbai"}'::jsonb,
      '{"size":2,"type":"couple"}'::jsonb,
      '{"units":"metric","privacy_level":"private","notifications":{"email":true,"push":true,"weekly_reports":true}}'::jsonb,
      '{"tier":"premium","features":["advanced_analytics","ai_predictions","admin"]}'::jsonb,
      NOW(),
      NOW()
    )
    ON CONFLICT (email) DO NOTHING
  `;

  // Demo User removed - only real users from database should appear in leaderboard

  // Removed goals seeding for demo user

  const [users] = await sql`SELECT COUNT(*) as count FROM users`;
  const [calcs] = await sql`SELECT COUNT(*) as count FROM carbon_calculations`;
  const [goals] = await sql`SELECT COUNT(*) as count FROM goals`;
}

main().catch(console.error);
