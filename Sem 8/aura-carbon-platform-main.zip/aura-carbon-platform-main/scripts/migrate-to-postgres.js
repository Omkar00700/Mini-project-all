#!/usr/bin/env node

const { execSync } = require("child_process");

function run(cmd, desc) {
  try {
    execSync(cmd, { stdio: "inherit" });
  } catch (err) {
    process.exit(1);
  }
}

if (!process.env.DATABASE_URL || process.env.DATABASE_URL.startsWith("file:")) {
  process.exit(1);
}

run("npx prisma generate", "Generate Prisma client for PostgreSQL");

run("npx prisma db push", "Push schema to PostgreSQL database");

run("npm run db:seed", "Seed initial data (emission factors, etc.)");
