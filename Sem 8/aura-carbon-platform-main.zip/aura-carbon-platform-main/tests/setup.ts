process.env.JWT_SECRET = "test-secret-for-jest";
import { PrismaClient } from "../generated/prisma";

// Polyfill for setImmediate (needed by Prisma in Jest jsdom environment)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(global as any).setImmediate =
  (global as any).setImmediate ||
  ((fn: (...args: unknown[]) => void) => setTimeout(fn, 0));

// Global Next.js app router mocks
jest.mock("next/headers", () => ({
  cookies: () => ({
    get: jest.fn().mockReturnValue({ value: "mock-token" }),
    set: jest.fn(),
    delete: jest.fn(),
    getAll: jest.fn(),
  }),
  headers: () => new Map(),
}));

jest.mock("next/navigation", () => ({
  redirect: jest.fn(),
  notFound: jest.fn(),
  useRouter: () => ({
    push: jest.fn(),
    replace: jest.fn(),
    prefetch: jest.fn(),
  }),
  usePathname: () => "/",
  useSearchParams: () => new URLSearchParams(),
}));

jest.mock("next/server", () => {
  return {
    NextResponse: {
      json: jest.fn((body, init) => ({
        body,
        status: init?.status || 200,
        cookies: { set: jest.fn(), delete: jest.fn(), get: jest.fn() },
      })),
      next: jest.fn(),
      redirect: jest.fn(),
    },
    NextRequest: jest.fn().mockImplementation(() => ({
      headers: new Map(),
      cookies: { get: jest.fn(), set: jest.fn(), delete: jest.fn() },
      url: "http://localhost:3000",
      json: jest.fn().mockResolvedValue({}),
    })),
  };
});

// Only initialize Prisma for tests that need it (skip for CI/CD workflow tests)
const shouldInitializePrisma = !expect.getState().testPath?.includes("ci-cd");

let prisma: PrismaClient | undefined;

if (shouldInitializePrisma) {
  // Global test setup
  prisma = new PrismaClient({
    datasources: {
      db: {
        url: process.env.DATABASE_URL || "file:./test.db",
      },
    },
  });

  beforeAll(async () => {
    // Connect to the database
    await prisma?.$connect();
  });

  afterAll(async () => {
    // Clean up and disconnect
    await prisma?.$disconnect();
  });

  // Make prisma available globally for tests
  global.prisma = prisma;

  // Clean database between tests
  beforeEach(async () => {
    if (!prisma) return;

    // Clean up all tables in reverse order to handle foreign key constraints
    const tablenames = await prisma.$queryRaw<Array<{ name: string }>>`
      SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_prisma_migrations';
    `;

    for (const { name } of tablenames) {
      await prisma.$executeRawUnsafe(`DELETE FROM ${name};`);
    }
  });
}
