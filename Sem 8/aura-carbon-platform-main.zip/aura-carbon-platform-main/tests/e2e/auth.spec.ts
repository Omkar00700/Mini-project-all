import { test, expect } from "@playwright/test";

test.describe("Authentication Flow", () => {
  // Use a predictable test user email
  const testEmail = `test-${Date.now()}@example.com`;
  const testPassword = "Password123!";

  test("should successfully register, login, and access dashboard", async ({
    page,
  }) => {
    // 1. Navigation to Home
    await page.goto("/");

    // 2. Click Start Calculation / Login
    await page.click("text=Start Calculation");

    // Should be on register/login page
    await expect(page).toHaveURL(/.*\/auth\/(login|register)/);

    // Switch to Register tab if not already on it
    if ((await page.locator("text=Create an Account").count()) === 0) {
      await page.click("text=Register");
    }

    // 3. Fill Registration Form
    await page.fill('input[name="name"]', "E2E Test User");
    await page.fill('input[name="email"]', testEmail);
    await page.fill('input[name="password"]', testPassword);

    // 4. Submit Registration
    await page.click('button[type="submit"]');

    // Upon successful auth, app should redirect to Dashboard or Onboarding
    await expect(page).toHaveURL(/.*(\/dashboard|\/onboarding)/, {
      timeout: 10000,
    });

    // 5. Verify HTTP-Only Cookie presence by checking API access
    // We navigate to an authenticated route to ensure the Edge Middleware passes us
    await page.goto("/api/auth/me");
    const authMeResult = await page.textContent("body");
    expect(authMeResult).toContain(testEmail);

    // 6. Test Logout
    await page.goto("/dashboard");
    // Open user menu
    await page.click('button[aria-haspopup="menu"]'); // Shadcn avatar dropdown
    await page.click("text=Log out");

    // Should be redirected to login
    await expect(page).toHaveURL(/.*\/auth\/login/);
  });
});
