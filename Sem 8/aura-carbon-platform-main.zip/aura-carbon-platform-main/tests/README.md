# Database Model Unit Tests

This directory contains comprehensive unit tests for all Prisma database models in the Aura Carbon Platform.

## Test Coverage

### User Model (`tests/models/user.test.ts`)

- ✅ User creation with valid data
- ✅ Email uniqueness constraint enforcement
- ✅ Required field validation
- ✅ User data updates
- ✅ User queries (by email, filters, counting)
- ✅ Cascade deletion of related records

### Organization Model (`tests/models/organization.test.ts`)

- ✅ Organization creation with valid data
- ✅ Required field validation
- ✅ Organization settings updates
- ✅ Cascade deletion to members and calculations

### OrganizationMember Model (`tests/models/organization.test.ts`)

- ✅ Member creation with valid data
- ✅ Unique constraint on organizationId + userId
- ✅ Foreign key validation
- ✅ Relationship loading (organization, user)
- ✅ Cascade deletion when user or organization is deleted

### CarbonCalculation Model (`tests/models/carbon-calculation.test.ts`)

- ✅ Calculation creation for users and organizations
- ✅ Required field validation
- ✅ Date range queries and filtering
- ✅ Aggregation operations (sum, average, count)
- ✅ Relationship loading (user, organization)
- ✅ Cascade deletion when user or organization is deleted

### EmissionFactor Model (`tests/models/emission-factor.test.ts`)

- ✅ Emission factor creation with valid data
- ✅ Optional validTo date handling
- ✅ Required field validation
- ✅ Queries by category, subcategory, and region
- ✅ Date range and confidence level filtering
- ✅ Index performance testing
- ✅ Value range validation (small to large values)
- ✅ Updates to factor values and metadata

### ActivityData Model (`tests/models/activity-data.test.ts`)

- ✅ Activity data creation with valid data
- ✅ Optional metadata handling
- ✅ Required field validation
- ✅ Foreign key validation
- ✅ Queries by user, date range, category, and source
- ✅ Aggregation and grouping operations
- ✅ Index performance testing
- ✅ Relationship loading (user)
- ✅ Cascade deletion when user is deleted
- ✅ Complex metadata structure handling
- ✅ Different value types and ranges

### ML Models (`tests/models/ml-models.test.ts`)

#### MlModel

- ✅ Model creation with performance metrics and deployment info
- ✅ Optional deployment info handling
- ✅ Unique constraint on name + version
- ✅ Queries by name, status, and type

#### Prediction

- ✅ Prediction creation with input/output data
- ✅ Optional confidence score handling
- ✅ Foreign key validation (user, model)
- ✅ Queries by user and prediction type
- ✅ Confidence score filtering
- ✅ Relationship loading (user, model)
- ✅ Cascade deletion when user or model is deleted

#### Recommendation

- ✅ Recommendation creation with impact and cost estimates
- ✅ Minimal data creation (optional fields)
- ✅ Difficulty score validation
- ✅ Queries by category, status, and impact level
- ✅ Status and user feedback updates
- ✅ Cascade deletion when user is deleted

## Test Infrastructure

### Setup (`tests/setup.ts`)

- Global Prisma client configuration
- Database connection management
- Automatic cleanup between tests
- SQLite test database setup

### Configuration (`jest.config.js`)

- TypeScript support with ts-jest
- Test environment configuration
- Coverage collection settings
- Module path mapping
- Single worker for database test isolation

## Running Tests

```bash
# Run all model tests
npm run test:models

# Run specific model test
npx jest tests/models/user.test.ts

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch
```

## Test Data Validation

The tests validate:

### Data Integrity

- ✅ Required field enforcement
- ✅ Unique constraint validation
- ✅ Foreign key relationship integrity
- ✅ Data type validation (JSON, dates, numbers)

### Constraint Enforcement

- ✅ Email uniqueness for users
- ✅ Organization member uniqueness
- ✅ Model name + version uniqueness
- ✅ Difficulty score range validation

### Relationship Management

- ✅ Cascade deletion behavior
- ✅ Relationship loading and joins
- ✅ Foreign key constraint enforcement

### Query Performance

- ✅ Index utilization testing
- ✅ Complex query performance
- ✅ Aggregation operations
- ✅ Date range queries

### Edge Cases

- ✅ Optional field handling
- ✅ Complex JSON metadata structures
- ✅ Large and small numeric values
- ✅ Date validation and ranges

## Coverage Summary

- **Total Test Suites**: 6
- **Total Tests**: 82
- **Models Covered**: 9 (User, Organization, OrganizationMember, CarbonCalculation, EmissionFactor, ActivityData, MlModel, Prediction, Recommendation)
- **Test Categories**: Creation, Validation, Queries, Updates, Relationships, Cascade Deletion, Performance

All tests pass successfully and provide comprehensive coverage of the database model functionality required for the Aura Carbon Platform.
