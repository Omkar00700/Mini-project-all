import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("ActivityData Model", () => {
  let prisma: PrismaClient;
  let testUser: any;

  beforeEach(async () => {
    prisma = global.prisma;

    // Create test user
    testUser = await prisma.user.create({
      data: {
        email: "activity@test.com",
        name: "Activity User",
        location: { country: "US", region: "CA", city: "SF" },
        household: { size: 1, type: "individual" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {},
        },
        subscription: { tier: "premium", features: ["detailed_tracking"] },
      },
    });
  });

  describe("ActivityData Creation", () => {
    it("should create activity data with valid data", async () => {
      const activityData = {
        userId: testUser.id,
        category: "transportation",
        subcategory: "car_gasoline",
        value: 150.5,
        unit: "km",
        date: new Date("2024-01-15"),
        source: "manual",
        metadata: {
          vehicle_type: "sedan",
          fuel_efficiency: 8.5,
          trip_purpose: "commute",
        },
      };

      const activity = await prisma.activityData.create({
        data: activityData,
      });

      expect(activity).toBeDefined();
      expect(activity.id).toBeDefined();
      expect(activity.userId).toBe(testUser.id);
      expect(activity.category).toBe(activityData.category);
      expect(activity.subcategory).toBe(activityData.subcategory);
      expect(activity.value).toBe(activityData.value);
      expect(activity.unit).toBe(activityData.unit);
      expect(activity.date).toEqual(activityData.date);
      expect(activity.source).toBe(activityData.source);
      expect(activity.metadata).toEqual(activityData.metadata);
      expect(activity.createdAt).toBeInstanceOf(Date);
    });

    it("should create activity data without metadata", async () => {
      const activityData = {
        userId: testUser.id,
        category: "energy",
        subcategory: "electricity",
        value: 250.0,
        unit: "kWh",
        date: new Date("2024-01-15"),
        source: "smart_meter",
        // metadata is optional
      };

      const activity = await prisma.activityData.create({
        data: activityData,
      });

      expect(activity.metadata).toBeNull();
    });

    it("should require all mandatory fields", async () => {
      await expect(
        prisma.activityData.create({
          data: {
            userId: testUser.id,
            category: "transportation",
            subcategory: "car",
            value: 100,
            unit: "km",
            // Missing date and source
          } as any,
        })
      ).rejects.toThrow();
    });

    it("should require valid user reference", async () => {
      await expect(
        prisma.activityData.create({
          data: {
            userId: "invalid-user-id",
            category: "transportation",
            subcategory: "car",
            value: 100,
            unit: "km",
            date: new Date(),
            source: "manual",
          },
        })
      ).rejects.toThrow();
    });
  });

  describe("ActivityData Queries", () => {
    beforeEach(async () => {
      // Create test activity data
      await prisma.activityData.createMany({
        data: [
          {
            userId: testUser.id,
            category: "transportation",
            subcategory: "car_gasoline",
            value: 50.0,
            unit: "km",
            date: new Date("2024-01-01"),
            source: "manual",
          },
          {
            userId: testUser.id,
            category: "transportation",
            subcategory: "public_transport",
            value: 25.0,
            unit: "km",
            date: new Date("2024-01-02"),
            source: "gps_tracking",
          },
          {
            userId: testUser.id,
            category: "energy",
            subcategory: "electricity",
            value: 150.0,
            unit: "kWh",
            date: new Date("2024-01-01"),
            source: "smart_meter",
          },
          {
            userId: testUser.id,
            category: "energy",
            subcategory: "natural_gas",
            value: 80.0,
            unit: "kWh",
            date: new Date("2024-01-01"),
            source: "utility_bill",
          },
          {
            userId: testUser.id,
            category: "food",
            subcategory: "meat_consumption",
            value: 2.5,
            unit: "kg",
            date: new Date("2024-01-03"),
            source: "manual",
          },
        ],
      });
    });

    it("should find activities by user and date range", async () => {
      const activities = await prisma.activityData.findMany({
        where: {
          userId: testUser.id,
          date: {
            gte: new Date("2024-01-01"),
            lte: new Date("2024-01-02"),
          },
        },
        orderBy: { date: "asc" },
      });

      expect(activities).toHaveLength(4); // 3 on Jan 1, 1 on Jan 2
    });

    it("should find activities by category", async () => {
      const transportationActivities = await prisma.activityData.findMany({
        where: {
          userId: testUser.id,
          category: "transportation",
        },
      });

      expect(transportationActivities).toHaveLength(2);
      expect(
        transportationActivities.every((a) => a.category === "transportation")
      ).toBe(true);
    });

    it("should find activities by category and subcategory", async () => {
      const carActivities = await prisma.activityData.findMany({
        where: {
          userId: testUser.id,
          category: "transportation",
          subcategory: "car_gasoline",
        },
      });

      expect(carActivities).toHaveLength(1);
      expect(carActivities[0].value).toBe(50.0);
    });

    it("should find activities by source", async () => {
      const manualActivities = await prisma.activityData.findMany({
        where: {
          userId: testUser.id,
          source: "manual",
        },
      });

      expect(manualActivities).toHaveLength(2); // car and food
    });

    it("should aggregate activity values", async () => {
      const transportationSum = await prisma.activityData.aggregate({
        where: {
          userId: testUser.id,
          category: "transportation",
        },
        _sum: { value: true },
        _count: true,
      });

      expect(transportationSum._sum.value).toBe(75.0); // 50 + 25
      expect(transportationSum._count).toBe(2);
    });

    it("should group activities by category", async () => {
      const groupedActivities = await prisma.activityData.groupBy({
        by: ["category"],
        where: { userId: testUser.id },
        _sum: { value: true },
        _count: true,
      });

      expect(groupedActivities).toHaveLength(3); // transportation, energy, food

      const transportationGroup = groupedActivities.find(
        (g) => g.category === "transportation"
      );
      expect(transportationGroup?._sum.value).toBe(75.0);
      expect(transportationGroup?._count).toBe(2);
    });
  });

  describe("ActivityData Indexes", () => {
    it("should efficiently query by userId and date", async () => {
      // Create many activities to test index performance
      const activitiesData = [];
      for (let i = 0; i < 1000; i++) {
        const date = new Date("2024-01-01");
        date.setDate(date.getDate() + (i % 365));

        activitiesData.push({
          userId: testUser.id,
          category: `category_${i % 5}`,
          subcategory: `subcategory_${i % 10}`,
          value: Math.random() * 100,
          unit: "unit",
          date: date,
          source: "automated",
        });
      }

      await prisma.activityData.createMany({
        data: activitiesData,
      });

      // Query should be fast due to index
      const startTime = Date.now();
      const activities = await prisma.activityData.findMany({
        where: {
          userId: testUser.id,
          date: {
            gte: new Date("2024-06-01"),
            lte: new Date("2024-06-30"),
          },
        },
      });
      const queryTime = Date.now() - startTime;

      expect(queryTime).toBeLessThan(100); // Should be fast
      expect(activities.length).toBeGreaterThan(0);
    });

    it("should efficiently query by category and subcategory", async () => {
      const activities = await prisma.activityData.findMany({
        where: {
          category: "transportation",
          subcategory: "car_gasoline",
        },
      });

      expect(activities.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("ActivityData Relationships", () => {
    it("should load user relationship", async () => {
      const activity = await prisma.activityData.create({
        data: {
          userId: testUser.id,
          category: "test",
          subcategory: "test",
          value: 100,
          unit: "test",
          date: new Date(),
          source: "test",
        },
      });

      const activityWithUser = await prisma.activityData.findUnique({
        where: { id: activity.id },
        include: { user: true },
      });

      expect(activityWithUser?.user?.email).toBe(testUser.email);
    });
  });

  describe("ActivityData Cascade Deletion", () => {
    it("should delete activities when user is deleted", async () => {
      await prisma.activityData.create({
        data: {
          userId: testUser.id,
          category: "test",
          subcategory: "test",
          value: 100,
          unit: "test",
          date: new Date(),
          source: "test",
        },
      });

      // Delete user
      await prisma.user.delete({
        where: { id: testUser.id },
      });

      // Verify activities are deleted
      const activities = await prisma.activityData.findMany({
        where: { userId: testUser.id },
      });
      expect(activities).toHaveLength(0);
    });
  });

  describe("ActivityData Value Types", () => {
    it("should handle different value types and ranges", async () => {
      const testCases = [
        { value: 0.001, description: "very small value" },
        { value: 0.0, description: "zero value" },
        { value: 1000000.5, description: "large value with decimal" },
        { value: 999999999, description: "very large integer" },
      ];

      for (const testCase of testCases) {
        const activity = await prisma.activityData.create({
          data: {
            userId: testUser.id,
            category: "test",
            subcategory: testCase.description,
            value: testCase.value,
            unit: "test",
            date: new Date(),
            source: "test",
          },
        });

        expect(activity.value).toBe(testCase.value);
      }
    });
  });

  describe("ActivityData Metadata", () => {
    it("should handle complex metadata structures", async () => {
      const complexMetadata = {
        location: {
          start: { lat: 37.7749, lng: -122.4194 },
          end: { lat: 37.7849, lng: -122.4094 },
        },
        vehicle: {
          make: "Toyota",
          model: "Prius",
          year: 2023,
          fuel_type: "hybrid",
        },
        conditions: {
          weather: "sunny",
          traffic: "moderate",
          temperature: 22.5,
        },
        tags: ["commute", "work", "regular_route"],
      };

      const activity = await prisma.activityData.create({
        data: {
          userId: testUser.id,
          category: "transportation",
          subcategory: "car_hybrid",
          value: 45.2,
          unit: "km",
          date: new Date(),
          source: "gps_tracking",
          metadata: complexMetadata,
        },
      });

      expect(activity.metadata).toEqual(complexMetadata);
    });
  });
});
