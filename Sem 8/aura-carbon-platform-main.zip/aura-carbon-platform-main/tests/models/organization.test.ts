import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("Organization Model", () => {
  let prisma: PrismaClient;

  beforeEach(() => {
    prisma = global.prisma;
  });

  describe("Organization Creation", () => {
    it("should create an organization with valid data", async () => {
      const orgData = {
        name: "Test Corporation",
        industry: "Technology",
        size: "enterprise",
        settings: {
          ghg_protocol_enabled: true,
          reporting_standards: ["CDP", "GRI"],
          default_currency: "USD",
        },
      };

      const organization = await prisma.organization.create({
        data: orgData,
      });

      expect(organization).toBeDefined();
      expect(organization.id).toBeDefined();
      expect(organization.name).toBe(orgData.name);
      expect(organization.industry).toBe(orgData.industry);
      expect(organization.size).toBe(orgData.size);
      expect(organization.settings).toEqual(orgData.settings);
      expect(organization.createdAt).toBeInstanceOf(Date);
      expect(organization.updatedAt).toBeInstanceOf(Date);
    });

    it("should require all mandatory fields", async () => {
      await expect(
        prisma.organization.create({
          data: {
            industry: "Technology",
            size: "startup",
            settings: {},
          } as any,
        })
      ).rejects.toThrow();
    });
  });

  describe("Organization Updates", () => {
    it("should update organization settings", async () => {
      const organization = await prisma.organization.create({
        data: {
          name: "Update Corp",
          industry: "Manufacturing",
          size: "sme",
          settings: { reporting_enabled: false },
        },
      });

      const updatedOrg = await prisma.organization.update({
        where: { id: organization.id },
        data: {
          settings: {
            reporting_enabled: true,
            compliance_standards: ["ISO 14001"],
          },
        },
      });

      expect(updatedOrg.settings).toEqual({
        reporting_enabled: true,
        compliance_standards: ["ISO 14001"],
      });
    });
  });

  describe("Organization Deletion", () => {
    it("should delete organization and cascade to members and calculations", async () => {
      // Create user first
      const user = await prisma.user.create({
        data: {
          email: "member@example.com",
          name: "Member User",
          location: { country: "US", region: "CA", city: "SF" },
          household: { size: 1, type: "individual" },
          preferences: {
            units: "metric",
            privacy_level: "private",
            notifications: {},
          },
          subscription: { tier: "free", features: [] },
        },
      });

      // Create organization
      const organization = await prisma.organization.create({
        data: {
          name: "Delete Corp",
          industry: "Technology",
          size: "startup",
          settings: {},
        },
      });

      // Create organization member
      await prisma.organizationMember.create({
        data: {
          organizationId: organization.id,
          userId: user.id,
          role: "admin",
          permissions: { can_edit: true },
        },
      });

      // Create carbon calculation
      await prisma.carbonCalculation.create({
        data: {
          organizationId: organization.id,
          periodStart: new Date("2024-01-01"),
          periodEnd: new Date("2024-01-31"),
          totalEmissions: 1000.5,
          breakdown: { scope1: 300, scope2: 400, scope3: 300.5 },
          metadata: { calculation_method: "ghg_protocol" },
        },
      });

      // Delete organization
      await prisma.organization.delete({
        where: { id: organization.id },
      });

      // Verify organization is deleted
      const deletedOrg = await prisma.organization.findUnique({
        where: { id: organization.id },
      });
      expect(deletedOrg).toBeNull();

      // Verify members are deleted (cascade)
      const members = await prisma.organizationMember.findMany({
        where: { organizationId: organization.id },
      });
      expect(members).toHaveLength(0);

      // Verify carbon calculations are deleted (cascade)
      const calculations = await prisma.carbonCalculation.findMany({
        where: { organizationId: organization.id },
      });
      expect(calculations).toHaveLength(0);
    });
  });
});

describe("OrganizationMember Model", () => {
  let prisma: PrismaClient;
  let testUser: any;
  let testOrganization: any;

  beforeEach(async () => {
    prisma = global.prisma;

    // Create test user
    testUser = await prisma.user.create({
      data: {
        email: "member@test.com",
        name: "Test Member",
        location: { country: "US", region: "CA", city: "SF" },
        household: { size: 1, type: "individual" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {},
        },
        subscription: { tier: "free", features: [] },
      },
    });

    // Create test organization
    testOrganization = await prisma.organization.create({
      data: {
        name: "Test Organization",
        industry: "Technology",
        size: "startup",
        settings: {},
      },
    });
  });

  describe("OrganizationMember Creation", () => {
    it("should create organization member with valid data", async () => {
      const memberData = {
        organizationId: testOrganization.id,
        userId: testUser.id,
        role: "admin",
        permissions: {
          can_edit: true,
          can_delete: false,
          can_invite: true,
        },
      };

      const member = await prisma.organizationMember.create({
        data: memberData,
      });

      expect(member).toBeDefined();
      expect(member.id).toBeDefined();
      expect(member.organizationId).toBe(memberData.organizationId);
      expect(member.userId).toBe(memberData.userId);
      expect(member.role).toBe(memberData.role);
      expect(member.permissions).toEqual(memberData.permissions);
      expect(member.joinedAt).toBeInstanceOf(Date);
    });

    it("should enforce unique constraint on organizationId and userId", async () => {
      const memberData = {
        organizationId: testOrganization.id,
        userId: testUser.id,
        role: "member",
        permissions: { can_edit: false },
      };

      // Create first membership
      await prisma.organizationMember.create({
        data: memberData,
      });

      // Attempt to create duplicate membership
      await expect(
        prisma.organizationMember.create({
          data: {
            ...memberData,
            role: "admin",
          },
        })
      ).rejects.toThrow();
    });

    it("should require valid foreign keys", async () => {
      await expect(
        prisma.organizationMember.create({
          data: {
            organizationId: "invalid-org-id",
            userId: testUser.id,
            role: "member",
            permissions: {},
          },
        })
      ).rejects.toThrow();

      await expect(
        prisma.organizationMember.create({
          data: {
            organizationId: testOrganization.id,
            userId: "invalid-user-id",
            role: "member",
            permissions: {},
          },
        })
      ).rejects.toThrow();
    });
  });

  describe("OrganizationMember Relationships", () => {
    it("should load organization and user relationships", async () => {
      const member = await prisma.organizationMember.create({
        data: {
          organizationId: testOrganization.id,
          userId: testUser.id,
          role: "member",
          permissions: { can_edit: false },
        },
      });

      const memberWithRelations = await prisma.organizationMember.findUnique({
        where: { id: member.id },
        include: {
          organization: true,
          user: true,
        },
      });

      expect(memberWithRelations?.organization.name).toBe(
        testOrganization.name
      );
      expect(memberWithRelations?.user.email).toBe(testUser.email);
    });
  });

  describe("OrganizationMember Cascade Deletion", () => {
    it("should delete member when user is deleted", async () => {
      const member = await prisma.organizationMember.create({
        data: {
          organizationId: testOrganization.id,
          userId: testUser.id,
          role: "member",
          permissions: {},
        },
      });

      // Delete user
      await prisma.user.delete({
        where: { id: testUser.id },
      });

      // Verify member is also deleted
      const deletedMember = await prisma.organizationMember.findUnique({
        where: { id: member.id },
      });
      expect(deletedMember).toBeNull();
    });

    it("should delete member when organization is deleted", async () => {
      const member = await prisma.organizationMember.create({
        data: {
          organizationId: testOrganization.id,
          userId: testUser.id,
          role: "member",
          permissions: {},
        },
      });

      // Delete organization
      await prisma.organization.delete({
        where: { id: testOrganization.id },
      });

      // Verify member is also deleted
      const deletedMember = await prisma.organizationMember.findUnique({
        where: { id: member.id },
      });
      expect(deletedMember).toBeNull();
    });
  });
});
