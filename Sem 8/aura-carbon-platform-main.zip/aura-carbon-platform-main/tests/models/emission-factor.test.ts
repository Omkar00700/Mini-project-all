import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("EmissionFactor Model", () => {
  let prisma: PrismaClient;

  beforeEach(() => {
    prisma = global.prisma;
  });

  describe("EmissionFactor Creation", () => {
    it("should create emission factor with valid data", async () => {
      const factorData = {
        category: "transportation",
        subcategory: "passenger_car_gasoline",
        region: "US",
        value: 0.404,
        unit: "kg CO2e/km",
        source: "EPA 2024",
        confidenceLevel: 0.95,
        validFrom: new Date("2024-01-01"),
        validTo: new Date("2024-12-31"),
      };

      const factor = await prisma.emissionFactor.create({
        data: factorData,
      });

      expect(factor).toBeDefined();
      expect(factor.id).toBeDefined();
      expect(factor.category).toBe(factorData.category);
      expect(factor.subcategory).toBe(factorData.subcategory);
      expect(factor.region).toBe(factorData.region);
      expect(factor.value).toBe(factorData.value);
      expect(factor.unit).toBe(factorData.unit);
      expect(factor.source).toBe(factorData.source);
      expect(factor.confidenceLevel).toBe(factorData.confidenceLevel);
      expect(factor.validFrom).toEqual(factorData.validFrom);
      expect(factor.validTo).toEqual(factorData.validTo);
      expect(factor.createdAt).toBeInstanceOf(Date);
    });

    it("should create emission factor without validTo date", async () => {
      const factorData = {
        category: "energy",
        subcategory: "electricity_grid",
        region: "CA",
        value: 0.233,
        unit: "kg CO2e/kWh",
        source: "CARB 2024",
        validFrom: new Date("2024-01-01"),
        // validTo is optional
      };

      const factor = await prisma.emissionFactor.create({
        data: factorData,
      });

      expect(factor.validTo).toBeNull();
    });

    it("should require all mandatory fields", async () => {
      await expect(
        prisma.emissionFactor.create({
          data: {
            category: "transportation",
            subcategory: "car",
            region: "US",
            value: 0.5,
            unit: "kg CO2e/km",
            // Missing source and validFrom
          } as any,
        })
      ).rejects.toThrow();
    });
  });

  describe("EmissionFactor Queries", () => {
    beforeEach(async () => {
      // Create test emission factors
      await prisma.emissionFactor.createMany({
        data: [
          {
            category: "transportation",
            subcategory: "passenger_car_gasoline",
            region: "US",
            value: 0.404,
            unit: "kg CO2e/km",
            source: "EPA 2024",
            confidenceLevel: 0.95,
            validFrom: new Date("2024-01-01"),
            validTo: new Date("2024-12-31"),
          },
          {
            category: "transportation",
            subcategory: "passenger_car_electric",
            region: "US",
            value: 0.18,
            unit: "kg CO2e/km",
            source: "EPA 2024",
            confidenceLevel: 0.9,
            validFrom: new Date("2024-01-01"),
            validTo: new Date("2024-12-31"),
          },
          {
            category: "energy",
            subcategory: "electricity_grid",
            region: "CA",
            value: 0.233,
            unit: "kg CO2e/kWh",
            source: "CARB 2024",
            confidenceLevel: 0.98,
            validFrom: new Date("2024-01-01"),
          },
          {
            category: "transportation",
            subcategory: "passenger_car_gasoline",
            region: "EU",
            value: 0.385,
            unit: "kg CO2e/km",
            source: "EEA 2024",
            confidenceLevel: 0.93,
            validFrom: new Date("2024-01-01"),
            validTo: new Date("2024-12-31"),
          },
        ],
      });
    });

    it("should find factors by category and subcategory", async () => {
      const factors = await prisma.emissionFactor.findMany({
        where: {
          category: "transportation",
          subcategory: "passenger_car_gasoline",
        },
      });

      expect(factors).toHaveLength(2); // US and EU
      expect(factors.every((f) => f.category === "transportation")).toBe(true);
      expect(
        factors.every((f) => f.subcategory === "passenger_car_gasoline")
      ).toBe(true);
    });

    it("should find factors by region", async () => {
      const usFactors = await prisma.emissionFactor.findMany({
        where: { region: "US" },
      });

      expect(usFactors).toHaveLength(2); // gasoline and electric cars
    });

    it("should find current valid factors", async () => {
      const currentDate = new Date("2024-06-15");
      const validFactors = await prisma.emissionFactor.findMany({
        where: {
          validFrom: { lte: currentDate },
          OR: [{ validTo: null }, { validTo: { gte: currentDate } }],
        },
      });

      expect(validFactors).toHaveLength(4); // All test factors are valid
    });

    it("should find factors with high confidence", async () => {
      const highConfidenceFactors = await prisma.emissionFactor.findMany({
        where: {
          confidenceLevel: { gte: 0.95 },
        },
      });

      expect(highConfidenceFactors).toHaveLength(2); // EPA gasoline and CARB electricity
    });

    it("should order factors by confidence level", async () => {
      const factors = await prisma.emissionFactor.findMany({
        orderBy: { confidenceLevel: "desc" },
      });

      expect(factors[0].confidenceLevel).toBe(0.98); // CARB electricity
      expect(factors[1].confidenceLevel).toBe(0.95); // EPA gasoline
    });
  });

  describe("EmissionFactor Indexes", () => {
    it("should efficiently query by category, subcategory, and region", async () => {
      // Create many factors to test index performance
      const factorsData = [];
      for (let i = 0; i < 100; i++) {
        factorsData.push({
          category: `category_${i % 10}`,
          subcategory: `subcategory_${i % 20}`,
          region: `region_${i % 5}`,
          value: Math.random(),
          unit: "kg CO2e/unit",
          source: `source_${i}`,
          validFrom: new Date("2024-01-01"),
        });
      }

      await prisma.emissionFactor.createMany({
        data: factorsData,
      });

      // Query should be fast due to index
      const startTime = Date.now();
      const factors = await prisma.emissionFactor.findMany({
        where: {
          category: "category_1",
          subcategory: "subcategory_5",
          region: "region_2",
        },
      });
      const queryTime = Date.now() - startTime;

      expect(queryTime).toBeLessThan(100); // Should be fast
      expect(factors.length).toBeGreaterThanOrEqual(0);
    });

    it("should efficiently query by date range", async () => {
      const factors = await prisma.emissionFactor.findMany({
        where: {
          validFrom: { gte: new Date("2024-01-01") },
          validTo: { lte: new Date("2024-12-31") },
        },
      });

      expect(factors.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("EmissionFactor Updates", () => {
    it("should update emission factor value and metadata", async () => {
      const factor = await prisma.emissionFactor.create({
        data: {
          category: "energy",
          subcategory: "natural_gas",
          region: "US",
          value: 0.202,
          unit: "kg CO2e/kWh",
          source: "EPA 2023",
          validFrom: new Date("2023-01-01"),
          validTo: new Date("2023-12-31"),
        },
      });

      const updatedFactor = await prisma.emissionFactor.update({
        where: { id: factor.id },
        data: {
          value: 0.198,
          source: "EPA 2024",
          confidenceLevel: 0.96,
          validFrom: new Date("2024-01-01"),
          validTo: new Date("2024-12-31"),
        },
      });

      expect(updatedFactor.value).toBe(0.198);
      expect(updatedFactor.source).toBe("EPA 2024");
      expect(updatedFactor.confidenceLevel).toBe(0.96);
    });
  });

  describe("EmissionFactor Validation", () => {
    it("should handle different value ranges", async () => {
      // Test very small values (e.g., for efficient technologies)
      const smallFactor = await prisma.emissionFactor.create({
        data: {
          category: "transportation",
          subcategory: "bicycle",
          region: "global",
          value: 0.001,
          unit: "kg CO2e/km",
          source: "Lifecycle Analysis 2024",
          validFrom: new Date("2024-01-01"),
        },
      });

      expect(smallFactor.value).toBe(0.001);

      // Test large values (e.g., for industrial processes)
      const largeFactor = await prisma.emissionFactor.create({
        data: {
          category: "industrial",
          subcategory: "cement_production",
          region: "global",
          value: 876.5,
          unit: "kg CO2e/tonne",
          source: "IPCC 2024",
          validFrom: new Date("2024-01-01"),
        },
      });

      expect(largeFactor.value).toBe(876.5);
    });
  });
});
