import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("ML Models", () => {
  let prisma: PrismaClient;
  let testUser: any;
  let testModel: any;

  beforeEach(async () => {
    prisma = global.prisma;

    // Create test user
    testUser = await prisma.user.create({
      data: {
        email: "ml@test.com",
        name: "ML User",
        location: { country: "US", region: "CA", city: "SF" },
        household: { size: 1, type: "individual" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {},
        },
        subscription: { tier: "premium", features: ["ai_predictions"] },
      },
    });
  });

  describe("MlModel", () => {
    describe("MlModel Creation", () => {
      it("should create ML model with valid data", async () => {
        const modelData = {
          name: "carbon_prediction_lstm",
          version: "1.2.0",
          type: "time_series_forecasting",
          status: "active",
          performanceMetrics: {
            accuracy: 0.92,
            mae: 45.2,
            rmse: 67.8,
            r2_score: 0.89,
            validation_loss: 0.034,
          },
          trainingDataInfo: {
            dataset_size: 50000,
            training_period: "2020-01-01 to 2023-12-31",
            features: [
              "historical_emissions",
              "seasonal_patterns",
              "user_demographics",
            ],
            target: "monthly_carbon_footprint",
          },
          deploymentInfo: {
            endpoint: "https://api.aura.com/ml/predict/carbon",
            container_image: "aura/carbon-predictor:1.2.0",
            resource_requirements: { cpu: "2", memory: "4Gi" },
          },
        };

        const model = await prisma.mlModel.create({
          data: modelData,
        });

        expect(model).toBeDefined();
        expect(model.id).toBeDefined();
        expect(model.name).toBe(modelData.name);
        expect(model.version).toBe(modelData.version);
        expect(model.type).toBe(modelData.type);
        expect(model.status).toBe(modelData.status);
        expect(model.performanceMetrics).toEqual(modelData.performanceMetrics);
        expect(model.trainingDataInfo).toEqual(modelData.trainingDataInfo);
        expect(model.deploymentInfo).toEqual(modelData.deploymentInfo);
        expect(model.createdAt).toBeInstanceOf(Date);
      });

      it("should create ML model without deployment info", async () => {
        const modelData = {
          name: "recommendation_engine",
          version: "0.1.0",
          type: "recommendation_system",
          status: "training",
          performanceMetrics: {
            precision: 0.85,
            recall: 0.78,
            f1_score: 0.81,
          },
          trainingDataInfo: {
            dataset_size: 25000,
            features: ["user_behavior", "carbon_data", "preferences"],
          },
          // deploymentInfo is optional
        };

        const model = await prisma.mlModel.create({
          data: modelData,
        });

        expect(model.deploymentInfo).toBeNull();
      });

      it("should enforce unique constraint on name and version", async () => {
        const modelData = {
          name: "duplicate_model",
          version: "1.0.0",
          type: "classification",
          status: "active",
          performanceMetrics: { accuracy: 0.9 },
          trainingDataInfo: { dataset_size: 1000 },
        };

        // Create first model
        await prisma.mlModel.create({ data: modelData });

        // Attempt to create duplicate
        await expect(
          prisma.mlModel.create({
            data: {
              ...modelData,
              status: "inactive",
            },
          })
        ).rejects.toThrow();
      });
    });

    describe("MlModel Queries", () => {
      beforeEach(async () => {
        // Create test models
        await prisma.mlModel.createMany({
          data: [
            {
              name: "carbon_predictor",
              version: "1.0.0",
              type: "regression",
              status: "active",
              performanceMetrics: { accuracy: 0.92 },
              trainingDataInfo: { dataset_size: 10000 },
            },
            {
              name: "carbon_predictor",
              version: "2.0.0",
              type: "regression",
              status: "active",
              performanceMetrics: { accuracy: 0.95 },
              trainingDataInfo: { dataset_size: 15000 },
            },
            {
              name: "recommendation_engine",
              version: "1.0.0",
              type: "recommendation",
              status: "deprecated",
              performanceMetrics: { precision: 0.8 },
              trainingDataInfo: { dataset_size: 5000 },
            },
          ],
        });

        testModel = await prisma.mlModel.findFirst({
          where: { name: "carbon_predictor", version: "2.0.0" },
        });
      });

      it("should find models by name", async () => {
        const models = await prisma.mlModel.findMany({
          where: { name: "carbon_predictor" },
          orderBy: { version: "desc" },
        });

        expect(models).toHaveLength(2);
        expect(models[0].version).toBe("2.0.0");
        expect(models[1].version).toBe("1.0.0");
      });

      it("should find active models", async () => {
        const activeModels = await prisma.mlModel.findMany({
          where: { status: "active" },
        });

        expect(activeModels).toHaveLength(2);
        expect(activeModels.every((m) => m.status === "active")).toBe(true);
      });

      it("should find models by type", async () => {
        const regressionModels = await prisma.mlModel.findMany({
          where: { type: "regression" },
        });

        expect(regressionModels).toHaveLength(2);
      });
    });
  });

  describe("Prediction", () => {
    beforeEach(async () => {
      testModel = await prisma.mlModel.create({
        data: {
          name: "test_predictor",
          version: "1.0.0",
          type: "forecasting",
          status: "active",
          performanceMetrics: { accuracy: 0.9 },
          trainingDataInfo: { dataset_size: 1000 },
        },
      });
    });

    describe("Prediction Creation", () => {
      it("should create prediction with valid data", async () => {
        const predictionData = {
          userId: testUser.id,
          modelId: testModel.id,
          predictionType: "carbon_footprint_forecast",
          inputData: {
            historical_data: [1200, 1150, 1300, 1250],
            user_profile: {
              location: "SF",
              household_size: 1,
              lifestyle: "eco_conscious",
            },
            forecast_horizon: 6,
          },
          outputData: {
            predictions: [1180, 1220, 1190, 1240, 1200, 1160],
            confidence_intervals: {
              lower: [1120, 1160, 1130, 1180, 1140, 1100],
              upper: [1240, 1280, 1250, 1300, 1260, 1220],
            },
            trend: "stable_with_slight_decrease",
          },
          confidenceScore: 0.87,
        };

        const prediction = await prisma.prediction.create({
          data: predictionData,
        });

        expect(prediction).toBeDefined();
        expect(prediction.id).toBeDefined();
        expect(prediction.userId).toBe(testUser.id);
        expect(prediction.modelId).toBe(testModel.id);
        expect(prediction.predictionType).toBe(predictionData.predictionType);
        expect(prediction.inputData).toEqual(predictionData.inputData);
        expect(prediction.outputData).toEqual(predictionData.outputData);
        expect(prediction.confidenceScore).toBe(predictionData.confidenceScore);
        expect(prediction.createdAt).toBeInstanceOf(Date);
      });

      it("should create prediction without confidence score", async () => {
        const predictionData = {
          userId: testUser.id,
          modelId: testModel.id,
          predictionType: "anomaly_detection",
          inputData: { activity_data: [100, 200, 150] },
          outputData: { anomaly_score: 0.15, is_anomaly: false },
        };

        const prediction = await prisma.prediction.create({
          data: predictionData,
        });

        expect(prediction.confidenceScore).toBeNull();
      });

      it("should require valid foreign keys", async () => {
        await expect(
          prisma.prediction.create({
            data: {
              userId: "invalid-user-id",
              modelId: testModel.id,
              predictionType: "test",
              inputData: {},
              outputData: {},
            },
          })
        ).rejects.toThrow();

        await expect(
          prisma.prediction.create({
            data: {
              userId: testUser.id,
              modelId: "invalid-model-id",
              predictionType: "test",
              inputData: {},
              outputData: {},
            },
          })
        ).rejects.toThrow();
      });
    });

    describe("Prediction Queries", () => {
      beforeEach(async () => {
        // Create test predictions
        await prisma.prediction.createMany({
          data: [
            {
              userId: testUser.id,
              modelId: testModel.id,
              predictionType: "monthly_forecast",
              inputData: { month: "january" },
              outputData: { prediction: 1200 },
              confidenceScore: 0.9,
            },
            {
              userId: testUser.id,
              modelId: testModel.id,
              predictionType: "weekly_forecast",
              inputData: { week: 1 },
              outputData: { prediction: 300 },
              confidenceScore: 0.85,
            },
            {
              userId: testUser.id,
              modelId: testModel.id,
              predictionType: "anomaly_detection",
              inputData: { data: [100, 200] },
              outputData: { anomaly: false },
            },
          ],
        });
      });

      it("should find predictions by user and type", async () => {
        const forecasts = await prisma.prediction.findMany({
          where: {
            userId: testUser.id,
            predictionType: { contains: "forecast" },
          },
        });

        expect(forecasts).toHaveLength(2);
      });

      it("should find predictions with high confidence", async () => {
        const highConfidencePredictions = await prisma.prediction.findMany({
          where: {
            userId: testUser.id,
            confidenceScore: { gte: 0.9 },
          },
        });

        expect(highConfidencePredictions).toHaveLength(1);
        expect(highConfidencePredictions[0].predictionType).toBe(
          "monthly_forecast"
        );
      });
    });

    describe("Prediction Relationships", () => {
      it("should load user and model relationships", async () => {
        const prediction = await prisma.prediction.create({
          data: {
            userId: testUser.id,
            modelId: testModel.id,
            predictionType: "test",
            inputData: {},
            outputData: {},
          },
        });

        const predictionWithRelations = await prisma.prediction.findUnique({
          where: { id: prediction.id },
          include: {
            user: true,
            model: true,
          },
        });

        expect(predictionWithRelations?.user?.email).toBe(testUser.email);
        expect(predictionWithRelations?.model?.name).toBe(testModel.name);
      });
    });

    describe("Prediction Cascade Deletion", () => {
      it("should delete predictions when user is deleted", async () => {
        await prisma.prediction.create({
          data: {
            userId: testUser.id,
            modelId: testModel.id,
            predictionType: "test",
            inputData: {},
            outputData: {},
          },
        });

        await prisma.user.delete({ where: { id: testUser.id } });

        const predictions = await prisma.prediction.findMany({
          where: { userId: testUser.id },
        });
        expect(predictions).toHaveLength(0);
      });

      it("should delete predictions when model is deleted", async () => {
        await prisma.prediction.create({
          data: {
            userId: testUser.id,
            modelId: testModel.id,
            predictionType: "test",
            inputData: {},
            outputData: {},
          },
        });

        await prisma.mlModel.delete({ where: { id: testModel.id } });

        const predictions = await prisma.prediction.findMany({
          where: { modelId: testModel.id },
        });
        expect(predictions).toHaveLength(0);
      });
    });
  });

  describe("Recommendation", () => {
    describe("Recommendation Creation", () => {
      it("should create recommendation with valid data", async () => {
        const recommendationData = {
          userId: testUser.id,
          title: "Switch to Electric Vehicle",
          description:
            "Based on your driving patterns, switching to an electric vehicle could reduce your transportation emissions by 60%.",
          category: "transportation",
          impactEstimate: 2400.5, // kg CO2e per year
          costEstimate: 35000.0,
          difficultyScore: 4,
          confidenceScore: 0.92,
          status: "active",
          userFeedback: {
            rating: 5,
            comment: "Very helpful recommendation",
            implementation_status: "considering",
          },
        };

        const recommendation = await prisma.recommendation.create({
          data: recommendationData,
        });

        expect(recommendation).toBeDefined();
        expect(recommendation.id).toBeDefined();
        expect(recommendation.userId).toBe(testUser.id);
        expect(recommendation.title).toBe(recommendationData.title);
        expect(recommendation.description).toBe(recommendationData.description);
        expect(recommendation.category).toBe(recommendationData.category);
        expect(recommendation.impactEstimate).toBe(
          recommendationData.impactEstimate
        );
        expect(recommendation.costEstimate).toBe(
          recommendationData.costEstimate
        );
        expect(recommendation.difficultyScore).toBe(
          recommendationData.difficultyScore
        );
        expect(recommendation.confidenceScore).toBe(
          recommendationData.confidenceScore
        );
        expect(recommendation.status).toBe(recommendationData.status);
        expect(recommendation.userFeedback).toEqual(
          recommendationData.userFeedback
        );
        expect(recommendation.createdAt).toBeInstanceOf(Date);
      });

      it("should create recommendation with minimal data", async () => {
        const recommendationData = {
          userId: testUser.id,
          title: "Reduce Meat Consumption",
          description: "Try having one meat-free day per week.",
          category: "food",
          impactEstimate: 156.0,
          // Optional fields: costEstimate, difficultyScore, confidenceScore, userFeedback
        };

        const recommendation = await prisma.recommendation.create({
          data: recommendationData,
        });

        expect(recommendation.costEstimate).toBeNull();
        expect(recommendation.difficultyScore).toBeNull();
        expect(recommendation.confidenceScore).toBeNull();
        expect(recommendation.userFeedback).toBeNull();
        expect(recommendation.status).toBe("active"); // Default value
      });

      it("should validate difficulty score range", async () => {
        // Note: This validation would typically be handled at the application level
        // Prisma schema only enforces the CHECK constraint if defined
        const validRecommendation = await prisma.recommendation.create({
          data: {
            userId: testUser.id,
            title: "Test Recommendation",
            description: "Test description",
            category: "test",
            impactEstimate: 100,
            difficultyScore: 3, // Valid range 1-5
          },
        });

        expect(validRecommendation.difficultyScore).toBe(3);
      });
    });

    describe("Recommendation Queries", () => {
      beforeEach(async () => {
        // Create test recommendations
        await prisma.recommendation.createMany({
          data: [
            {
              userId: testUser.id,
              title: "Solar Panels",
              description: "Install solar panels on your roof",
              category: "energy",
              impactEstimate: 3000.0,
              costEstimate: 15000.0,
              difficultyScore: 5,
              confidenceScore: 0.95,
              status: "active",
            },
            {
              userId: testUser.id,
              title: "LED Bulbs",
              description: "Replace incandescent bulbs with LED",
              category: "energy",
              impactEstimate: 200.0,
              costEstimate: 50.0,
              difficultyScore: 1,
              confidenceScore: 0.99,
              status: "active",
            },
            {
              userId: testUser.id,
              title: "Bike to Work",
              description: "Use bicycle for short commutes",
              category: "transportation",
              impactEstimate: 800.0,
              difficultyScore: 2,
              confidenceScore: 0.85,
              status: "implemented",
            },
          ],
        });
      });

      it("should find recommendations by category", async () => {
        const energyRecommendations = await prisma.recommendation.findMany({
          where: {
            userId: testUser.id,
            category: "energy",
          },
          orderBy: { impactEstimate: "desc" },
        });

        expect(energyRecommendations).toHaveLength(2);
        expect(energyRecommendations[0].title).toBe("Solar Panels");
        expect(energyRecommendations[1].title).toBe("LED Bulbs");
      });

      it("should find recommendations by status", async () => {
        const activeRecommendations = await prisma.recommendation.findMany({
          where: {
            userId: testUser.id,
            status: "active",
          },
        });

        expect(activeRecommendations).toHaveLength(2);
      });

      it("should find high-impact recommendations", async () => {
        const highImpactRecommendations = await prisma.recommendation.findMany({
          where: {
            userId: testUser.id,
            impactEstimate: { gte: 1000.0 },
          },
        });

        expect(highImpactRecommendations.length).toBeGreaterThanOrEqual(1); // At least Solar
      });

      it("should find easy recommendations", async () => {
        const easyRecommendations = await prisma.recommendation.findMany({
          where: {
            userId: testUser.id,
            difficultyScore: { lte: 2 },
          },
        });

        expect(easyRecommendations).toHaveLength(2); // LED and Bike
      });

      it("should order recommendations by impact-to-difficulty ratio", async () => {
        // This would typically be calculated at the application level
        const recommendations = await prisma.recommendation.findMany({
          where: { userId: testUser.id },
          orderBy: [{ impactEstimate: "desc" }, { difficultyScore: "asc" }],
        });

        expect(recommendations[0].title).toBe("Solar Panels"); // Highest impact
      });
    });

    describe("Recommendation Updates", () => {
      it("should update recommendation status and user feedback", async () => {
        const recommendation = await prisma.recommendation.create({
          data: {
            userId: testUser.id,
            title: "Test Recommendation",
            description: "Test description",
            category: "test",
            impactEstimate: 100,
            status: "active",
          },
        });

        const updatedRecommendation = await prisma.recommendation.update({
          where: { id: recommendation.id },
          data: {
            status: "implemented",
            userFeedback: {
              rating: 4,
              comment: "Successfully implemented",
              implementation_date: "2024-01-15",
              actual_impact: 95.5,
            },
          },
        });

        expect(updatedRecommendation.status).toBe("implemented");
        expect(updatedRecommendation.userFeedback).toEqual({
          rating: 4,
          comment: "Successfully implemented",
          implementation_date: "2024-01-15",
          actual_impact: 95.5,
        });
      });
    });

    describe("Recommendation Cascade Deletion", () => {
      it("should delete recommendations when user is deleted", async () => {
        await prisma.recommendation.create({
          data: {
            userId: testUser.id,
            title: "Test Recommendation",
            description: "Test description",
            category: "test",
            impactEstimate: 100,
          },
        });

        await prisma.user.delete({ where: { id: testUser.id } });

        const recommendations = await prisma.recommendation.findMany({
          where: { userId: testUser.id },
        });
        expect(recommendations).toHaveLength(0);
      });
    });
  });

  afterAll(async () => {
    // Cleanup persistent Neon DB records created during testing
    await prisma.prediction.deleteMany({
      where: { user: { email: "ml@test.com" } },
    });
    await prisma.recommendation.deleteMany({
      where: { user: { email: "ml@test.com" } },
    });
    await prisma.user.deleteMany({ where: { email: "ml@test.com" } });
  });
});
