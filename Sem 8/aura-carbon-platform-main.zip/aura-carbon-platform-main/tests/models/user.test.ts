import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("User Model", () => {
  let prisma: PrismaClient;

  beforeEach(() => {
    prisma = global.prisma;
  });

  describe("User Creation", () => {
    it("should create a user with valid data", async () => {
      const userData = {
        email: "test@example.com",
        name: "Test User",
        location: {
          country: "US",
          region: "California",
          city: "San Francisco",
          coordinates: [-122.4194, 37.7749],
        },
        household: {
          size: 2,
          type: "family",
          income_bracket: "middle",
        },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {
            email: true,
            push: false,
          },
        },
        subscription: {
          tier: "free",
          features: ["basic_tracking"],
        },
      };

      const user = await prisma.user.create({
        data: userData,
      });

      expect(user).toBeDefined();
      expect(user.id).toBeDefined();
      expect(user.email).toBe(userData.email);
      expect(user.name).toBe(userData.name);
      expect(user.location).toEqual(userData.location);
      expect(user.household).toEqual(userData.household);
      expect(user.preferences).toEqual(userData.preferences);
      expect(user.subscription).toEqual(userData.subscription);
      expect(user.createdAt).toBeInstanceOf(Date);
      expect(user.updatedAt).toBeInstanceOf(Date);
    });

    it("should enforce unique email constraint", async () => {
      const userData = {
        email: "duplicate@example.com",
        name: "User One",
        location: { country: "US", region: "CA", city: "SF" },
        household: { size: 1, type: "individual" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {},
        },
        subscription: { tier: "free", features: [] },
      };

      // Create first user
      await prisma.user.create({ data: userData });

      // Attempt to create second user with same email
      await expect(
        prisma.user.create({
          data: {
            ...userData,
            name: "User Two",
          },
        })
      ).rejects.toThrow();
    });

    it("should require all mandatory fields", async () => {
      // Test missing email
      await expect(
        prisma.user.create({
          data: {
            name: "Test User",
            location: {},
            household: {},
            preferences: {},
            subscription: {},
          } as any,
        })
      ).rejects.toThrow();

      // Test missing name
      await expect(
        prisma.user.create({
          data: {
            email: "test@example.com",
            location: {},
            household: {},
            preferences: {},
            subscription: {},
          } as any,
        })
      ).rejects.toThrow();
    });
  });

  describe("User Updates", () => {
    it("should update user data correctly", async () => {
      const user = await prisma.user.create({
        data: {
          email: "update@example.com",
          name: "Original Name",
          location: { country: "US", region: "CA", city: "SF" },
          household: { size: 1, type: "individual" },
          preferences: {
            units: "metric",
            privacy_level: "private",
            notifications: {},
          },
          subscription: { tier: "free", features: [] },
        },
      });

      const updatedUser = await prisma.user.update({
        where: { id: user.id },
        data: {
          name: "Updated Name",
          preferences: {
            units: "imperial",
            privacy_level: "public",
            notifications: { email: true },
          },
        },
      });

      expect(updatedUser.name).toBe("Updated Name");
      expect(updatedUser.preferences).toEqual({
        units: "imperial",
        privacy_level: "public",
        notifications: { email: true },
      });
      expect(updatedUser.updatedAt.getTime()).toBeGreaterThan(
        user.updatedAt.getTime()
      );
    });
  });

  describe("User Queries", () => {
    beforeEach(async () => {
      // Create test users
      await prisma.user.createMany({
        data: [
          {
            email: "user1@example.com",
            name: "User One",
            location: { country: "US", region: "CA", city: "SF" },
            household: { size: 1, type: "individual" },
            preferences: {
              units: "metric",
              privacy_level: "private",
              notifications: {},
            },
            subscription: { tier: "free", features: [] },
          },
          {
            email: "user2@example.com",
            name: "User Two",
            location: { country: "US", region: "NY", city: "NYC" },
            household: { size: 4, type: "family" },
            preferences: {
              units: "imperial",
              privacy_level: "public",
              notifications: {},
            },
            subscription: { tier: "premium", features: ["advanced_analytics"] },
          },
        ],
      });
    });

    it("should find user by email", async () => {
      const user = await prisma.user.findUnique({
        where: { email: "user1@example.com" },
      });

      expect(user).toBeDefined();
      expect(user?.name).toBe("User One");
    });

    it("should find users with filters", async () => {
      const users = await prisma.user.findMany({
        where: {
          name: {
            contains: "User",
          },
        },
      });

      expect(users).toHaveLength(2);
    });

    it("should count users correctly", async () => {
      const count = await prisma.user.count();
      expect(count).toBe(2);
    });
  });

  describe("User Deletion", () => {
    it("should delete user and cascade to related records", async () => {
      const user = await prisma.user.create({
        data: {
          email: "delete@example.com",
          name: "Delete User",
          location: { country: "US", region: "CA", city: "SF" },
          household: { size: 1, type: "individual" },
          preferences: {
            units: "metric",
            privacy_level: "private",
            notifications: {},
          },
          subscription: { tier: "free", features: [] },
        },
      });

      // Create related activity data
      await prisma.activityData.create({
        data: {
          userId: user.id,
          category: "transportation",
          subcategory: "car",
          value: 100,
          unit: "km",
          date: new Date(),
          source: "manual",
        },
      });

      // Delete user
      await prisma.user.delete({
        where: { id: user.id },
      });

      // Verify user is deleted
      const deletedUser = await prisma.user.findUnique({
        where: { id: user.id },
      });
      expect(deletedUser).toBeNull();

      // Verify related activity data is also deleted (cascade)
      const activityData = await prisma.activityData.findMany({
        where: { userId: user.id },
      });
      expect(activityData).toHaveLength(0);
    });
  });
});
