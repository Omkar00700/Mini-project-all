import { describe, it, expect, beforeEach } from "@jest/globals";
import { PrismaClient } from "../../generated/prisma";

describe("CarbonCalculation Model", () => {
  let prisma: PrismaClient;
  let testUser: any;
  let testOrganization: any;

  beforeEach(async () => {
    prisma = global.prisma;

    // Create test user
    testUser = await prisma.user.create({
      data: {
        email: "carbon@test.com",
        name: "Carbon User",
        location: { country: "US", region: "CA", city: "SF" },
        household: { size: 2, type: "family" },
        preferences: {
          units: "metric",
          privacy_level: "private",
          notifications: {},
        },
        subscription: { tier: "premium", features: ["advanced_analytics"] },
      },
    });

    // Create test organization
    testOrganization = await prisma.organization.create({
      data: {
        name: "Carbon Corp",
        industry: "Manufacturing",
        size: "enterprise",
        settings: { ghg_protocol: true },
      },
    });
  });

  describe("CarbonCalculation Creation", () => {
    it("should create carbon calculation for user", async () => {
      const calculationData = {
        userId: testUser.id,
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-01-31"),
        totalEmissions: 2500.75,
        breakdown: {
          transportation: 800.25,
          energy: 600.5,
          food: 500.0,
          consumption: 400.0,
          waste: 200.0,
        },
        confidenceScore: 0.85,
        metadata: {
          calculation_method: "ai_enhanced",
          emission_factors_version: "2024.1",
          data_quality_score: 0.9,
          missing_data_percentage: 5.2,
        },
      };

      const calculation = await prisma.carbonCalculation.create({
        data: calculationData,
      });

      expect(calculation).toBeDefined();
      expect(calculation.id).toBeDefined();
      expect(calculation.userId).toBe(testUser.id);
      expect(calculation.organizationId).toBeNull();
      expect(calculation.totalEmissions).toBe(2500.75);
      expect(calculation.breakdown).toEqual(calculationData.breakdown);
      expect(calculation.confidenceScore).toBe(0.85);
      expect(calculation.metadata).toEqual(calculationData.metadata);
      expect(calculation.createdAt).toBeInstanceOf(Date);
    });

    it("should create carbon calculation for organization", async () => {
      const calculationData = {
        organizationId: testOrganization.id,
        periodStart: new Date("2024-01-01"),
        periodEnd: new Date("2024-12-31"),
        totalEmissions: 50000.0,
        breakdown: {
          scope1: 15000.0,
          scope2: 20000.0,
          scope3: 15000.0,
        },
        confidenceScore: 0.95,
        metadata: {
          calculation_method: "ghg_protocol",
          verification_status: "third_party_verified",
          reporting_standards: ["CDP", "GRI", "TCFD"],
        },
      };

      const calculation = await prisma.carbonCalculation.create({
        data: calculationData,
      });

      expect(calculation.organizationId).toBe(testOrganization.id);
      expect(calculation.userId).toBeNull();
      expect(calculation.totalEmissions).toBe(50000.0);
    });

    it("should require mandatory fields", async () => {
      await expect(
        prisma.carbonCalculation.create({
          data: {
            userId: testUser.id,
            periodStart: new Date("2024-01-01"),
            // Missing periodEnd, totalEmissions, breakdown, metadata
          } as any,
        })
      ).rejects.toThrow();
    });

    it("should validate period dates", async () => {
      const calculationData = {
        userId: testUser.id,
        periodStart: new Date("2024-02-01"),
        periodEnd: new Date("2024-01-01"), // End before start
        totalEmissions: 1000,
        breakdown: { total: 1000 },
        metadata: {},
      };

      // Note: This test depends on application-level validation
      // Prisma itself doesn't enforce date logic constraints
      const calculation = await prisma.carbonCalculation.create({
        data: calculationData,
      });

      expect(calculation.periodStart.getTime()).toBeGreaterThan(
        calculation.periodEnd.getTime()
      );
    });
  });

  describe("CarbonCalculation Queries", () => {
    beforeEach(async () => {
      // Create multiple calculations for testing
      await prisma.carbonCalculation.createMany({
        data: [
          {
            userId: testUser.id,
            periodStart: new Date("2024-01-01"),
            periodEnd: new Date("2024-01-31"),
            totalEmissions: 1000,
            breakdown: { transportation: 500, energy: 500 },
            metadata: { month: "january" },
          },
          {
            userId: testUser.id,
            periodStart: new Date("2024-02-01"),
            periodEnd: new Date("2024-02-29"),
            totalEmissions: 1200,
            breakdown: { transportation: 600, energy: 600 },
            metadata: { month: "february" },
          },
          {
            organizationId: testOrganization.id,
            periodStart: new Date("2024-01-01"),
            periodEnd: new Date("2024-03-31"),
            totalEmissions: 25000,
            breakdown: { scope1: 8000, scope2: 10000, scope3: 7000 },
            metadata: { quarter: "Q1" },
          },
        ],
      });
    });

    it("should find calculations by user", async () => {
      const userCalculations = await prisma.carbonCalculation.findMany({
        where: { userId: testUser.id },
        orderBy: { periodStart: "asc" },
      });

      expect(userCalculations).toHaveLength(2);
      expect(userCalculations[0].totalEmissions).toBe(1000);
      expect(userCalculations[1].totalEmissions).toBe(1200);
    });

    it("should find calculations by organization", async () => {
      const orgCalculations = await prisma.carbonCalculation.findMany({
        where: { organizationId: testOrganization.id },
      });

      expect(orgCalculations).toHaveLength(1);
      expect(orgCalculations[0].totalEmissions).toBe(25000);
    });

    it("should filter calculations by date range", async () => {
      const calculations = await prisma.carbonCalculation.findMany({
        where: {
          periodStart: {
            gte: new Date("2024-01-01"),
          },
          periodEnd: {
            lte: new Date("2024-02-29"),
          },
        },
      });

      expect(calculations).toHaveLength(2); // January and February user calculations
    });

    it("should aggregate emissions data", async () => {
      const aggregation = await prisma.carbonCalculation.aggregate({
        where: { userId: testUser.id },
        _sum: { totalEmissions: true },
        _avg: { totalEmissions: true },
        _count: true,
      });

      expect(aggregation._sum.totalEmissions).toBe(2200); // 1000 + 1200
      expect(aggregation._avg.totalEmissions).toBe(1100);
      expect(aggregation._count).toBe(2);
    });
  });

  describe("CarbonCalculation Relationships", () => {
    it("should load user relationship", async () => {
      const calculation = await prisma.carbonCalculation.create({
        data: {
          userId: testUser.id,
          periodStart: new Date("2024-01-01"),
          periodEnd: new Date("2024-01-31"),
          totalEmissions: 1000,
          breakdown: {},
          metadata: {},
        },
      });

      const calculationWithUser = await prisma.carbonCalculation.findUnique({
        where: { id: calculation.id },
        include: { user: true },
      });

      expect(calculationWithUser?.user?.email).toBe(testUser.email);
    });

    it("should load organization relationship", async () => {
      const calculation = await prisma.carbonCalculation.create({
        data: {
          organizationId: testOrganization.id,
          periodStart: new Date("2024-01-01"),
          periodEnd: new Date("2024-01-31"),
          totalEmissions: 10000,
          breakdown: {},
          metadata: {},
        },
      });

      const calculationWithOrg = await prisma.carbonCalculation.findUnique({
        where: { id: calculation.id },
        include: { organization: true },
      });

      expect(calculationWithOrg?.organization?.name).toBe(
        testOrganization.name
      );
    });
  });

  describe("CarbonCalculation Cascade Deletion", () => {
    it("should delete calculations when user is deleted", async () => {
      await prisma.carbonCalculation.create({
        data: {
          userId: testUser.id,
          periodStart: new Date("2024-01-01"),
          periodEnd: new Date("2024-01-31"),
          totalEmissions: 1000,
          breakdown: {},
          metadata: {},
        },
      });

      // Delete user
      await prisma.user.delete({
        where: { id: testUser.id },
      });

      // Verify calculations are deleted
      const calculations = await prisma.carbonCalculation.findMany({
        where: { userId: testUser.id },
      });
      expect(calculations).toHaveLength(0);
    });

    it("should delete calculations when organization is deleted", async () => {
      await prisma.carbonCalculation.create({
        data: {
          organizationId: testOrganization.id,
          periodStart: new Date("2024-01-01"),
          periodEnd: new Date("2024-01-31"),
          totalEmissions: 10000,
          breakdown: {},
          metadata: {},
        },
      });

      // Delete organization
      await prisma.organization.delete({
        where: { id: testOrganization.id },
      });

      // Verify calculations are deleted
      const calculations = await prisma.carbonCalculation.findMany({
        where: { organizationId: testOrganization.id },
      });
      expect(calculations).toHaveLength(0);
    });
  });
});
