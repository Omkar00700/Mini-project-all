/**
 * Bug Condition Exploration Test for CI/CD Pipeline Fixes
 *
 * **Validates: Requirements 2.1, 2.2, 2.3**
 *
 * CRITICAL: This test MUST FAIL on unfixed code - failure confirms the bugs exist
 * DO NOT attempt to fix the test or the code when it fails
 *
 * This test encodes the expected behavior - it will validate the fix when it passes after implementation
 * GOAL: Surface counterexamples that demonstrate the bugs exist
 */

import { describe, test, expect } from "@jest/globals";
import * as fc from "fast-check";
import * as fs from "fs";
import * as path from "path";

describe("Bug Condition Exploration - CI/CD Pipeline Fixes", () => {
  /**
   * Property 1: Bug Condition - Pipeline Fails Without Required Variables
   *
   * **Validates: Requirements 2.1, 2.2, 2.3**
   *
   * This property tests that the CI pipeline completes successfully even when:
   * 1. DIRECT_URL is not configured (Bug 1 - database migrations)
   * 2. psutil is not installed (Bug 2 - ML service dependencies)
   *
   * On UNFIXED code, this test will FAIL because:
   * - Prisma migration will fail with "DIRECT_URL environment variable is not set"
   * - ML tests will fail with "ImportError: No module named 'psutil'"
   *
   * On FIXED code, this test will PASS because:
   * - Migration step will be skipped gracefully when DIRECT_URL is absent
   * - psutil will be in requirements.txt and installed
   */
  test("Property 1: Pipeline completes successfully without DIRECT_URL and with all ML dependencies", () => {
    fc.assert(
      fc.property(
        // Generate test scenarios for CI pipeline execution
        fc.record({
          // Simulate CI environment without DIRECT_URL
          hasDIRECT_URL: fc.constant(false),
          // Simulate checking for psutil in requirements
          checkPsutilInRequirements: fc.constant(true),
        }),
        (scenario) => {
          // Test Bug 1: Check if workflow handles missing DIRECT_URL
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Check if migration step is conditional or removed
          const hasMigrationStep = workflowContent.includes(
            "npx prisma migrate deploy"
          );

          if (hasMigrationStep) {
            // If migration step exists, it should be conditional on DIRECT_URL
            const migrationStepMatch = workflowContent.match(
              /- name: Run database migrations[\s\S]*?run: npx prisma migrate deploy/
            );

            if (migrationStepMatch) {
              const migrationSection = migrationStepMatch[0];
              // Check if there's a conditional (if: env.DIRECT_URL != '')
              const hasConditional =
                migrationSection.includes("if:") &&
                (migrationSection.includes("DIRECT_URL") ||
                  migrationSection.includes("env.DIRECT_URL"));

              expect(hasConditional).toBe(true);
            }
          }

          // Test Bug 2: Check if psutil is in ML service requirements
          const requirementsPath = path.join(
            process.cwd(),
            "ml-service/requirements.txt"
          );
          const requirementsContent = fs.readFileSync(
            requirementsPath,
            "utf-8"
          );

          // psutil should be present in requirements.txt
          const hasPsutil = requirementsContent.includes("psutil");
          expect(hasPsutil).toBe(true);

          // Both conditions must be satisfied for the pipeline to work
          return true;
        }
      ),
      {
        numRuns: 10, // Run 10 times to ensure consistency
        verbose: true,
      }
    );
  });

  /**
   * Additional test: Verify actual CI workflow behavior
   *
   * This test simulates what happens in CI by checking the workflow file
   * and requirements.txt to confirm the bugs exist or are fixed.
   */
  test("Verify CI workflow migration step is conditional on DIRECT_URL", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Check if migration step exists
    const hasMigrationStep = workflowContent.includes(
      "npx prisma migrate deploy"
    );

    if (hasMigrationStep) {
      // Extract the migration step section
      const lines = workflowContent.split("\n");
      let migrationStepIndex = -1;
      let migrationStepIndent = 0;

      for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes("Run database migrations")) {
          migrationStepIndex = i;
          migrationStepIndent = lines[i].search(/\S/);
          break;
        }
      }

      if (migrationStepIndex !== -1) {
        // Look for the 'if:' condition in the step
        let hasConditional = false;
        let hasDirectUrlCheck = false;

        // Check the step and a few lines before it for conditional
        for (
          let i = Math.max(0, migrationStepIndex - 2);
          i < Math.min(lines.length, migrationStepIndex + 5);
          i++
        ) {
          const line = lines[i];
          if (line.trim().startsWith("if:")) {
            hasConditional = true;
            if (line.includes("DIRECT_URL")) {
              hasDirectUrlCheck = true;
            }
          }
        }

        // The migration step should have a conditional check for DIRECT_URL
        expect(hasConditional && hasDirectUrlCheck).toBe(true);
      }
    } else {
      // If migration step is removed entirely, that's also a valid fix
      // Test passes in this case
      expect(hasMigrationStep).toBe(false);
    }
  });

  test("Verify psutil is in ML service requirements.txt", () => {
    const requirementsPath = path.join(
      process.cwd(),
      "ml-service/requirements.txt"
    );
    const requirementsContent = fs.readFileSync(requirementsPath, "utf-8");

    // psutil should be present in requirements.txt
    const hasPsutil = requirementsContent.includes("psutil");

    // This will FAIL on unfixed code (psutil is missing)
    // This will PASS on fixed code (psutil is added)
    expect(hasPsutil).toBe(true);
  });
});
