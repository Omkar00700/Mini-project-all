/**
 * Preservation Property Tests for CI/CD Pipeline Fixes
 *
 * **Validates: Requirements 3.1, 3.2, 3.3, 3.4**
 *
 * IMPORTANT: Follow observation-first methodology
 * These tests observe behavior on UNFIXED code when DIRECT_URL IS configured
 * and all dependencies are present.
 *
 * EXPECTED OUTCOME: Tests PASS on unfixed code (confirms baseline behavior to preserve)
 *
 * These tests ensure that when the fix is applied, all existing pipeline behavior
 * remains unchanged for successful pipeline runs with complete configuration.
 *
 * @jest-environment node
 */

import * as fc from "fast-check";
import * as fs from "fs";
import * as path from "path";

describe("Preservation Properties - CI/CD Pipeline Behavior With Full Configuration", () => {
  /**
   * Property 2: Preservation - Pipeline Behavior With Full Configuration
   *
   * **Validates: Requirements 3.1, 3.2, 3.3, 3.4**
   *
   * This property verifies that when DIRECT_URL IS configured and all dependencies
   * are present, the pipeline behaves exactly as it did before any fixes.
   *
   * Key behaviors to preserve:
   * - Database migrations run successfully when DIRECT_URL is configured (3.1)
   * - Test execution and coverage reporting work correctly (3.2)
   * - Build, Docker, and deployment jobs execute in proper sequence (3.3, 3.4)
   * - All environment variables and job dependencies function correctly
   */
  test("Property 2.1: Database migrations run when DIRECT_URL is configured", () => {
    fc.assert(
      fc.property(
        // Generate scenarios with DIRECT_URL configured
        fc.record({
          hasDIRECT_URL: fc.constant(true),
          hasDATABASE_URL: fc.constant(true),
        }),
        (scenario) => {
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Verify migration step exists in the workflow
          const hasMigrationStep = workflowContent.includes(
            "npx prisma migrate deploy"
          );
          expect(hasMigrationStep).toBe(true);

          // Verify the test job has the migration step
          const testJobMatch = workflowContent.match(
            /test:[\s\S]*?(?=\n  \w+:|$)/
          );
          if (testJobMatch) {
            const testJobContent = testJobMatch[0];
            expect(testJobContent).toContain("npx prisma migrate deploy");
          }

          return true;
        }
      ),
      {
        numRuns: 10,
        verbose: true,
      }
    );
  });

  test("Property 2.2: Prisma client generation step exists and runs before migrations", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Verify Prisma client generation exists
    const hasGenerateStep = workflowContent.includes("npx prisma generate");
    expect(hasGenerateStep).toBe(true);

    // Verify the order: generate should come before migrate
    const generateIndex = workflowContent.indexOf("npx prisma generate");
    const migrateIndex = workflowContent.indexOf("npx prisma migrate deploy");

    if (generateIndex !== -1 && migrateIndex !== -1) {
      expect(generateIndex).toBeLessThan(migrateIndex);
    }
  });

  test("Property 2.3: Test job includes database seeding step", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Verify seed step exists
    const hasSeedStep =
      workflowContent.includes("npm run db:seed") ||
      workflowContent.includes("Seed test data");
    expect(hasSeedStep).toBe(true);
  });

  test("Property 2.4: Test job runs tests with coverage", () => {
    fc.assert(
      fc.property(
        fc.record({
          testJobExists: fc.constant(true),
        }),
        (scenario) => {
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Verify test execution with coverage
          const hasTestCoverage =
            workflowContent.includes("npm run test:coverage") ||
            workflowContent.includes("Run tests with coverage");
          expect(hasTestCoverage).toBe(true);

          // Verify coverage upload step exists
          const hasCoverageUpload =
            workflowContent.includes("codecov/codecov-action") ||
            workflowContent.includes("Upload coverage report");
          expect(hasCoverageUpload).toBe(true);

          return true;
        }
      ),
      {
        numRuns: 5,
        verbose: true,
      }
    );
  });

  test("Property 2.5: ML service test job executes with pytest", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Verify ML test job exists
    const hasMLTestJob =
      workflowContent.includes("test-ml:") ||
      workflowContent.includes("Test ML Service");
    expect(hasMLTestJob).toBe(true);

    // Verify pytest is used
    const hasPytest = workflowContent.includes("pytest");
    expect(hasPytest).toBe(true);
  });

  test("Property 2.6: Build job depends on test and test-ml jobs", () => {
    fc.assert(
      fc.property(
        fc.record({
          checkJobDependencies: fc.constant(true),
        }),
        (scenario) => {
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Find the build job section
          const buildJobMatch = workflowContent.match(
            /build:[\s\S]*?(?=\n  \w+:|$)/
          );
          expect(buildJobMatch).toBeTruthy();

          if (buildJobMatch) {
            const buildJobContent = buildJobMatch[0];

            // Verify build job has needs: [test, test-ml]
            const hasTestDependency = buildJobContent.includes("test");
            const hasMLTestDependency = buildJobContent.includes("test-ml");

            expect(hasTestDependency).toBe(true);
            expect(hasMLTestDependency).toBe(true);
          }

          return true;
        }
      ),
      {
        numRuns: 5,
        verbose: true,
      }
    );
  });

  test("Property 2.7: Docker job depends on build job and runs only on main branch", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Find the docker job section
    const dockerJobMatch = workflowContent.match(
      /docker:[\s\S]*?(?=\n  \w+:|$)/
    );
    expect(dockerJobMatch).toBeTruthy();

    if (dockerJobMatch) {
      const dockerJobContent = dockerJobMatch[0];

      // Verify docker job depends on build
      expect(dockerJobContent).toContain("build");

      // Verify conditional execution on main branch
      const hasMainBranchCondition = dockerJobContent.includes(
        "github.ref == 'refs/heads/main'"
      );
      expect(hasMainBranchCondition).toBe(true);
    }
  });

  test("Property 2.8: Deploy job depends on docker job and runs only on main branch", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Find the deploy job section
    const deployJobMatch = workflowContent.match(
      /deploy:[\s\S]*?(?=\n  \w+:|$)/
    );
    expect(deployJobMatch).toBeTruthy();

    if (deployJobMatch) {
      const deployJobContent = deployJobMatch[0];

      // Verify deploy job depends on docker
      expect(deployJobContent).toContain("docker");

      // Verify conditional execution on main branch
      const hasMainBranchCondition = deployJobContent.includes(
        "github.ref == 'refs/heads/main'"
      );
      expect(hasMainBranchCondition).toBe(true);

      // Verify production environment
      const hasProductionEnv = deployJobContent.includes(
        "environment: production"
      );
      expect(hasProductionEnv).toBe(true);
    }
  });

  test("Property 2.9: Test job has required service containers (postgres, redis)", () => {
    fc.assert(
      fc.property(
        fc.record({
          checkServices: fc.constant(true),
        }),
        (scenario) => {
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Find the test job section
          const testJobMatch = workflowContent.match(
            /test:[\s\S]*?(?=\n  \w+:|$)/
          );
          expect(testJobMatch).toBeTruthy();

          if (testJobMatch) {
            const testJobContent = testJobMatch[0];

            // Verify postgres service
            expect(testJobContent).toContain("postgres");
            expect(testJobContent).toContain("postgres:15");

            // Verify redis service
            expect(testJobContent).toContain("redis");
            expect(testJobContent).toContain("redis:7");
          }

          return true;
        }
      ),
      {
        numRuns: 5,
        verbose: true,
      }
    );
  });

  test("Property 2.10: Test job has required environment variables", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Find the test job section
    const testJobMatch = workflowContent.match(/test:[\s\S]*?(?=\n  \w+:|$)/);
    expect(testJobMatch).toBeTruthy();

    if (testJobMatch) {
      const testJobContent = testJobMatch[0];

      // Verify required environment variables
      expect(testJobContent).toContain("DATABASE_URL");
      expect(testJobContent).toContain("REDIS_URL");
      expect(testJobContent).toContain("JWT_SECRET");
      expect(testJobContent).toContain("NODE_ENV");
    }
  });

  test("Property 2.11: Pipeline job sequence is preserved (lint -> test/test-ml -> build -> docker -> deploy)", () => {
    fc.assert(
      fc.property(
        fc.record({
          verifyJobSequence: fc.constant(true),
        }),
        (scenario) => {
          const workflowPath = path.join(
            process.cwd(),
            ".github/workflows/ci-cd.yml"
          );
          const workflowContent = fs.readFileSync(workflowPath, "utf-8");

          // Verify lint job exists
          expect(workflowContent).toContain("lint:");

          // Verify test job depends on lint
          const testJobMatch = workflowContent.match(
            /test:[\s\S]*?needs: lint/
          );
          expect(testJobMatch).toBeTruthy();

          // Verify test-ml job depends on lint
          const testMLJobMatch = workflowContent.match(
            /test-ml:[\s\S]*?needs: lint/
          );
          expect(testMLJobMatch).toBeTruthy();

          // Verify build job depends on both test jobs
          const buildJobMatch = workflowContent.match(
            /build:[\s\S]*?needs: \[test, test-ml\]/
          );
          expect(buildJobMatch).toBeTruthy();

          // Verify docker job depends on build
          const dockerJobMatch = workflowContent.match(
            /docker:[\s\S]*?needs: build/
          );
          expect(dockerJobMatch).toBeTruthy();

          // Verify deploy job depends on docker
          const deployJobMatch = workflowContent.match(
            /deploy:[\s\S]*?needs: docker/
          );
          expect(deployJobMatch).toBeTruthy();

          return true;
        }
      ),
      {
        numRuns: 5,
        verbose: true,
      }
    );
  });

  test("Property 2.12: Docker job builds both app and ML service images", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Find the docker job section
    const dockerJobMatch = workflowContent.match(
      /docker:[\s\S]*?(?=\n  \w+:|$)/
    );
    expect(dockerJobMatch).toBeTruthy();

    if (dockerJobMatch) {
      const dockerJobContent = dockerJobMatch[0];

      // Verify app image build
      expect(dockerJobContent).toContain("Build and push app image");
      expect(dockerJobContent).toContain("Dockerfile.app");

      // Verify ML service image build
      expect(dockerJobContent).toContain("Build and push ML service image");
      expect(dockerJobContent).toContain("ml-service/Dockerfile");
    }
  });

  test("Property 2.13: Deploy job includes health check and notifications", () => {
    const workflowPath = path.join(
      process.cwd(),
      ".github/workflows/ci-cd.yml"
    );
    const workflowContent = fs.readFileSync(workflowPath, "utf-8");

    // Find the deploy job section
    const deployJobMatch = workflowContent.match(
      /deploy:[\s\S]*?(?=\n  \w+:|$)/
    );
    expect(deployJobMatch).toBeTruthy();

    if (deployJobMatch) {
      const deployJobContent = deployJobMatch[0];

      // Verify health check exists
      expect(deployJobContent).toContain("Health check");
      expect(deployJobContent).toContain("curl");

      // Verify notification step exists
      expect(deployJobContent).toContain("Notify deployment status");
      expect(deployJobContent).toContain("action-slack");
    }
  });
});
