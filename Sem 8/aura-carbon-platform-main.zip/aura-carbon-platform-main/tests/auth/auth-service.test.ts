import { AuthService } from "@/services/auth";
import { createClient } from "@/lib/supabase/client";
import type {
  LoginCredentials,
  RegisterCredentials,
  ResetPasswordCredentials,
  UpdatePasswordCredentials,
} from "@/types/auth";

// Mock Supabase client
jest.mock("@/lib/supabase/client");

const mockSupabaseClient = {
  auth: {
    signInWithPassword: jest.fn(),
    signUp: jest.fn(),
    signOut: jest.fn(),
    resetPasswordForEmail: jest.fn(),
    updateUser: jest.fn(),
    signInWithOAuth: jest.fn(),
    getSession: jest.fn(),
    getUser: jest.fn(),
    onAuthStateChange: jest.fn(),
  },
};

const mockCreateClient = createClient as jest.MockedFunction<
  typeof createClient
>;
mockCreateClient.mockReturnValue(mockSupabaseClient as any);

describe("AuthService", () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService();
    jest.clearAllMocks();
  });

  describe("signIn", () => {
    const validCredentials: LoginCredentials = {
      email: "test@example.com",
      password: "password123",
    };

    it("should successfully sign in with valid credentials", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      const mockSession = { access_token: "token123", user: mockUser };

      mockSupabaseClient.auth.signInWithPassword.mockResolvedValue({
        data: { user: mockUser, session: mockSession },
        error: null,
      });

      const result = await authService.signIn(validCredentials);

      expect(mockSupabaseClient.auth.signInWithPassword).toHaveBeenCalledWith({
        email: validCredentials.email,
        password: validCredentials.password,
      });
      expect(result.data).toBeDefined();
      expect(result.error).toBeUndefined();
    });

    it("should return error for invalid credentials", async () => {
      const mockError = { message: "Invalid login credentials", status: 400 };

      mockSupabaseClient.auth.signInWithPassword.mockResolvedValue({
        data: { user: null, session: null },
        error: mockError,
      });

      const result = await authService.signIn(validCredentials);

      expect(result.error).toEqual({
        message: "Invalid login credentials",
        status: 400,
      });
      expect(result.data).toBeUndefined();
    });

    it("should handle network errors gracefully", async () => {
      mockSupabaseClient.auth.signInWithPassword.mockRejectedValue(
        new Error("Network error")
      );

      const result = await authService.signIn(validCredentials);

      expect(result.error).toEqual({
        message: "Network error",
      });
    });

    it("should handle unknown errors gracefully", async () => {
      mockSupabaseClient.auth.signInWithPassword.mockRejectedValue(
        "Unknown error"
      );

      const result = await authService.signIn(validCredentials);

      expect(result.error).toEqual({
        message: "An unexpected error occurred",
      });
    });
  });

  describe("signUp", () => {
    const validCredentials: RegisterCredentials = {
      email: "newuser@example.com",
      password: "Password123!",
      confirmPassword: "Password123!",
      fullName: "New User",
    };

    it("should successfully register a new user", async () => {
      const mockUser = { id: "456", email: "newuser@example.com" };

      mockSupabaseClient.auth.signUp.mockResolvedValue({
        data: { user: mockUser, session: null },
        error: null,
      });

      const result = await authService.signUp(validCredentials);

      expect(mockSupabaseClient.auth.signUp).toHaveBeenCalledWith({
        email: validCredentials.email,
        password: validCredentials.password,
        options: {
          data: {
            full_name: validCredentials.fullName,
          },
        },
      });
      expect(result.data).toBeDefined();
      expect(result.error).toBeUndefined();
    });

    it("should return error for duplicate email", async () => {
      const mockError = { message: "User already registered", status: 422 };

      mockSupabaseClient.auth.signUp.mockResolvedValue({
        data: { user: null, session: null },
        error: mockError,
      });

      const result = await authService.signUp(validCredentials);

      expect(result.error).toEqual({
        message: "User already registered",
        status: 422,
      });
    });

    it("should handle registration errors gracefully", async () => {
      mockSupabaseClient.auth.signUp.mockRejectedValue(
        new Error("Registration failed")
      );

      const result = await authService.signUp(validCredentials);

      expect(result.error).toEqual({
        message: "Registration failed",
      });
    });
  });

  describe("signOut", () => {
    it("should successfully sign out", async () => {
      mockSupabaseClient.auth.signOut.mockResolvedValue({ error: null });

      await expect(authService.signOut()).resolves.toBeUndefined();
      expect(mockSupabaseClient.auth.signOut).toHaveBeenCalled();
    });

    it("should throw error when sign out fails", async () => {
      const mockError = { message: "Sign out failed" };
      mockSupabaseClient.auth.signOut.mockResolvedValue({ error: mockError });

      await expect(authService.signOut()).rejects.toThrow("Sign out failed");
    });
  });

  describe("resetPassword", () => {
    const credentials: ResetPasswordCredentials = {
      email: "test@example.com",
    };

    // Mock window.location.origin
    beforeAll(() => {
      Object.defineProperty(window, "location", {
        value: {
          origin: "http://localhost:3000",
        },
        writable: true,
      });
    });

    it("should successfully send password reset email", async () => {
      mockSupabaseClient.auth.resetPasswordForEmail.mockResolvedValue({
        error: null,
      });

      const result = await authService.resetPassword(credentials);

      expect(
        mockSupabaseClient.auth.resetPasswordForEmail
      ).toHaveBeenCalledWith(credentials.email, {
        redirectTo: "http://localhost:3000/auth/reset-password",
      });
      expect(result.success).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should return error when reset fails", async () => {
      const mockError = { message: "Email not found", status: 404 };
      mockSupabaseClient.auth.resetPasswordForEmail.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.resetPassword(credentials);

      expect(result.error).toEqual({
        message: "Email not found",
        status: 404,
      });
      expect(result.success).toBeUndefined();
    });

    it("should handle reset password errors gracefully", async () => {
      mockSupabaseClient.auth.resetPasswordForEmail.mockRejectedValue(
        new Error("Network error")
      );

      const result = await authService.resetPassword(credentials);

      expect(result.error).toEqual({
        message: "Network error",
      });
    });
  });

  describe("updatePassword", () => {
    const credentials: UpdatePasswordCredentials = {
      password: "NewPassword123!",
      confirmPassword: "NewPassword123!",
    };

    it("should successfully update password", async () => {
      mockSupabaseClient.auth.updateUser.mockResolvedValue({
        data: { user: { id: "123" } },
        error: null,
      });

      const result = await authService.updatePassword(credentials);

      expect(mockSupabaseClient.auth.updateUser).toHaveBeenCalledWith({
        password: credentials.password,
      });
      expect(result.success).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should return error when update fails", async () => {
      const mockError = { message: "Password update failed", status: 400 };
      mockSupabaseClient.auth.updateUser.mockResolvedValue({
        data: { user: null },
        error: mockError,
      });

      const result = await authService.updatePassword(credentials);

      expect(result.error).toEqual({
        message: "Password update failed",
        status: 400,
      });
    });

    it("should handle update password errors gracefully", async () => {
      mockSupabaseClient.auth.updateUser.mockRejectedValue(
        new Error("Update failed")
      );

      const result = await authService.updatePassword(credentials);

      expect(result.error).toEqual({
        message: "Update failed",
      });
    });
  });

  describe("signInWithOAuth", () => {
    beforeAll(() => {
      Object.defineProperty(window, "location", {
        value: {
          origin: "http://localhost:3000",
        },
        writable: true,
      });
    });

    it("should successfully initiate Google OAuth", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("google");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "google",
        options: {
          redirectTo: "http://localhost:3000/auth/callback",
        },
      });
      expect(result.success).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should successfully initiate LinkedIn OAuth", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "linkedin_oidc",
        options: {
          redirectTo: "http://localhost:3000/auth/callback",
        },
      });
      expect(result.success).toBe(true);
    });

    it("should return error when OAuth fails", async () => {
      const mockError = { message: "OAuth provider error", status: 400 };
      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "OAuth provider error",
        status: 400,
      });
    });

    it("should handle OAuth errors gracefully", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockRejectedValue(
        new Error("OAuth failed")
      );

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "OAuth failed",
      });
    });
  });

  describe("getSession", () => {
    it("should successfully get current session", async () => {
      const mockSession = { access_token: "token123", user: { id: "123" } };
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const result = await authService.getSession();

      expect(result).toEqual(mockSession);
      expect(mockSupabaseClient.auth.getSession).toHaveBeenCalled();
    });

    it("should throw error when getting session fails", async () => {
      const mockError = { message: "Session error" };
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: mockError,
      });

      await expect(authService.getSession()).rejects.toThrow("Session error");
    });
  });

  describe("getUser", () => {
    it("should successfully get current user", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });

      const result = await authService.getUser();

      expect(result).toEqual(mockUser);
      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalled();
    });

    it("should throw error when getting user fails", async () => {
      const mockError = { message: "User error" };
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: mockError,
      });

      await expect(authService.getUser()).rejects.toThrow("User error");
    });
  });

  describe("onAuthStateChange", () => {
    it("should set up auth state change listener", () => {
      const mockCallback = jest.fn();
      const mockSubscription = { unsubscribe: jest.fn() };

      mockSupabaseClient.auth.onAuthStateChange.mockReturnValue({
        data: { subscription: mockSubscription },
      });

      const result = authService.onAuthStateChange(mockCallback);

      expect(mockSupabaseClient.auth.onAuthStateChange).toHaveBeenCalledWith(
        mockCallback
      );
      expect(result).toEqual({ data: { subscription: mockSubscription } });
    });
  });
});
