import { AuthService } from "@/services/auth";
import { createClient } from "@/lib/supabase/client";

// Mock Supabase client
jest.mock("@/lib/supabase/client");

const mockSupabaseClient = {
  auth: {
    signInWithOAuth: jest.fn(),
    onAuthStateChange: jest.fn(),
    getSession: jest.fn(),
    getUser: jest.fn(),
  },
};

const mockCreateClient = createClient as jest.MockedFunction<
  typeof createClient
>;
mockCreateClient.mockReturnValue(mockSupabaseClient as any);

describe("OAuth Integration Tests", () => {
  let authService: AuthService;

  beforeEach(() => {
    authService = new AuthService();
    jest.clearAllMocks();

    // Mock window.location.origin
    Object.defineProperty(window, "location", {
      value: {
        origin: "http://localhost:3000",
      },
      writable: true,
    });
  });

  describe("Google OAuth Integration", () => {
    it("should initiate Google OAuth flow with correct parameters", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("google");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "google",
        options: {
          redirectTo: "http://localhost:3000/auth/callback",
        },
      });
      expect(result.success).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should handle Google OAuth provider errors", async () => {
      const mockError = {
        message: "Google OAuth configuration error",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "Google OAuth configuration error",
        status: 400,
      });
      expect(result.success).toBeUndefined();
    });

    it("should handle Google OAuth network errors", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockRejectedValue(
        new Error("Network timeout during OAuth")
      );

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "Network timeout during OAuth",
      });
    });

    it("should handle Google OAuth popup blocked", async () => {
      const mockError = {
        message: "Popup blocked by browser",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "Popup blocked by browser",
        status: 400,
      });
    });

    it("should handle Google OAuth user cancellation", async () => {
      const mockError = {
        message: "User cancelled OAuth flow",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "User cancelled OAuth flow",
        status: 400,
      });
    });
  });

  describe("LinkedIn OAuth Integration", () => {
    it("should initiate LinkedIn OAuth flow with correct parameters", async () => {
      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "linkedin_oidc",
        options: {
          redirectTo: "http://localhost:3000/auth/callback",
        },
      });
      expect(result.success).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should handle LinkedIn OAuth provider errors", async () => {
      const mockError = {
        message: "LinkedIn OAuth configuration error",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(result.error).toEqual({
        message: "LinkedIn OAuth configuration error",
        status: 400,
      });
    });

    it("should handle LinkedIn OAuth scope errors", async () => {
      const mockError = {
        message: "Insufficient OAuth scope permissions",
        status: 403,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(result.error).toEqual({
        message: "Insufficient OAuth scope permissions",
        status: 403,
      });
    });

    it("should handle LinkedIn OAuth rate limiting", async () => {
      const mockError = {
        message: "OAuth rate limit exceeded",
        status: 429,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(result.error).toEqual({
        message: "OAuth rate limit exceeded",
        status: 429,
      });
    });
  });

  describe("OAuth Callback Handling", () => {
    it("should handle successful OAuth callback", async () => {
      const mockUser = {
        id: "123",
        email: "user@example.com",
        user_metadata: {
          full_name: "John Doe",
          avatar_url: "https://example.com/avatar.jpg",
          provider: "google",
        },
      };
      const mockSession = {
        access_token: "oauth_access_token",
        refresh_token: "oauth_refresh_token",
        user: mockUser,
      };

      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const session = await authService.getSession();

      expect(session).toEqual(mockSession);
      expect(session.user.user_metadata?.provider).toBe("google");
    });

    it("should handle OAuth callback with missing user data", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "No session found" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "No session found"
      );
    });

    it("should handle OAuth callback with expired state", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "OAuth state expired" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "OAuth state expired"
      );
    });
  });

  describe("OAuth State Management", () => {
    it("should handle OAuth state parameter validation", async () => {
      // Mock URL with state parameter
      const mockURL = new URL(
        "http://localhost:3000/auth/callback?state=valid_state&code=auth_code"
      );

      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: { access_token: "token", user: { id: "123" } } },
        error: null,
      });

      const session = await authService.getSession();
      expect(session).toBeDefined();
    });

    it("should handle invalid OAuth state parameter", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "Invalid OAuth state parameter" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "Invalid OAuth state parameter"
      );
    });

    it("should handle missing OAuth state parameter", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "Missing OAuth state parameter" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "Missing OAuth state parameter"
      );
    });
  });

  describe("OAuth Error Scenarios", () => {
    it("should handle OAuth provider maintenance", async () => {
      const mockError = {
        message: "OAuth provider temporarily unavailable",
        status: 503,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "OAuth provider temporarily unavailable",
        status: 503,
      });
    });

    it("should handle OAuth configuration errors", async () => {
      const mockError = {
        message: "Invalid OAuth client configuration",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(result.error).toEqual({
        message: "Invalid OAuth client configuration",
        status: 400,
      });
    });

    it("should handle OAuth redirect URI mismatch", async () => {
      const mockError = {
        message: "OAuth redirect URI mismatch",
        status: 400,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "OAuth redirect URI mismatch",
        status: 400,
      });
    });

    it("should handle OAuth token exchange errors", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "Failed to exchange OAuth code for token" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "Failed to exchange OAuth code for token"
      );
    });
  });

  describe("OAuth Security Tests", () => {
    it("should handle CSRF protection in OAuth flow", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "CSRF token mismatch" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "CSRF token mismatch"
      );
    });

    it("should handle OAuth code replay attacks", async () => {
      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: null },
        error: { message: "OAuth authorization code already used" },
      });

      await expect(authService.getSession()).rejects.toThrow(
        "OAuth authorization code already used"
      );
    });

    it("should handle OAuth scope manipulation", async () => {
      const mockError = {
        message: "Requested OAuth scope not authorized",
        status: 403,
      };

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: mockError,
      });

      const result = await authService.signInWithOAuth("google");

      expect(result.error).toEqual({
        message: "Requested OAuth scope not authorized",
        status: 403,
      });
    });
  });

  describe("OAuth User Data Handling", () => {
    it("should handle OAuth user with minimal profile data", async () => {
      const mockUser = {
        id: "123",
        email: "user@example.com",
        user_metadata: {
          provider: "google",
        },
      };
      const mockSession = {
        access_token: "token",
        user: mockUser,
      };

      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const session = await authService.getSession();
      expect(session.user.user_metadata?.full_name).toBeUndefined();
      expect(session.user.user_metadata?.avatar_url).toBeUndefined();
      expect(session.user.user_metadata?.provider).toBe("google");
    });

    it("should handle OAuth user with complete profile data", async () => {
      const mockUser = {
        id: "123",
        email: "user@example.com",
        user_metadata: {
          full_name: "John Doe",
          avatar_url: "https://example.com/avatar.jpg",
          provider: "linkedin_oidc",
        },
      };
      const mockSession = {
        access_token: "token",
        user: mockUser,
      };

      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const session = await authService.getSession();
      expect(session.user.user_metadata?.full_name).toBe("John Doe");
      expect(session.user.user_metadata?.avatar_url).toBe(
        "https://example.com/avatar.jpg"
      );
      expect(session.user.user_metadata?.provider).toBe("linkedin_oidc");
    });

    it("should handle OAuth user email verification status", async () => {
      const mockUser = {
        id: "123",
        email: "user@example.com",
        email_confirmed_at: new Date().toISOString(),
        user_metadata: {
          provider: "google",
        },
      };
      const mockSession = {
        access_token: "token",
        user: mockUser,
      };

      mockSupabaseClient.auth.getSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const session = await authService.getSession();
      expect(session.user.email_confirmed_at).toBeDefined();
    });
  });

  describe("OAuth Environment Handling", () => {
    it("should handle different redirect URLs for different environments", async () => {
      // Test production environment
      Object.defineProperty(window, "location", {
        value: {
          origin: "https://aura-platform.com",
        },
        writable: true,
      });

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("google");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "google",
        options: {
          redirectTo: "https://aura-platform.com/auth/callback",
        },
      });
    });

    it("should handle staging environment redirect URLs", async () => {
      Object.defineProperty(window, "location", {
        value: {
          origin: "https://staging.aura-platform.com",
        },
        writable: true,
      });

      mockSupabaseClient.auth.signInWithOAuth.mockResolvedValue({
        error: null,
      });

      const result = await authService.signInWithOAuth("linkedin_oidc");

      expect(mockSupabaseClient.auth.signInWithOAuth).toHaveBeenCalledWith({
        provider: "linkedin_oidc",
        options: {
          redirectTo: "https://staging.aura-platform.com/auth/callback",
        },
      });
    });
  });
});
