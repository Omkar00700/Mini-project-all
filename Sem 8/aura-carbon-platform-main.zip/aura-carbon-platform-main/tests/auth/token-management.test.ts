import {
  refreshAccessToken,
  validateToken,
  getTokenExpiry,
  isTokenExpired,
  shouldRefreshToken,
} from "@/lib/auth/tokens";
import { createClient } from "@/lib/supabase/server";

// Mock Supabase server client
jest.mock("@/lib/supabase/server");

const mockSupabaseClient = {
  auth: {
    refreshSession: jest.fn(),
    getUser: jest.fn(),
  },
};

const mockCreateClient = createClient as jest.MockedFunction<
  typeof createClient
>;
mockCreateClient.mockReturnValue(mockSupabaseClient as any);

describe("Token Management", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("refreshAccessToken", () => {
    it("should successfully refresh access token", async () => {
      const mockSession = {
        access_token: "new_token",
        refresh_token: "refresh_token",
        user: { id: "123" },
      };

      mockSupabaseClient.auth.refreshSession.mockResolvedValue({
        data: { session: mockSession },
        error: null,
      });

      const result = await refreshAccessToken();

      expect(result.success).toBe(true);
      expect(result.session).toEqual(mockSession);
      expect(result.error).toBeUndefined();
      expect(mockSupabaseClient.auth.refreshSession).toHaveBeenCalled();
    });

    it("should return error when refresh fails", async () => {
      const mockError = { message: "Refresh token expired" };

      mockSupabaseClient.auth.refreshSession.mockResolvedValue({
        data: { session: null },
        error: mockError,
      });

      const result = await refreshAccessToken();

      expect(result.success).toBe(false);
      expect(result.error).toBe("Refresh token expired");
      expect(result.session).toBeUndefined();
    });

    it("should handle refresh errors gracefully", async () => {
      mockSupabaseClient.auth.refreshSession.mockRejectedValue(
        new Error("Network error")
      );

      const result = await refreshAccessToken();

      expect(result.success).toBe(false);
      expect(result.error).toBe("Network error");
    });

    it("should handle unknown errors gracefully", async () => {
      mockSupabaseClient.auth.refreshSession.mockRejectedValue("Unknown error");

      const result = await refreshAccessToken();

      expect(result.success).toBe(false);
      expect(result.error).toBe("Unknown error occurred");
    });
  });

  describe("validateToken", () => {
    const validToken = "valid.jwt.token";

    it("should return true for valid token", async () => {
      const mockUser = { id: "123", email: "test@example.com" };

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });

      const result = await validateToken(validToken);

      expect(result).toBe(true);
      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalledWith(validToken);
    });

    it("should return false for invalid token", async () => {
      const mockError = { message: "Invalid token" };

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: mockError,
      });

      const result = await validateToken("invalid.token");

      expect(result).toBe(false);
    });

    it("should return false when user is null", async () => {
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: null,
      });

      const result = await validateToken(validToken);

      expect(result).toBe(false);
    });

    it("should handle validation errors gracefully", async () => {
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Validation error")
      );

      const result = await validateToken(validToken);

      expect(result).toBe(false);
    });
  });

  describe("getTokenExpiry", () => {
    it("should extract expiry from valid JWT token", () => {
      // Create a mock JWT token with expiry in 1 hour
      const futureTimestamp = Math.floor(Date.now() / 1000) + 3600;
      const payload = { exp: futureTimestamp, sub: "123" };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = getTokenExpiry(mockToken);

      expect(result).toBeInstanceOf(Date);
      expect(result?.getTime()).toBe(futureTimestamp * 1000);
    });

    it("should return null for invalid token format", () => {
      const invalidToken = "invalid.token";

      const result = getTokenExpiry(invalidToken);

      expect(result).toBeNull();
    });

    it("should return null for token without exp claim", () => {
      const payload = { sub: "123" }; // No exp claim
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = getTokenExpiry(mockToken);

      expect(result).toBeNull();
    });

    it("should handle malformed payload gracefully", () => {
      const mockToken = "header.invalid_base64.signature";

      const result = getTokenExpiry(mockToken);

      expect(result).toBeNull();
    });

    it("should handle non-JSON payload gracefully", () => {
      const encodedPayload = btoa("not json");
      const mockToken = `header.${encodedPayload}.signature`;

      const result = getTokenExpiry(mockToken);

      expect(result).toBeNull();
    });
  });

  describe("isTokenExpired", () => {
    it("should return false for non-expired token", () => {
      // Create token that expires in 1 hour
      const futureTimestamp = Math.floor(Date.now() / 1000) + 3600;
      const payload = { exp: futureTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = isTokenExpired(mockToken);

      expect(result).toBe(false);
    });

    it("should return true for expired token", () => {
      // Create token that expired 1 hour ago
      const pastTimestamp = Math.floor(Date.now() / 1000) - 3600;
      const payload = { exp: pastTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = isTokenExpired(mockToken);

      expect(result).toBe(true);
    });

    it("should return true for token without expiry", () => {
      const result = isTokenExpired("invalid.token");

      expect(result).toBe(true);
    });

    it("should return true for token expiring exactly now", () => {
      const nowTimestamp = Math.floor(Date.now() / 1000);
      const payload = { exp: nowTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = isTokenExpired(mockToken);

      expect(result).toBe(true);
    });
  });

  describe("shouldRefreshToken", () => {
    it("should return false for token with plenty of time left", () => {
      // Create token that expires in 1 hour
      const futureTimestamp = Math.floor(Date.now() / 1000) + 3600;
      const payload = { exp: futureTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = shouldRefreshToken(mockToken, 5); // 5 minute buffer

      expect(result).toBe(false);
    });

    it("should return true for token expiring within buffer time", () => {
      // Create token that expires in 2 minutes
      const soonTimestamp = Math.floor(Date.now() / 1000) + 120;
      const payload = { exp: soonTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = shouldRefreshToken(mockToken, 5); // 5 minute buffer

      expect(result).toBe(true);
    });

    it("should return true for expired token", () => {
      // Create token that expired 1 hour ago
      const pastTimestamp = Math.floor(Date.now() / 1000) - 3600;
      const payload = { exp: pastTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = shouldRefreshToken(mockToken);

      expect(result).toBe(true);
    });

    it("should return true for invalid token", () => {
      const result = shouldRefreshToken("invalid.token");

      expect(result).toBe(true);
    });

    it("should use default buffer of 5 minutes", () => {
      // Create token that expires in 3 minutes
      const soonTimestamp = Math.floor(Date.now() / 1000) + 180;
      const payload = { exp: soonTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      const result = shouldRefreshToken(mockToken); // No buffer specified

      expect(result).toBe(true);
    });

    it("should handle custom buffer times", () => {
      // Create token that expires in 8 minutes
      const futureTimestamp = Math.floor(Date.now() / 1000) + 480;
      const payload = { exp: futureTimestamp };
      const encodedPayload = btoa(JSON.stringify(payload));
      const mockToken = `header.${encodedPayload}.signature`;

      // Should not refresh with 5 minute buffer
      expect(shouldRefreshToken(mockToken, 5)).toBe(false);

      // Should refresh with 10 minute buffer
      expect(shouldRefreshToken(mockToken, 10)).toBe(true);
    });
  });
});
