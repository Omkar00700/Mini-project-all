# Authentication System Tests

This directory contains comprehensive unit tests for the Aura platform's authentication system, covering all authentication flows, OAuth integration, token handling, and security features.

## Test Coverage

### Authentication Service Tests (`auth-service.test.ts`)

- ✅ **Sign In Flow**
  - Successful authentication with valid credentials
  - Error handling for invalid credentials
  - Network error handling
  - Unknown error handling
- ✅ **Sign Up Flow**
  - Successful user registration
  - Duplicate email error handling
  - Registration error handling
- ✅ **Sign Out Flow**
  - Successful sign out
  - Sign out error handling
- ✅ **Password Reset Flow**
  - Successful password reset email sending
  - Email not found error handling
  - Network error handling
- ✅ **Password Update Flow**
  - Successful password updates
  - Update failure error handling
- ✅ **OAuth Integration**
  - Google OAuth initiation
  - LinkedIn OAuth initiation
  - OAuth error handling
- ✅ **Session Management**
  - Session retrieval
  - User retrieval
  - Auth state change listeners

### Token Management Tests (`token-management.test.ts`)

- ✅ **Token Refresh**
  - Successful access token refresh
  - Refresh token expiry handling
  - Network error handling
  - Unknown error handling
- ✅ **Token Validation**
  - Valid token validation
  - Invalid token handling
  - Null user handling
  - Validation error handling
- ✅ **Token Expiry Parsing**
  - Valid JWT token expiry extraction
  - Invalid token format handling
  - Missing exp claim handling
  - Malformed payload handling
- ✅ **Token Expiry Checking**
  - Non-expired token detection
  - Expired token detection
  - Token without expiry handling
  - Edge case timing handling
- ✅ **Token Refresh Decision**
  - Tokens with sufficient time remaining
  - Tokens expiring within buffer time
  - Already expired tokens
  - Invalid tokens
  - Custom buffer time handling

### Middleware Tests (`middleware.test.ts`)

- ✅ **withAuth Middleware**
  - Authenticated user handling
  - Unauthenticated request rejection (401)
  - Auth error handling
  - Unexpected error handling (500)
  - Handler error handling
- ✅ **withOptionalAuth Middleware**
  - Authenticated user handling
  - Unauthenticated user handling (null user)
  - Auth error handling with null user
  - Unexpected error handling (500)
  - Handler error handling
- ✅ **Route Creators**
  - createAuthenticatedRoute functionality
  - createOptionalAuthRoute functionality
- ✅ **Security Edge Cases**
  - Malformed auth headers
  - Expired tokens
  - Invalid JWT signatures
  - Network timeouts
  - Database connection errors

### Validation Tests (`validation.test.ts`)

- ✅ **Login Schema Validation**
  - Valid login data acceptance
  - Empty email rejection
  - Invalid email format rejection
  - Empty password rejection
  - Short password rejection
  - Multiple validation errors
- ✅ **Registration Schema Validation**
  - Valid registration data acceptance
  - Full name validation (empty, too short, too long)
  - Password complexity requirements
  - Password confirmation matching
  - Special character validation
- ✅ **Reset Password Schema Validation**
  - Valid email acceptance
  - Empty email rejection
  - Invalid email format rejection
  - Various valid email formats
- ✅ **Update Password Schema Validation**
  - Valid password update data
  - Password complexity enforcement
  - Password confirmation matching
- ✅ **Security Edge Cases**
  - Unicode characters in names
  - Email plus addressing
  - Email subdomains
  - SQL injection attempt handling
  - XSS attempt handling
  - Very long passwords
  - All allowed special characters

### OAuth Integration Tests (`oauth-integration.test.ts`)

- ✅ **Google OAuth**
  - OAuth flow initiation with correct parameters
  - Provider error handling
  - Network error handling
  - Popup blocked handling
  - User cancellation handling
- ✅ **LinkedIn OAuth**
  - OAuth flow initiation with correct parameters
  - Provider error handling
  - Scope error handling
  - Rate limiting handling
- ✅ **OAuth Callback Handling**
  - Successful callback processing
  - Missing user data handling
  - Expired state handling
- ✅ **OAuth State Management**
  - State parameter validation
  - Invalid state parameter handling
  - Missing state parameter handling
- ✅ **OAuth Error Scenarios**
  - Provider maintenance handling
  - Configuration error handling
  - Redirect URI mismatch handling
  - Token exchange error handling
- ✅ **OAuth Security**
  - CSRF protection
  - Code replay attack prevention
  - Scope manipulation handling
- ✅ **OAuth User Data**
  - Minimal profile data handling
  - Complete profile data handling
  - Email verification status handling
- ✅ **Environment Handling**
  - Different redirect URLs for environments
  - Production environment handling
  - Staging environment handling

### Security Edge Cases Tests (`security-edge-cases.test.ts`)

- ✅ **Brute Force Protection**
  - Rate limiting on login attempts
  - Account lockout after failed attempts
  - Progressive delays in login attempts
- ✅ **Token Security**
  - Malformed JWT token handling
  - Missing JWT claims handling
  - Invalid exp claim handling
  - Negative exp claim handling
  - Very large exp claim handling
- ✅ **Session Hijacking Protection**
  - Invalid user session validation
  - Concurrent session invalidation
  - Session timeout handling
- ✅ **Input Validation Security**
  - SQL injection attempt handling
  - XSS attempt handling
  - Extremely long input strings
  - Null and undefined inputs
- ✅ **Network Security**
  - Man-in-the-middle attack simulation
  - DNS spoofing attempt handling
  - Network timeout attack handling
- ✅ **Authorization Bypass Attempts**
  - Middleware authentication bypass attempts
  - Forged authorization header handling
  - Privilege escalation attempt handling
- ✅ **Password Security Edge Cases**
  - Special character only passwords
  - Unicode character passwords
  - Emoji character passwords
  - Extremely long passwords
- ✅ **Race Condition Security**
  - Concurrent login attempt handling
  - Concurrent token refresh handling
- ✅ **Memory and Resource Security**
  - Memory exhaustion attempt handling
  - Resource exhaustion through rapid requests

## Test Infrastructure

### Setup (`setup.ts`)

- Global test environment configuration
- Browser API mocking (TextEncoder, TextDecoder)
- Window object mocking for browser-specific code
- JWT token parsing utilities (btoa, atob)
- Console method mocking for cleaner test output
- Mock cleanup between tests

### Configuration

- Jest configuration integration
- TypeScript support
- Module path mapping
- Test environment setup
- Coverage collection

## Running Tests

```bash
# Run all authentication tests
npm run test:auth

# Run specific test file
npx jest tests/auth/auth-service.test.ts

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch
```

## Test Categories

### Functional Testing

- ✅ Authentication flow testing
- ✅ OAuth integration testing
- ✅ Token management testing
- ✅ Session management testing
- ✅ Password operations testing

### Security Testing

- ✅ Input validation testing
- ✅ Token security testing
- ✅ Session security testing
- ✅ Brute force protection testing
- ✅ Injection attack prevention testing
- ✅ Authorization bypass prevention testing

### Error Handling Testing

- ✅ Network error handling
- ✅ Service error handling
- ✅ Validation error handling
- ✅ Authentication error handling
- ✅ Authorization error handling

### Edge Case Testing

- ✅ Malformed input handling
- ✅ Boundary condition testing
- ✅ Race condition testing
- ✅ Resource exhaustion testing
- ✅ Environment variation testing

## Coverage Summary

- **Total Test Suites**: 6
- **Total Tests**: 156
- **Authentication Flows**: Sign in, Sign up, Sign out, Password reset, Password update
- **OAuth Providers**: Google, LinkedIn
- **Security Features**: Rate limiting, Token validation, Session management, Input validation
- **Edge Cases**: Malformed data, Network errors, Security attacks, Race conditions

## Requirements Coverage

This test suite covers all requirements specified in task 3.5:

### ✅ Authentication Flows (Requirements 1.1, 1.3)

- Email/password authentication
- OAuth authentication (Google, LinkedIn)
- Registration and login flows
- Password reset and update flows
- Session management and state changes

### ✅ OAuth Integration and Token Handling (Requirements 1.1, 1.3)

- OAuth provider integration
- Token refresh mechanisms
- Token validation and expiry
- OAuth callback handling
- OAuth error scenarios

### ✅ Security Features and Edge Cases (Requirements 1.5, 1.6)

- Two-factor authentication support
- Password security requirements
- Brute force protection
- Session hijacking prevention
- Input validation security
- Network security
- Authorization bypass prevention

All tests pass successfully and provide comprehensive coverage of the authentication system functionality required for the Aura Carbon Platform, ensuring robust security and reliable authentication flows.
