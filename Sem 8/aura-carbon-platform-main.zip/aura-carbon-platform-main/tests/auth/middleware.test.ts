import { NextRequest, NextResponse } from "next/server";
import {
  withAuth,
  withOptionalAuth,
  createAuthenticatedRoute,
  createOptionalAuthRoute,
} from "@/lib/auth/middleware";
import { createClient } from "@/lib/supabase/server";

// Mock Supabase server client
jest.mock("@/lib/supabase/server");

const mockSupabaseClient = {
  auth: {
    getUser: jest.fn(),
  },
};

const mockCreateClient = createClient as jest.MockedFunction<
  typeof createClient
>;
mockCreateClient.mockReturnValue(mockSupabaseClient as any);

// Mock NextResponse
jest.mock("next/server", () => ({
  NextRequest: jest.fn(),
  NextResponse: {
    json: jest.fn(),
  },
}));

const mockNextResponse = NextResponse as jest.Mocked<typeof NextResponse>;

describe("Auth Middleware", () => {
  let mockRequest: NextRequest;
  let mockHandler: jest.MockedFunction<
    (request: NextRequest, user: any) => Promise<NextResponse>
  >;
  let mockOptionalHandler: jest.MockedFunction<
    (request: NextRequest, user: any | null) => Promise<NextResponse>
  >;

  beforeEach(() => {
    jest.clearAllMocks();
    mockRequest = new NextRequest("http://localhost:3000/api/test");
    mockHandler = jest.fn();
    mockOptionalHandler = jest.fn();

    // Mock NextResponse.json to return a proper response object
    mockNextResponse.json.mockImplementation(
      (body, init) =>
        ({
          json: () => Promise.resolve(body),
          status: init?.status || 200,
        }) as any
    );
  });

  describe("withAuth", () => {
    it("should call handler with authenticated user", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockHandler.mockResolvedValue(mockResponse);

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalled();
      expect(mockHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(result).toBe(mockResponse);
    });

    it("should return 401 when user is not authenticated", async () => {
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: null,
      });

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockHandler).not.toHaveBeenCalled();
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Unauthorized" },
        { status: 401 }
      );
    });

    it("should return 401 when auth error occurs", async () => {
      const mockError = { message: "Invalid token" };
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: mockError,
      });

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockHandler).not.toHaveBeenCalled();
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Unauthorized" },
        { status: 401 }
      );
    });

    it("should return 500 when unexpected error occurs", async () => {
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Database connection failed")
      );

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockHandler).not.toHaveBeenCalled();
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });

    it("should handle handler errors gracefully", async () => {
      const mockUser = { id: "123", email: "test@example.com" };

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockHandler.mockRejectedValue(new Error("Handler error"));

      // The middleware catches handler errors and returns 500
      const result = await withAuth(mockRequest, mockHandler);

      expect(mockHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });
  });

  describe("withOptionalAuth", () => {
    it("should call handler with authenticated user when user exists", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockOptionalHandler.mockResolvedValue(mockResponse);

      const result = await withOptionalAuth(mockRequest, mockOptionalHandler);

      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalled();
      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(result).toBe(mockResponse);
    });

    it("should call handler with null user when not authenticated", async () => {
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: null,
      });
      mockOptionalHandler.mockResolvedValue(mockResponse);

      const result = await withOptionalAuth(mockRequest, mockOptionalHandler);

      expect(mockSupabaseClient.auth.getUser).toHaveBeenCalled();
      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, null);
      expect(result).toBe(mockResponse);
    });

    it("should call handler with null user when auth error occurs", async () => {
      const mockError = { message: "Invalid token" };
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: mockError,
      });
      mockOptionalHandler.mockResolvedValue(mockResponse);

      const result = await withOptionalAuth(mockRequest, mockOptionalHandler);

      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, null);
      expect(result).toBe(mockResponse);
    });

    it("should return 500 when unexpected error occurs", async () => {
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Database connection failed")
      );

      const result = await withOptionalAuth(mockRequest, mockOptionalHandler);

      expect(mockOptionalHandler).not.toHaveBeenCalled();
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });

    it("should handle handler errors gracefully", async () => {
      const mockUser = { id: "123", email: "test@example.com" };

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockOptionalHandler.mockRejectedValue(new Error("Handler error"));

      // The middleware catches handler errors and returns 500
      const result = await withOptionalAuth(mockRequest, mockOptionalHandler);

      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });
  });

  describe("createAuthenticatedRoute", () => {
    it("should create a route that requires authentication", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockHandler.mockResolvedValue(mockResponse);

      const authenticatedRoute = createAuthenticatedRoute(mockHandler);
      const result = await authenticatedRoute(mockRequest);

      expect(mockHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(result).toBe(mockResponse);
    });

    it("should return 401 for unauthenticated requests", async () => {
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: null,
      });

      const authenticatedRoute = createAuthenticatedRoute(mockHandler);
      const result = await authenticatedRoute(mockRequest);

      expect(mockHandler).not.toHaveBeenCalled();
      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Unauthorized" },
        { status: 401 }
      );
    });
  });

  describe("createOptionalAuthRoute", () => {
    it("should create a route that works with or without authentication", async () => {
      const mockUser = { id: "123", email: "test@example.com" };
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: mockUser },
        error: null,
      });
      mockOptionalHandler.mockResolvedValue(mockResponse);

      const optionalAuthRoute = createOptionalAuthRoute(mockOptionalHandler);
      const result = await optionalAuthRoute(mockRequest);

      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, mockUser);
      expect(result).toBe(mockResponse);
    });

    it("should work without authentication", async () => {
      const mockResponse = { status: 200 } as NextResponse;

      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: null,
      });
      mockOptionalHandler.mockResolvedValue(mockResponse);

      const optionalAuthRoute = createOptionalAuthRoute(mockOptionalHandler);
      const result = await optionalAuthRoute(mockRequest);

      expect(mockOptionalHandler).toHaveBeenCalledWith(mockRequest, null);
      expect(result).toBe(mockResponse);
    });
  });

  describe("Security Edge Cases", () => {
    it("should handle malformed auth headers", async () => {
      // Simulate malformed authorization header scenario
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Malformed authorization header")
      );

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });

    it("should handle expired tokens gracefully", async () => {
      const expiredTokenError = { message: "JWT expired" };
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: expiredTokenError,
      });

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Unauthorized" },
        { status: 401 }
      );
    });

    it("should handle invalid JWT signatures", async () => {
      const invalidSignatureError = { message: "Invalid JWT signature" };
      mockSupabaseClient.auth.getUser.mockResolvedValue({
        data: { user: null },
        error: invalidSignatureError,
      });

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Unauthorized" },
        { status: 401 }
      );
    });

    it("should handle network timeouts", async () => {
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Network timeout")
      );

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });

    it("should handle database connection errors", async () => {
      mockSupabaseClient.auth.getUser.mockRejectedValue(
        new Error("Database connection failed")
      );

      const result = await withAuth(mockRequest, mockHandler);

      expect(mockNextResponse.json).toHaveBeenCalledWith(
        { error: "Internal server error" },
        { status: 500 }
      );
    });
  });
});
