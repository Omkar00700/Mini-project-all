import {
  loginSchema,
  registerSchema,
  resetPasswordSchema,
  updatePasswordSchema,
} from "@/lib/validations/auth";
import { ZodError } from "zod";

describe("Auth Validation Schemas", () => {
  describe("loginSchema", () => {
    it("should validate correct login data", () => {
      const validData = {
        email: "test@example.com",
        password: "password123",
      };

      const result = loginSchema.parse(validData);
      expect(result).toEqual(validData);
    });

    it("should reject empty email", () => {
      const invalidData = {
        email: "",
        password: "password123",
      };

      expect(() => loginSchema.parse(invalidData)).toThrow(ZodError);

      try {
        loginSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Email is required");
        expect(zodError.errors[0].path).toEqual(["email"]);
      }
    });

    it("should reject invalid email format", () => {
      const invalidData = {
        email: "invalid-email",
        password: "password123",
      };

      expect(() => loginSchema.parse(invalidData)).toThrow(ZodError);

      try {
        loginSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Please enter a valid email address"
        );
      }
    });

    it("should reject empty password", () => {
      const invalidData = {
        email: "test@example.com",
        password: "",
      };

      expect(() => loginSchema.parse(invalidData)).toThrow(ZodError);

      try {
        loginSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Password is required");
      }
    });

    it("should reject password shorter than 8 characters", () => {
      const invalidData = {
        email: "test@example.com",
        password: "1234567",
      };

      expect(() => loginSchema.parse(invalidData)).toThrow(ZodError);

      try {
        loginSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Password must be at least 8 characters"
        );
      }
    });

    it("should handle multiple validation errors", () => {
      const invalidData = {
        email: "invalid-email",
        password: "123",
      };

      try {
        loginSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors).toHaveLength(2);
        expect(
          zodError.errors.some((e) => e.message.includes("valid email"))
        ).toBe(true);
        expect(
          zodError.errors.some((e) => e.message.includes("8 characters"))
        ).toBe(true);
      }
    });
  });

  describe("registerSchema", () => {
    it("should validate correct registration data", () => {
      const validData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      const result = registerSchema.parse(validData);
      expect(result).toEqual(validData);
    });

    it("should reject empty full name", () => {
      const invalidData = {
        fullName: "",
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Full name is required");
      }
    });

    it("should reject full name shorter than 2 characters", () => {
      const invalidData = {
        fullName: "J",
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Full name must be at least 2 characters"
        );
      }
    });

    it("should reject full name longer than 100 characters", () => {
      const longName = "a".repeat(101);
      const invalidData = {
        fullName: longName,
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Full name must be less than 100 characters"
        );
      }
    });

    it("should reject weak password without uppercase", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "password123!",
        confirmPassword: "password123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toContain("uppercase letter");
      }
    });

    it("should reject weak password without lowercase", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "PASSWORD123!",
        confirmPassword: "PASSWORD123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toContain("lowercase letter");
      }
    });

    it("should reject weak password without number", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "Password!",
        confirmPassword: "Password!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toContain("number");
      }
    });

    it("should reject weak password without special character", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "Password123",
        confirmPassword: "Password123",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toContain("special character");
      }
    });

    it("should reject mismatched passwords", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "DifferentPassword123!",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Passwords do not match");
        expect(zodError.errors[0].path).toEqual(["confirmPassword"]);
      }
    });

    it("should reject empty confirm password", () => {
      const invalidData = {
        fullName: "John Doe",
        email: "john@example.com",
        password: "Password123!",
        confirmPassword: "",
      };

      expect(() => registerSchema.parse(invalidData)).toThrow(ZodError);

      try {
        registerSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(
          zodError.errors.some(
            (e) => e.message === "Please confirm your password"
          )
        ).toBe(true);
      }
    });

    it("should validate various special characters", () => {
      const specialChars = ["!", "@", "$", "%", "*", "?", "&"]; // Only chars allowed by regex

      specialChars.forEach((char) => {
        const validData = {
          fullName: "John Doe",
          email: "john@example.com",
          password: `Password123${char}`,
          confirmPassword: `Password123${char}`,
        };

        expect(() => registerSchema.parse(validData)).not.toThrow();
      });
    });
  });

  describe("resetPasswordSchema", () => {
    it("should validate correct reset password data", () => {
      const validData = {
        email: "test@example.com",
      };

      const result = resetPasswordSchema.parse(validData);
      expect(result).toEqual(validData);
    });

    it("should reject empty email", () => {
      const invalidData = {
        email: "",
      };

      expect(() => resetPasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        resetPasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Email is required");
      }
    });

    it("should reject invalid email format", () => {
      const invalidData = {
        email: "invalid-email",
      };

      expect(() => resetPasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        resetPasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Please enter a valid email address"
        );
      }
    });

    it("should accept various valid email formats", () => {
      const validEmails = [
        "test@example.com",
        "user.name@domain.co.uk",
        "user+tag@example.org",
        "user123@test-domain.com",
      ];

      validEmails.forEach((email) => {
        const validData = { email };
        expect(() => resetPasswordSchema.parse(validData)).not.toThrow();
      });
    });
  });

  describe("updatePasswordSchema", () => {
    it("should validate correct update password data", () => {
      const validData = {
        password: "NewPassword123!",
        confirmPassword: "NewPassword123!",
      };

      const result = updatePasswordSchema.parse(validData);
      expect(result).toEqual(validData);
    });

    it("should reject empty password", () => {
      const invalidData = {
        password: "",
        confirmPassword: "NewPassword123!",
      };

      expect(() => updatePasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        updatePasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Password is required");
      }
    });

    it("should reject password shorter than 8 characters", () => {
      const invalidData = {
        password: "Pass1!",
        confirmPassword: "Pass1!",
      };

      expect(() => updatePasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        updatePasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe(
          "Password must be at least 8 characters"
        );
      }
    });

    it("should enforce same password complexity as registration", () => {
      const weakPasswords = [
        "password123!", // No uppercase
        "PASSWORD123!", // No lowercase
        "Password!", // No number
        "Password123", // No special character
      ];

      weakPasswords.forEach((password) => {
        const invalidData = {
          password,
          confirmPassword: password,
        };

        expect(() => updatePasswordSchema.parse(invalidData)).toThrow(ZodError);
      });
    });

    it("should reject mismatched passwords", () => {
      const invalidData = {
        password: "NewPassword123!",
        confirmPassword: "DifferentPassword123!",
      };

      expect(() => updatePasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        updatePasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(zodError.errors[0].message).toBe("Passwords do not match");
        expect(zodError.errors[0].path).toEqual(["confirmPassword"]);
      }
    });

    it("should reject empty confirm password", () => {
      const invalidData = {
        password: "NewPassword123!",
        confirmPassword: "",
      };

      expect(() => updatePasswordSchema.parse(invalidData)).toThrow(ZodError);

      try {
        updatePasswordSchema.parse(invalidData);
      } catch (error) {
        const zodError = error as ZodError;
        expect(
          zodError.errors.some(
            (e) => e.message === "Please confirm your password"
          )
        ).toBe(true);
      }
    });
  });

  describe("Edge Cases and Security", () => {
    it("should handle unicode characters in names", () => {
      const validData = {
        fullName: "José María García-López",
        email: "jose@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      expect(() => registerSchema.parse(validData)).not.toThrow();
    });

    it("should handle email with plus addressing", () => {
      const validData = {
        email: "user+test@example.com",
      };

      expect(() => resetPasswordSchema.parse(validData)).not.toThrow();
    });

    it("should handle email with subdomain", () => {
      const validData = {
        email: "user@mail.example.com",
      };

      expect(() => resetPasswordSchema.parse(validData)).not.toThrow();
    });

    it("should reject SQL injection attempts in email", () => {
      const maliciousData = {
        email: "'; DROP TABLE users; --",
      };

      expect(() => resetPasswordSchema.parse(maliciousData)).toThrow(ZodError);
    });

    it("should reject XSS attempts in full name", () => {
      const maliciousData = {
        fullName: '<script>alert("xss")</script>',
        email: "test@example.com",
        password: "Password123!",
        confirmPassword: "Password123!",
      };

      // Should not throw validation error (validation doesn't sanitize)
      // but the name should be properly escaped when displayed
      expect(() => registerSchema.parse(maliciousData)).not.toThrow();
    });

    it("should handle very long passwords", () => {
      const longPassword = "A1!" + "a".repeat(1000);
      const validData = {
        password: longPassword,
        confirmPassword: longPassword,
      };

      expect(() => updatePasswordSchema.parse(validData)).not.toThrow();
    });

    it("should handle passwords with all allowed special characters", () => {
      const password = "Password123@$!%*?&";
      const validData = {
        password,
        confirmPassword: password,
      };

      expect(() => updatePasswordSchema.parse(validData)).not.toThrow();
    });
  });
});
