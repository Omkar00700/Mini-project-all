// Authentication test setup
import { TextEncoder, TextDecoder } from "util";

// Mock global objects for browser APIs
global.TextEncoder = TextEncoder as any;
global.TextDecoder = TextDecoder as any;

// Mock window object for browser-specific code
Object.defineProperty(global, "window", {
  value: {
    location: {
      origin: "http://localhost:3000",
    },
  },
  writable: true,
});

// Mock btoa and atob for JWT token parsing tests
global.btoa = (str: string) => Buffer.from(str, "binary").toString("base64");
global.atob = (str: string) => Buffer.from(str, "base64").toString("binary");

// Mock console methods to reduce test noise
const originalConsoleError = console.error;
const originalConsoleWarn = console.warn;

beforeAll(() => {
  console.error = jest.fn();
  console.warn = jest.fn();
});

afterAll(() => {
  console.error = originalConsoleError;
  console.warn = originalConsoleWarn;
});

// Clean up mocks between tests
beforeEach(() => {
  jest.clearAllMocks();
});
